package com.mikael8367.nexustech.digitalmine;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Bootstrap;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.NibbleArray;

/** Exercises all registry states and metadata storage; world checks use a simulated world. */
public final class DigitalMineMetadataRegressionTest {
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }

    private static void allRegistryStates() {
        for (Block block : DigitalMineRegistry.BLOCKS) {
            Set<Integer> used = new HashSet<>();
            int expected = block == DigitalMineRegistry.CASING ? 2 : 8;
            check(block.getBlockState().getValidStates().size() == expected, "unexpected states: " + block);
            NibbleArray saved = new NibbleArray();
            int index = 0;
            for (IBlockState state : block.getBlockState().getValidStates()) {
                int meta = block.getMetaFromState(state);
                check(meta >= 0 && meta < 16, "metadata exceeds 4 bits: " + state);
                check(used.add(meta), "metadata collision: " + state);
                check(block.getStateFromMeta(meta).equals(state), "registry state roundtrip: " + state);
                saved.set(index, 0, 0, meta);
                index++;
            }
            // NibbleArray is the 1.12 chunk-section representation for metadata.
            NBTTagCompound nbt = new NBTTagCompound();
            nbt.setByteArray("Data", saved.getData().clone());
            NibbleArray loaded = new NibbleArray(nbt.getByteArray("Data"));
            index = 0;
            for (IBlockState state : block.getBlockState().getValidStates()) {
                check(block.getStateFromMeta(loaded.get(index++, 0, 0)).equals(state), "saved metadata roundtrip: " + state);
            }
        }
    }

    private static void legacyMetadata() {
        check(!DigitalMineRegistry.CASING.getStateFromMeta(0).getValue(DigitalMineCasing.FORMED), "old casing is unformed");
        check(DigitalMineRegistry.CASING.getStateFromMeta(1).getValue(DigitalMineCasing.FORMED), "formed casing metadata");
        for (DigitalMineBlock b : new DigitalMineBlock[] { DigitalMineRegistry.BASIC, DigitalMineRegistry.ADVANCED }) {
            for (int i = 0; i < 4; i++) {
                IBlockState old = b.getStateFromMeta(i);
                check(old.getValue(DigitalMineBlock.FACING) == EnumFacing.getHorizontal(i), "legacy facing " + i);
                check(!old.getValue(DigitalMineBlock.FORMED), "legacy formed " + i);
                check(b.getMetaFromState(old) == i, "legacy metadata " + i);
                check(b.getStateFromMeta(i | 4).getValue(DigitalMineBlock.FORMED), "new formed bit " + i);
            }
        }
    }

    private static void authoritativeVisualState() throws Exception {
        for (EnumFacing facing : EnumFacing.HORIZONTALS) {
            DigitalMineTest.TestWorld world = DigitalMineTest.world();
            BlockPos pos = new BlockPos(100, 64, 100);
            DigitalMineTile.Basic mine = DigitalMineTest.assemble(world, pos, facing);
            BlockPos part = pos.up();
            IBlockState mineState = world.states.get(pos);
            IBlockState casingState = world.states.get(part);
            check(mine.structureValid(), "formed structure " + facing);
            check(DigitalMineRegistry.BASIC.getActualState(mineState, world, pos).getValue(DigitalMineBlock.FORMED), "controller formed visual");
            check(DigitalMineRegistry.CASING.getActualState(casingState, world, part).getValue(DigitalMineCasing.FORMED), "casing formed visual");
            NBTTagCompound casingPacket = world.tiles.get(part).getUpdateTag();
            NBTTagCompound minePacket = mine.getUpdateTag();
            check(casingPacket.getBoolean("Formed") && minePacket.getBoolean("Formed"), "formed update tags");
            world.tiles.remove(part);
            check(!mine.structureValid(), "broken structure");
            // Even a saved formed bit cannot make the actual visual state or server structure valid.
            check(!DigitalMineRegistry.BASIC.getActualState(mineState.withProperty(DigitalMineBlock.FORMED, true), world, pos).getValue(DigitalMineBlock.FORMED), "stale controller bit");
            check(!DigitalMineRegistry.CASING.getActualState(casingState.withProperty(DigitalMineCasing.FORMED, true), world, part).getValue(DigitalMineCasing.FORMED), "stale casing bit");
            check(!mine.getUpdateTag().getBoolean("Formed"), "broken update tag");
        }
    }

    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        allRegistryStates(); legacyMetadata(); authoritativeVisualState();
        Bootstrap.printToSYSOUT("PASS: all Digital Mine registry states, 4-bit metadata and saved nibble roundtrips, legacy mappings and derived visuals");
    }
}
