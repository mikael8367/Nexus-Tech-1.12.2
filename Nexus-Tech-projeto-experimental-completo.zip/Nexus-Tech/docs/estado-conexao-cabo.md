# Diagnóstico da ponte ProjectE–SSN

A ponte continua **sem conexão funcional**: não expõe IConnectable, inventário ou ações de transferência e não altera itens ou EMC. O novo `BridgeEndpoint` é uma observação de servidor por jogador, atualizada enquanto a GUI estiver aberta; a GUI mostra adjacência da mesa e um resumo dos ponteiros SSN. Não há slots ou comandos de escrita.

O endpoint verifica jogador real autenticado (referência da lista de jogadores do servidor, UUID, mundo, distância, vivo e não FakePlayer), thread principal, bloco e tile ainda válidos e chunks carregados. `TableAdjacency` valida a versão ProjectE `1.12.2-PE1.4.1` e o bloco oficial da mesa; adjacência não significa acesso ou conexão. `SsnAdjacentProbe` valida versão Forge SSN `2.0.1` (release 1.12.2-2.0.1), lado oposto, cabo simples de classe exata, posição, dimensão e controlador carregado. Outras versões, tipos, chunks, erros ou dados inconsistentes não habilitam acesso. Leituras não forçam carregamento. Uma mesa pode ser identificada, mas a leitura de dados pessoais de ProjectE permanece desabilitada até validação da integração real.

São observadas as seis faces. Dois ponteiros distintos acionam aviso de múltiplos controladores atribuídos; ponteiros repetidos são deduplicados. Qualquer leitura não conclusiva resulta em estado incompleto, exceto que múltiplos ponteiros conhecidos preservam o aviso. Um único controlador atribuído **não prova caminho conectado**, não identifica todas as redes e pode estar desatualizado. Outros tipos de cabo/controlador não são percorridos; 'sem cabo simples' não afirma inexistência de rede. Não é feita varredura completa da rede nem concedida permissão para conexão.

## Bloqueio de conexão

Na implementação SSN analisada, `TileMaster` visita a topologia e, se encontra outro `TileMaster`, chama `nukeAndDrop`, que faz drop, `setBlockToAir` e `removeTileEntity`. Expor IConnectable na ponte poderia unir redes e introduzir esse caminho destrutivo. Uma inspeção pontual não impede mudanças subsequentes de topologia/chunks; por isso não justifica ativação. Colocar/remover blocos próximos pode em si notificar SSN, fora do controle do diagnóstico. Sem solução comprovada, a integração fica bloqueada.

As suítes são simulações de contratos e mundos; não constituem teste com mods reais em Minecraft, nem prova de ausência de efeitos de outros mods. Não houve publicação nem geração de JAR. O trabalho não altera o código de energia ou build.gradle; alterações pré-existentes nesses arquivos são independentes.
