# Integração experimental isolada

**Não usar em mundos importantes.** Esta cópia local está em worktree separado, HEAD destacado em `618c67afb6bd226fa95314b0f4434822adc9f2cd`. Ela reúne a árvore de trabalho local `bridge-main-dev` (incluindo alterações não commitadas e arquivos não rastreados em `src` e `docs`) e o commit industrial `66c2c6c` de `/tmp/nexus-industrial-2026`. Não houve push, commit ou alteração da main ou da branch industrial. Os caches/builds não foram copiados. O worktree contém alterações não commitadas e arquivos não rastreados: guardá-lo é essencial, pois `git diff` sozinho não inclui os arquivos não rastreados.

## Fusão

IDs de GUI: máquinas 0, ponte 1, minerador 71 e reator 8367. Rotas de cliente/servidor foram preservadas e o registro de GUI permanece único. A registry original mantém ponte e cabo; registries industriais são assinantes Forge independentes. PreInit registra tiles do minerador e gerador de minérios; o evento de registro de itens adiciona entradas ao Ore Dictionary e init registra receitas de fundição. Os idiomas conservam ambas as partes. A configuração de build é a da árvore de trabalho da ponte, incluindo suítes standalone; o commit industrial não alterava build.gradle. Cópias originais não foram apagadas.

A ponte continua diagnóstica, sem transferência de itens/EMC, sem IConnectableLink ou capability de inventário/FE. O SSN analisado pode destruir um controlador ao unir redes; não há solução comprovada. A operação real e leitura pessoal ProjectE não foram validadas. As observações não provam ligação à rede.

## Exceção FE

No teste simulado foi encontrado que um receptor que altera seu estoque e lança exceção de `receiveEnergy` podia receber FE e a origem recuperar a reserva, duplicando FE. Nesta cópia `EnergyNetwork.sendPass` trata conservadoramente uma chamada real que lança exceção: considera toda a oferta restante consumida e interrompe a busca, evitando reembolso incerto. Isso pode **perder FE**, inclusive se o receptor lançou antes de alterar o estoque; a interface não informa o quanto foi realmente aceito. É uma troca de segurança deliberada, não garantia de atomicidade. Falhas em `getCapability`/`canReceive` antes da chamada não são contabilizadas como transferência; falhas de simulação não gastam FE. A extração de uma fonte que muda estado e lança exceção pode perder energia; endpoints que mentem ou violam simulação também não são protegidos. Nenhuma dessas hipóteses foi testada em Minecraft real.

## Resultado observado

Java 8 `1.8.0_512`, Gradle 4.9: `check` final passou com 22 suítes Java standalone; três verificações Python passaram com 8, 2 e 5 testes. Testes de assinatura oficial ProjectE e SSN foram explicitamente pulados por ausência dos JARs no classpath. Uma primeira tentativa com cache incorreto falhou por falta de ForgeGradle; o cache indicado abaixo funcionou. O teste combinado descobriu a exceção FE; após corrigir, também exigiu atualizar a regressão anterior para o novo comportamento conservador. A última verificação completa passou. Sem JAR em `build/libs`.

## Continuação de recursos

Foram adicionadas 13 receitas alternativas com lingotes de cobre e estanho do Ore Dictionary, sem substituir as receitas anteriores; a receita da mina básica depende do revestimento digital e a do controlador nuclear depende do núcleo, ambos com alternativas próprias. Seus padrões e limites estão no README. As quatro texturas de placas e ligas foram codificadas como fontes `.png.b64`, sem alteração dos bytes; os PNGs originais foram preservados em `src/main/texture_sources/original_png/items`, fora da árvore de recursos, para não duplicar as texturas geradas. O teste geral de recursos e o novo teste de receitas validam essas fontes. O teste original da expansão foi preservado sem alterações e falha na checagem de textura porque espera os PNGs diretamente em `resources`; para compatibilizá-lo é necessário alterar o teste ou voltar a duplicar os recursos. Esta continuação executa apenas verificações estáticas em Python: não executa Gradle, não gera artefatos e não testa Forge, cliente, servidor, conflitos com ingredientes de outros mods ou jogabilidade.

## Reprodução local sem JAR

Necessário JDK 8, Gradle 4.9, Python 3 e Pillow, cache ForgeGradle/Forge já preenchido. Os caminhos abaixo se referem a este ambiente; cache offline indisponível em outra máquina não pode ser recriado sem primeiro baixar dependências. `--offline` se refere à resolução do Gradle, não prova de isolamento total de rede de todos os plugins.

```sh
cd /home/daytona/workspace/nexus-integrado-experimental
export JAVA_HOME=/home/daytona/workspace/nexus-test/jdk
export PATH="$JAVA_HOME/bin:$PATH"
export GRADLE_USER_HOME=/home/daytona/workspace/bridge-build-check/.gradle-user
GRADLE="$GRADLE_USER_HOME/wrapper/dists/gradle-4.9-bin/e9cinqnqvph59rr7g70qubb4t/gradle-4.9/bin/gradle"
"$GRADLE" --offline --no-daemon --max-workers=1 -Dorg.gradle.jvmargs=-Xmx768m check -x jar -x reobfJar
python3 src/test/java/com/mikael8367/nexustech/test_integration_assets.py
python3 src/test/java/com/mikael8367/nexustech/ores/test_ore_assets.py
python3 src/test/java/com/mikael8367/nexustech/test_experimental_integration.py
```

`check` executa as suítes Java que têm `main`; os testes Python são separados. `ExperimentalEnergyIntegrationTest` usa mundo simulado, classes reais do gerador/cabo/minerador e um endpoint que altera energia e lança exceção. Os testes estáticos verificam dispatch, IDs, recursos e isolamento, sem provar funcionamento. Os testes de assinatura opcionais de ProjectE/SSN são pulados sem os JARs reais. Sem execução do cliente/servidor, sem teste do modpack real, colisões de IDs em runtime, salvamento de mundos, renderização, multiplayer, chunks e compatibilidade entre mods não foram comprovados. Antes de uso, fazer testes em mundos descartáveis com backup, versões reais dos mods e servidor dedicado; não habilitar conexão/transferência da ponte sem projeto e validação independentes.
