# Expansão industrial experimental

A prensa elétrica (`nexus_metal_press`) e a fundidora de ligas (`nexus_alloy_smelter`) não substituem a fornalha, o triturador ou o compressor existentes. Não dependem de alteração dos registradores globais: blocos, itens, tiles e modelos usam subscribers Forge em `machinesexpansion`. Elas só recebem FE (não puxam); fontes Nexus já enviam energia, inclusive através do cabo. Entrada/saída por `IItemHandler` em qualquer face; o slot 2 é apenas de saída. Entradas também são extraíveis para recuperação. Sem GUI: clique com item na mão para inserir; clique com mão vazia para retirar a saída; agachado e mão vazia para recuperar entradas. Quebrar o bloco deixa cair o conteúdo.

Cada operação: 100 ticks, 20 FE/tick (2.000 FE), buffer de 20.000 FE, recebimento máximo de 1.000 FE/chamada. Pausa sem energia; saída cheia/incompatível não consome nada e cancela progresso parcial. Alteração de entrada cancela progresso parcial; não devolve energia já gasta. Insumos com NBT, dano ou item recipiente são rejeitados para não destruir dados ou recipientes.

- Prensa: 1 `ingotCopper` → 1 placa de cobre; 1 `ingotTin` → 1 placa de estanho.
- Fundidora: 3 `ingotCopper` + 1 `ingotTin` → 4 bronze; 3 `ingotCopper` + 1 `ingotZinc` → 4 latão. Cobre no slot 0, estanho/zinco no 1.
- Placas registram `plateCopper` e `plateTin`; ligas registram `ingotBronze` e `ingotBrass`. São usadas na receita da fundidora e receita alternativa de 12 cabos, respectivamente. Há receitas JSON para cada máquina.

## Disponibilidade de minérios

O módulo `ores` existente registra no evento de itens os minérios e lingotes Nexus de cobre, estanho e zinco no Ore Dictionary e, em `OreRegistry.init`, uma receita de fundição vanilla de cada minério para um lingote. `NexusTech.init` chama essa inicialização. Portanto não é preciso outro mod para obter os insumos, **desde que o módulo de minérios e sua inicialização permaneçam integrados**. Outros mods podem fornecer itens com os mesmos nomes do dicionário. As receitas JSON das máquinas são receitas de bancada; as receitas de processamento são internas, não JSON/JEI.

## Traduções

Os nomes das máquinas, placas e ligas estão adicionados a `pt_br.lang` e `en_us.lang`, preservando as entradas existentes. O modelo do latão referencia `textures/items/nexus_brass_ingot.png`. A verificação em Minecraft real continua necessária.

## Limites da validação

`ExpansionMachineTest` usa mundo falso, itens vanilla registrados como substitutos do Ore Dictionary e classes reais Forge, sem iniciar Minecraft. Testa evento de blocos/tiles, máquina, buffer, simulação, troca de entrada, persistência básica, extração automatizada, saída cheia e energia de bateria Nexus via cabo. O bootstrap isolado informa falta de `.mcassetsroot` e erros de receitas vanilla; não é um teste de carregamento real dos JSON, itens ou texturas. Não foi executado cliente/servidor Forge completo nem Gradle. A ordem real de registro/descoberta automática dos subscribers, crafting JSON, texturas, interação e salvamento com itens Nexus precisam ser verificados no jogo antes de considerar a expansão pronta para distribuição.

## Auditoria complementar da integração

Compilação isolada Java 8 dos dois pacotes e testes executáveis `ExpansionMachineTest`, `PowerExpansionTest` e `ExpansionDiscoveryTest`: passaram. O último verifica a leitura das anotações pelo parser ASM do Forge, modid, lados e métodos; não inicia o ciclo de registro. `test_expansion_assets.py` verifica nomes nos dois idiomas, referências locais, PNGs e estrutura das receitas, mas não carrega os recursos no jogo. Inspeção estática do bytecode encontrou referências client apenas nas classes `*Client`. A inicialização isolada emitiu avisos de `.mcassetsroot` e receitas vanilla ausentes. O teste usa classes de dependências já compiladas: cliente Forge e servidor dedicado reais continuam pendentes. Não foi executado Gradle, nem gerado JAR ou feito push nesta auditoria.
