# Expansão de energia experimental

Subsistema isolado `powerexpansion`, para Forge 1.12.2. Os registros são por eventos Forge; modelos são registrados somente no cliente. Não altera os registros ou GUI compartilhados. Ainda precisa ser testado dentro do Minecraft e em servidor dedicado antes de uso em mundos importantes; faça backup.

## Blocos

* `nexustech:powerexpansion_battery_advanced`: 1.000.000 FE, entrada e saída até 4.000 FE/tick, somando todas as faces.
* `nexustech:powerexpansion_battery_elite`: 10.000.000 FE, entrada e saída até 16.000 FE/tick, somando todas as faces.
* `nexustech:powerexpansion_solar_large`: gera 64 FE/tick, armazena até 8.192 FE e fornece até 512 FE/tick. Gera **e fornece** apenas em dimensão com céu, durante o dia, sem chuva/trovão e com céu visível acima. Energia acumulada permanece no painel à noite.

O painel é uma versão **compacta e segura em um bloco**, não uma estrutura 3x3: ele parece amplo ocupando toda a largura do bloco, sem geometria fora dele. A caixa de colisão/seleção é 1 × 14,5/16 × 1, contida na posição do bloco; ela cobre também o espaço vazio sob as bordas. Não coloca nem substitui blocos vizinhos. Clique com o botão direito para ver a energia na barra de status; não há GUI. Os nomes dos itens e a mensagem de energia usam as traduções `pt_br` e `en_us`; os idiomas existentes foram preservados.

As baterias são passivas: a fonte deve empurrar FE ou o consumidor deve puxar FE; o painel tenta empurrar para vizinhos e cabos. Conexões FE são disponíveis em todas as faces. Os limites são separados para entrada e saída e compartilhados entre faces por tick; chamadas de simulação não consomem energia nem limite. O cabo existente tem suas próprias políticas e limites, portanto a vazão final pode ser menor. Energia é salva no NBT do bloco. Na quebra normal por jogador, o item individual guarda sua carga e a devolve ao colocar; ferramentas com Toque Suave seguem o mesmo caminho. Criativo, comandos, remoções por outros mods e explosões podem não produzir um item, portanto não garantem conservar energia. Itens carregados não empilham.

Se um destinatário FE de outro mod modificar seu estoque e lançar exceção, o painel não pode saber quanto foi recebido: não reembolsa a oferta incerta, podendo perder energia para evitar duplicação. Outros mods que mintam sobre a quantidade aceita também não oferecem uma garantia transacional. Não há promessa de comportamento seguro para mods defeituosos ou que alterem blocos durante eventos de quebra.

## Receitas

Receitas `forge:ore_shaped` em `assets/nexustech/recipes/powerexpansion_*.json`, com `ingotCopper`, `ingotLead`, `ingotTitanium`, `ingotSilver`, `ingotAluminum` e `ingotTin`, aceitando também fornecedores compatíveis no Ore Dictionary. Nenhuma consome uma bateria ou painel carregados. As receitas dependem do subsistema de minérios Nexus estar registrado.

## Verificação

`PowerExpansionTest` é um `main` isolado: cobre limites por faces, simulação, persistência NBT, geração sob céu/dia/chuva, guarda contra reentrada, endpoint com exceção, criação de drop e restauração da carga ao colocar, e transferência através da implementação real do cabo Nexus em mundo simulado. A compilação isolada Java 8 e o teste passaram; o bootstrap isolado emitiu avisos de assets/receitas vanilla ausentes, por não estar rodando o jogo completo. Isso não valida carregamento real de assets/receitas, registro em servidor, quebra/colocação nem integração com outros mods.

Quando não houver outras compilações rodando, a integração deve compilar o projeto e testar em cliente e servidor Forge 1.12.2: receitas e modelos, inventário, colocação/quebra e recolocação com carga e Toque Suave, descarregar e recarregar chunks/mundo, céu/noite/chuva/dimensões sem céu, cabos e máquinas, além de eventos de outros mods. Não rodar Gradle simultaneamente no mesmo diretório. Nenhum JAR, APK ou push foi feito por esta tarefa.

## Auditoria complementar da integração

Compilação isolada Java 8 dos dois pacotes e testes executáveis `ExpansionMachineTest`, `PowerExpansionTest` e `ExpansionDiscoveryTest`: passaram. O último verifica a leitura das anotações pelo parser ASM do Forge, modid, lados e métodos; não inicia o ciclo de registro. `test_expansion_assets.py` verifica nomes nos dois idiomas, referências locais, PNGs e estrutura das receitas, mas não carrega os recursos no jogo. Inspeção estática do bytecode encontrou referências client apenas nas classes `*Client`. A inicialização isolada emitiu avisos de `.mcassetsroot` e receitas vanilla ausentes. O teste usa classes de dependências já compiladas: cliente Forge e servidor dedicado reais continuam pendentes. Não foi executado Gradle, nem gerado JAR ou feito push nesta auditoria.
