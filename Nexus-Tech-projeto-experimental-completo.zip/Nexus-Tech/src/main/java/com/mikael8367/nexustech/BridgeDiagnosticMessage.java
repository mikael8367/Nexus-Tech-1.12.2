package com.mikael8367.nexustech;

import com.mikael8367.nexustech.ssnbridge.SsnAdjacentProbe;
import com.mikael8367.nexustech.tablebridge.TableAdjacency;

/** Explanation of an incomplete read, never a connectivity or access decision. */
final class BridgeDiagnosticMessage {
    private BridgeDiagnosticMessage() { }
    static String explain(int[] faces, boolean pt) {
        int best = 0;
        if (faces != null) for (int packed : faces) {
            int t = (packed & 7) - 1, s = (packed >>> 3) - 1;
            if (t == TableAdjacency.Result.UNAVAILABLE.ordinal()) best = Math.max(best, 4);
            else if (t == TableAdjacency.Result.UNLOADED.ordinal()) best = Math.max(best, 5);
            else if (t == TableAdjacency.Result.ERROR.ordinal() || t == TableAdjacency.Result.INVALID_INPUT.ordinal()) best = Math.max(best, 7);
            if (s < 0 || s >= SsnAdjacentProbe.State.values().length) continue;
            switch (SsnAdjacentProbe.State.values()[s]) {
                case UNKNOWN_TILE: best = Math.max(best, 1); break;
                case NO_MASTER: best = Math.max(best, 2); break;
                case NO_CAPABILITY: case INCONSISTENT_SELF: case OTHER_DIMENSION: case MASTER_UNAVAILABLE:
                    best = Math.max(best, 3); break;
                case UNLOADED: best = Math.max(best, 5); break;
                case SSN_ABSENT: case UNSUPPORTED_VERSION: case API_UNAVAILABLE: best = Math.max(best, 6); break;
                case INVALID_CONTEXT: case NOT_NEXUS_CABLE: case ERROR: best = Math.max(best, 7); break;
                default: break;
            }
        }
        switch (best) {
            case 1: return pt ? "SSN: bloco vizinho nao identificado" : "SSN: unknown adjacent block";
            case 2: return pt ? "SSN: cabo sem controlador atribuido" : "SSN: cable has no assigned master";
            case 3: return pt ? "SSN: dados do cabo/controlador invalidos" : "SSN: invalid cable/master data";
            case 4: return pt ? "ProjectE: versao/API indisponivel" : "ProjectE: version/API unavailable";
            case 5: return pt ? "Regiao nao carregada" : "Chunk not loaded";
            case 6: return pt ? "SSN ausente ou versao/API incompativel" : "SSN absent or version/API incompatible";
            case 7: return pt ? "Erro ou contexto de leitura invalido" : "Read error or invalid context";
            default: return "";
        }
    }
}
