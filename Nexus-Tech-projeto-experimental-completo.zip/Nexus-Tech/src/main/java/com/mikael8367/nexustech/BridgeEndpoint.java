package com.mikael8367.nexustech;

import com.mikael8367.nexustech.ssnbridge.SsnAdjacentProbe;
import com.mikael8367.nexustech.tablebridge.TableAdjacency;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;

/** Server-side per-viewer observations only; never grants access to either network. */
public final class BridgeEndpoint {
    public enum TableSummary { WAITING, ADJACENT, NONE, INCOMPLETE }
    public enum NetworkSummary { WAITING, NONE, ASSIGNED, MULTIPLE, INCOMPLETE }
    public static final class Snapshot {
        public final TableSummary table;
        public final NetworkSummary network;
        private final int[] faces;
        private Snapshot(TableSummary table, NetworkSummary network, int[] faces) {
            this.table = table; this.network = network; this.faces = faces.clone();
        }
        /** Zero means not observed. Otherwise table ordinal+1 and SSN ordinal+1, packed. */
        public int face(EnumFacing face) { return faces[face.ordinal()]; }
    }
    interface Observer {
        TableAdjacency.Result table(EnumFacing face);
        SsnAdjacentProbe.Result ssn(EnumFacing face);
    }
    private static Snapshot unavailable() {
        return new Snapshot(TableSummary.INCOMPLETE, NetworkSummary.INCOMPLETE, new int[6]);
    }
    /** Caller supplies the server container's viewer, never a client-chosen UUID. */
    public static Snapshot inspect(EntityPlayerMP player, BridgeTile tile) {
        try {
            if (player == null || player instanceof FakePlayer || player.isDead || tile == null
                    || !(player.world instanceof WorldServer) || player.world.isRemote
                    || tile.getWorld() != player.world || tile.isInvalid()
                    || FMLCommonHandler.instance().getEffectiveSide() != Side.SERVER) return unavailable();
            World world = player.world;
            MinecraftServer server = player.getServer();
            if (server == null || server != world.getMinecraftServer() || !server.isCallingFromMinecraftThread()
                    || server.getPlayerList().getPlayerByUUID(player.getUniqueID()) != player) return unavailable();
            BlockPos pos = tile.getPos();
            if (pos == null || !world.isValid(pos) || !world.isBlockLoaded(pos)
                    || world.getTileEntity(pos) != tile || world.getBlockState(pos).getBlock() != ModRegistry.BRIDGE
                    || !(player.getDistanceSq(pos.getX()+.5, pos.getY()+.5, pos.getZ()+.5) <= 64.0)) return unavailable();
            return observe(new Observer() {
                public TableAdjacency.Result table(EnumFacing face) { return TableAdjacency.inspect(world, pos, face); }
                public SsnAdjacentProbe.Result ssn(EnumFacing face) { return SsnAdjacentProbe.inspect(world, pos, face); }
            });
        } catch (RuntimeException | LinkageError ex) { return unavailable(); }
    }
    /** A snapshot of assigned pointers is not evidence of a connected path. */
    static Snapshot observe(Observer observer) {
        if (observer == null) return unavailable();
        int[] faces = new int[6]; boolean tableFound = false, tableUnknown = false, networkUnknown = false;
        Set<BlockPos> masters = new HashSet<>();
        try {
            for (EnumFacing side : EnumFacing.values()) {
                TableAdjacency.Result t = observer.table(side);
                SsnAdjacentProbe.Result s = observer.ssn(side);
                if (t == null || s == null || s.state == null) return unavailable();
                faces[side.ordinal()] = (t.ordinal() + 1) | ((s.state.ordinal() + 1) << 3);
                if (t == TableAdjacency.Result.ADJACENT_ONLY) tableFound = true;
                else if (t != TableAdjacency.Result.NO_MATCH) tableUnknown = true;
                if (s.state == SsnAdjacentProbe.State.ASSIGNED_MASTER && s.masterPos != null) masters.add(s.masterPos);
                else if (s.state != SsnAdjacentProbe.State.NOT_PLAIN_SSN_CABLE) networkUnknown = true;
            }
            TableSummary table = tableUnknown ? TableSummary.INCOMPLETE : tableFound ? TableSummary.ADJACENT : TableSummary.NONE;
            NetworkSummary network = masters.size() > 1 ? NetworkSummary.MULTIPLE
                    : networkUnknown ? NetworkSummary.INCOMPLETE : masters.isEmpty() ? NetworkSummary.NONE : NetworkSummary.ASSIGNED;
            return new Snapshot(table, network, faces);
        } catch (RuntimeException | LinkageError ex) { return unavailable(); }
    }
    private BridgeEndpoint() { }
}
