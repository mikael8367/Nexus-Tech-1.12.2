package com.mikael8367.nexustech;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public final class BridgeGui extends GuiContainer {
    private final BridgeContainer bridge;
    private final EntityPlayer viewer;
    private static final String[] SIDES = {"down", "up", "north", "south", "west", "east"};
    private static final String[] STATUS = {"none", "table", "other_pe", "master", "request", "inventory", "cable", "other_ssn", "unloaded", "waiting"};
    public BridgeGui(EntityPlayer viewer, BridgeTile tile) {
        super(new BridgeContainer(viewer, tile));
        this.bridge = (BridgeContainer)inventorySlots; this.viewer = viewer;
        // Compact enough for a 230-pixel-high logical viewport (as in the supplied screenshot).
        xSize = 250; ySize = 216;
    }
    private String text(String key) { return I18n.format("gui.nexustech.bridge." + key); }
    private void line(String value, int y, int color) {
        fontRenderer.drawString(fontRenderer.trimStringToWidth(value, xSize - 18), 9, y, color);
    }
    @Override protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        drawRect(guiLeft, guiTop, guiLeft + xSize, guiTop + ySize, 0xff202c37);
        drawRect(guiLeft + 3, guiTop + 3, guiLeft + xSize - 3, guiTop + ySize - 3, 0xffd8e0e4);
        drawRect(guiLeft + 7, guiTop + 28, guiLeft + xSize - 7, guiTop + 102, 0xfff1f4f4);
    }
    @Override protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        int color = 0x26323a;
        line(text("title"), 7, color);
        line(text("player") + " " + viewer.getName(), 18, color);
        int mods = bridge.getValue(6);
        String modText = mods == BridgeDiagnostics.WAITING ? text("waiting") :
            "ProjectE: " + text((mods & 1) != 0 ? "loaded" : "absent") + " | SSN: " + text((mods & 2) != 0 ? "loaded" : "absent");
        line(modText, 31, color);
        for (int i = 0; i < SIDES.length; i++) {
            int value = bridge.getValue(i);
            line(text(SIDES[i]) + ": " + text(STATUS[value]), 43 + i * 10, color);
        }
        String[] table = {"waiting", "table_verified", "table_none", "scan_incomplete"};
        String[] network = {"waiting", "ssn_none", "ssn_assigned", "ssn_multiple", "scan_incomplete"};
        line(text("table_scan") + " " + text(table[bridge.getTableSummary()]), 105, color);
        line(text("ssn_scan") + " " + text(network[bridge.getNetworkSummary()]), 116, color);
        int state = bridge.getPeState();
        if (state == ProjectEReadOnly.OK || state == ProjectEReadOnly.FULL) {
            line(text("emc") + " " + bridge.getEmc(), 128, color);
            line(text(state == ProjectEReadOnly.FULL ? "tome_count" : "learned") + " " + bridge.getLearnedCount(), 139, color);
            if (state == ProjectEReadOnly.FULL) line(text("full"), 150, color);
        } else {
            String key = state == ProjectEReadOnly.WAITING ? "waiting" : state == ProjectEReadOnly.ERROR ? "pe_error" : "pe_unavailable";
            line(text("pe_data") + " " + text(key), 128, color);
        }
        boolean pt = "pt_br".equalsIgnoreCase(mc.getLanguageManager().getCurrentLanguage().getLanguageCode());
        if (bridge.getTableSummary() == BridgeEndpoint.TableSummary.INCOMPLETE.ordinal()
                || bridge.getNetworkSummary() == BridgeEndpoint.NetworkSummary.INCOMPLETE.ordinal()) {
            int[] faces = new int[6];
            for (int i = 0; i < 6; i++) faces[i] = bridge.getEndpointFace(i);
            String detail = BridgeDiagnosticMessage.explain(faces, pt);
            if (!detail.isEmpty()) line(detail, 162, 0x963f18);
        }
        line(pt ? "Bloqueada: integracao SSN incompleta." : "Blocked: SSN integration incomplete.", 177, 0x963f18);
        line(pt ? "Sem transacoes; risco aos controladores." : "No transactions; risk to controllers.", 190, 0x963f18);
        line(pt ? "Sem itens/EMC. Adjacencia nao e ligacao." : "No items/EMC. Adjacency is not a link.", 203, 0x963f18);
    }
    @Override public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground(); super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
