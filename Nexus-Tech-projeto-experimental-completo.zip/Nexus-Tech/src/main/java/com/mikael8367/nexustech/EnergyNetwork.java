package com.mikael8367.nexustech;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import com.mikael8367.nexustech.powerexpansion.PowerTile;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Iterative traversal: cables have no buffer. Never query an unloaded position. */
final class EnergyNetwork {
    // Bound per-call work. Endpoints beyond either limit may be unreachable on
    // every tick until the network is split or shortened.
    private static final int MAX_CABLES = 8192;
    private static final int MAX_PATH_CHECKS = 131072;
    private static final ThreadLocal<Boolean> ACTIVE = new ThreadLocal<Boolean>();
    private static final Logger LOGGER = LogManager.getLogger("NexusTech");
    private static final long LOG_INTERVAL_NANOS = 60_000_000_000L;
    private static long lastFailureLog;
    private static boolean hasLoggedFailure;
    private static long suppressedFailures;
    private EnergyNetwork() { }

    // Callbacks can remove, unload or replace a queued cable or origin.
    private static boolean live(World world, BlockPos pos, TileEntity expected) {
        return expected != null && !expected.isInvalid() && world.isBlockLoaded(pos)
                && world.getTileEntity(pos) == expected;
    }

    // The discovery tree is acyclic: parents are recorded only for newly visited
    // cables. A live child alone is insufficient after a callback removes an
    // ancestor. Recheck the whole recorded route without loading chunks.
    private static boolean livePath(World world, BlockPos current, BlockPos origin,
                                    Map<BlockPos, TileEntity> nodes, Map<BlockPos, BlockPos> parents, int[] budget) {
        for (BlockPos node = current; node != null; node = parents.get(node)) {
            if (budget[0]-- <= 0) return false;
            if (!live(world, node, nodes.get(node))) return false;
            if (node.equals(origin)) return true;
        }
        return false;
    }

    // A broken endpoint can be visited every tick. Limit log volume globally without
    // retaining world/tile references, and report the number suppressed next time.
    private static synchronized void logEndpointFailure(BlockPos pos, RuntimeException error) {
        long now = System.nanoTime();
        if (!hasLoggedFailure || now - lastFailureLog >= LOG_INTERVAL_NANOS) {
            LOGGER.warn("Forge Energy endpoint at {} failed ({} similar failures suppressed); skipping it for this traversal",
                    pos, suppressedFailures, error);
            lastFailureLog = now;
            hasLoggedFailure = true;
            suppressedFailures = 0;
        } else if (suppressedFailures < Long.MAX_VALUE) {
            suppressedFailures++;
        }
    }
    private static boolean isNexusBattery(TileEntity tile) {
        return tile instanceof MachineTile.Battery || tile instanceof PowerTile.AdvancedBattery
                || tile instanceof PowerTile.EliteBattery;
    }
    /**
     * Pull from loaded endpoints adjacent to the origin or its cable component.
     * A machine origin must be the excluded consumer; a cable origin can be
     * used by a sided external consumer. The shared guard also covers direct
     * neighbours and callbacks while resolving capabilities.
     */
    static int pull(World world, BlockPos origin, BlockPos excludedConsumer, int amount,
                    boolean simulate, boolean allowNexusBatteries) {
        if (world == null || origin == null || world.isRemote || amount <= 0
                || Boolean.TRUE.equals(ACTIVE.get())) return 0;
        ACTIVE.set(true);
        int moved = 0;
        try {
            if (!world.isBlockLoaded(origin)) return 0;
            TileEntity start = world.getTileEntity(origin);
            if (start == null || start.isInvalid() || (!(start instanceof MachineTile.Cable)
                    && (!(start instanceof MachineTile) || !origin.equals(excludedConsumer)))) return 0;
            // Simulated sources may likewise be aliases of one underlying buffer.
            Queue<BlockPos> queue = new ArrayDeque<>();
            Set<BlockPos> cables = new HashSet<>();
            Set<BlockPos> endpoints = new HashSet<>();
            Map<BlockPos, TileEntity> nodes = new HashMap<>();
            Map<BlockPos, BlockPos> parents = new HashMap<>();
            int[] pathBudget = { MAX_PATH_CHECKS };
            nodes.put(origin, start);
            queue.add(origin); cables.add(origin);
            while (!queue.isEmpty() && moved < amount) {
                BlockPos current = queue.remove();
                for (EnumFacing direction : EnumFacing.VALUES) {
                    if (!live(world, origin, start)) return moved;
                    if (pathBudget[0] <= 0) return moved;
                    BlockPos next = current.offset(direction);
                    if (next.equals(excludedConsumer) || !world.isBlockLoaded(next)) continue;
                    TileEntity tile = world.getTileEntity(next);
                    if (tile == null || tile.isInvalid()) continue;
                    if (tile instanceof MachineTile.Cable) {
                        if (!cables.contains(next)) {
                            if (cables.size() >= MAX_CABLES) return moved;
                            cables.add(next); nodes.put(next, tile); parents.put(next, current); queue.add(next);
                        }
                        continue;
                    }
                    if ((!allowNexusBatteries && isNexusBattery(tile))
                            || endpoints.contains(next)) continue;
                    // Try other faces only until this endpoint supplies energy.
                    try {
                        if (!livePath(world, current, origin, nodes, parents, pathBudget)) continue;
                        IEnergyStorage source = tile.getCapability(CapabilityEnergy.ENERGY, direction.getOpposite());
                        if (source == null || !source.canExtract()) continue;
                        if (!livePath(world, current, origin, nodes, parents, pathBudget)) return moved;
                        // A vanished or replaced endpoint does not invalidate the rest of
                        // the network. Do not probe its replacement during this pass.
                        if (!live(world, next, tile)) { endpoints.add(next); continue; }
                        int extracted = source.extractEnergy(simulate ? amount : amount - moved, simulate);
                        extracted = Math.max(0, Math.min(simulate ? amount : amount - moved, extracted));
                        if (extracted > 0) { moved = simulate ? Math.max(moved, extracted) : moved + extracted; endpoints.add(next); }
                    } catch (RuntimeException error) {
                        // No return value is available if the endpoint mutated before throwing.
                        // Do not retry another face in this traversal; preserve earlier transfers.
                        endpoints.add(next);
                        logEndpointFailure(next, error);
                    }
                    if (moved >= amount) break;
                }
            }
            return moved;
        } catch (RuntimeException error) {
            // Keep the completed transfers even if a world query fails later.
            logEndpointFailure(origin, error);
            return moved;
        } finally { ACTIVE.remove(); }
    }
    private static boolean exposesExtraction(TileEntity tile) {
        for (EnumFacing face : EnumFacing.VALUES) {
            IEnergyStorage storage = tile.getCapability(CapabilityEnergy.ENERGY, face);
            if (storage != null && storage.canExtract()) return true;
        }
        return false;
    }
    static int send(World world, BlockPos origin, BlockPos excludedSource, int amount, boolean simulate, boolean batterySource) {
        if (world == null || origin == null || world.isRemote || amount <= 0 || Boolean.TRUE.equals(ACTIVE.get())) return 0;
        ACTIVE.set(true);
        int moved = 0;
        try {
            if (!world.isBlockLoaded(origin)) return 0;
            TileEntity start = world.getTileEntity(origin);
            if (!(start instanceof MachineTile) || start.isInvalid()
                    || (!(start instanceof MachineTile.Cable) && !origin.equals(excludedSource))) return 0;
            // Consumers first, then Nexus batteries as buffers. Otherwise a nearby
            // battery can consume all generator output before a cabled machine,
            // and the battery cannot safely push to bidirectional FE endpoints.
            // Independent simulations cannot reveal whether distinct FE wrappers share a
            // backing buffer (e.g. the 17 miner casings). Use the best single probe
            // rather than summing hypothetical accepts; real transfers still aggregate.
            moved = sendPass(world, origin, start, excludedSource, amount, simulate, batterySource, false);
            if (!batterySource && moved < amount && world.isBlockLoaded(origin)
                    && world.getTileEntity(origin) == start && !start.isInvalid()) {
                int buffered = sendPass(world, origin, start, excludedSource,
                        simulate ? amount : amount - moved, simulate, false, true);
                moved = simulate ? Math.max(moved, buffered) : moved + buffered;
            }
            return moved;
        } catch (RuntimeException error) {
            logEndpointFailure(origin, error);
            return moved;
        } finally { ACTIVE.remove(); }
    }
    private static int sendPass(World world, BlockPos origin, TileEntity start, BlockPos excludedSource, int amount,
                                boolean simulate, boolean batterySource, boolean batteriesOnly) {
            int moved = 0;
            try {
            Queue<BlockPos> queue = new ArrayDeque<>();
            Set<BlockPos> cables = new HashSet<>();
            Set<BlockPos> endpoints = new HashSet<>();
            Map<BlockPos, TileEntity> nodes = new HashMap<>();
            Map<BlockPos, BlockPos> parents = new HashMap<>();
            int[] pathBudget = { MAX_PATH_CHECKS };
            nodes.put(origin, start);
            queue.add(origin); cables.add(origin);
            while (!queue.isEmpty() && moved < amount) {
                BlockPos current = queue.remove();
                for (EnumFacing direction : EnumFacing.VALUES) {
                    if (!live(world, origin, start)) return moved;
                    if (pathBudget[0] <= 0) return moved;
                    BlockPos next = current.offset(direction);
                    if (next.equals(excludedSource) || !world.isBlockLoaded(next)) continue;
                    TileEntity tile = world.getTileEntity(next);
                    if (tile == null || tile.isInvalid()) continue;
                    if (tile instanceof MachineTile.Cable) {
                        if (!cables.contains(next)) {
                            if (cables.size() >= MAX_CABLES) return moved;
                            cables.add(next); nodes.put(next, tile); parents.put(next, current); queue.add(next);
                        }
                        continue;
                    }
                    if ((batterySource && isNexusBattery(tile))
                            || (batteriesOnly != isNexusBattery(tile))) continue;
                    // A block may expose different capabilities on different faces: only mark
                    // it visited after a face actually accepts energy.
                    if (endpoints.contains(next)) continue;
                    boolean calledReceive = false;
                    try {
                        if (!livePath(world, current, origin, nodes, parents, pathBudget)) continue;
                        IEnergyStorage receiver = tile.getCapability(CapabilityEnergy.ENERGY, direction.getOpposite());
                        if (receiver == null || !receiver.canReceive()) continue;
                        // A storage endpoint can be empty after a pull; excluding only
                        // this tick's donors makes it bounce back on the next tick.
                        // Inspect every face because input and output may be sided.
                        // Conservatively let such endpoints pull, rather than push to them.
                        if (batterySource && exposesExtraction(tile)) continue;
                        if (!livePath(world, current, origin, nodes, parents, pathBudget)) return moved;
                        // Skip only the stale endpoint, not other reachable receivers.
                        if (!live(world, next, tile)) { endpoints.add(next); continue; }
                        calledReceive = true;
                        int accepted = receiver.receiveEnergy(simulate ? amount : amount - moved, simulate);
                        int offer = simulate ? amount : amount - moved;
                        // A negative return is invalid and may follow an unreported mutation.
                        // Never refund that real offer or continue to another receiver.
                        if (accepted < 0 && !simulate) { moved = amount; endpoints.add(next); break; }
                        accepted = Math.max(0, Math.min(offer, accepted));
                        if (accepted > 0) { moved = simulate ? Math.max(moved, accepted) : moved + accepted; endpoints.add(next); }
                    } catch (RuntimeException error) {
                        // An actual receive may have mutated before throwing. Conservatively
                        // consume the entire uncertain offer and stop: this can lose FE,
                        // but never refunds an amount that may already have been received.
                        if (calledReceive && !simulate) moved = amount;
                        endpoints.add(next);
                        logEndpointFailure(next, error);
                    }
                    if (moved >= amount) break;
                }
            }
            return moved;
            } catch (RuntimeException error) {
                // Never refund already credited receivers if a later world lookup fails.
                logEndpointFailure(origin, error);
                return moved;
            }
    }
}
