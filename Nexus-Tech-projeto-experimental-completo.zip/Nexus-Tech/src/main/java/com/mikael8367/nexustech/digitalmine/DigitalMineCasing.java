package com.mikael8367.nexustech.digitalmine;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public final class DigitalMineCasing extends Block {
    public static final PropertyBool FORMED = PropertyBool.create("formed");
    public DigitalMineCasing() {
        super(Material.IRON);
        setRegistryName(NexusTech.MODID, "digital_mine_casing");
        setUnlocalizedName(NexusTech.MODID + ".digital_mine_casing");
        setCreativeTab(NexusTech.CREATIVE_TAB);
        setHardness(4.0F); setResistance(15.0F);
        setDefaultState(blockState.getBaseState().withProperty(FORMED, false));
    }
    @Override protected BlockStateContainer createBlockState() { return new BlockStateContainer(this, FORMED); }
    @Override public IBlockState getActualState(IBlockState state, IBlockAccess access, BlockPos pos) {
        TileEntity te = access.getTileEntity(pos);
        return state.withProperty(FORMED, te instanceof DigitalMineCasingTile && ((DigitalMineCasingTile)te).visualFormed());
    }
    @Override public boolean hasTileEntity(IBlockState state) { return true; }
    @Override public TileEntity createTileEntity(World world, IBlockState state) { return new DigitalMineCasingTile(); }
    @Override public boolean onBlockActivated(World w, BlockPos p, IBlockState s, EntityPlayer player, EnumHand hand, EnumFacing face, float x, float y, float z) {
        return DigitalMineStructure.activate(w, p, player, hand);
    }
}
