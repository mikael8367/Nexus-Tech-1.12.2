package com.mikael8367.nexustech.digitalmine;

import javax.annotation.Nullable;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;

/** No independent inventory or energy: every reference is bound to its original controller. */
public final class DigitalMineCasingTile extends TileEntity implements ITickable {
    private boolean formed;
    private long generation;
    private final class Binding {
        final DigitalMineTile mine;
        final long atGeneration = generation;
        boolean revoked;
        Binding(DigitalMineTile mine) { this.mine = mine; }
        boolean valid() {
            if (revoked || generation != atGeneration || !bound(mine)) { revoked = true; return false; }
            return true;
        }
    }
    boolean visualFormed() {
        if (world == null) return false;
        if (world.isRemote) return formed;
        return attached() && DigitalMineStructure.controllerAt(world, pos) != null;
    }
    private boolean attached() {
        return world != null && !world.isRemote && !isInvalid() && world.isBlockLoaded(pos)
                && world.getTileEntity(pos) == this && world.getBlockState(pos).getBlock() == DigitalMineRegistry.CASING;
    }
    private boolean bound(DigitalMineTile mine) { return attached() && DigitalMineStructure.controllerAt(world, pos) == mine; }
    @Override public void update() {
        if (!attached() || world.getTotalWorldTime() % 10 != 0) return;
        boolean next = DigitalMineStructure.controllerAt(world, pos) != null;
        if (formed != next) {
            if (!next) generation++;
            formed = next;
            net.minecraft.block.state.IBlockState state = world.getBlockState(pos);
            world.notifyBlockUpdate(pos, state, state, 2);
        }
    }
    @Override public NBTTagCompound getUpdateTag() { NBTTagCompound n = new NBTTagCompound(); n.setBoolean("Formed", visualFormed()); return n; }
    @Override public SPacketUpdateTileEntity getUpdatePacket() { return new SPacketUpdateTileEntity(pos, 0, getUpdateTag()); }
    @Override public void handleUpdateTag(NBTTagCompound n) {
        formed = n.getBoolean("Formed");
        // The neighbouring cable's model also depends on this capability probe.
        if (world != null) world.markBlockRangeForRenderUpdate(pos.add(-1, -1, -1), pos.add(1, 1, 1));
    }
    @Override public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity packet) { handleUpdateTag(packet.getNbtCompound()); }
    @Override public boolean hasCapability(Capability<?> cap, @Nullable EnumFacing side) {
        if (world != null && world.isRemote && cap == CapabilityEnergy.ENERGY)
            // Visual advertisement only. getCapability remains null on clients.
            return !isInvalid() && formed;
        if (cap == CapabilityEnergy.ENERGY || cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY)
            return attached() && DigitalMineStructure.controllerAt(world, pos) != null;
        return super.hasCapability(cap, side);
    }
    @Override public <T> T getCapability(Capability<T> cap, @Nullable EnumFacing side) {
        if (cap != CapabilityEnergy.ENERGY && cap != CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) return super.getCapability(cap, side);
        if (!attached()) return null;
        final DigitalMineTile mine = DigitalMineStructure.controllerAt(world, pos);
        if (mine == null) return null;
        final Binding binding = new Binding(mine);
        if (cap == CapabilityEnergy.ENERGY) {
            final IEnergyStorage target = mine.getCapability(CapabilityEnergy.ENERGY, side);
            if (target == null) return null;
            return CapabilityEnergy.ENERGY.cast(new IEnergyStorage() {
                public int receiveEnergy(int amount, boolean simulate) { return binding.valid() ? target.receiveEnergy(amount, simulate) : 0; }
                public int extractEnergy(int amount, boolean simulate) { return 0; }
                public int getEnergyStored() { return binding.valid() ? target.getEnergyStored() : 0; }
                public int getMaxEnergyStored() { return binding.valid() ? target.getMaxEnergyStored() : 0; }
                public boolean canExtract() { return false; }
                public boolean canReceive() { return binding.valid() && target.canReceive(); }
            });
        }
        final IItemHandler target = mine.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, side);
        if (target == null) return null;
        return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(new IItemHandler() {
            public int getSlots() { return binding.valid() ? target.getSlots() : 0; }
            public ItemStack getStackInSlot(int slot) { return binding.valid() ? target.getStackInSlot(slot) : ItemStack.EMPTY; }
            public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) { return stack; }
            public ItemStack extractItem(int slot, int amount, boolean simulate) { return binding.valid() ? target.extractItem(slot, amount, simulate) : ItemStack.EMPTY; }
            public int getSlotLimit(int slot) { return binding.valid() ? target.getSlotLimit(slot) : 0; }
        });
    }
}
