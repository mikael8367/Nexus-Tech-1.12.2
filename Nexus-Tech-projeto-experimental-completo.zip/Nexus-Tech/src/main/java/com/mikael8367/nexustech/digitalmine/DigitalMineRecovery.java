package com.mikael8367.nexustech.digitalmine;

import com.mikael8367.nexustech.NexusTech;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Per-dimension overflow which outlives the controller, including rejected spawns. */
@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class DigitalMineRecovery extends WorldSavedData {
    private static final String KEY = "nexustech_digitalmine_recovery";
    private final List<Entry> entries = new ArrayList<>();
    // The spawn may already have taken effect despite a thrown exception.
    // Such entries are evidence for manual inspection, not a delivery queue.
    private final List<Entry> quarantine = new ArrayList<>();
    private boolean delivering;
    private int next;
    private static final class Entry {
        final BlockPos pos; final ItemStack stack;
        Entry(BlockPos pos, ItemStack stack) { this.pos = pos.toImmutable(); this.stack = stack.copy(); }
    }
    public DigitalMineRecovery() { this(KEY); }
    public DigitalMineRecovery(String name) { super(name); }
    static DigitalMineRecovery get(World world) {
        MapStorage storage = world.getPerWorldStorage();
        DigitalMineRecovery data = (DigitalMineRecovery) storage.getOrLoadData(DigitalMineRecovery.class, KEY);
        if (data == null) { data = new DigitalMineRecovery(KEY); storage.setData(KEY, data); }
        return data;
    }
    void enqueue(BlockPos pos, ItemStack stack) {
        if (!stack.isEmpty()) { entries.add(new Entry(pos, stack)); markDirty(); }
    }
    void quarantine(BlockPos pos, ItemStack stack) {
        if (!stack.isEmpty()) { quarantine.add(new Entry(pos, stack)); markDirty(); }
    }
    int size() { return entries.size(); }
    // Bounded retries without loading chunks or reentry. Trust a normal false
    // return as rejection, but never retry an exception with unknown effects.
    void retry(World world) {
        if (delivering || entries.isEmpty()) return;
        delivering = true;
        try {
            int budget = Math.min(64, entries.size());
            while (budget-- > 0 && !entries.isEmpty()) {
                if (next >= entries.size()) next = 0;
                Entry entry = entries.get(next);
                if (!world.isBlockLoaded(entry.pos)) { next++; continue; }
                // Move BEFORE calling external code: even an intervening save or
                // unexpected Error sees an uncertain entry, not a retryable one.
                // markDirty schedules a save; it is not a synchronous disk commit.
                entries.remove(next);
                quarantine.add(entry);
                markDirty();
                try {
                    boolean spawned = world.spawnEntity(new EntityItem(world, entry.pos.getX()+.5,
                            entry.pos.getY()+.5, entry.pos.getZ()+.5, entry.stack.copy()));
                    if (spawned) quarantine.remove(entry);
                    else { quarantine.remove(entry); entries.add(entry); }
                    markDirty();
                } catch (RuntimeException failedSpawn) {
                    // Keep the evidence; no automatic retry, even if no effect occurred.
                }
            }
        } finally { delivering = false; }
    }
    @SubscribeEvent public static void worldTick(TickEvent.WorldTickEvent event) {
        if (!event.world.isRemote && event.phase == TickEvent.Phase.END && event.world.getTotalWorldTime() % 20 == 0)
            get(event.world).retry(event.world);
    }
    @Override public void readFromNBT(NBTTagCompound nbt) {
        entries.clear(); quarantine.clear(); next = 0;
        readEntries(nbt.getTagList("Entries", 10), entries);
        readEntries(nbt.getTagList("Quarantine", 10), quarantine);
    }
    private static void readEntries(NBTTagList list, List<Entry> target) {
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound tag = list.getCompoundTagAt(i);
            ItemStack stack = new ItemStack(tag.getCompoundTag("Stack"));
            if (!stack.isEmpty()) target.add(new Entry(new BlockPos(tag.getInteger("X"), tag.getInteger("Y"), tag.getInteger("Z")), stack));
        }
    }
    private static NBTTagList writeEntries(List<Entry> entries) {
        NBTTagList list = new NBTTagList();
        for (Entry entry : entries) {
            NBTTagCompound tag = new NBTTagCompound();
            tag.setInteger("X", entry.pos.getX()); tag.setInteger("Y", entry.pos.getY()); tag.setInteger("Z", entry.pos.getZ());
            tag.setTag("Stack", entry.stack.writeToNBT(new NBTTagCompound())); list.appendTag(tag);
        }
        return list;
    }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        nbt.setTag("Entries", writeEntries(entries));
        nbt.setTag("Quarantine", writeEntries(quarantine));
        return nbt;
    }
}
