package com.mikael8367.nexustech.digitalmine;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;

/** All authority decisions are made on the server and revalidated, never from visual state. */
final class DigitalMineStructure {
    private static final String LAST = "NexusDigitalMineHelp";
    private DigitalMineStructure() {}
    static DigitalMineTile controllerAt(World world, BlockPos part) {
        if (world == null || world.isRemote || !world.isBlockLoaded(part)) return null;
        DigitalMineTile found = null;
        // Reverse the footprint transform: controller = part - back*d - right*x - up*y.
        // Every possible origin must be loaded; unknown is not a free reservation.
        for (EnumFacing front : EnumFacing.HORIZONTALS)
            for (int d=0; d<3; d++) for (int y=0; y<2; y++) for (int x=-1; x<=1; x++) {
                BlockPos p = part.offset(front.getOpposite(), -d).offset(front.rotateY(), -x).down(y);
                if (p.getY()<0 || p.getY()>=world.getHeight()) continue;
                if (!world.isBlockLoaded(p)) return null;
                if (!(world.getBlockState(p).getBlock() instanceof DigitalMineBlock)) continue;
                if (world.getBlockState(p).getValue(DigitalMineBlock.FACING) != front) continue;
                TileEntity te = world.getTileEntity(p);
                if (te instanceof DigitalMineTile && ((DigitalMineTile)te).structureValid()) {
                    if (found != null && found != te) return null;
                    found = (DigitalMineTile)te;
                }
            }
        return found;
    }
    static boolean activate(World world, BlockPos part, EntityPlayer player, EnumHand hand) {
        if (world.isRemote || hand != EnumHand.MAIN_HAND) return true;
        DigitalMineTile mine = controllerAt(world, part);
        if (mine != null) {
            if (mine.authorized(player)) player.openGui(com.mikael8367.nexustech.NexusTech.INSTANCE,
                    DigitalMineRegistry.GUI_ID, world, mine.getPos().getX(), mine.getPos().getY(), mine.getPos().getZ());
            return true;
        }
        // A player's own NBT gives a bounded per-player throttle without a global leak.
        long now = world.getTotalWorldTime();
        net.minecraft.nbt.NBTTagCompound data = player.getEntityData();
        if (!data.hasKey(LAST) || now < data.getLong(LAST) || now - data.getLong(LAST) >= 20) {
            data.setLong(LAST, now);
            player.sendMessage(new TextComponentTranslation("chat.nexustech.digitalmine.build"));
        }
        return true;
    }
}
