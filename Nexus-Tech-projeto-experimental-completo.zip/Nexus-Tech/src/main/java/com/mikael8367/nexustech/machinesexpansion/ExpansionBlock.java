package com.mikael8367.nexustech.machinesexpansion;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;

/** Interact without a GUI: held stack inserts, empty hand extracts output;
 * sneak with an empty hand to recover inputs. */
public final class ExpansionBlock extends Block {
    private final boolean alloy;
    ExpansionBlock(String id, boolean alloy) {
        super(Material.IRON); this.alloy = alloy;
        setRegistryName(NexusTech.MODID, id); setUnlocalizedName(NexusTech.MODID + "." + id);
        setHardness(3); setResistance(10); setHarvestLevel("pickaxe", 1); setCreativeTab(NexusTech.CREATIVE_TAB);
    }
    @Override public boolean hasTileEntity(IBlockState state) { return true; }
    @Override public TileEntity createTileEntity(World world, IBlockState state) { return alloy ? new ExpansionTile.Alloy() : new ExpansionTile.Press(); }
    @Override public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing side, float x, float y, float z) {
        if (world.isRemote) return true;
        TileEntity tile = world.getTileEntity(pos);
        if (!(tile instanceof ExpansionTile)) return true;
        IItemHandler inv = tile.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, side);
        if (inv == null) return true;
        ItemStack held = player.getHeldItem(hand);
        if (!held.isEmpty()) {
            ItemStack remaining = inv.insertItem(0, held, false);
            if (!remaining.isEmpty()) remaining = inv.insertItem(1, remaining, false);
            player.setHeldItem(hand, remaining);
        } else {
            ItemStack got = inv.extractItem(player.isSneaking() ? 0 : 2, 64, false);
            if (got.isEmpty() && player.isSneaking()) got = inv.extractItem(1, 64, false);
            if (!got.isEmpty()) player.setHeldItem(hand, got);
        }
        return true;
    }
    @Override public void breakBlock(World world, BlockPos pos, IBlockState state) {
        TileEntity tile = world.getTileEntity(pos);
        if (!world.isRemote && tile instanceof ExpansionTile) {
            ExpansionTile machine = (ExpansionTile) tile;
            for (int i = 0; i < 3; i++) {
                ItemStack stack = machine.drain(i);
                if (!stack.isEmpty()) world.spawnEntity(new EntityItem(world, pos.getX()+0.5, pos.getY()+0.5, pos.getZ()+0.5, stack));
            }
        }
        super.breakBlock(world, pos, state);
    }
}
