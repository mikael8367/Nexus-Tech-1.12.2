package com.mikael8367.nexustech.machinesexpansion;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = NexusTech.MODID, value = Side.CLIENT)
public final class ExpansionClient {
    private ExpansionClient() {}
    @SubscribeEvent public static void models(ModelRegistryEvent e) {
        for (Item item : new Item[] {Item.getItemFromBlock(ExpansionRegistry.PRESS), Item.getItemFromBlock(ExpansionRegistry.ALLOY), ExpansionRegistry.COPPER_PLATE, ExpansionRegistry.TIN_PLATE, ExpansionRegistry.BRONZE, ExpansionRegistry.BRASS})
            ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
    }
}
