package com.mikael8367.nexustech.machinesexpansion;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.oredict.OreDictionary;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class ExpansionRegistry {
    public static final ExpansionBlock PRESS = new ExpansionBlock("nexus_metal_press", false);
    public static final ExpansionBlock ALLOY = new ExpansionBlock("nexus_alloy_smelter", true);
    public static final Item COPPER_PLATE = item("nexus_copper_plate");
    public static final Item TIN_PLATE = item("nexus_tin_plate");
    public static final Item BRONZE = item("nexus_bronze_ingot");
    public static final Item BRASS = item("nexus_brass_ingot");
    private ExpansionRegistry() {}
    private static Item item(String id) { return new Item().setRegistryName(NexusTech.MODID, id).setUnlocalizedName(NexusTech.MODID + "." + id).setCreativeTab(NexusTech.CREATIVE_TAB); }
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e) {
        e.getRegistry().register(PRESS); e.getRegistry().register(ALLOY);
        GameRegistry.registerTileEntity(ExpansionTile.Press.class, new ResourceLocation(NexusTech.MODID, "nexus_metal_press"));
        GameRegistry.registerTileEntity(ExpansionTile.Alloy.class, new ResourceLocation(NexusTech.MODID, "nexus_alloy_smelter"));
    }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> e) {
        for (Block b : new Block[]{PRESS, ALLOY}) e.getRegistry().register(new ItemBlock(b).setRegistryName(b.getRegistryName()));
        for (Item i : new Item[]{COPPER_PLATE, TIN_PLATE, BRONZE, BRASS}) e.getRegistry().register(i);
        OreDictionary.registerOre("plateCopper", COPPER_PLATE); OreDictionary.registerOre("plateTin", TIN_PLATE);
        OreDictionary.registerOre("ingotBronze", BRONZE); OreDictionary.registerOre("ingotBrass", BRASS);
    }
}
