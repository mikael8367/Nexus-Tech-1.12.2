package com.mikael8367.nexustech.machinesexpansion;

import javax.annotation.Nullable;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.oredict.OreDictionary;

/** Fixed inventories; slot 0 is copper (press also accepts tin), slot 1 tin/zinc,
 * slot 2 output. No GUI dependency. Input/output may be extracted on any side. */
public abstract class ExpansionTile extends TileEntity implements ITickable {
    static final int CAPACITY = 20000, RATE = 1000, COST = 20, TIME = 100;
    private final boolean alloy;
    private int energy, progress;
    private boolean processing;
    private final ItemStackHandler inventory = new ItemStackHandler(3) {
        @Override protected void onContentsChanged(int slot) {
            if (!processing && slot < 2) progress = 0;
            markDirty();
        }
    };
    private final IItemHandler access = new IItemHandler() {
        public int getSlots() { return 3; }
        public ItemStack getStackInSlot(int slot) { return inventory.getStackInSlot(slot).copy(); }
        public int getSlotLimit(int slot) { return inventory.getSlotLimit(slot); }
        public boolean isItemValid(int slot, ItemStack stack) { return accepts(slot, stack); }
        public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
            if (!live() || processing || !accepts(slot, stack)) return stack;
            return inventory.insertItem(slot, stack, simulate);
        }
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            if (!live() || processing || amount <= 0) return ItemStack.EMPTY;
            return inventory.extractItem(slot, amount, simulate);
        }
    };
    private final IEnergyStorage power = new IEnergyStorage() {
        public int receiveEnergy(int offered, boolean simulate) {
            if (!live() || processing || offered <= 0) return 0;
            int n = Math.min(Math.min(offered, RATE), CAPACITY - energy);
            if (!simulate && n > 0) { energy += n; markDirty(); }
            return n;
        }
        public int extractEnergy(int amount, boolean simulate) { return 0; }
        public int getEnergyStored() { return energy; }
        public int getMaxEnergyStored() { return CAPACITY; }
        public boolean canExtract() { return false; }
        public boolean canReceive() { return true; }
    };
    protected ExpansionTile(boolean alloy) { this.alloy = alloy; }
    public static final class Press extends ExpansionTile { public Press() { super(false); } }
    public static final class Alloy extends ExpansionTile { public Alloy() { super(true); } }
    private boolean live() { return world != null && !world.isRemote && !isInvalid() && world.isBlockLoaded(pos) && world.getTileEntity(pos) == this; }
    private static boolean ore(ItemStack s, String key) {
        if (s.isEmpty() || s.hasTagCompound() || s.isItemDamaged() || s.getItem().hasContainerItem(s)) return false;
        int id = OreDictionary.getOreID(key);
        for (int n : OreDictionary.getOreIDs(s)) if (n == id) return true;
        return false;
    }
    private boolean accepts(int slot, ItemStack stack) {
        if (slot == 0) return ore(stack, "ingotCopper") || (!alloy && ore(stack, "ingotTin"));
        return alloy && slot == 1 && (ore(stack, "ingotTin") || ore(stack, "ingotZinc"));
    }
    private ItemStack result() {
        ItemStack a = inventory.getStackInSlot(0), b = inventory.getStackInSlot(1);
        if (alloy) {
            if (a.getCount() < 3 || b.getCount() < 1 || !ore(a, "ingotCopper")) return ItemStack.EMPTY;
            if (ore(b, "ingotTin")) return new ItemStack(ExpansionRegistry.BRONZE, 4);
            if (ore(b, "ingotZinc")) return new ItemStack(ExpansionRegistry.BRASS, 4);
        } else {
            if (ore(a, "ingotCopper")) return new ItemStack(ExpansionRegistry.COPPER_PLATE);
            if (ore(a, "ingotTin")) return new ItemStack(ExpansionRegistry.TIN_PLATE);
        }
        return ItemStack.EMPTY;
    }
    private boolean fits(ItemStack result) {
        ItemStack out = inventory.getStackInSlot(2);
        if (result.isEmpty()) return false;
        int limit = Math.min(inventory.getSlotLimit(2), result.getMaxStackSize());
        return out.isEmpty() ? result.getCount() <= limit : ItemStack.areItemsEqual(out, result)
                && ItemStack.areItemStackTagsEqual(out, result) && out.getCount() <= limit - result.getCount();
    }
    /** Pull when needed: expansion batteries are passive and cannot push to us.
     * Do not load neighbouring chunks or credit a tile removed by a foreign callback. */
    private void pullEnergy() {
        if (!live() || processing) return;
        final net.minecraft.world.World expectedWorld = world;
        final net.minecraft.util.math.BlockPos origin = pos.toImmutable();
        processing = true;
        try {
            for (EnumFacing side : EnumFacing.VALUES) {
                if (world != expectedWorld || !pos.equals(origin) || !live() || energy >= COST) break;
                net.minecraft.util.math.BlockPos next = origin.offset(side);
                if (!expectedWorld.isBlockLoaded(next)) continue;
                try {
                    TileEntity source = expectedWorld.getTileEntity(next);
                    if (source == null || source.isInvalid()) continue;
                    IEnergyStorage handler = source.getCapability(CapabilityEnergy.ENERGY, side.getOpposite());
                    if (handler == null || !handler.canExtract()) continue;
                    if (world != expectedWorld || !pos.equals(origin) || !live()
                            || !expectedWorld.isBlockLoaded(next) || expectedWorld.getTileEntity(next) != source
                            || source.isInvalid() || source.getCapability(CapabilityEnergy.ENERGY, side.getOpposite()) != handler) continue;
                    if (world != expectedWorld || !pos.equals(origin) || !live()
                            || !expectedWorld.isBlockLoaded(next) || expectedWorld.getTileEntity(next) != source || source.isInvalid()) continue;
                    // Limit the request to actual free capacity, and reserve exclusive access
                    // via processing until the foreign call returns.
                    int request = Math.min(RATE, CAPACITY - energy);
                    int received = handler.extractEnergy(request, false);
                    if (world != expectedWorld || !pos.equals(origin) || !live()) break;
                    // Invalid return values have no reliable conservation semantics.
                    if (received > 0 && received <= request) { energy += received; markDirty(); }
                } catch (RuntimeException ignored) {
                    // A source may have mutated before throwing; never credit unknown FE.
                }
            }
        } finally { processing = false; }
    }
    @Override public void update() {
        if (!live() || processing) return;
        ItemStack output = result();
        if (!fits(output)) { if (progress != 0) { progress = 0; markDirty(); } return; }
        if (energy < COST) {
            pullEnergy();
            if (!live()) return;
            output = result();
            if (!fits(output)) { if (progress != 0) { progress = 0; markDirty(); } return; }
        }
        if (energy < COST) return;
        processing = true;
        try {
            energy -= COST; progress++;
            if (progress >= TIME) {
                ItemStack current = inventory.getStackInSlot(2);
                if (current.isEmpty()) inventory.setStackInSlot(2, output.copy());
                else { ItemStack next = current.copy(); next.grow(output.getCount()); inventory.setStackInSlot(2, next); }
                inventory.extractItem(0, alloy ? 3 : 1, false);
                if (alloy) inventory.extractItem(1, 1, false);
                progress = 0;
            }
            markDirty();
        } finally { processing = false; }
    }
    ItemStack drain(int slot) { return inventory.extractItem(slot, Integer.MAX_VALUE, false); }
    @Override public boolean hasCapability(Capability<?> cap, @Nullable EnumFacing side) {
        return cap == CapabilityEnergy.ENERGY || cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability(cap, side);
    }
    @Override public <T> T getCapability(Capability<T> cap, @Nullable EnumFacing side) {
        if (cap == CapabilityEnergy.ENERGY) return CapabilityEnergy.ENERGY.cast(power);
        if (cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(access);
        return super.getCapability(cap, side);
    }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag); tag.setInteger("Energy", energy); tag.setInteger("Progress", progress); tag.setTag("Inventory", inventory.serializeNBT()); return tag;
    }
    @Override public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag);
        energy = Math.max(0, Math.min(CAPACITY, tag.getInteger("Energy")));
        if (tag.hasKey("Inventory", 10)) { NBTTagCompound saved = tag.getCompoundTag("Inventory").copy(); saved.setInteger("Size", 3); inventory.deserializeNBT(saved); }
        progress = Math.max(0, Math.min(TIME - 1, tag.getInteger("Progress")));
    }
}
