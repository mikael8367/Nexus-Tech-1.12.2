package com.mikael8367.nexustech.nuclear;

import com.mikael8367.nexustech.NexusTech;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Per-dimension recovery survives removal of the controller and rejected entity spawns. */
@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class NuclearRecovery extends WorldSavedData {
 private static final String KEY="nexustech_nuclear_recovery";
 private final List<Entry> entries=new ArrayList<>();
 private boolean delivering;
 private int next;
 private static final class Entry {
  final BlockPos pos; final ItemStack stack; boolean quarantined;
  Entry(BlockPos p,ItemStack s){pos=p.toImmutable();stack=s.copy();}
 }
 public NuclearRecovery(){this(KEY);}
 public NuclearRecovery(String name){super(name);}
 static NuclearRecovery get(World w){
  MapStorage storage=w.getPerWorldStorage();
  NuclearRecovery data=(NuclearRecovery)storage.getOrLoadData(NuclearRecovery.class,KEY);
  if(data==null){data=new NuclearRecovery(KEY);storage.setData(KEY,data);}
  return data;
 }
 void enqueue(BlockPos pos,ItemStack stack){if(!stack.isEmpty()){entries.add(new Entry(pos,stack));markDirty();}}
 int size(){return entries.size();}
 void retry(World w){
  if(delivering || entries.isEmpty())return;
  delivering=true;
  try{
   int budget=Math.min(64,entries.size());
   while(budget-->0 && !entries.isEmpty()){
    if(next>=entries.size())next=0;
    Entry e=entries.get(next);boolean spawned=false;
    if(!e.quarantined && w.isBlockLoaded(e.pos)){
     // Reentrant serialization must see uncertainty before invoking external code.
     // markDirty schedules a save; it is not a synchronous disk commit.
     e.quarantined=true;markDirty();
     try{
      spawned=w.spawnEntity(new EntityItem(w,e.pos.getX()+.5,e.pos.getY()+.5,e.pos.getZ()+.5,e.stack.copy()));
      if(!spawned){e.quarantined=false;markDirty();} // normal false is a definite rejection
     }
     catch(RuntimeException ex){
      // A callback may have spawned the entity before throwing. Do not retry
      // uncertain delivery automatically; preserve the entry for inspection.
      org.apache.logging.log4j.LogManager.getLogger("NexusTech").error("Nuclear recovery delivery indeterminate at {}; entry quarantined",e.pos,ex);
     }
    }
    if(spawned){entries.remove(next);markDirty();}else next++;
   }
  }finally{delivering=false;}
 }
 @SubscribeEvent public static void worldTick(TickEvent.WorldTickEvent e){
  if(!e.world.isRemote && e.phase==TickEvent.Phase.END && e.world.getTotalWorldTime()%20==0)get(e.world).retry(e.world);
 }
 @Override public void readFromNBT(NBTTagCompound n){
  entries.clear();next=0;
  NBTTagList list=n.getTagList("Entries",10);
  for(int i=0;i<list.tagCount();i++){
   NBTTagCompound t=list.getCompoundTagAt(i);ItemStack s=new ItemStack(t.getCompoundTag("Stack"));
   if(!s.isEmpty()){Entry e=new Entry(new BlockPos(t.getInteger("X"),t.getInteger("Y"),t.getInteger("Z")),s);e.quarantined=t.getBoolean("Quarantined");entries.add(e);}
  }
 }
 @Override public NBTTagCompound writeToNBT(NBTTagCompound n){
  NBTTagList list=new NBTTagList();
  for(Entry e:entries){NBTTagCompound t=new NBTTagCompound();t.setInteger("X",e.pos.getX());t.setInteger("Y",e.pos.getY());t.setInteger("Z",e.pos.getZ());t.setBoolean("Quarantined",e.quarantined);t.setTag("Stack",e.stack.writeToNBT(new NBTTagCompound()));list.appendTag(t);}
  n.setTag("Entries",list);return n;
 }
}
