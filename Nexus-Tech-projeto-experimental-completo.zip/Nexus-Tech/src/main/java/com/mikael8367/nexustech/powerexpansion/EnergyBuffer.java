package com.mikael8367.nexustech.powerexpansion;

/** Integer FE buffer. Each direction has a shared budget across all faces per world tick. */
public final class EnergyBuffer {
    private final int capacity, inputRate, outputRate;
    private int stored, inputUsed, outputUsed;
    private long tick = Long.MIN_VALUE;

    public EnergyBuffer(int capacity, int inputRate, int outputRate) {
        if (capacity <= 0 || inputRate < 0 || outputRate < 0) throw new IllegalArgumentException();
        this.capacity = capacity; this.inputRate = inputRate; this.outputRate = outputRate;
    }
    private void reset(long now) {
        if (tick != now) { tick = now; inputUsed = outputUsed = 0; }
    }
    public int receive(int amount, boolean simulate, long now) {
        reset(now);
        int n = Math.min(Math.max(0, amount), Math.min(capacity - stored, inputRate - inputUsed));
        if (!simulate) { stored += n; inputUsed += n; }
        return n;
    }
    public int extract(int amount, boolean simulate, long now) {
        reset(now);
        int n = Math.min(Math.max(0, amount), Math.min(stored, outputRate - outputUsed));
        if (!simulate) { stored -= n; outputUsed += n; }
        return n;
    }
    /** Internal solar production is not an external input. */
    public int generate(int amount) {
        int n = Math.min(Math.max(0, amount), capacity - stored);
        stored += n; return n;
    }
    /** Refund only an unaccepted part of the same reservation, before another call. */
    public void refundOutput(int amount) {
        if (amount < 0 || amount > outputUsed || amount > capacity - stored) throw new IllegalArgumentException();
        stored += amount; outputUsed -= amount;
    }
    public int stored() { return stored; }
    public int capacity() { return capacity; }
    public void load(int amount) { stored = Math.max(0, Math.min(capacity, amount)); inputUsed = outputUsed = 0; tick = Long.MIN_VALUE; }
}
