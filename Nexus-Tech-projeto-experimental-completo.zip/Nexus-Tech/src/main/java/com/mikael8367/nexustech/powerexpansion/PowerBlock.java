package com.mikael8367.nexustech.powerexpansion;

import javax.annotation.Nullable;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public final class PowerBlock extends Block {
    enum Type { ADVANCED, ELITE, SOLAR }
    private final Type type;
    private static final AxisAlignedBB PANEL = new AxisAlignedBB(0, 0, 0, 1, 0.90625, 1);
    PowerBlock(String name, Type type) {
        super(Material.IRON); this.type = type;
        setRegistryName(NexusTech.MODID, name); setUnlocalizedName(NexusTech.MODID + "." + name);
        setCreativeTab(NexusTech.CREATIVE_TAB); setHardness(3.0F); setResistance(10.0F);
        if (type == Type.SOLAR) { fullBlock = false; setLightOpacity(0); }
    }
    @Override public boolean isOpaqueCube(IBlockState state) { return type != Type.SOLAR; }
    @Override public boolean isFullCube(IBlockState state) { return type != Type.SOLAR; }
    @Override public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess world, BlockPos pos) {
        return type == Type.SOLAR ? PANEL : FULL_BLOCK_AABB;
    }
    @Override public boolean hasTileEntity(IBlockState state) { return true; }
    @Override public TileEntity createTileEntity(World world, IBlockState state) {
        switch (type) {
            case ADVANCED: return new PowerTile.AdvancedBattery();
            case ELITE: return new PowerTile.EliteBattery();
            default: return new PowerTile.LargeSolar();
        }
    }
    @Override public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player,
                                               EnumHand hand, EnumFacing face, float x, float y, float z) {
        if (!world.isRemote) {
            TileEntity tile = world.getTileEntity(pos);
            if (tile instanceof PowerTile) {
                EnergyBuffer b = ((PowerTile) tile).buffer;
                player.sendStatusMessage(new TextComponentTranslation("message.nexustech.powerexpansion.energy", b.stored(), b.capacity()), true);
            }
        }
        return true;
    }
    @Override public void onBlockPlacedBy(World world, BlockPos pos, IBlockState state,
                                           @Nullable EntityLivingBase placer, ItemStack stack) {
        super.onBlockPlacedBy(world, pos, state, placer, stack);
        if (!world.isRemote && world.getTileEntity(pos) instanceof PowerTile) {
            ((PowerTile) world.getTileEntity(pos)).restoreItemEnergy(stack.getTagCompound());
        }
    }
    @Override public void getDrops(NonNullList<ItemStack> drops, IBlockAccess world, BlockPos pos,
                                   IBlockState state, int fortune) {
        ItemStack stack = new ItemStack(this);
        TileEntity tile = world.getTileEntity(pos);
        if (tile instanceof PowerTile && ((PowerTile) tile).buffer.stored() > 0) {
            NBTTagCompound tag = new NBTTagCompound();
            tag.setInteger(PowerTile.ENERGY_KEY, ((PowerTile) tile).buffer.stored());
            stack.setTagCompound(tag);
        }
        drops.add(stack);
    }
    // Keep the tile alive until harvestBlock reads its energy. Creative removal stays immediate.
    @Override public boolean removedByPlayer(IBlockState state, World world, BlockPos pos,
                                              EntityPlayer player, boolean willHarvest) {
        if (!willHarvest) return super.removedByPlayer(state, world, pos, player, false);
        onBlockHarvested(world, pos, state, player);
        return true;
    }
    @Override public void harvestBlock(World world, EntityPlayer player, BlockPos pos, IBlockState state,
                                       @Nullable TileEntity tile, ItemStack tool) {
        PowerTile power = tile instanceof PowerTile ? (PowerTile) tile : null;
        if (power != null) power.harvesting = true; // freeze FE during drop callbacks
        try {
            super.harvestBlock(world, player, pos, state, tile, tool);
            // A callback may replace the block; never delete its replacement.
            if (world.getBlockState(pos).getBlock() == this && world.getTileEntity(pos) == tile) {
                world.setBlockToAir(pos);
            }
        } finally {
            if (power != null) power.harvesting = false;
        }
    }
    @Override public boolean canSilkHarvest(World world, BlockPos pos, IBlockState state, EntityPlayer player) {
        return false; // use the same energy-preserving drop path for every pickaxe
    }
}
