package com.mikael8367.nexustech.powerexpansion;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class PowerRegistry {
    public static final PowerBlock ADVANCED = new PowerBlock("powerexpansion_battery_advanced", PowerBlock.Type.ADVANCED);
    public static final PowerBlock ELITE = new PowerBlock("powerexpansion_battery_elite", PowerBlock.Type.ELITE);
    public static final PowerBlock SOLAR = new PowerBlock("powerexpansion_solar_large", PowerBlock.Type.SOLAR);
    public static final Block[] BLOCKS = { ADVANCED, ELITE, SOLAR };
    private PowerRegistry() { }
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> event) {
        for (Block b : BLOCKS) event.getRegistry().register(b);
        GameRegistry.registerTileEntity(PowerTile.AdvancedBattery.class, id("powerexpansion_battery_advanced"));
        GameRegistry.registerTileEntity(PowerTile.EliteBattery.class, id("powerexpansion_battery_elite"));
        GameRegistry.registerTileEntity(PowerTile.LargeSolar.class, id("powerexpansion_solar_large"));
    }
    private static ResourceLocation id(String name) { return new ResourceLocation(NexusTech.MODID, name); }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> event) {
        for (Block b : BLOCKS) {
            ItemBlock item = new ItemBlock(b);
            item.setRegistryName(b.getRegistryName());
            item.setMaxStackSize(1); // a charged block is always a distinct item
            event.getRegistry().register(item);
        }
    }
}
