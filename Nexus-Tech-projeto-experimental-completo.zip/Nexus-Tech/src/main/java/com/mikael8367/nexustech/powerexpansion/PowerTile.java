package com.mikael8367.nexustech.powerexpansion;

import javax.annotation.Nullable;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;

/** Passive FE batteries and an actively pushing solar generator. */
public abstract class PowerTile extends TileEntity {
    static final String ENERGY_KEY = "PowerExpansionEnergy";
    final EnergyBuffer buffer;
    private final boolean input;
    boolean pushing;
    boolean harvesting;
    private final IEnergyStorage storage = new IEnergyStorage() {
        public int receiveEnergy(int amount, boolean simulate) {
            if (!input || pushing || !live()) return 0;
            int n = buffer.receive(amount, simulate, world.getTotalWorldTime());
            if (!simulate && n > 0) markDirty();
            return n;
        }
        public int extractEnergy(int amount, boolean simulate) {
            if (pushing || !live() || !outputAllowed()) return 0;
            int n = buffer.extract(amount, simulate, world.getTotalWorldTime());
            if (!simulate && n > 0) markDirty();
            return n;
        }
        public int getEnergyStored() { return buffer.stored(); }
        public int getMaxEnergyStored() { return buffer.capacity(); }
        public boolean canExtract() { return true; }
        public boolean canReceive() { return input; }
    };
    protected PowerTile(int capacity, int inputRate, int outputRate) {
        buffer = new EnergyBuffer(capacity, inputRate, outputRate);
        input = inputRate > 0;
    }
    public static final class AdvancedBattery extends PowerTile {
        public AdvancedBattery() { super(1000000, 4000, 4000); }
    }
    public static final class EliteBattery extends PowerTile {
        public EliteBattery() { super(10000000, 16000, 16000); }
    }
    public static final class LargeSolar extends PowerTile implements ITickable {
        public LargeSolar() { super(8192, 0, 512); }
        @Override boolean outputAllowed() {
            BlockPos sky = pos.up();
            return world.provider.hasSkyLight() && world.isDaytime() && !world.isRaining()
                    && !world.isThundering() && world.isBlockLoaded(sky) && world.canSeeSky(sky);
        }
        @Override public void update() {
            if (pushing || !live() || !outputAllowed()) return;
            if (buffer.generate(64) > 0) markDirty();
            push();
        }
    }
    boolean outputAllowed() { return true; }
    final boolean live() {
        return world != null && !world.isRemote && !isInvalid() && !harvesting && world.isBlockLoaded(pos)
                && world.getTileEntity(pos) == this;
    }
    final void push() {
        if (!live() || pushing) return;
        pushing = true;
        try { for (EnumFacing side : EnumFacing.VALUES) {
            if (!live()) return;
            BlockPos next = pos.offset(side);
            if (!world.isBlockLoaded(next)) continue;
            TileEntity target = world.getTileEntity(next);
            if (target == null || target.isInvalid()) continue;
            IEnergyStorage receiver;
            try { receiver = target.getCapability(CapabilityEnergy.ENERGY, side.getOpposite()); }
            catch (RuntimeException ignored) { continue; }
            if (receiver == null) continue;
            try { if (!receiver.canReceive()) continue; }
            catch (RuntimeException ignored) { continue; }
            if (!live() || !world.isBlockLoaded(next) || world.getTileEntity(next) != target || target.isInvalid()) continue;
            int offered = buffer.extract(Integer.MAX_VALUE, false, world.getTotalWorldTime());
            if (offered == 0) return;
            markDirty(); // reserve before invoking external code
            try {
                int accepted = receiver.receiveEnergy(offered, false);
                // Invalid return values are not trusted; never refund if receiver claimed more than offered.
                if (accepted >= 0 && accepted <= offered && live()) {
                    int remainder = offered - accepted;
                    if (remainder > 0) { buffer.refundOutput(remainder); markDirty(); }
                }
            } catch (RuntimeException ignored) {
                // Mutation may already have happened: keep the entire offer debited.
            }
        } } finally { pushing = false; }
    }
    @Override public boolean hasCapability(Capability<?> cap, @Nullable EnumFacing face) {
        return cap == CapabilityEnergy.ENERGY || super.hasCapability(cap, face);
    }
    @Override public <T> T getCapability(Capability<T> cap, @Nullable EnumFacing face) {
        if (cap == CapabilityEnergy.ENERGY) return CapabilityEnergy.ENERGY.cast(storage);
        return super.getCapability(cap, face);
    }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        super.writeToNBT(nbt); nbt.setInteger(ENERGY_KEY, buffer.stored()); return nbt;
    }
    @Override public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt); buffer.load(nbt.getInteger(ENERGY_KEY));
    }
    void restoreItemEnergy(NBTTagCompound tag) {
        if (tag != null) { buffer.load(tag.getInteger(ENERGY_KEY)); markDirty(); }
    }
}
