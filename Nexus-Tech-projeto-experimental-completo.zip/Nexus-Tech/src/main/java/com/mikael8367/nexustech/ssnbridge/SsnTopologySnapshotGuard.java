package com.mikael8367.nexustech.ssnbridge;

import com.mikael8367.nexustech.BridgeTile;
import com.mikael8367.nexustech.ModRegistry;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;

/**
 * Read-only, point-in-time prevalidation of a HYPOTHETICAL six-sided bridge.
 * Never exposes a capability or refreshes a master. A completed snapshot is NOT
 * permission to connect: later topology/chunk changes can destroy a master.
 * Intentionally accepts only exact plain SSN cables and masters; any other
 * tile on the boundary is unknown, including SSN IO/link cables and chests.
 */
public final class SsnTopologySnapshotGuard {
    public enum State {
        INVALID_CONTEXT, SSN_ABSENT, UNSUPPORTED_VERSION, API_UNAVAILABLE,
        UNLOADED, NOT_BRIDGE, UNKNOWN_TILE, INCONSISTENT_CABLE,
        TOO_LARGE, NO_MASTER, ONE_MASTER, MULTIPLE_MASTERS, ERROR
    }
    public static final class Result {
        public final State state;
        /** Present only for ONE_MASTER, and not a safe-to-connect token. */
        public final BlockPos masterPos;
        public final int exploredNodes;
        private Result(State state, BlockPos masterPos, int exploredNodes) {
            this.state = state; this.masterPos = masterPos; this.exploredNodes = exploredNodes;
        }
    }
    private static final int MAX_NODES = 1024;
    private SsnTopologySnapshotGuard() { }
    private static Result result(State s, int count) { return new Result(s, null, count); }

    /** Invoke only on the authoritative server thread; no unloaded chunks are read. */
    public static Result inspect(World world, BlockPos bridgePos) {
        if (world == null || bridgePos == null || world.isRemote || world.provider == null)
            return result(State.INVALID_CONTEXT, 0);
        try {
            MinecraftServer server = world.getMinecraftServer();
            if (server == null || !server.isCallingFromMinecraftThread()) return result(State.INVALID_CONTEXT, 0);
            if (!world.isValid(bridgePos)) return result(State.INVALID_CONTEXT, 0);
            if (!world.isBlockLoaded(bridgePos)) return result(State.UNLOADED, 0);
            if (world.getBlockState(bridgePos).getBlock() != ModRegistry.BRIDGE) return result(State.NOT_BRIDGE, 0);
            if (!Loader.isModLoaded("storagenetwork")) return result(State.SSN_ABSENT, 0);
            ModContainer mod = Loader.instance().getIndexedModList().get("storagenetwork");
            if (mod == null || !SsnAdjacentProbe.supportedVersion(mod.getVersion()))
                return result(State.UNSUPPORTED_VERSION, 0);
            ClassLoader cl = SsnTopologySnapshotGuard.class.getClassLoader();
            Class<?> holder = Class.forName("mrriegel.storagenetwork.capabilities.StorageNetworkCapabilities", false, cl);
            Field field = holder.getField("CONNECTABLE_CAPABILITY");
            if (!Modifier.isStatic(field.getModifiers()) || field.getType() != Capability.class)
                return result(State.API_UNAVAILABLE, 0);
            Object cap = field.get(null);
            if (!(cap instanceof Capability)) return result(State.API_UNAVAILABLE, 0);
            SsnAdjacentProbe.Api api = new SsnAdjacentProbe.Api((Capability<?>)cap,
                Class.forName("mrriegel.storagenetwork.api.capability.IConnectable", false, cl),
                Class.forName("mrriegel.storagenetwork.api.data.DimPos", false, cl),
                Class.forName("mrriegel.storagenetwork.block.cable.TileCable", false, cl),
                Class.forName("mrriegel.storagenetwork.block.master.TileMaster", false, cl),
                Class.forName("mrriegel.storagenetwork.api.network.INetworkMaster", false, cl));
            return inspectPrepared(world, bridgePos, api, MAX_NODES);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError ex) {
            return result(State.API_UNAVAILABLE, 0);
        }
    }

    /* Package-private for tests. This method assumes the caller enforces server thread and version. */
    static Result inspectPrepared(World world, BlockPos bridgePos, SsnAdjacentProbe.Api api, int maxNodes) {
        if (world == null || world.isRemote || world.provider == null || bridgePos == null || api == null || maxNodes < 1 || maxNodes > MAX_NODES)
            return result(State.INVALID_CONTEXT, 0);
        int count = 0;
        try {
            if (!world.isValid(bridgePos)) return result(State.INVALID_CONTEXT, 0);
            if (!world.isBlockLoaded(bridgePos)) return result(State.UNLOADED, 0);
            TileEntity bridge = world.getTileEntity(bridgePos);
            if (!(bridge instanceof BridgeTile) || bridge.isInvalid() || bridge.getWorld() != world || !bridgePos.equals(bridge.getPos()))
                return result(State.NOT_BRIDGE, 0);
            Set<BlockPos> visited = new HashSet<>();
            ArrayDeque<BlockPos> pending = new ArrayDeque<>();
            BlockPos origin = bridgePos.toImmutable();
            visited.add(origin); pending.add(origin);
            BlockPos foundMaster = null;
            int dim = world.provider.getDimension();
            while (!pending.isEmpty()) {
                BlockPos current = pending.removeFirst();
                count++;
                for (EnumFacing direction : EnumFacing.values()) {
                    BlockPos next = current.offset(direction).toImmutable();
                    if (visited.contains(next)) continue;
                    if (!world.isValid(next)) return result(State.INVALID_CONTEXT, count);
                    if (!world.isBlockLoaded(next)) return result(State.UNLOADED, count);
                    TileEntity tile = world.getTileEntity(next);
                    if (tile == null) {
                        if (SsnAdjacentProbe.missingTileState(world, next) != SsnAdjacentProbe.State.NOT_PLAIN_SSN_CABLE)
                            return result(State.UNKNOWN_TILE, count);
                        continue;
                    }
                    if (tile.isInvalid() || tile.getWorld() != world || !next.equals(tile.getPos()))
                        return result(State.UNKNOWN_TILE, count);
                    boolean isMaster = tile.getClass() == api.master && api.masterApi.isInstance(tile);
                    if (isMaster) {
                        if (foundMaster != null && !foundMaster.equals(next)) return result(State.MULTIPLE_MASTERS, count);
                        foundMaster = next;
                    } else {
                        // Do not invoke capabilities on unknown third-party tiles.
                        if (tile.getClass() != api.cable) return result(State.UNKNOWN_TILE, count);
                        EnumFacing entryFace = direction.getOpposite();
                        if (!tile.hasCapability(api.cap, entryFace)) return result(State.INCONSISTENT_CABLE, count);
                        Object con = tile.getCapability(api.cap, entryFace);
                        if (!api.connectable.isInstance(con)) return result(State.INCONSISTENT_CABLE, count);
                        Object self = api.self.invoke(con);
                        if (!api.dimPos.isInstance(self) || api.dimension.getInt(self) != dim || !next.equals(api.blockPos.invoke(self)))
                            return result(State.INCONSISTENT_CABLE, count);
                    }
                    if (visited.size() >= maxNodes) return result(State.TOO_LARGE, count);
                    visited.add(next); pending.add(next);
                }
            }
            return foundMaster == null ? result(State.NO_MASTER, count) : new Result(State.ONE_MASTER, foundMaster, count);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError ex) {
            return result(State.ERROR, count);
        }
    }
}
