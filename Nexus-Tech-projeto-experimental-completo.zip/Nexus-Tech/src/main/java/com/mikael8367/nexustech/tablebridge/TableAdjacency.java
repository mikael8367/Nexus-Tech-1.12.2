package com.mikael8367.nexustech.tablebridge;

import com.mikael8367.nexustech.BridgeTile;
import com.mikael8367.nexustech.ModRegistry;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;

/** Stateless, server-side observation only. ADJACENT is NOT a working connection. */
public final class TableAdjacency {
    public enum Result { ADJACENT_ONLY, NO_MATCH, UNLOADED, UNAVAILABLE, INVALID_INPUT, ERROR }
    private static final String VERSION = "1.12.2-PE1.4.1";
    private static final ResourceLocation TABLE_ID = new ResourceLocation("projecte", "transmutation_table");
    private TableAdjacency() { }

    /** Must be called on the server world thread. No state or authorization is retained. */
    public static Result inspect(World world, BlockPos cablePos, EnumFacing direction) {
        if (!(world instanceof WorldServer) || world.isRemote || cablePos == null || direction == null) return Result.INVALID_INPUT;
        try {
            MinecraftServer server = world.getMinecraftServer();
            if (server == null || !server.isCallingFromMinecraftThread()) return Result.INVALID_INPUT;
            if (!Loader.isModLoaded("projecte")) return Result.UNAVAILABLE;
            ModContainer mod = Loader.instance().getIndexedModList().get("projecte");
            if (mod == null || !VERSION.equals(mod.getVersion())) return Result.UNAVAILABLE;
            ClassLoader loader = TableAdjacency.class.getClassLoader();
            Class<?> holder = Class.forName("moze_intel.projecte.gameObjs.ObjHandler", false, loader);
            Class<?> tableClass = Class.forName("moze_intel.projecte.gameObjs.blocks.TransmutationStone", false, loader);
            Field field = holder.getField("transmuteStone");
            if (!Modifier.isStatic(field.getModifiers()) || field.getType() != Block.class) return Result.UNAVAILABLE;
            Object table = field.get(null);
            if (table == null || table.getClass() != tableClass || !(table instanceof Block)
                    || !TABLE_ID.equals(((Block)table).getRegistryName())) return Result.UNAVAILABLE;
            return inspectWithExpectedBlocks(world, cablePos, direction, ModRegistry.BRIDGE, (Block)table);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            return Result.ERROR;
        }
    }

    // Injection is solely for standalone tests. Production always resolves the real block above.
    static Result inspectWithExpectedBlocks(World world, BlockPos cablePos, EnumFacing direction,
                                             Block expectedCable, Block expectedTable) {
        if (world == null || world.isRemote || cablePos == null || direction == null
                || expectedCable == null || expectedTable == null || expectedCable == expectedTable) return Result.INVALID_INPUT;
        BlockPos neighbor = cablePos.offset(direction);
        try {
            if (!world.isValid(cablePos) || !world.isValid(neighbor)) return Result.INVALID_INPUT;
            // Do not touch states or tiles of unloaded chunks, even transiently.
            if (!world.isBlockLoaded(cablePos) || !world.isBlockLoaded(neighbor)) return Result.UNLOADED;
            IBlockState cableState = world.getBlockState(cablePos);
            if (cableState == null || cableState.getBlock() != expectedCable) return Result.NO_MATCH;
            TileEntity tile = world.getTileEntity(cablePos);
            if (!(tile instanceof BridgeTile) || tile.isInvalid() || tile.getWorld() != world
                    || !cablePos.equals(tile.getPos())) return Result.NO_MATCH;
            IBlockState tableState = world.getBlockState(neighbor);
            if (tableState == null || tableState.getBlock() != expectedTable) return Result.NO_MATCH;
            // PE's TransmutationStone has no tile entity. Proximity alone is all we can assert.
            return Result.ADJACENT_ONLY;
        } catch (RuntimeException | LinkageError e) {
            return Result.ERROR;
        }
    }
}
