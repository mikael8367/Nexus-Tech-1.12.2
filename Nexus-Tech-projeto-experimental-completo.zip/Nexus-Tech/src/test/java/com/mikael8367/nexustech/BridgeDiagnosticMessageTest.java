package com.mikael8367.nexustech;

import com.mikael8367.nexustech.ssnbridge.SsnAdjacentProbe.State;
import com.mikael8367.nexustech.tablebridge.TableAdjacency.Result;
import net.minecraft.init.Bootstrap;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

/** Pure regression checks: no mod/network mutation or live client required. */
public final class BridgeDiagnosticMessageTest {
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    private static int face(Result t, State s) { return (t.ordinal() + 1) | ((s.ordinal() + 1) << 3); }
    public static void main(String[] args) {
        check(BridgeDiagnosticMessage.explain(new int[6], true).isEmpty(), "unobserved");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.NO_MATCH, State.NOT_PLAIN_SSN_CABLE)}, true).isEmpty(), "no failure");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.NO_MATCH, State.UNKNOWN_TILE)}, true).contains("nao identificado"), "unknown not empty");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.NO_MATCH, State.NO_MASTER)}, true).contains("sem controlador"), "no master");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.UNAVAILABLE, State.NOT_PLAIN_SSN_CABLE)}, true).contains("ProjectE"), "unavailable table API");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.NO_MATCH, State.UNLOADED)}, true).contains("nao carregada"), "unloaded");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.NO_MATCH, State.UNSUPPORTED_VERSION)}, false).contains("incompatible"), "unsupported SSN");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.NO_MATCH, State.UNKNOWN_TILE), face(Result.NO_MATCH, State.API_UNAVAILABLE)}, false).contains("incompatible"), "priority");
        check(BridgeDiagnosticMessage.explain(new int[] {face(Result.ERROR, State.ASSIGNED_MASTER)}, false).contains("error"), "table error");
        Bootstrap.register();
        BridgeBlock block = ModRegistry.BRIDGE;
        AxisAlignedBB box = block.getBoundingBox(block.getDefaultState(), null, BlockPos.ORIGIN);
        check(box.minX == 5.0/16 && box.minY == 5.0/16 && box.minZ == 5.0/16
            && box.maxX == 11.0/16 && box.maxY == 11.0/16 && box.maxZ == 11.0/16, "hitbox matches body");
        Bootstrap.printToSYSOUT("PASS bridge diagnostic explanations and body hitbox");
    }
}
