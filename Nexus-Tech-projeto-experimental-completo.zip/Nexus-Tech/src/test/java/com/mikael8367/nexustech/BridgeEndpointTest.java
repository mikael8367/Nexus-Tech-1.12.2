package com.mikael8367.nexustech;

import com.mikael8367.nexustech.ssnbridge.SsnAdjacentProbe;
import com.mikael8367.nexustech.tablebridge.TableAdjacency;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

/** Snapshot composition uses simulated observations, never live mods. */
public final class BridgeEndpointTest {
    static void check(boolean b, String m) { if (!b) throw new AssertionError(m); }
    static SsnAdjacentProbe.Result result(SsnAdjacentProbe.State s, BlockPos p) throws Exception {
        Constructor<SsnAdjacentProbe.Result> c = SsnAdjacentProbe.Result.class.getDeclaredConstructor(SsnAdjacentProbe.State.class, BlockPos.class);
        c.setAccessible(true); return c.newInstance(s,p);
    }
    static class Fake implements BridgeEndpoint.Observer {
        TableAdjacency.Result[] t = new TableAdjacency.Result[6];
        SsnAdjacentProbe.Result[] s = new SsnAdjacentProbe.Result[6];
        int tc, sc; boolean fail;
        Fake() throws Exception {
            Arrays.fill(t, TableAdjacency.Result.NO_MATCH);
            Arrays.fill(s, result(SsnAdjacentProbe.State.NOT_PLAIN_SSN_CABLE, null));
        }
        public TableAdjacency.Result table(EnumFacing f) { tc++; if (fail) throw new IllegalStateException(); return t[f.ordinal()]; }
        public SsnAdjacentProbe.Result ssn(EnumFacing f) { sc++; return s[f.ordinal()]; }
    }
    public static void main(String[] args) throws Exception {
        Fake f = new Fake();
        BridgeEndpoint.Snapshot x = BridgeEndpoint.observe(f);
        check(x.table == BridgeEndpoint.TableSummary.NONE && x.network == BridgeEndpoint.NetworkSummary.NONE, "empty");
        check(f.tc == 6 && f.sc == 6, "all faces exactly once");
        int e = EnumFacing.EAST.ordinal(), w = EnumFacing.WEST.ordinal(), n = EnumFacing.NORTH.ordinal();
        f.t[e] = TableAdjacency.Result.ADJACENT_ONLY;
        f.s[w] = result(SsnAdjacentProbe.State.ASSIGNED_MASTER, new BlockPos(1,64,1));
        x = BridgeEndpoint.observe(f);
        check(x.table == BridgeEndpoint.TableSummary.ADJACENT && x.network == BridgeEndpoint.NetworkSummary.ASSIGNED, "adjacency and pointer only");
        check((x.face(EnumFacing.EAST) & 7) == TableAdjacency.Result.ADJACENT_ONLY.ordinal()+1, "table face packing");
        check((x.face(EnumFacing.WEST) >>> 3) == SsnAdjacentProbe.State.ASSIGNED_MASTER.ordinal()+1, "ssn face packing");
        f.s[n] = result(SsnAdjacentProbe.State.ASSIGNED_MASTER, new BlockPos(1,64,1));
        check(BridgeEndpoint.observe(f).network == BridgeEndpoint.NetworkSummary.ASSIGNED, "deduplicate pointers");
        f.s[n] = result(SsnAdjacentProbe.State.ASSIGNED_MASTER, new BlockPos(2,64,1));
        check(BridgeEndpoint.observe(f).network == BridgeEndpoint.NetworkSummary.MULTIPLE, "distinct pointers");
        f.s[0] = result(SsnAdjacentProbe.State.UNLOADED, null);
        check(BridgeEndpoint.observe(f).network == BridgeEndpoint.NetworkSummary.MULTIPLE, "multiple remains warning even if incomplete");
        f.s[n] = result(SsnAdjacentProbe.State.NO_MASTER, null);
        check(BridgeEndpoint.observe(f).network == BridgeEndpoint.NetworkSummary.INCOMPLETE, "unloaded/no master fail closed");
        for (SsnAdjacentProbe.State s : SsnAdjacentProbe.State.values()) {
            if (s == SsnAdjacentProbe.State.ASSIGNED_MASTER || s == SsnAdjacentProbe.State.NOT_PLAIN_SSN_CABLE) continue;
            Fake g = new Fake(); g.s[e] = result(s,null);
            check(BridgeEndpoint.observe(g).network == BridgeEndpoint.NetworkSummary.INCOMPLETE, "failure state " + s);
        }
        Fake g = new Fake(); g.s[e] = result(SsnAdjacentProbe.State.ASSIGNED_MASTER,null);
        check(BridgeEndpoint.observe(g).network == BridgeEndpoint.NetworkSummary.INCOMPLETE, "missing pointer");
        for (TableAdjacency.Result t : TableAdjacency.Result.values()) {
            if (t == TableAdjacency.Result.ADJACENT_ONLY || t == TableAdjacency.Result.NO_MATCH) continue;
            g = new Fake(); g.t[e] = t; g.t[w] = TableAdjacency.Result.ADJACENT_ONLY;
            check(BridgeEndpoint.observe(g).table == BridgeEndpoint.TableSummary.INCOMPLETE, "table failure " + t);
        }
        g = new Fake(); g.s[e] = null;
        check(BridgeEndpoint.observe(g).network == BridgeEndpoint.NetworkSummary.INCOMPLETE, "null result");
        g = new Fake(); g.fail = true;
        check(BridgeEndpoint.observe(g).table == BridgeEndpoint.TableSummary.INCOMPLETE, "exception");
        check(BridgeEndpoint.inspect(null,null).network == BridgeEndpoint.NetworkSummary.INCOMPLETE, "unauthenticated");
        System.out.println("BridgeEndpointTest passed");
    }
}
