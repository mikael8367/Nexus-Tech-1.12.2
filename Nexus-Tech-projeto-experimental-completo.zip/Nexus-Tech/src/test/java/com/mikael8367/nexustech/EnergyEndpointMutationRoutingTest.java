package com.mikael8367.nexustech;

import net.minecraft.init.Bootstrap;
import net.minecraft.util.math.BlockPos;

/** Routing continues only through live paths after an endpoint changes during its capability probe. */
public final class EnergyEndpointMutationRoutingTest extends NexusEnergyTestSupport {
    static void endpointChange(final boolean pull, final boolean simulate, final int mutation) throws Exception {
        final FakeWorld w = world(false);
        w.put(O, new Cable());
        w.put(O.down(), new Cable());
        w.put(O.east(), new Cable());
        final BlockPos changed = O.down().east();
        Endpoint first = new Endpoint(pull ? 25 : 0, !pull, pull);
        first.receiveLimit = 25; first.extractLimit = 25;
        Endpoint good = new Endpoint(pull ? 75 : 0, !pull, pull);
        final int[] replacementProbes = {0};
        final Endpoint replacement = new Endpoint(pull ? 100 : 0, !pull, pull) {
            @Override public boolean canReceive() { replacementProbes[0]++; return true; }
            @Override public boolean canExtract() { replacementProbes[0]++; return true; }
        };
        Endpoint stale = new Endpoint(pull ? 100 : 0, !pull, pull) {
            void mutate() {
                if (mutation == 0) w.tiles.remove(changed);
                else if (mutation == 1) w.put(changed, replacement);
                else w.unloaded.add(changed);
            }
            @Override public boolean canReceive() { mutate(); return true; }
            @Override public boolean canExtract() { mutate(); return true; }
        };
        w.put(O.up(), first); w.put(changed, stale); w.put(O.east().east(), good);
        int moved = pull ? EnergyNetwork.pull(w, O, W, 100, simulate, true)
                : EnergyNetwork.send(w, O, W, 100, simulate, false);
        String ctx = " pull=" + pull + " simulate=" + simulate + " mutation=" + mutation;
        eq(moved, simulate ? (pull ? 75 : 100) : 100, "other endpoints remain reachable" + ctx);
        eq(first.energy, pull ? (simulate ? 25 : 0) : (simulate ? 0 : 25), "prior accounting" + ctx);
        eq(good.energy, pull ? (simulate ? 75 : 0) : (simulate ? 0 : 75), "later accounting" + ctx);
        eq(stale.energy, pull ? 100 : 0, "stale endpoint untouched" + ctx);
        eq(replacement.energy, pull ? 100 : 0, "replacement untouched" + ctx);
        eq(replacementProbes[0], 0, "no second-face probe of replacement" + ctx);
        eq(w.forbiddenQueries, 0, "no unloaded tile queries" + ctx);
        if (!simulate) eq(pull ? 100 - first.energy - good.energy : first.energy + good.energy,
                moved, "conservation" + ctx);
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        for (boolean pull : new boolean[]{false, true})
            for (boolean simulate : new boolean[]{false, true})
                for (int mutation = 0; mutation < 3; mutation++) endpointChange(pull, simulate, mutation);
        Bootstrap.printToSYSOUT("PASS endpoint mutation routing");
    }
}
