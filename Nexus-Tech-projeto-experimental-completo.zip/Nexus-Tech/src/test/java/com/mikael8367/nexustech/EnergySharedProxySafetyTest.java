package com.mikael8367.nexustech;

import net.minecraft.init.Bootstrap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.energy.IEnergyStorage;
import com.mikael8367.nexustech.powerexpansion.PowerTile;

/** Fake-world tests; distinct positions model wrappers forwarding to one controller. */
public final class EnergySharedProxySafetyTest extends NexusEnergyTestSupport {
    static final class Shared { int energy, capacity; Shared(int n, int cap) { energy=n; capacity=cap; } }
    static final class Proxy extends Endpoint {
        final Shared shared; final boolean input;
        Proxy(Shared shared, boolean input) { super(0, input, !input); this.shared=shared; this.input=input; }
        @Override public int receiveEnergy(int n, boolean sim) {
            int got=Math.min(n,shared.capacity-shared.energy); if (!sim) shared.energy+=got; return got;
        }
        @Override public int extractEnergy(int n, boolean sim) {
            int got=Math.min(n,shared.energy); if (!sim) shared.energy-=got; return got;
        }
    }
    static void aliases(boolean pull) throws Exception {
        FakeWorld w=world(false); Cable origin=new Cable(); w.put(O,origin);
        Shared s=new Shared(pull ? 70 : 30, 100);
        // 17 separate endpoints in a line, each connected through cables.
        for (int i=1;i<=17;i++) {
            BlockPos wire=O.add(i,0,0); w.put(wire,new Cable()); w.put(wire.up(),new Proxy(s,!pull));
        }
        IEnergyStorage cable=cap(origin,EnumFacing.WEST);
        int simulated=pull ? cable.extractEnergy(1000,true) : cable.receiveEnergy(1000,true);
        eq(simulated,70,"shared buffer simulation " + pull); eq(s.energy,pull?70:30,"simulation is nonmutating");
        int actual=pull ? cable.extractEnergy(1000,false) : cable.receiveEnergy(1000,false);
        eq(actual,70,"shared actual " + pull); eq(s.energy,pull?0:100,"shared final " + pull);
        eq(w.forbiddenQueries,0,"no unloaded lookups");
    }
    static void distinctActual() throws Exception {
        FakeWorld w=world(false); Cable c=new Cable(); w.put(O,c);
        Endpoint a=new Endpoint(0,true,false), b=new Endpoint(0,true,false); a.receiveLimit=30; b.receiveLimit=40;
        w.put(O.up(),a); w.put(O.east(),b);
        eq(cap(c,EnumFacing.WEST).receiveEnergy(100,true),40,"simulation conservative for unknown aliases");
        eq(cap(c,EnumFacing.WEST).receiveEnergy(100,false),70,"real distinct endpoints aggregate");
        eq(a.energy+b.energy,70,"all actually accepted energy counted");
    }
    static void invalidAndReentry() throws Exception {
        FakeWorld w=world(false); Generator g=new Generator(); g.energy=100; w.put(O,g);
        Endpoint bad=new Endpoint(0,true,false) {
            @Override public int receiveEnergy(int n,boolean sim) {
                if (!sim) { energy+=20; eq(EnergyNetwork.send(w,O,O,10,false,false),0,"nested send blocked"); return -1; }
                return 0;
            }
        };
        Endpoint later=new Endpoint(0,true,false); w.put(O.down(),bad); w.put(O.up(),later);
        g.update(); eq(g.energy,0,"negative result consumes uncertain offer"); eq(bad.energy,20,"bad receiver mutated");
        eq(later.energy,0,"no continuation after invalid result");
        eq(EnergyNetwork.send(w,O,O,10,true,false),10,"guard released after invalid result");
    }
    static void expandedBattery() throws Exception {
        FakeWorld w=world(false); Battery old=new Battery(); PowerTile.AdvancedBattery expanded=new PowerTile.AdvancedBattery();
        net.minecraft.nbt.NBTTagCompound tag=new net.minecraft.nbt.NBTTagCompound();
        tag.setInteger("PowerExpansionEnergy",100); expanded.readFromNBT(tag);
        w.put(O,old); w.put(O.down(),expanded); Endpoint machine=new Endpoint(0,true,false); w.put(O.up(),machine);
        eq(EnergyNetwork.send(w,O,O,100,false,false),100,"consumer wins over expanded battery");
        eq(machine.energy,100,"machine prioritized");
        IEnergyStorage es=cap(expanded,EnumFacing.UP);
        eq(EnergyNetwork.pull(w,O,O,100,false,false),0,"old battery does not pull expanded battery");
        eq(es.getEnergyStored(),100,"expanded battery remains charged");
        eq(EnergyNetwork.send(w,O,O,100,false,true),100,"old battery supplies consumer");
        eq(es.getEnergyStored(),100,"old battery does not push to expanded battery");
    }
    static void boundedNetwork() throws Exception {
        FakeWorld w=world(false); Cable start=new Cable(); w.put(O,start);
        Endpoint early=new Endpoint(0,true,false); early.receiveLimit=10; w.put(O.up(),early);
        for (int i=1;i<=8200;i++) w.put(O.add(i,0,0),new Cable());
        Endpoint far=new Endpoint(0,true,false); w.put(O.add(8200,1,0),far);
        eq(cap(start,EnumFacing.WEST).receiveEnergy(100,false),10,"bounded traversal preserves earlier accounting");
        eq(early.energy,10,"early endpoint paid"); eq(far.energy,0,"oversized traversal stopped");
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability(); aliases(false); aliases(true); distinctActual(); invalidAndReentry(); expandedBattery(); boundedNetwork();
        Bootstrap.printToSYSOUT("PASS shared proxy accounting, conservative simulation, invalid return, reentry and expanded batteries");
    }
}
