package com.mikael8367.nexustech;

import net.minecraft.init.Bootstrap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.energy.IEnergyStorage;

/** Regression tests for callback-driven topology mutation and transfer accounting. */
public final class EnergyTopologyMutationTest extends NexusEnergyTestSupport {
    static void removedQueuedCable(boolean pull) throws Exception {
        FakeWorld w = world(false);
        Cable origin = new Cable(), queued = new Cable();
        Endpoint first = new Endpoint(pull ? 25 : 0, !pull, pull);
        first.receiveLimit = 25;
        Endpoint behind = new Endpoint(pull ? 100 : 0, !pull, pull);
        w.put(O, origin); w.put(O.down(), queued); w.put(O.up(), first);
        w.put(O.down().down(), behind);
        if (pull) first.onExtract = () -> w.tiles.remove(O.down());
        else first.onReceive = () -> w.tiles.remove(O.down());
        IEnergyStorage wire = cap(origin, EnumFacing.WEST);
        int moved = pull ? wire.extractEnergy(100, false) : wire.receiveEnergy(100, false);
        eq(moved, 25, "removed queued cable stops traversal " + pull);
        eq(behind.energy, pull ? 100 : 0, "disconnected endpoint untouched " + pull);
        eq(first.energy, pull ? 0 : 25, "first transfer accounted " + pull);
    }
    // The child remains valid and queued after its already-visited parent is removed.
    static void mutateAncestor(FakeWorld w, BlockPos pos, int mutation) {
        if (mutation == 0) w.tiles.remove(pos);
        else if (mutation == 1) w.put(pos, new Cable());
        else w.unloaded.add(pos);
    }
    static void removedAncestor(boolean pull, boolean probe, boolean simulate, int mutation) throws Exception {
        FakeWorld w = world(false);
        Cable origin = new Cable(), parent = new Cable(), child = new Cable();
        BlockPos parentPos = O.down(), childPos = parentPos.down();
        Endpoint first = new Endpoint(pull ? 25 : 0, !pull, pull) {
            @Override public boolean canReceive() {
                if (!pull && probe) mutateAncestor(w, parentPos, mutation);
                return super.canReceive();
            }
            @Override public boolean canExtract() {
                if (pull && probe) mutateAncestor(w, parentPos, mutation);
                return super.canExtract();
            }
        };
        first.receiveLimit = 25;
        Endpoint behind = new Endpoint(pull ? 100 : 0, !pull, pull);
        w.put(O, origin); w.put(parentPos, parent); w.put(childPos, child);
        w.put(parentPos.east(), first); w.put(childPos.down(), behind);
        if (!probe) {
            if (pull) first.onExtract = () -> mutateAncestor(w, parentPos, mutation);
            else first.onReceive = () -> mutateAncestor(w, parentPos, mutation);
        }
        IEnergyStorage wire = cap(origin, EnumFacing.WEST);
        int moved = pull ? wire.extractEnergy(100, simulate) : wire.receiveEnergy(100, simulate);
        eq(moved, probe ? 0 : 25, "removed ancestor: pull=" + pull + " probe=" + probe
                + " simulate=" + simulate + " mutation=" + mutation);
        eq(behind.energy, pull ? 100 : 0, "valid descendant must not route after parent removal");
        eq(first.energy, pull ? (probe || simulate ? 25 : 0) : (probe || simulate ? 0 : 25), "earlier transfer accounting");
        eq(w.forbiddenQueries, 0, "never query an unloaded tile");
    }
    static void cableCycle(boolean pull) throws Exception {
        FakeWorld w = world(false);
        Cable origin = new Cable();
        Endpoint end = new Endpoint(pull ? 25 : 0, !pull, pull);
        end.receiveLimit = 25;
        w.put(O, origin); w.put(O.down(), new Cable());
        w.put(O.east(), new Cable()); w.put(O.down().east(), new Cable());
        w.put(O.down().east().down(), end);
        IEnergyStorage wire = cap(origin, EnumFacing.WEST);
        eq(pull ? wire.extractEnergy(100, false) : wire.receiveEnergy(100, false), 25,
                "cyclic cable graph terminates and endpoint visited once");
        eq(end.energy, pull ? 0 : 25, "cycle accounting");
    }
    static void removedOrigin() throws Exception {
        FakeWorld w = world(false); Cable origin = new Cable();
        Endpoint first = new Endpoint(0, true, false); first.receiveLimit = 20;
        Endpoint second = new Endpoint(0, true, false);
        w.put(O, origin); w.put(O.down(), first); w.put(O.up(), second);
        first.onReceive = () -> w.tiles.remove(O);
        eq(cap(origin, EnumFacing.WEST).receiveEnergy(100, false), 20, "removed origin stops routing");
        eq(first.energy, 20, "credited receiver is accounted"); eq(second.energy, 0, "no transfer after removal");
    }
    static void replacedDuringProbe() throws Exception {
        FakeWorld w = world(false); Cable origin = new Cable();
        Endpoint sink = new Endpoint(0, true, false) {
            @Override public boolean canReceive() { w.tiles.remove(O); return true; }
        };
        w.put(O, origin); w.put(O.up(), sink);
        eq(cap(origin, EnumFacing.WEST).receiveEnergy(100, false), 0, "origin removed during probe");
        eq(sink.energy, 0, "no receive through removed origin");
    }
    static void worldFailureAfterReceive() throws Exception {
        FakeWorld w = world(false); Generator generator = new Generator(); generator.energy = 100;
        Endpoint first = new Endpoint(0, true, false); first.receiveLimit = 30;
        w.put(O, generator); w.put(O.down(), first);
        first.onReceive = () -> w.faultAt = O;
        generator.update();
        eq(first.energy, 30, "completed receive remains credited");
        eq(generator.energy, 70, "completed receive is not refunded on world failure");
        w.faultAt = null;
        first.onReceive = null;
        generator.update();
        eq(generator.energy + first.energy, 100, "guard resets after world failure");
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        for (boolean pull : new boolean[]{false, true})
            for (boolean probe : new boolean[]{false, true})
                for (boolean simulate : new boolean[]{false, true})
                    for (int mutation = 0; mutation < 3; mutation++)
                        removedAncestor(pull, probe, simulate, mutation);
        cableCycle(false); cableCycle(true);
        removedQueuedCable(false); removedQueuedCable(true); removedOrigin();
        replacedDuringProbe(); worldFailureAfterReceive();
        Bootstrap.printToSYSOUT("PASS energy topology mutation and accounting");
    }
}
