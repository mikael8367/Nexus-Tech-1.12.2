package com.mikael8367.nexustech;

import java.lang.reflect.Constructor;
import java.util.concurrent.Callable;
import com.mikael8367.nexustech.machinesexpansion.ExpansionRegistry;
import com.mikael8367.nexustech.machinesexpansion.ExpansionTile;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.oredict.OreDictionary;

/** Standalone Forge fixture: use vanilla items as dictionary stand-ins. */
public final class ExpansionMachineTest extends NexusEnergyTestSupport {
 static void tick(ExpansionTile t,int n){for(int i=0;i<n;i++)t.update();}
 static IItemHandler items(ExpansionTile t){return t.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.DOWN);}
 static IEnergyStorage power(ExpansionTile t){return t.getCapability(CapabilityEnergy.ENERGY,EnumFacing.UP);}
 static void charge(ExpansionTile t,int amount){while(amount>0){int n=power(t).receiveEnergy(amount,false);ok(n>0,"charge");amount-=n;}}
 @SuppressWarnings("unchecked") public static void main(String[] args) throws Exception {
  Bootstrap.register(); setupCapability();
  java.util.List<net.minecraft.block.Block> blocks=new java.util.ArrayList<>();
  net.minecraftforge.registries.IForgeRegistry<net.minecraft.block.Block> registry=(net.minecraftforge.registries.IForgeRegistry<net.minecraft.block.Block>)java.lang.reflect.Proxy.newProxyInstance(net.minecraftforge.registries.IForgeRegistry.class.getClassLoader(),new Class<?>[]{net.minecraftforge.registries.IForgeRegistry.class},(proxy,method,arguments)->{if(method.getName().equals("register")){blocks.add((net.minecraft.block.Block)arguments[0]);return null;} if(method.getName().equals("getRegistrySuperType"))return net.minecraft.block.Block.class; throw new AssertionError(method.getName());});
  ExpansionRegistry.blocks(new net.minecraftforge.event.RegistryEvent.Register<>(new ResourceLocation("minecraft:blocks"),registry));
  eq(blocks.size(),2,"event registration");
  Constructor<?> c=Capability.class.getDeclaredConstructors()[0];c.setAccessible(true);
  CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<IItemHandler>)c.newInstance("test:items",null,(Callable<IItemHandler>)()->null);
  OreDictionary.registerOre("ingotCopper",Items.IRON_INGOT);OreDictionary.registerOre("ingotTin",Items.GOLD_INGOT);OreDictionary.registerOre("ingotZinc",Items.BRICK);
  FakeWorld w=world(false);ExpansionTile.Press p=new ExpansionTile.Press();w.put(O,p);
  IItemHandler inv=items(p); IEnergyStorage e=power(p);
  eq(e.receiveEnergy(-1,false),0,"reject negative FE");eq(e.receiveEnergy(5000,true),1000,"bounded simulated FE");eq(e.getEnergyStored(),0,"simulate energy");
  ok(inv.insertItem(2,new ItemStack(Items.IRON_INGOT),false).getCount()==1,"output insertion denied");
  ItemStack tagged=new ItemStack(Items.IRON_INGOT);tagged.setTagCompound(new NBTTagCompound());ok(!inv.insertItem(0,tagged,false).isEmpty(),"tagged input refused");
  ok(inv.insertItem(0,new ItemStack(Items.IRON_INGOT,2),true).isEmpty(),"simulate insert");ok(inv.getStackInSlot(0).isEmpty(),"simulate did not insert");
  inv.insertItem(0,new ItemStack(Items.IRON_INGOT,2),false);inv.getStackInSlot(0).setCount(64);eq(inv.getStackInSlot(0).getCount(),2,"defensive stack copy");
  charge(p,4000);tick(p,100);eq(inv.getStackInSlot(0).getCount(),1,"press consumed one");eq(inv.getStackInSlot(2).getCount(),1,"one plate produced");ok(inv.getStackInSlot(2).getItem()==ExpansionRegistry.COPPER_PLATE,"copper plate");eq(e.getEnergyStored(),2000,"exact cost");
  tick(p,100);eq(inv.getStackInSlot(0).getCount(),0,"second consumed");eq(inv.getStackInSlot(2).getCount(),2,"stack output");
  ItemStack simulated=inv.extractItem(2,64,true);eq(simulated.getCount(),2,"simulate extract");eq(inv.getStackInSlot(2).getCount(),2,"simulate no extraction");
  inv.extractItem(2,64,false);
  inv.insertItem(0,new ItemStack(Items.IRON_INGOT),false);charge(p,2000);tick(p,99);inv.extractItem(0,1,false);inv.insertItem(0,new ItemStack(Items.GOLD_INGOT),false);tick(p,1);ok(inv.getStackInSlot(2).isEmpty(),"input switch resets progress");
  NBTTagCompound saved=p.writeToNBT(new NBTTagCompound()); ExpansionTile.Press restored=new ExpansionTile.Press(); w.put(O,restored); restored.readFromNBT(saved);
  eq(items(restored).getStackInSlot(0).getCount(),1,"inventory survives reload");eq(power(restored).getEnergyStored(),0,"energy persists");eq(e.receiveEnergy(50,false),0,"stale energy capability blocked");ok(inv.extractItem(0,1,false).isEmpty(),"stale item capability blocked");
  FakeWorld a=world(false);ExpansionTile.Alloy alloy=new ExpansionTile.Alloy();a.put(O,alloy);IItemHandler ai=items(alloy);
  ai.insertItem(0,new ItemStack(Items.IRON_INGOT,3),false);ai.insertItem(1,new ItemStack(Items.GOLD_INGOT),false);charge(alloy,2000);tick(alloy,100);
  eq(ai.getStackInSlot(0).getCount(),0,"bronze copper debit");eq(ai.getStackInSlot(1).getCount(),0,"bronze tin debit");eq(ai.getStackInSlot(2).getCount(),4,"bronze output count");ok(ai.getStackInSlot(2).getItem()==ExpansionRegistry.BRONZE,"bronze output");
  ai.insertItem(0,new ItemStack(Items.IRON_INGOT,3),false);ai.insertItem(1,new ItemStack(Items.BRICK),false);charge(alloy,2000);tick(alloy,100);eq(ai.getStackInSlot(0).getCount(),3,"wrong output blocks input");eq(power(alloy).getEnergyStored(),2000,"wrong output costs no energy");
  ai.extractItem(2,64,false);tick(alloy,100);eq(ai.getStackInSlot(2).getCount(),4,"brass output count");ok(ai.getStackInSlot(2).getItem()==ExpansionRegistry.BRASS,"brass output");
  FakeWorld network=world(false); ExpansionTile.Press machine=new ExpansionTile.Press(); Battery battery=new Battery(); battery.energy=1000; network.put(W,battery); network.put(O,new Cable()); network.put(E,machine); battery.update(); eq(power(machine).getEnergyStored(),128,"Nexus cable pushes FE to expansion"); eq(battery.energy,872,"Nexus battery debited");
  ai.extractItem(2,64,false); for(int i=0;i<16;i++){ai.insertItem(0,new ItemStack(Items.IRON_INGOT,3),false);ai.insertItem(1,new ItemStack(Items.GOLD_INGOT),false);charge(alloy,2000);tick(alloy,100);} eq(ai.getStackInSlot(2).getCount(),64,"output reaches stack limit");
  ai.insertItem(0,new ItemStack(Items.IRON_INGOT,3),false);ai.insertItem(1,new ItemStack(Items.GOLD_INGOT),false);charge(alloy,2000);tick(alloy,100);eq(ai.getStackInSlot(2).getCount(),64,"no output overflow");eq(ai.getStackInSlot(0).getCount(),3,"full output preserves inputs");eq(power(alloy).getEnergyStored(),2000,"full output preserves FE");
  Bootstrap.printToSYSOUT("PASS expansion registry, FE network, processing, conservation, simulation, backpressure, invalidation, NBT");
 }
}
