package com.mikael8367.nexustech;

import com.mikael8367.nexustech.digitalmine.DigitalMineTile;
import com.mikael8367.nexustech.digitalmine.DigitalMineBlock;
import com.mikael8367.nexustech.digitalmine.DigitalMineCasingTile;
import com.mikael8367.nexustech.digitalmine.DigitalMineRegistry;
import net.minecraft.init.Bootstrap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.energy.IEnergyStorage;

/** Isolated fake-world cross-module test, not a live Forge or modpack test. */
public final class ExperimentalEnergyIntegrationTest extends NexusEnergyTestSupport {
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        FakeWorld w = world(false);
        Generator generator = new Generator(); generator.energy = 200;
        Cable cable = new Cable(); DigitalMineTile.Basic miner = new DigitalMineTile.Basic();
        BridgeTile bridge = new BridgeTile();
        w.put(O, generator); w.put(E, cable); w.put(E.east(), miner); w.put(E.up(), bridge);
        IEnergyStorage wire = cap(cable, EnumFacing.WEST);
        eq(wire.receiveEnergy(100, true), 0, "unformed mine refuses energy");
        BlockPos origin = E.east();
        EnumFacing front = EnumFacing.WEST;
        w.states.put(origin, DigitalMineRegistry.BASIC.getDefaultState().withProperty(DigitalMineBlock.FACING, front));
        for (int depth = 0; depth < 3; depth++) for (int y = 0; y < 2; y++) for (int x = -1; x <= 1; x++) {
            BlockPos p = origin.offset(front.getOpposite(), depth).offset(front.rotateY(), x).up(y);
            if (!p.equals(origin)) {
                w.states.put(p, DigitalMineRegistry.CASING.getDefaultState());
                w.put(p, new DigitalMineCasingTile());
            }
        }
        ok(miner.structureValid(), "mine multiblock is formed");
        eq(wire.receiveEnergy(100, true), 100, "simulated cable input reaches mine");
        eq(miner.energy, 0, "simulation does not charge mine");
        eq(generator.energy, 200, "simulation does not spend generator");
        generator.update();
        eq(miner.energy, 100, "generator charges real digital mine via real cable");
        eq(generator.energy, 100, "generator debited exactly");
        eq(generator.energy + miner.energy, 200, "FE conserved across modules");
        ok(!bridge.hasCapability(net.minecraftforge.energy.CapabilityEnergy.ENERGY, EnumFacing.DOWN), "diagnostic bridge exposes no FE");
        FakeWorld faulty = world(false);
        Generator source = new Generator(); source.energy = 200;
        Cable wire2 = new Cable();
        Endpoint broken = new Endpoint(0, true, false) {
            @Override public int receiveEnergy(int n, boolean sim) {
                if (!sim) energy += Math.min(30, n);
                throw new IllegalStateException("test endpoint failed after potential mutation");
            }
        };
        faulty.put(O, source); faulty.put(E, wire2); faulty.put(E.east(), broken);
        source.update();
        eq(source.energy, 100, "uncertain offer is not refunded");
        eq(broken.energy, 30, "faulty endpoint mutated before throwing");
        eq(source.energy + broken.energy, 130, "uncertain remainder may be lost, not duplicated");
        System.out.println("PASS fake-world generator -> FE cable -> digital mine, bridge isolation and conservative exception handling");
    }
}
