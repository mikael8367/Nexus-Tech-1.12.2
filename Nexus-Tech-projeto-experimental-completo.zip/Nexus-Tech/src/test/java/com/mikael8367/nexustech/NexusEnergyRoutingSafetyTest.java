package com.mikael8367.nexustech;

import net.minecraft.init.Bootstrap;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.energy.IEnergyStorage;

/** Regression checks for priority, cached capabilities and changing network topology. */
public final class NexusEnergyRoutingSafetyTest extends NexusEnergyTestSupport {
    static void priority() throws Exception {
        FakeWorld w = world(false);
        Generator g = new Generator(); g.energy = 200;
        Battery b = new Battery();
        Endpoint machine = new Endpoint(0, true, true);
        machine.extractLimit = 0; // passive receiver reports an output capability but cannot supply FE
        w.put(O, g); w.put(O.down(), b); w.put(E, new Cable()); w.put(E.east(), machine);
        g.update(); b.update();
        eq(machine.energy, 100, "generator should prioritize machine over nearby buffer");
        eq(b.energy, 100, "battery may pull the generator's remaining buffer");
        eq(g.energy + b.energy + machine.energy, 200, "priority conservation");
    }
    static void partialAndSimulation() throws Exception {
        for (boolean viaCable : new boolean[]{false, true}) {
            FakeWorld w = world(false); Cable cable = new Cable(); Battery battery = new Battery();
            Endpoint consumer = new Endpoint(0, true, false); consumer.receiveLimit = 30;
            w.put(O, cable); w.put(O.down(), battery);
            if (viaCable) { w.put(E, new Cable()); w.put(E.east(), consumer); }
            else w.put(E, consumer);
            IEnergyStorage wire = cap(cable, EnumFacing.WEST);
            eq(wire.receiveEnergy(100, true), 100, "simulated consumer plus battery " + viaCable);
            eq(consumer.energy + battery.energy, 0, "simulation does not mutate " + viaCable);
            eq(wire.receiveEnergy(100, false), 100, "actual consumer plus battery " + viaCable);
            eq(consumer.energy, 30, "consumer served before battery " + viaCable);
            eq(battery.energy, 70, "surplus stored " + viaCable);
            eq(consumer.energy + battery.energy, 100, "partial conservation " + viaCable);
        }
    }
    static void disconnectedAndExcluded() throws Exception {
        FakeWorld w = world(false); Cable cable = new Cable(); Battery b = new Battery();
        Endpoint source = new Endpoint(90, true, true); Endpoint sink = new Endpoint(0, true, false);
        w.put(O, cable); w.put(W, source); w.put(O.down(), b); w.put(E, new Cable()); w.put(E.east(), sink);
        w.unloaded.add(E);
        eq(cap(cable, EnumFacing.WEST).receiveEnergy(90, false), 90, "battery receives when cable disconnected");
        eq(source.energy, 90, "source side excluded");
        eq(b.energy, 90, "reachable buffer accepts"); eq(sink.energy, 0, "unloaded cable blocks path");
        eq(w.forbiddenQueries, 0, "unloaded node never queried");
    }
    static void invalidated() throws Exception {
        FakeWorld w = world(false); Cable cable = new Cable(); Endpoint sink = new Endpoint(0, true, false);
        w.put(O, cable); w.put(E, sink); IEnergyStorage cached = cap(cable, EnumFacing.WEST);
        cable.invalidate();
        eq(cached.receiveEnergy(50, false), 0, "invalid cable cannot send");
        eq(EnergyNetwork.send(w, O, W, 50, false, false), 0, "invalid network origin cannot send");
        eq(EnergyNetwork.pull(w, O, W, 50, false, true), 0, "invalid network origin cannot pull");
        eq(sink.energy, 0, "invalid cable has no effects");
        FakeWorld network = world(false); Generator generator = new Generator(); generator.energy = 100;
        Cable broken = new Cable(); Endpoint target = new Endpoint(0, true, false);
        network.put(O, generator); network.put(E, broken); network.put(E.east(), target);
        broken.invalidate(); generator.update();
        eq(target.energy, 0, "invalid intermediary must not transmit");
        eq(generator.energy, 100, "invalid intermediary conserves FE");
    }
    static void removedCable() throws Exception {
        FakeWorld w = world(false); Cable cable = new Cable(); Endpoint sink = new Endpoint(0, true, false);
        w.put(O, cable); w.put(E, sink);
        IEnergyStorage cached = cap(cable, EnumFacing.WEST);
        w.tiles.remove(O);
        eq(cached.receiveEnergy(100, false), 0, "removed cached cable must not send");
        eq(sink.energy, 0, "removed cable cannot energize sink");
        eq(cached.extractEnergy(100, false), 0, "removed cached cable cannot extract");
    }
    static void replacedSource() throws Exception {
        FakeWorld w = world(false); Generator generator = new Generator(); generator.energy = 100;
        Endpoint sink = new Endpoint(0, true, false); w.put(O, generator); w.put(E, sink);
        IEnergyStorage cached = cap(generator, EnumFacing.WEST);
        w.put(O, new Cable());
        eq(cached.extractEnergy(50, false), 0, "replaced generator capability inert");
        generator.update();
        eq(sink.energy, 0, "replaced generator must not tick");
        eq(generator.energy, 100, "stale generator energy unchanged");
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        priority(); partialAndSimulation(); disconnectedAndExcluded(); invalidated(); removedCable(); replacedSource();
        Bootstrap.printToSYSOUT("PASS routing and stale capability safety");
    }
}
