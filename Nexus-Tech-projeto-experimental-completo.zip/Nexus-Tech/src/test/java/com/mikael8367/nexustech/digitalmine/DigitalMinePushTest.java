package com.mikael8367.nexustech.digitalmine;

import java.lang.reflect.Field;
import java.util.UUID;
import net.minecraft.init.Blocks;
import net.minecraft.init.Bootstrap;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

/** Simulated endpoints; not a substitute for an actual Forge server. */
public final class DigitalMinePushTest {
    static void check(boolean b, String s) { if (!b) throw new AssertionError(s); }
    static final class Destination extends TileEntity {
        EnumFacing expected; int calls, realCalls; String fault = ""; Runnable callback;
        final ItemStackHandler items = new ItemStackHandler(1);
        final IItemHandler handler = new IItemHandler() {
            public int getSlots() { return 1; }
            public ItemStack getStackInSlot(int i) { return items.getStackInSlot(i); }
            public int getSlotLimit(int i) { return items.getSlotLimit(i); }
            public ItemStack extractItem(int i,int count,boolean sim) { return items.extractItem(i,count,sim); }
            public ItemStack insertItem(int i, ItemStack stack, boolean sim) {
                calls++; if (!sim) realCalls++;
                if (callback != null) { Runnable c=callback; callback=null; c.run(); }
                if (fault.equals(sim ? "sim-before" : "before")) throw new IllegalStateException("before");
                ItemStack left = items.insertItem(i,stack,sim);
                if (fault.equals(sim ? "sim-after" : "after")) {
                    if (sim) items.insertItem(i,stack,false);
                    throw new IllegalStateException("after");
                }
                if (fault.equals("invalid") && !sim) return new ItemStack(Blocks.DIAMOND_BLOCK, 1);
                return left;
            }
        };
        public boolean hasCapability(Capability<?> c, EnumFacing face) {
            if (c == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) { check(face == expected,"wrong face " + face + " expected " + expected); return true; }
            return false;
        }
        public <T> T getCapability(Capability<T> c, EnumFacing face) {
            check(face == expected,"wrong get face"); return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(handler);
        }
    }
    static void owner(DigitalMineTile m) throws Exception {
        Field f=DigitalMineTile.class.getDeclaredField("owner"); f.setAccessible(true); f.set(m,UUID.randomUUID());
    }
    static void run(DigitalMineTile m, int ticks) { for(int i=0;i<ticks;i++) m.pushItems(); }
    static int q(DigitalMineTile m) { return m.writeToNBT(new NBTTagCompound()).getTagList("PushQuarantine",10).tagCount(); }
    static BlockPos at(BlockPos p, EnumFacing d) {
        switch(d) {
            case DOWN:return p.down(); case UP:return p.up(2); case NORTH:return p.north();
            case SOUTH:return p.south(3); case WEST:return p.west(2); default:return p.east(2);
        }
    }
    static void faces() throws Exception {
        for (EnumFacing side: EnumFacing.VALUES) {
            DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(100,64,100);
            DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); owner(m);
            Destination dest=new Destination(); dest.expected=side.getOpposite(); w.tiles.put(at(p,side),dest);
            m.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,10)); run(m,20);
            check(dest.items.getStackInSlot(0).getCount()==10 && m.inventory.getStackInSlot(0).isEmpty(),"push on "+side+" dest="+dest.items.getStackInSlot(0).getCount()+" src="+m.inventory.getStackInSlot(0).getCount()+" calls="+dest.calls+" q="+q(m)+" valid="+m.structureValid());
            check(dest.realCalls==1 && q(m)==0 && w.illegalReads==0,"no duplicate on "+side);
        }
    }
    static void partialAndFull() throws Exception {
        DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(100,64,100);
        DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); owner(m);
        Destination d=new Destination(); d.expected=EnumFacing.SOUTH; w.tiles.put(p.north(),d);
        d.items.setStackInSlot(0,new ItemStack(Blocks.STONE,64)); m.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,10)); run(m,20);
        check(m.inventory.getStackInSlot(0).getCount()==10 && d.realCalls==0 && q(m)==0,"full chest backpressure");
        d.items.setStackInSlot(0,new ItemStack(Blocks.STONE,60)); run(m,20);
        check(d.items.getStackInSlot(0).getCount()==64 && m.inventory.getStackInSlot(0).getCount()==6 && q(m)==0,"partial insertion reconciled");
        IItemHandler pull=m.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.DOWN);
        check(pull.extractItem(0,3,false).getCount()==3 && m.inventory.getStackInSlot(0).getCount()==3,"hopper-style pull remains available");
        w.unloaded.add(p.north()); run(m,20); check(w.illegalReads==0 && m.inventory.getStackInSlot(0).getCount()==3,"unloaded destination not read");
    }
    static void faults() throws Exception {
        for (String fault : new String[]{"sim-before","sim-after","before","after","invalid"}) {
            DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(100,64,100);
            DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); owner(m);
            Destination d=new Destination(); d.expected=EnumFacing.SOUTH; d.fault=fault; w.tiles.put(p.north(),d);
            m.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,7)); run(m,20);
            check(q(m)==1 && m.inventory.getStackInSlot(0).isEmpty(),"uncertain transfer quarantined "+fault);
            int effects=d.items.getStackInSlot(0).getCount(), calls=d.calls;
            run(m,40); check(d.calls==calls && d.items.getStackInSlot(0).getCount()==effects,"uncertain never retried "+fault);
            DigitalMineTile.Basic loaded=new DigitalMineTile.Basic(); loaded.readFromNBT(m.writeToNBT(new NBTTagCompound()));
            check(q(loaded)==1 && loaded.inventory.getStackInSlot(0).isEmpty(),"quarantine persisted "+fault);
        }
    }
    static void reentryAndRemoval() throws Exception {
        for (boolean remove : new boolean[]{false,true}) {
            DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(100,64,100);
            DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); owner(m);
            Destination d=new Destination(); d.expected=EnumFacing.SOUTH; w.tiles.put(p.north(),d);
            m.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,7));
            IItemHandler pull=m.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.DOWN);
            d.callback=()-> { m.update(); m.pushItems(); check(pull.extractItem(0,99,false).isEmpty(),"reentrant pull blocked");
                if (remove) { m.onControllerRemoved(); w.tiles.remove(p); m.invalidate(); } };
            run(m,20);
            if (remove) {
                check(d.realCalls==0 && d.items.getStackInSlot(0).isEmpty(),"removed during simulation: no commit");
                DigitalMineRecovery r=DigitalMineRecovery.get(w); r.retry(w);
                check(w.spawned.size()==1 && w.spawned.get(0).getCount()==7,"removal restores and drains once");
            } else check(d.items.getStackInSlot(0).getCount()==7 && d.realCalls==1 && q(m)==0,"reentry no duplication");
        }
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); DigitalMineRegistry.registerTiles();
        java.lang.reflect.Constructor<?> ctor=net.minecraftforge.common.capabilities.Capability.class.getDeclaredConstructors()[0]; ctor.setAccessible(true);
        net.minecraftforge.energy.CapabilityEnergy.ENERGY=(Capability<net.minecraftforge.energy.IEnergyStorage>)ctor.newInstance("test:energy",null,(java.util.concurrent.Callable<net.minecraftforge.energy.IEnergyStorage>)() -> null);
        CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<IItemHandler>)ctor.newInstance("test:item",null,(java.util.concurrent.Callable<IItemHandler>)() -> null);
        faces(); partialAndFull(); faults(); reentryAndRemoval();
        System.out.println("PASS DigitalMinePushTest");
    }
}
