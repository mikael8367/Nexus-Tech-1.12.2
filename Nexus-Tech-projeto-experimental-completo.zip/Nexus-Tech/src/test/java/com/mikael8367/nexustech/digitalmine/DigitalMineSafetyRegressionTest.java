package com.mikael8367.nexustech.digitalmine;

import com.mojang.authlib.GameProfile;
import com.mikael8367.nexustech.EnergyCableBlock;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.UUID;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Bootstrap;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import sun.misc.Unsafe;

/** Adversarial simulated callbacks and render/GUI checks, not a live Forge server. */
public final class DigitalMineSafetyRegressionTest {
    static void check(boolean b, String m) { if (!b) throw new AssertionError(m); }
    static Unsafe unsafe() throws Exception { Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); return (Unsafe)f.get(null); }
    static void owner(DigitalMineTile m, UUID id) throws Exception { Field f=DigitalMineTile.class.getDeclaredField("owner"); f.setAccessible(true); f.set(m,id); }
    static final class Source extends DigitalMineTest.Source {
        String phase; Runnable change; int gets; IEnergyStorage alternate;
        void callback(String at) { if (at.equals(phase) && change != null) { Runnable r=change; change=null; r.run(); } }
        @Override public boolean hasCapability(Capability<?> c, EnumFacing f) { callback("has"); return super.hasCapability(c,f); }
        @Override public <T> T getCapability(Capability<T> c, EnumFacing f) {
            gets++; callback(gets==1 ? "get" : "get2");
            return c == CapabilityEnergy.ENERGY ? CapabilityEnergy.ENERGY.cast(alternate == null ? this : alternate) : null;
        }
        @Override public boolean canExtract() { callback("can"); return true; }
        @Override public int extractEnergy(int n, boolean simulate) { callback("extract"); return super.extractEnergy(n,simulate); }
    }
    static void callbacks() throws Exception {
        Method pull=DigitalMineTile.class.getDeclaredMethod("pullEnergy"); pull.setAccessible(true);
        for (String phase : new String[]{"has","get","can","get2"}) for (String mutation : new String[]{"structure","unload","controller","provider","disable","owner","world"}) {
            DigitalMineTest.TestWorld w=DigitalMineTest.world(), otherWorld=DigitalMineTest.world(); BlockPos p=new BlockPos(100,64,100), at=p.down();
            DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); owner(m,UUID.randomUUID());
            Source s=new Source(); s.phase=phase; w.tiles.put(at,s);
            s.change=()-> { switch (mutation) {
                case "structure": w.tiles.remove(p.up()); break;
                case "unload": w.unloaded.add(p.up()); break;
                case "controller": w.tiles.remove(p); break;
                case "provider": w.tiles.put(at,new DigitalMineTest.Source()); break;
                case "disable": m.enabled=false; break;
                case "owner": try { owner(m,UUID.randomUUID()); } catch(Exception e) { throw new RuntimeException(e); } break;
                case "world": m.setWorld(otherWorld); break;
            }};
            pull.invoke(m);
            check(s.extracted==0 && m.energy==0,phase+"/"+mutation+" must not extract");
            check(w.illegalReads==0,phase+"/"+mutation+" must not read unloaded blocks");
        }
        for (String phase : new String[]{"can","get2"}) {
            DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(120,64,120);
            DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); owner(m,UUID.randomUUID());
            Source s=new Source(); s.phase=phase; w.tiles.put(p.down(),s);
            s.change=()->s.alternate=new DigitalMineTest.Source();
            pull.invoke(m); check(s.extracted==0 && m.energy==0,"swapped handler after "+phase);
        }
        DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(140,64,140);
        DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); owner(m,UUID.randomUUID());
        Source s=new Source(); w.tiles.put(p.down(),s); s.phase="extract"; s.change=()->w.tiles.remove(p.up());
        pull.invoke(m); check(s.extracted==1000 && m.energy==0,"destruction during extraction withholds uncertain credit");
        DigitalMineTest.TestWorld cw=DigitalMineTest.world(); BlockPos cp=new BlockPos(145,64,145);
        DigitalMineTile.Basic cm=DigitalMineTest.assemble(cw,cp,EnumFacing.NORTH); owner(cm,UUID.randomUUID());
        Source cs=new Source(); cw.tiles.put(cp.down(),cs); cs.phase="can"; cs.change=()->{ cm.energy=cm.capacity-25; cm.update(); };
        pull.invoke(cm); check(cs.extracted==25 && cm.energy==cm.capacity,"recalculate room after callback; nested tick blocked");
        DigitalMineTest.TestWorld tw=DigitalMineTest.world(); BlockPos tp=new BlockPos(150,64,150);
        DigitalMineTile.Basic tm=DigitalMineTest.assemble(tw,tp,EnumFacing.NORTH); owner(tm,UUID.randomUUID()); tm.energy=2000;
        Source ts=new Source(); tw.tiles.put(tp.down(),ts); ts.phase="can"; ts.change=()->tw.tiles.remove(tp.up());
        tm.update(); check(ts.extracted==0 && tm.cursor==0 && tm.energy==2000,"tick does not continue mining after invalidation");
    }
    static void casings() throws Exception {
        DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(160,64,160);
        DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,EnumFacing.NORTH); BlockPos part=p.up();
        TileEntity saved=w.tiles.remove(part); check(!m.structureValid(),"missing casing tile");
        w.tiles.put(part,new TileEntity(){}); check(!m.structureValid(),"wrong casing tile");
        w.tiles.put(part,saved); saved.invalidate(); check(!m.structureValid(),"invalid casing tile");
        saved.validate(); saved.setPos(part.east()); check(!m.structureValid(),"wrong casing position");
        saved.setPos(part); saved.setWorld(DigitalMineTest.world()); check(!m.structureValid(),"wrong casing world");
        saved.setWorld(w); check(m.structureValid(),"valid casing restored");
    }
    static void visual() throws Exception {
        DigitalMineTest.TestWorld w=DigitalMineTest.world(); Unsafe u=unsafe(); u.putBoolean(w,u.objectFieldOffset(World.class.getField("isRemote")),true);
        BlockPos part=new BlockPos(5,64,5), cable=part.west(); DigitalMineCasingTile c=new DigitalMineCasingTile(); c.setWorld(w); c.setPos(part); w.tiles.put(part,c); w.states.put(part,DigitalMineRegistry.CASING.getDefaultState());
        EnergyCableBlock block=new EnergyCableBlock(); w.states.put(cable,block.getDefaultState());
        check(!block.getActualState(block.getDefaultState(),w,cable).getValue(EnergyCableBlock.EAST),"unformed cable");
        NBTTagCompound tag=new NBTTagCompound(); tag.setBoolean("Formed",true); c.handleUpdateTag(tag);
        check(w.renderMin.equals(part.add(-1,-1,-1)) && w.renderMax.equals(part.add(1,1,1)),"redraw neighbours");
        check(c.hasCapability(CapabilityEnergy.ENERGY,EnumFacing.WEST),"client visual advertises FE");
        check(c.getCapability(CapabilityEnergy.ENERGY,EnumFacing.WEST)==null,"client has no FE transaction");
        check(!c.hasCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.WEST),"no client item capability");
        check(block.getActualState(block.getDefaultState(),w,cable).getValue(EnergyCableBlock.EAST),"formed cable connects");
        tag.setBoolean("Formed",false); c.handleUpdateTag(tag);
        check(!block.getActualState(block.getDefaultState(),w,cable).getValue(EnergyCableBlock.EAST),"broken cable disconnects");
    }
    static class Player extends FakePlayer {
        UUID id;
        Player(WorldServer w, GameProfile g) { super(w,g); }
        @Override public UUID getUniqueID() { return id; }
    }
    static void gui() throws Exception {
        for (EnumFacing facing: EnumFacing.HORIZONTALS) {
            DigitalMineTest.TestWorld w=DigitalMineTest.world(); BlockPos p=new BlockPos(180,64,180); DigitalMineTile.Basic m=DigitalMineTest.assemble(w,p,facing);
            Player player=(Player)unsafe().allocateInstance(Player.class); player.world=w; player.id=UUID.randomUUID(); player.inventory=new InventoryPlayer(player); owner(m,player.id);
            BlockPos remote=p.offset(facing.getOpposite(),2).up();
            player.posX=remote.getX()+.5+facing.getOpposite().getFrontOffsetX()*7.5; player.posY=remote.getY()+.5; player.posZ=remote.getZ()+.5+facing.getOpposite().getFrontOffsetZ()*7.5;
            check(player.getDistanceSq(p.getX()+.5,p.getY()+.5,p.getZ()+.5)>64,"beyond controller");
            DigitalMineContainer c=new DigitalMineContainer(player.inventory,m);
            check(c.canInteractWith(player),"near far casing "+facing);
            check(DigitalMineGuiHooks.server(DigitalMineRegistry.GUI_ID,player,w,p.getX(),p.getY(),p.getZ()) != null,"server GUI opens");
            player.posX+=facing.getOpposite().getFrontOffsetX()*2; player.posZ+=facing.getOpposite().getFrontOffsetZ()*2;
            check(!c.canInteractWith(player),"too far "+facing);
            player.posX=remote.getX()+.5; player.posZ=remote.getZ()+.5; player.id=UUID.randomUUID();
            check(!c.canInteractWith(player),"non-owner rejected"); owner(m,player.id);
            w.tiles.remove(remote); check(!c.canInteractWith(player),"invalid structure rejected");
        }
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); DigitalMineRegistry.registerTiles();
        java.lang.reflect.Constructor<?> ctor=Capability.class.getDeclaredConstructors()[0]; ctor.setAccessible(true);
        CapabilityEnergy.ENERGY=(Capability<IEnergyStorage>)ctor.newInstance("test:energy",null,(java.util.concurrent.Callable<IEnergyStorage>)()->null);
        CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<net.minecraftforge.items.IItemHandler>)ctor.newInstance("test:item",null,(java.util.concurrent.Callable<net.minecraftforge.items.IItemHandler>)()->null);
        callbacks(); casings(); visual(); gui();
        Bootstrap.printToSYSOUT("PASS: callback invalidation, provider identity, casing tile, client cable, GUI range");
    }
}
