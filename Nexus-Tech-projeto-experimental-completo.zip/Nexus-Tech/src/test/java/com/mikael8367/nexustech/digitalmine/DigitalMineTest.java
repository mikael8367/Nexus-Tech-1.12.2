package com.mikael8367.nexustech.digitalmine;

import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Bootstrap;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import sun.misc.Unsafe;

public final class DigitalMineTest {
    static void check(boolean b, String s) { if (!b) throw new AssertionError(s); }
    static class TestWorld extends World {
        Map<BlockPos,IBlockState> states; Map<BlockPos,TileEntity> tiles; Set<BlockPos> unloaded; int illegalReads;
        net.minecraft.world.GameRules rules; boolean allowSpawn; List<ItemStack> spawned;
        net.minecraft.world.storage.MapStorage storage; Runnable onDirty; Runnable onSpawn; long time;
        BlockPos renderMin, renderMax;
        @Override public void markBlockRangeForRenderUpdate(BlockPos min, BlockPos max) { renderMin=min; renderMax=max; }
        String spawnFault; int spawnCalls;
        private TestWorld() { super(null,null,null,null,false); }
        protected IChunkProvider createChunkProvider() { return null; }
        protected boolean isChunkLoaded(int x,int z,boolean a) { return true; }
        public boolean isBlockLoaded(BlockPos p) { return !unloaded.contains(p); }
        public IBlockState getBlockState(BlockPos p) { if (unloaded.contains(p)) { illegalReads++; throw new AssertionError("unloaded state"); } IBlockState s=states.get(p); return s == null ? Blocks.AIR.getDefaultState() : s; }
        public TileEntity getTileEntity(BlockPos p) { if (unloaded.contains(p)) { illegalReads++; throw new AssertionError("unloaded tile"); } return tiles.get(p); }
        public int getHeight() { return 256; }
        public net.minecraft.world.GameRules getGameRules() { return rules; }
        public boolean spawnEntity(net.minecraft.entity.Entity entity) {
            spawnCalls++;
            if (onSpawn != null) { Runnable callback=onSpawn; onSpawn=null; callback.run(); }
            if ("before".equals(spawnFault)) throw new IllegalStateException("before effect");
            if (!allowSpawn || net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new net.minecraftforge.event.entity.EntityJoinWorldEvent(entity, this))) return false;
            spawned.add(((net.minecraft.entity.item.EntityItem) entity).getItem().copy());
            if ("after".equals(spawnFault)) throw new IllegalStateException("after effect");
            if ("error-after".equals(spawnFault)) throw new AssertionError("fatal after effect");
            return true;
        }
        public void markChunkDirty(BlockPos p, TileEntity t) { if (onDirty != null) { Runnable callback=onDirty; onDirty=null; callback.run(); } }
        @Override public void notifyBlockUpdate(BlockPos p, IBlockState oldState, IBlockState newState, int flags) {}
        public net.minecraft.world.storage.MapStorage getPerWorldStorage() { return storage; }
        public long getTotalWorldTime() { return time; }
        public void removeTileEntity(BlockPos p) { TileEntity tile=tiles.remove(p); if (tile!=null) tile.invalidate(); }
    }
    static TestWorld world() throws Exception {
        Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true);
        Unsafe u=(Unsafe)f.get(null); TestWorld w=(TestWorld)u.allocateInstance(TestWorld.class);
        w.states=new HashMap<>(); w.tiles=new HashMap<>(); w.unloaded=new HashSet<>();
        w.rules=new net.minecraft.world.GameRules(); w.allowSpawn=true; w.spawned=new ArrayList<>(); w.storage=new net.minecraft.world.storage.MapStorage(null);
        Field rand=World.class.getDeclaredField("rand"); rand.setAccessible(true); rand.set(w,new Random(1));
        Field provider=World.class.getDeclaredField("provider"); provider.setAccessible(true); provider.set(w,new net.minecraft.world.WorldProviderSurface());
        return w;
    }
    static DigitalMineTile.Basic assemble(TestWorld w, BlockPos origin, EnumFacing front) {
        DigitalMineTile.Basic t = new DigitalMineTile.Basic(); t.setWorld(w); t.setPos(origin); w.tiles.put(origin,t);
        w.states.put(origin, DigitalMineRegistry.BASIC.getDefaultState().withProperty(DigitalMineBlock.FACING,front));
        for (int d=0;d<3;d++) for (int y=0;y<2;y++) for (int x=-1;x<=1;x++) {
            BlockPos p=origin.offset(front.getOpposite(),d).offset(front.rotateY(),x).up(y);
            if (!p.equals(origin)) {
                w.states.put(p, DigitalMineRegistry.CASING.getDefaultState());
                DigitalMineCasingTile casing = new DigitalMineCasingTile(); casing.setWorld(w); casing.setPos(p); w.tiles.put(p, casing);
            }
        }
        return t;
    }
    static class Source extends TileEntity implements net.minecraftforge.energy.IEnergyStorage {
        int stored=10000, extracted=0;
        public boolean hasCapability(net.minecraftforge.common.capabilities.Capability<?> c, EnumFacing side) { return c == net.minecraftforge.energy.CapabilityEnergy.ENERGY; }
        public <T> T getCapability(net.minecraftforge.common.capabilities.Capability<T> c, EnumFacing side) { return c == net.minecraftforge.energy.CapabilityEnergy.ENERGY ? net.minecraftforge.energy.CapabilityEnergy.ENERGY.cast(this) : null; }
        public int receiveEnergy(int n, boolean s) { return 0; }
        public int extractEnergy(int n, boolean s) { int v=Math.min(stored,n); if(!s){stored-=v; extracted+=v;} return v; }
        public int getEnergyStored(){return stored;} public int getMaxEnergyStored(){return 10000;}
        public boolean canExtract(){return true;} public boolean canReceive(){return false;}
    }
    static class FaultySource extends Source {
        final String phase;
        FaultySource(String p) { phase=p; }
        public boolean hasCapability(net.minecraftforge.common.capabilities.Capability<?> c, EnumFacing side) {
            if (phase.equals("has")) throw new IllegalStateException("has"); return super.hasCapability(c,side);
        }
        public <T> T getCapability(net.minecraftforge.common.capabilities.Capability<T> c, EnumFacing side) {
            if (phase.equals("get")) throw new IllegalStateException("get"); return super.getCapability(c,side);
        }
        public boolean canExtract() { if (phase.equals("can")) throw new IllegalStateException("can"); return true; }
        public int extractEnergy(int n, boolean simulated) {
            if (phase.equals("extract")) throw new IllegalStateException("extract");
            if (phase.equals("mutate")) { super.extractEnergy(250,false); throw new IllegalStateException("after mutation"); }
            return super.extractEnergy(n,simulated);
        }
    }
    static void testFaultsAndDrops() throws Exception {
        java.lang.reflect.Method pull=DigitalMineTile.class.getDeclaredMethod("pullEnergy"); pull.setAccessible(true);
        for (String phase : new String[]{"has","get","can","extract","mutate"}) {
            TestWorld w=world(); BlockPos p=new BlockPos(20,64,20); DigitalMineTile.Basic machine=assemble(w,p,EnumFacing.NORTH);
            Field ownerField=DigitalMineTile.class.getDeclaredField("owner"); ownerField.setAccessible(true); ownerField.set(machine,UUID.randomUUID());
            FaultySource bad=new FaultySource(phase); Source good=new Source();
            w.tiles.put(p.down(),bad); w.tiles.put(p.north(),good);
            pull.invoke(machine);
            check(machine.energy==1000 && good.extracted==1000,"failed "+phase+" isolated, healthy endpoint credited once");
            check(bad.extracted==(phase.equals("mutate")?250:0),"uncredited failed extraction "+phase);
            machine.energy=0; w.tiles.remove(p.down()); pull.invoke(machine);
            check(machine.energy==1000 && good.extracted==2000,"transfer guard reset after "+phase);
        }
        TestWorld w=world(); BlockPos p=new BlockPos(20,64,20); DigitalMineTile.Basic machine=assemble(w,p,EnumFacing.NORTH);
        w.rules.setOrCreateGameRule("doTileDrops","false");
        net.minecraft.block.Block.spawnAsEntity(w,p,new ItemStack(Blocks.DIAMOND_BLOCK));
        check(w.spawned.isEmpty(),"vanilla spawnAsEntity suppressed by game rule");
        for(int i=0;i<machine.inventory.getSlots();i++) machine.inventory.setStackInSlot(i,new ItemStack(Blocks.STONE,64));
        DigitalMineRecovery recovery=DigitalMineRecovery.get(w);
        machine.queueDrop(new ItemStack(Blocks.DIAMOND_BLOCK,3)); machine.deliverPending(p);
        check(w.spawned.isEmpty() && recovery.size()==1 && machine.pendingDrops().isEmpty(),"overflow handed to recovery without immediate callback");
        recovery.retry(w);
        check(w.spawned.size()==1 && w.spawned.get(0).getCount()==3 && recovery.size()==0,"explicit overflow spawn with doTileDrops false");
        w.allowSpawn=false; machine.queueDrop(new ItemStack(Blocks.DIAMOND_BLOCK,5)); machine.deliverPending(p); recovery.retry(w);
        check(recovery.size()==1,"rejected spawn retained in world data");
        NBTTagCompound nbt=recovery.writeToNBT(new NBTTagCompound()); DigitalMineRecovery restored=new DigitalMineRecovery(); restored.readFromNBT(nbt);
        check(restored.size()==1,"world recovery NBT restored");
        w.unloaded.add(p); w.allowSpawn=true; restored.retry(w);
        check(restored.size()==1 && w.spawned.size()==1,"unloaded recovery deferred"); w.unloaded.clear();
        restored.retry(w); restored.retry(w);
        check(restored.size()==0 && w.spawned.size()==2 && w.spawned.get(1).getCount()==5,"recovered once after restart");
        machine.queueDrop(new ItemStack(Blocks.DIAMOND_BLOCK,2)); machine.invalidate(); machine.deliverPending(p);
        check(recovery.size()==2 && machine.pendingDrops().isEmpty(),"detached tile hands drops to world recovery");
        // Recovery had its original entry too: use an isolated world for removal.
        TestWorld rw=world(); BlockPos rp=new BlockPos(40,64,40); DigitalMineTile.Basic rm=assemble(rw,rp,EnumFacing.NORTH);
        rm.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,7)); rm.queueDrop(new ItemStack(Blocks.DIAMOND_BLOCK,4));
        rw.allowSpawn=false; DigitalMineRegistry.BASIC.breakBlock(rw,rp,rw.states.get(rp));
        DigitalMineRecovery rr=DigitalMineRecovery.get(rw); rr.retry(rw);
        check(rr.size()==2 && rw.spawned.isEmpty(),"breaking controller retains inventory and pending on refusal");
        NBTTagCompound saved=rr.writeToNBT(new NBTTagCompound()); DigitalMineRecovery reloaded=new DigitalMineRecovery(); reloaded.readFromNBT(saved);
        rw.allowSpawn=true; rw.onSpawn=()->reloaded.retry(rw); reloaded.retry(rw); reloaded.retry(rw);
        check(reloaded.size()==0 && rw.spawned.size()==2 && rw.spawned.get(0).getCount()==7 && rw.spawned.get(1).getCount()==4,"break recovery persisted and reentrant retry cannot duplicate");
        // A callback removes the controller inside ItemStackHandler.insertItem.
        TestWorld cw=world(); BlockPos cp=new BlockPos(50,64,50); DigitalMineTile.Basic cm=assemble(cw,cp,EnumFacing.NORTH);
        cm.queueDrop(new ItemStack(Blocks.DIAMOND_BLOCK,9));
        cw.onDirty=()->{ cm.onControllerRemoved(); cw.tiles.remove(cp); cm.invalidate(); };
        cm.deliverPending(cp); DigitalMineRecovery cr=DigitalMineRecovery.get(cw);
        check(cr.size()==1 && cm.pendingDrops().isEmpty() && cm.inventory.getStackInSlot(0).isEmpty(),"insertion callback removal defers transfer without duplication");
        cr.retry(cw); check(cw.spawned.size()==1 && cw.spawned.get(0).getCount()==9,"deferred callback drop recovered exactly once");
        // Full inventory backpressure cache must reset when inventory changes.
        TestWorld bw=world(); BlockPos bp=new BlockPos(60,64,60); DigitalMineTile.Basic bm=assemble(bw,bp,EnumFacing.NORTH);
        for(int i=0;i<bm.inventory.getSlots();i++) bm.inventory.setStackInSlot(i,new ItemStack(Blocks.STONE,64));
        net.minecraft.util.NonNullList<ItemStack> noRoom=net.minecraft.util.NonNullList.create(); noRoom.add(new ItemStack(Blocks.DIAMOND_BLOCK));
        check(!bm.canStoreDrops(bp.down(),Blocks.STONE.getDefaultState(),noRoom),"real capacity check caches blocked target");
        Field blocked=DigitalMineTile.class.getDeclaredField("blockedTarget"); blocked.setAccessible(true);
        java.lang.reflect.Method mine=DigitalMineTile.class.getDeclaredMethod("mine",BlockPos.class,IBlockState.class,int.class); mine.setAccessible(true);
        for(int i=0;i<20;i++) check(((Integer)mine.invoke(bm,bp.down(),Blocks.STONE.getDefaultState(),1200))==2,"blocked target returns before firing events");
        bm.inventory.setStackInSlot(0,ItemStack.EMPTY);
        check(blocked.get(bm)==null && bm.canStoreDrops(bp.down(),Blocks.STONE.getDefaultState(),noRoom),"inventory change wakes blocked target");
        // Removal from within removedByPlayer/harvest callback: mine's finally
        // must flush the removed tile even if entity spawns are denied.
        TestWorld mw=world(); BlockPos mp=new BlockPos(70,64,70); DigitalMineTile.Basic mm=assemble(mw,mp,EnumFacing.NORTH);
        mm.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,11));
        Field mining=DigitalMineTile.class.getDeclaredField("mining"); mining.setAccessible(true); mining.setBoolean(mm,true);
        mm.onControllerRemoved(); mw.tiles.remove(mp); mm.invalidate(); mm.queueDrop(new ItemStack(Blocks.DIAMOND_BLOCK,6)); mm.deliverPending(mp);
        check(DigitalMineRecovery.get(mw).size()==1 && mm.inventory.getStackInSlot(0).getCount()==11,"in-flight removal waits for mining operation");
        mining.setBoolean(mm,false); java.lang.reflect.Method finish=DigitalMineTile.class.getDeclaredMethod("finishDeferredRemoval"); finish.setAccessible(true); finish.invoke(mm);
        DigitalMineRecovery mr=DigitalMineRecovery.get(mw); mw.allowSpawn=false; mr.retry(mw);
        check(mr.size()==2 && mm.inventory.getStackInSlot(0).isEmpty(),"detached mine contents survive refused spawn");
        DigitalMineRecovery afterRestart=new DigitalMineRecovery(); afterRestart.readFromNBT(mr.writeToNBT(new NBTTagCompound()));
        mw.allowSpawn=true; afterRestart.retry(mw);
        check(afterRestart.size()==0 && mw.spawned.size()==2 && mw.spawned.get(0).getCount()==6 && mw.spawned.get(1).getCount()==11,"in-flight removal recovery roundtrip");


    }
    static void testPartialShiftClickWakesAndRestarts() throws Exception {
        TestWorld w=world(); BlockPos p=new BlockPos(80,64,80), target=p.down();
        DigitalMineTile.Basic machine=assemble(w,p,EnumFacing.NORTH);
        for (int i=0; i<27; i++) machine.inventory.setStackInSlot(i,new ItemStack(Blocks.STONE,64));
        net.minecraft.entity.player.InventoryPlayer playerInventory=new net.minecraft.entity.player.InventoryPlayer(null);
        for (int i=0; i<36; i++) playerInventory.setInventorySlotContents(i,new ItemStack(Blocks.STONE,64));
        DigitalMineContainer container=new DigitalMineContainer(playerInventory,machine);
        IBlockState state=Blocks.STONE.getDefaultState();
        net.minecraft.util.NonNullList<ItemStack> drops=net.minecraft.util.NonNullList.create();
        drops.add(new ItemStack(Blocks.STONE));
        check(!machine.canStoreDrops(target,state,drops),"full inventory blocks target");
        java.lang.reflect.Method mine=DigitalMineTile.class.getDeclaredMethod("mine",BlockPos.class,IBlockState.class,int.class);
        mine.setAccessible(true);
        check(((Integer)mine.invoke(machine,target,state,1200))==2,"blocked target is cached");
        check(container.transferStackInSlot(null,0).isEmpty() && ((Integer)mine.invoke(machine,target,state,1200))==2,
            "unsuccessful shift-click leaves blocked cache in place");
        playerInventory.setInventorySlotContents(0,new ItemStack(Blocks.STONE,63));
        final boolean[] dirtied={false}; w.onDirty=()->dirtied[0]=true;
        ItemStack moved=container.transferStackInSlot(null,0);
        check(!moved.isEmpty() && moved.getCount()==64 && machine.inventory.getStackInSlot(0).getCount()==63
            && playerInventory.getStackInSlot(0).getCount()==64,"shift-click moves exactly one item, leaves source nonempty");
        check(dirtied[0],"partial extraction marks tile dirty for saving");
        // The test world is not WorldServer: zero means the cache no longer short-circuits,
        // not that a real block has been mined.
        check(((Integer)mine.invoke(machine,target,state,1200))==0,"partial shift-click wakes cached target for retry");
        check(machine.canStoreDrops(target,state,drops),"freed space accepts blocked drop");
        DigitalMineTile.Basic restored=new DigitalMineTile.Basic();
        restored.readFromNBT(machine.writeToNBT(new NBTTagCompound()));
        check(restored.inventory.getStackInSlot(0).getCount()==63 && restored.canStoreDrops(target,state,drops),
            "partial extraction and available space survive NBT restart");
    }
    static void testShiftClickReentrantRemoval() throws Exception {
        for (boolean partial : new boolean[]{false,true}) {
            TestWorld w=world(); BlockPos p=new BlockPos(180,64,180);
            DigitalMineTile.Basic m=assemble(w,p,EnumFacing.NORTH);
            m.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,64));
            final class CallbackInventory extends net.minecraft.entity.player.InventoryPlayer {
                Runnable callback;
                CallbackInventory() { super(null); }
                @Override public void markDirty() { super.markDirty(); if (callback != null) { Runnable c=callback; callback=null; c.run(); } }
            }
            CallbackInventory player=new CallbackInventory();
            if (partial) {
                for (int i=0;i<36;i++) player.setInventorySlotContents(i,new ItemStack(Blocks.STONE,64));
                player.setInventorySlotContents(0,new ItemStack(Blocks.STONE,63));
            }
            DigitalMineContainer c=new DigitalMineContainer(player,m);
            final boolean[] removed={false};
            player.callback=()->{ removed[0]=true; m.onControllerRemoved(); w.tiles.remove(p); m.invalidate(); };
            c.transferStackInSlot(null,0);
            check(removed[0],"shift-click destination callback removed controller");
            int playerCount=0; for (int i=0;i<36;i++) playerCount+=player.getStackInSlot(i).getCount();
            DigitalMineRecovery recovery=DigitalMineRecovery.get(w); recovery.retry(w);
            int ground=0; for (ItemStack s:w.spawned) ground+=s.getCount();
            int initial=64+(partial ? 36*64-1 : 0);
            check(playerCount+ground==initial,"reentrant shift-click removal preserves items: player="+playerCount+" ground="+ground);
        }
    }
    static void testCorruptInventoryAndCachedCapability() throws Exception {
        DigitalMineTile.Basic source = new DigitalMineTile.Basic();
        source.inventory.setStackInSlot(0, new ItemStack(Blocks.STONE, 7));
        NBTTagCompound nbt = source.writeToNBT(new NBTTagCompound());
        NBTTagCompound inv = nbt.getCompoundTag("Inventory");
        inv.setInteger("Size", 1);
        DigitalMineTile.Basic restored = new DigitalMineTile.Basic();
        restored.readFromNBT(nbt);
        check(restored.inventory.getSlots() == 27 && restored.inventory.getStackInSlot(0).getCount() == 7,
            "corrupt inventory size must not shrink the 27-slot GUI");
        inv.setInteger("Size", 1000000000);
        NBTTagCompound extra = new ItemStack(Blocks.DIAMOND_BLOCK, 5).writeToNBT(new NBTTagCompound());
        extra.setInteger("Slot", 30);
        inv.getTagList("Items", 10).appendTag(extra);
        NBTTagCompound duplicate = new ItemStack(Blocks.STONE, 3).writeToNBT(new NBTTagCompound());
        duplicate.setInteger("Slot", 0);
        inv.getTagList("Items", 10).appendTag(duplicate);
        restored.readFromNBT(nbt);
        check(restored.inventory.getSlots() == 27 && restored.pendingDrops().size() == 2
            && restored.pendingDrops().get(0).getCount() == 5 && restored.pendingDrops().get(1).getCount() == 3
            && restored.inventory.getStackInSlot(0).getCount() == 7,
            "out-of-range and duplicate saved items retained without giant allocation");
        DigitalMineTile.Basic twice = new DigitalMineTile.Basic();
        twice.readFromNBT(restored.writeToNBT(new NBTTagCompound()));
        check(twice.pendingDrops().size() == 2 && twice.pendingDrops().get(0).getCount() == 5
            && twice.pendingDrops().get(1).getCount() == 3,
            "recovered excess persists on next save");
        TestWorld w = world(); BlockPos p = new BlockPos(190,64,190);
        DigitalMineTile.Basic machine = assemble(w,p,EnumFacing.NORTH);
        machine.inventory.setStackInSlot(0,new ItemStack(Blocks.STONE,8));
        net.minecraftforge.items.IItemHandler output = machine.getCapability(net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.NORTH);
        check(output != null && output.insertItem(0,new ItemStack(Blocks.STONE),false).getCount()==1,"output refuses insertion");
        ItemStack view = output.getStackInSlot(0); view.shrink(3);
        check(machine.inventory.getStackInSlot(0).getCount()==8,"output view cannot mutate inventory");
        w.unloaded.add(p);
        check(output.extractItem(0,2,false).isEmpty() && machine.inventory.getStackInSlot(0).getCount()==8,
            "cached capability cannot extract in unloaded chunk");
        w.unloaded.clear();
        check(output.extractItem(0,2,false).getCount()==2,"attached output can extract");
        w.tiles.remove(p);
        check(output.extractItem(0,2,false).isEmpty() && machine.inventory.getStackInSlot(0).getCount()==6,
            "cached capability cannot extract detached controller");
    }
    static void testNbtExcessDelivery() throws Exception {
        TestWorld w=world(); BlockPos p=new BlockPos(202,64,202);
        DigitalMineTile.Basic machine=assemble(w,p,EnumFacing.NORTH);
        for (int i=0;i<27;i++) machine.inventory.setStackInSlot(i,new ItemStack(Blocks.STONE,64));
        NBTTagCompound raw=machine.writeToNBT(new NBTTagCompound());
        NBTTagCompound inv=raw.getCompoundTag("Inventory"); inv.setInteger("Size",1);
        NBTTagCompound extra=new ItemStack(Blocks.DIAMOND_BLOCK,5).writeToNBT(new NBTTagCompound()); extra.setInteger("Slot",30);
        NBTTagCompound dup=new ItemStack(Blocks.DIAMOND_BLOCK,3).writeToNBT(new NBTTagCompound()); dup.setInteger("Slot",0);
        inv.getTagList("Items",10).appendTag(extra); inv.getTagList("Items",10).appendTag(dup);
        machine.readFromNBT(raw);
        check(machine.pendingDrops().size()==2 && machine.inventory.getSlots()==27,"excess read as pending");
        machine.enabled=false; machine.update();
        DigitalMineRecovery recovery=DigitalMineRecovery.get(w);
        check(machine.pendingDrops().isEmpty() && recovery.size()==2 && w.spawned.isEmpty(),"full inventory forwards both excess stacks to recovery");
        NBTTagCompound saved=recovery.writeToNBT(new NBTTagCompound());
        DigitalMineRecovery restored=new DigitalMineRecovery(); restored.readFromNBT(saved);
        w.allowSpawn=false; restored.retry(w);
        check(restored.size()==2 && w.spawned.isEmpty(),"NBT overflow survives rejected spawn");
        DigitalMineRecovery again=new DigitalMineRecovery(); again.readFromNBT(restored.writeToNBT(new NBTTagCompound()));
        w.allowSpawn=true; again.retry(w);
        check(again.size()==0 && w.spawned.size()==2 && w.spawned.get(0).getCount()==5
            && w.spawned.get(1).getCount()==3,"overflow delivered once after persisted retry");
        // A free slot receives excess directly; world recovery is not needed.
        TestWorld w2=world(); BlockPos p2=new BlockPos(203,64,203); DigitalMineTile.Basic free=assemble(w2,p2,EnumFacing.NORTH);
        NBTTagCompound n=free.writeToNBT(new NBTTagCompound());
        net.minecraft.nbt.NBTTagList list=new net.minecraft.nbt.NBTTagList();
        list.appendTag(extra.copy()); n.getCompoundTag("Inventory").setTag("Items",list);
        free.readFromNBT(n); free.enabled=false; free.update();
        check(free.pendingDrops().isEmpty() && free.inventory.getStackInSlot(0).getCount()==5
            && DigitalMineRecovery.get(w2).size()==0,"space routes excess to inventory first");
    }
    static void testRecoveryDiskPersistence() throws Exception {
        java.io.File dir=java.nio.file.Files.createTempDirectory("digitalmine-savedata-").toFile();
        net.minecraft.world.storage.ISaveHandler handler=(net.minecraft.world.storage.ISaveHandler)
            java.lang.reflect.Proxy.newProxyInstance(DigitalMineTest.class.getClassLoader(),
                new Class<?>[]{net.minecraft.world.storage.ISaveHandler.class},
                (proxy,method,args)->method.getName().equals("getMapFileFromName")
                    ? new java.io.File(dir,args[0]+".dat") : null);
        TestWorld w=world(); w.storage=new net.minecraft.world.storage.MapStorage(handler);
        BlockPos p=new BlockPos(210,64,210); DigitalMineRecovery data=DigitalMineRecovery.get(w);
        data.enqueue(p,new ItemStack(Blocks.DIAMOND_BLOCK,7));
        w.spawnFault="after"; data.retry(w); w.storage.saveAllData();
        check(new java.io.File(dir,"nexustech_digitalmine_recovery.dat").isFile(),"MapStorage writes recovery data");
        w.storage=new net.minecraft.world.storage.MapStorage(handler); w.spawnFault=null;
        DigitalMineRecovery loaded=DigitalMineRecovery.get(w); loaded.retry(w);
        check(w.spawnCalls==1 && w.spawned.size()==1
            && loaded.writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==1,
            "real compressed MapStorage reload keeps quarantine without retry");
        loaded.enqueue(p,new ItemStack(Blocks.STONE,2)); w.allowSpawn=false; loaded.retry(w); w.storage.saveAllData();
        w.storage=new net.minecraft.world.storage.MapStorage(handler); loaded=DigitalMineRecovery.get(w);
        w.allowSpawn=true; loaded.retry(w);
        check(w.spawnCalls==3 && w.spawned.size()==2 && w.spawned.get(1).getCount()==2
            && loaded.writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==1,
            "disk reload retries rejection but not quarantine");
    }
    static void testUncertainSpawn() throws Exception {
        for (String fault : new String[]{"after", "before"}) {
            TestWorld w=world(); BlockPos p=new BlockPos(201,64,201);
            DigitalMineRecovery data=DigitalMineRecovery.get(w);
            data.enqueue(p,new ItemStack(Blocks.DIAMOND_BLOCK,5));
            final NBTTagCompound[] during={null};
            w.onSpawn=()->during[0]=data.writeToNBT(new NBTTagCompound());
            w.spawnFault=fault; data.retry(w); w.spawnFault=null; data.retry(w);
            check(during[0].getTagList("Entries",10).tagCount()==0
                && during[0].getTagList("Quarantine",10).tagCount()==1,
                "save inside spawn observes quarantine before effect");
            DigitalMineRecovery interrupted=new DigitalMineRecovery(); interrupted.readFromNBT(during[0]);
            interrupted.retry(w);
            check(w.spawnCalls==1,"snapshot during callback never auto-retries");
            check(w.spawnCalls==1 && w.spawned.size()==(fault.equals("after")?1:0),
                "uncertain "+fault+" must not be retried, even if the effect already happened");
            NBTTagCompound saved=data.writeToNBT(new NBTTagCompound());
            net.minecraft.nbt.NBTTagList quarantine=saved.getTagList("Quarantine",10);
            check(data.size()==0 && quarantine.tagCount()==1,"uncertain spawn quarantined");
            NBTTagCompound entry=quarantine.getCompoundTagAt(0);
            check(entry.getInteger("X")==201 && entry.getInteger("Y")==64 && entry.getInteger("Z")==201
                && new ItemStack(entry.getCompoundTag("Stack")).getCount()==5,"quarantine retains position and item");
            DigitalMineRecovery restored=new DigitalMineRecovery(); restored.readFromNBT(saved);
            restored.retry(w); restored.retry(w);
            check(w.spawnCalls==1 && restored.writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==1,
                "quarantine persists across reload without retry");
            restored.enqueue(p,new ItemStack(Blocks.STONE,2)); restored.retry(w);
            check(w.spawnCalls==2 && w.spawned.size()==(fault.equals("after")?2:1),
                "quarantine does not block unrelated entries");
        }
    }
    static void testFatalSpawn() throws Exception {
        TestWorld w=world(); DigitalMineRecovery data=DigitalMineRecovery.get(w);
        data.enqueue(new BlockPos(220,64,220),new ItemStack(Blocks.DIAMOND_BLOCK,4));
        w.spawnFault="error-after"; boolean propagated=false;
        try { data.retry(w); } catch (AssertionError expected) { propagated=true; }
        check(propagated && w.spawned.size()==1 && data.size()==0,"fatal Error propagates after effect");
        DigitalMineRecovery restored=new DigitalMineRecovery(); restored.readFromNBT(data.writeToNBT(new NBTTagCompound()));
        w.spawnFault=null; restored.retry(w);
        check(w.spawnCalls==1 && restored.writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==1,
            "fatal Error leaves serializable quarantine without retry");
    }
    static void testTickAndCancellation() throws Exception {
        TestWorld w=world(); BlockPos p=new BlockPos(100,64,100); DigitalMineRecovery data=DigitalMineRecovery.get(w);
        data.enqueue(p,new ItemStack(Blocks.DIAMOND_BLOCK,5));
        w.allowSpawn=false;
        DigitalMineRecovery.worldTick(new net.minecraftforge.fml.common.gameevent.TickEvent.WorldTickEvent(net.minecraftforge.fml.relauncher.Side.SERVER,net.minecraftforge.fml.common.gameevent.TickEvent.Phase.START,w));
        w.time=1; DigitalMineRecovery.worldTick(new net.minecraftforge.fml.common.gameevent.TickEvent.WorldTickEvent(net.minecraftforge.fml.relauncher.Side.SERVER,net.minecraftforge.fml.common.gameevent.TickEvent.Phase.END,w));
        check(w.spawned.isEmpty() && data.size()==1,"tick waits for end phase and 20 tick interval");
        w.time=20; DigitalMineRecovery.worldTick(new net.minecraftforge.fml.common.gameevent.TickEvent.WorldTickEvent(net.minecraftforge.fml.relauncher.Side.SERVER,net.minecraftforge.fml.common.gameevent.TickEvent.Phase.END,w));
        check(data.size()==1 && w.spawned.isEmpty(),"refused entity spawn retains item");
        w.allowSpawn=true; w.time=40;
        DigitalMineRecovery.worldTick(new net.minecraftforge.fml.common.gameevent.TickEvent.WorldTickEvent(net.minecraftforge.fml.relauncher.Side.SERVER,net.minecraftforge.fml.common.gameevent.TickEvent.Phase.END,w));
        check(data.size()==0 && w.spawned.size()==1 && w.spawned.get(0).getCount()==5,"later tick retries accepted spawn once");
    }
    static class RemoveBlock extends net.minecraft.block.Block {
        final DigitalMineTile tile; String result; int seen;
        RemoveBlock(DigitalMineTile tile, String result) { super(net.minecraft.block.material.Material.ROCK); this.tile=tile; this.result=result; }
        @Override public boolean removedByPlayer(IBlockState state, World w, BlockPos p, net.minecraft.entity.player.EntityPlayer player, boolean harvest) {
            seen=tile.energy;
            if (result.equals("throw")) throw new IllegalStateException("test callback");
            if (result.equals("unloaded")) ((TestWorld)w).unloaded.add(p);
            if (result.equals("success")) ((TestWorld)w).states.put(p,Blocks.AIR.getDefaultState());
            return !result.equals("false");
        }
    }
    static void testEnergyReservation() throws Exception {
        TestWorld w=world(); BlockPos p=new BlockPos(90,64,90), target=p.down(); DigitalMineTile.Basic m=assemble(w,p,EnumFacing.NORTH);
        for (String result : new String[]{"false","unchanged","throw","success"}) {
            m.energy=3000; RemoveBlock block=new RemoveBlock(m,result); IBlockState state=block.getDefaultState(); w.states.put(target,state);
            boolean ok=false;
            try { ok=m.removeTarget(target,state,null,1200); } catch (IllegalStateException ex) { check(result.equals("throw"),"only expected callback exception"); }
            check(block.seen==1800,"energy reserved before "+result+" callback");
            check(ok==result.equals("success") && m.energy==(ok?1800:3000),"energy committed/refunded on "+result);
        }
        m.energy=3000; RemoveBlock uncertain=new RemoveBlock(m,"unloaded"); IBlockState old=uncertain.getDefaultState();
        w.states.put(target,old);
        check(!m.removeTarget(target,old,null,1200),"unloaded target after callback is not confirmed removed");
        check(m.energy==1800 && w.illegalReads==0,"uncertain removal retains cost and does not load/read chunk");
        w.unloaded.clear();
        check(w.getBlockState(target)==old,"true callback left original target intact");
    }
    static class HarvestListener {
        int calls;
        @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
        public void onHarvest(net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent e) {
            calls++; e.getDrops().clear(); e.getDrops().add(new ItemStack(Blocks.DIAMOND_BLOCK,3)); e.setDropChance(1);
        }
    }
    static void testPartsAndCapabilities() throws Exception {
        for (EnumFacing front : EnumFacing.HORIZONTALS) {
            TestWorld w = world(); BlockPos p = new BlockPos(230, 64, 230);
            DigitalMineTile.Basic mine = assemble(w, p, front);
            mine.inventory.setStackInSlot(0, new ItemStack(Blocks.DIAMOND_BLOCK, 9));
            List<DigitalMineCasingTile> parts = new ArrayList<>();
            for (int d=0;d<3;d++) for (int y=0;y<2;y++) for (int x=-1;x<=1;x++) {
                BlockPos at=p.offset(front.getOpposite(),d).offset(front.rotateY(),x).up(y);
                if (at.equals(p)) continue;
                DigitalMineCasingTile part=new DigitalMineCasingTile(); part.setWorld(w); part.setPos(at); w.tiles.put(at,part); parts.add(part);
                check(DigitalMineStructure.controllerAt(w,at)==mine, "resolve every part "+front+" "+at);
                check(DigitalMineRegistry.CASING.getActualState(w.states.get(at),w,at).getValue(DigitalMineCasing.FORMED), "formed casing actual state");
                for (EnumFacing side : EnumFacing.VALUES) {
                    net.minecraftforge.energy.IEnergyStorage energy=part.getCapability(net.minecraftforge.energy.CapabilityEnergy.ENERGY,side);
                    net.minecraftforge.items.IItemHandler item=part.getCapability(net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,side);
                    check(energy!=null && item!=null && energy.receiveEnergy(1,true)==1 && item.extractItem(0,1,true).getCount()==1, "all faces simulate");
                }
            }
            check(parts.size()==17 && DigitalMineRegistry.BASIC.getActualState(w.states.get(p),w,p).getValue(DigitalMineBlock.FORMED), "18 formed cells");
            DigitalMineCasingTile part=parts.get(0);
            net.minecraftforge.energy.IEnergyStorage oldEnergy=part.getCapability(net.minecraftforge.energy.CapabilityEnergy.ENERGY,EnumFacing.DOWN);
            net.minecraftforge.items.IItemHandler oldItem=part.getCapability(net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.DOWN);
            check(oldEnergy.receiveEnergy(200,false)==200 && mine.energy==200, "FE credited exactly once");
            check(oldItem.extractItem(0,1,false).getCount()==1 && mine.inventory.getStackInSlot(0).getCount()==8, "part extracts once");
            BlockPos missing=parts.get(1).getPos(); IBlockState saved=w.states.remove(missing);
            check(oldEnergy.receiveEnergy(50,false)==0 && oldItem.extractItem(0,1,false).isEmpty(), "invalid structure refuses cached references");
            check(!DigitalMineRegistry.CASING.getActualState(w.states.get(part.getPos()),w,part.getPos()).getValue(DigitalMineCasing.FORMED), "invalid actual state");
            w.states.put(missing,saved);
            check(oldEnergy.receiveEnergy(50,false)==0 && oldItem.extractItem(0,1,false).isEmpty(), "observed invalidation permanently revokes cached references");
            net.minecraftforge.energy.IEnergyStorage freshEnergy=part.getCapability(net.minecraftforge.energy.CapabilityEnergy.ENERGY,EnumFacing.DOWN);
            net.minecraftforge.items.IItemHandler freshItem=part.getCapability(net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.DOWN);
            check(freshEnergy != null && freshItem != null, "fresh references after rebuild");
            w.unloaded.add(missing);
            check(freshEnergy.receiveEnergy(50,false)==0 && freshItem.extractItem(0,1,false).isEmpty(), "unloaded structure refuses cached references");
            w.unloaded.clear(); w.tiles.remove(part.getPos());
            DigitalMineCasingTile replacement=new DigitalMineCasingTile(); replacement.setWorld(w); replacement.setPos(part.getPos()); w.tiles.put(part.getPos(),replacement);
            check(oldEnergy.receiveEnergy(50,false)==0 && oldItem.extractItem(0,1,false).isEmpty(), "removed casing cannot forward");
            check(w.illegalReads==0, "no unloaded reads in parts");
        }
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        DigitalMineRegistry.registerTiles();
        java.lang.reflect.Constructor<?> ctor=net.minecraftforge.common.capabilities.Capability.class.getDeclaredConstructors()[0]; ctor.setAccessible(true);
        net.minecraftforge.energy.CapabilityEnergy.ENERGY=(net.minecraftforge.common.capabilities.Capability<net.minecraftforge.energy.IEnergyStorage>)ctor.newInstance("test:energy",null,(java.util.concurrent.Callable<net.minecraftforge.energy.IEnergyStorage>)() -> null);
        net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(net.minecraftforge.common.capabilities.Capability<net.minecraftforge.items.IItemHandler>)ctor.newInstance("test:item",null,(java.util.concurrent.Callable<net.minecraftforge.items.IItemHandler>)() -> null);
        testPartsAndCapabilities();
        testUncertainSpawn();
        testFatalSpawn();
        testRecoveryDiskPersistence();
        testNbtExcessDelivery();
        testShiftClickReentrantRemoval();
        testCorruptInventoryAndCachedCapability();
        BlockPos origin=new BlockPos(17,64,20);
        for (boolean advanced : new boolean[]{false,true}) for (EnumFacing front : EnumFacing.HORIZONTALS) {
            TestWorld w=world(); DigitalMineTile tile=advanced ? new DigitalMineTile.Advanced() : new DigitalMineTile.Basic();
            tile.setWorld(w); tile.setPos(origin); w.tiles.put(origin,tile);
            DigitalMineBlock block=advanced ? DigitalMineRegistry.ADVANCED : DigitalMineRegistry.BASIC;
            IBlockState control=block.getDefaultState().withProperty(DigitalMineBlock.FACING,front);
            check(block.getStateFromMeta(block.getMetaFromState(control)).equals(control),"metadata "+front);
            w.states.put(origin,control);
            Set<BlockPos> cells=new HashSet<>();
            for(int d=0;d<3;d++) for(int y=0;y<2;y++) for(int x=-1;x<=1;x++) {
                BlockPos p=origin.offset(front.getOpposite(),d).offset(front.rotateY(),x).up(y); cells.add(p);
                if (!p.equals(origin)) {
                    w.states.put(p,DigitalMineRegistry.CASING.getDefaultState());
                    DigitalMineCasingTile casing=new DigitalMineCasingTile(); casing.setWorld(w); casing.setPos(p); w.tiles.put(p,casing);
                }
            }
            check(cells.size()==18,"18 unique positions"); check(tile.structureValid(),"assembled "+front);
            for(BlockPos p: cells) {
                if (p.equals(origin)) continue;
                IBlockState saved=w.states.remove(p); check(!tile.structureValid(),"missing "+p); w.states.put(p,saved);
                w.unloaded.add(p); check(!tile.structureValid(),"unloaded "+p); w.unloaded.remove(p);
            }
            w.unloaded.add(origin); check(!tile.structureValid(),"unloaded controller"); w.unloaded.clear();
            check(w.illegalReads==0,"never read unloaded");
        }
        DigitalMineTile a=new DigitalMineTile.Advanced(); a.energy=54321; a.mode=1; a.cursor=384; a.delay=7; a.enabled=false;
        a.inventory.setStackInSlot(3,new ItemStack(Blocks.STONE,17));
        NBTTagCompound nbt=a.writeToNBT(new NBTTagCompound()); DigitalMineTile b=new DigitalMineTile.Advanced(); b.readFromNBT(nbt);
        check(b.energy==54321 && b.mode==1 && b.cursor==384 && b.delay==7 && !b.enabled,"persistent fields");
        check(b.inventory.getStackInSlot(3).getCount()==17 && b.inventory.getStackInSlot(3).getItem()==net.minecraft.item.Item.getItemFromBlock(Blocks.STONE),"persistent inventory");
        nbt.setInteger("Energy",Integer.MAX_VALUE); nbt.setInteger("Mode",99); nbt.setInteger("Delay",Integer.MAX_VALUE); b.readFromNBT(nbt);
        check(b.energy==b.capacity && b.mode==0 && b.delay==b.baseDelay,"corrupt nbt clamped");
        TestWorld w=world(); BlockPos p=new BlockPos(0,64,0);
        DigitalMineTile.Basic first=assemble(w,p,EnumFacing.NORTH);
        DigitalMineTile.Basic second=assemble(w,p.add(2,0,0),EnumFacing.NORTH);
        check(first.structureValid() && !second.structureValid(),"overlapping casing has one deterministic winner");
        w.states.remove(p); check(second.structureValid(),"reservation released when first is removed");
        w.states.put(p,DigitalMineRegistry.BASIC.getDefaultState().withProperty(DigitalMineBlock.FACING,EnumFacing.NORTH));
        BlockPos firstOnly=p.add(-1,0,0); w.states.remove(firstOnly);
        check(second.structureValid(),"reservation released when first is physically invalid");
        w.states.put(firstOnly,DigitalMineRegistry.CASING.getDefaultState());
        w.unloaded.add(p); check(!second.structureValid(),"unloaded competing controller never assumed free");
        check(w.illegalReads==0,"no unloaded conflict reads");

        TestWorld eworld=world(); BlockPos ep=new BlockPos(20,64,20);
        DigitalMineTile.Basic machine=assemble(eworld,ep,EnumFacing.NORTH);
        Field owner=DigitalMineTile.class.getDeclaredField("owner"); owner.setAccessible(true); owner.set(machine,UUID.randomUUID());
        Source src=new Source(); eworld.tiles.put(ep.down(),src);
        machine.enabled=false; machine.update(); check(src.extracted==0,"disabled does not pull FE");
        machine.enabled=true; eworld.states.remove(ep.up()); machine.update(); check(src.extracted==0,"invalid structure does not pull FE");
        eworld.states.put(ep.up(),DigitalMineRegistry.CASING.getDefaultState());
        machine.energy=2000;
        BlockPos skipped=ep.add(-8,-1,-8); eworld.unloaded.add(skipped);
        machine.update(); check(src.extracted==1000 && machine.cursor==128,"advance beyond unloaded target in one tick");
        machine.update(); check(machine.cursor==256,"does not revisit skipped target next tick");
        check(eworld.illegalReads==0,"never reads skipped target");

        net.minecraft.util.NonNullList<ItemStack> list=net.minecraft.util.NonNullList.create(); list.add(new ItemStack(Blocks.STONE));
        HarvestListener listener=new HarvestListener();
        Field id=net.minecraftforge.fml.common.eventhandler.EventBus.class.getDeclaredField("busID"); id.setAccessible(true);
        int busId=id.getInt(net.minecraftforge.common.MinecraftForge.EVENT_BUS);
        net.minecraftforge.fml.common.eventhandler.ListenerList listeners = new net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent(eworld,ep,Blocks.STONE.getDefaultState(),0,1,list,null,false).getListenerList();
        net.minecraftforge.fml.common.eventhandler.IEventListener hook = event -> { if (event instanceof net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent) listener.onHarvest((net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent)event); };
        listeners.register(busId,net.minecraftforge.fml.common.eventhandler.EventPriority.NORMAL,hook);
        net.minecraft.util.NonNullList<ItemStack> selected=DigitalMineTile.harvestDrops(list,eworld,ep,Blocks.STONE.getDefaultState(),null,new Random(1));
        listeners.unregister(busId,hook);
        check(listener.calls==1 && selected.size()==1 && selected.get(0).getItem()==net.minecraft.item.Item.getItemFromBlock(Blocks.DIAMOND_BLOCK) && selected.get(0).getCount()==3,"one harvest event honors modified list");
        check(DigitalMineTile.selectDrops(selected,-1,new Random(1)).isEmpty(),"drop chance suppresses drops");
        check(DigitalMineTile.selectDrops(selected,1,new Random(1)).size()==1,"drop chance retains drops");
        testFaultsAndDrops(); testEnergyReservation(); testTickAndCancellation(); testPartialShiftClickWakesAndRestarts();
        Bootstrap.printToSYSOUT("PASS: structures, exclusivity/release, unloaded chunks, disabled/invalid FE, scan, HarvestDropsEvent, chance, metadata, NBT, faulty FE endpoints, persistent recovery, reentrancy, backpressure and FE reservation");
    }
}
