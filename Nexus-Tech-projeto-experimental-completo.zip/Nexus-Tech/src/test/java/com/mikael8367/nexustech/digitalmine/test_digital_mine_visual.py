#!/usr/bin/env python3
"""Static regression for Digital Mine models; does not render Minecraft."""
import base64
import io
import json
import unittest
from pathlib import Path
from PIL import Image

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'build.gradle').exists())
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures'


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


class DigitalMineVisualTest(unittest.TestCase):
    def test_same_facing_coplanar_faces_do_not_overlap(self):
        # Positive-area overlapping, same-facing quads can flicker (z-fighting).
        faces = {'north': (2, 'from'), 'south': (2, 'to'),
                 'down': (1, 'from'), 'up': (1, 'to'),
                 'west': (0, 'from'), 'east': (0, 'to')}
        for kind in ('basic', 'advanced'):
            model = load(ASSETS / 'models/block' / ('digital_mine_' + kind + '.json'))
            for i, a in enumerate(model['elements']):
                for j, b in enumerate(model['elements'][:i]):
                    for face, (axis, bound) in faces.items():
                        if face not in a['faces'] or face not in b['faces']:
                            continue
                        other_axes = [n for n in range(3) if n != axis]
                        overlap = all(max(a['from'][n], b['from'][n]) < min(a['to'][n], b['to'][n]) for n in other_axes)
                        with self.subTest(kind=kind, first=j, second=i, face=face):
                            self.assertFalse(a[bound][axis] == b[bound][axis] and overlap)

    def test_facing_models_and_source_textures(self):
        for kind in ('basic', 'advanced'):
            name = 'digital_mine_' + kind
            state = load(ASSETS / 'blockstates' / (name + '.json'))['variants']
            directions = (('north', 0), ('east', 90), ('south', 180), ('west', 270))
            self.assertEqual(set(state), {'facing=' + d + ',formed=' + f
                                          for d, _ in directions for f in ('false', 'true')})
            for direction, rotation in directions:
                for formed in ('false', 'true'):
                    variant = state['facing=' + direction + ',formed=' + formed]
                    suffix = '_formed' if formed == 'true' else ''
                    self.assertEqual(variant['model'], 'nexustech:' + name + suffix)
                    self.assertEqual(variant.get('y', 0), rotation)
            for suffix in ('', '_formed'):
                model = load(ASSETS / 'models/block' / (name + suffix + '.json'))
                if suffix:
                    self.assertEqual(model['parent'], 'nexustech:block/' + name)
                else:
                    self.assertEqual(model['elements'][0]['faces']['north']['texture'], '#front')
                for ref in model['textures'].values():
                    self.assertTrue(ref.startswith('nexustech:'))
                    path = TEXTURES / (ref.split(':', 1)[1] + '.png.b64')
                    data = base64.b64decode(path.read_text().strip(), validate=True)
                    with Image.open(io.BytesIO(data)) as image:
                        image.verify()
            self.assertEqual(load(ASSETS / 'models/item' / (name + '.json'))['parent'], 'nexustech:block/' + name)

    def test_covering_faces_are_preserved(self):
        basic = load(ASSETS / 'models/block/digital_mine_basic.json')['elements']
        advanced = load(ASSETS / 'models/block/digital_mine_advanced.json')['elements']
        self.assertIn('down', basic[1]['faces'])
        self.assertIn('up', advanced[2]['faces'])
        self.assertEqual((basic[1]['from'], basic[1]['to']), ([0, 0, 0], [16, 2, 16]))
        self.assertEqual((advanced[2]['from'], advanced[2]['to']), ([0, 14, 0], [16, 15, 16]))


if __name__ == '__main__':
    unittest.main()
