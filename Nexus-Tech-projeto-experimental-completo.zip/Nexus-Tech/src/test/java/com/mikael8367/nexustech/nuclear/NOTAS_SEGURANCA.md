# Regressões de segurança nuclear

Com Java 8 e dependências ForgeGradle já em cache, executar na raiz do projeto:

```sh
bash ./gradlew --offline --no-daemon -I src/test/java/com/mikael8367/nexustech/nuclear/nuclear-safety-check.init.gradle nuclearSafetyCheck
```

O teste principal `NuclearUpdateReentryTest` executa `NuclearRecoveryTest`, que também executa `NuclearSafetyTest`, `NuclearReactorTest` e `NuclearRegressionTest`. A regressão de reentrada cobre callbacks em `getCapability`, `canReceive` e `receiveEnergy`, orçamento de saída, consumo de combustível, tick seguinte e liberação da guarda após erro. Inclui rejeição e reentrada no descarte, repetição com chunk carregado, salvamento/restauração NBT da fila e handlers guardados depois da remoção. No teste NBT isolado, um item vanilla registrado substitui o combustível, porque o bootstrap standalone não registra o item do mod; a entrega do combustível real é testada sem serialização. Abrange estrutura inválida ou indisponível, interrupção e persistência, ausência de religamento automático, reinício manual após resfriamento, retenção de vínculos e proteção de mineração com controlador quente ou inacessível, disputa por peças, comportamento do tanque e simulação, além das regressões prévias de energia, itens e estruturas.

A fila é WorldSavedData por dimensão: a remoção transfere os itens e os retries ocorrem a cada 20 ticks, somente em chunks carregados. Se spawn retornar false, a pilha permanece. Se outro mod lançar exceção depois de adicionar a entidade, não é possível saber se houve efeito e o retry pode duplicar. Não existe transação atômica entre inventário, WorldSavedData e entidades/chunks: crash ou rollback de salvamentos pode causar perda ou duplicação. Água, FE e combustível já consumido do controlador não são recuperados ao removê-lo.

Os testes usam o controlador e os handlers reais em um mundo isolado de teste. O callback de proteção é chamado com um evento de teste cuja capacidade de cancelamento simula a transformação de eventos do Forge, ausente no teste isolado; não substitui teste em jogo com carregamento real de chunks, barramento Forge, jogadores ou outros mods. A proteção por `BreakEvent` destina-se à mineração por jogador; não garante proteção contra remoções feitas por explosões ou outros mods. Perdas que ocorram e sejam revertidas antes de uma verificação do controlador não são detectadas por estes testes.
