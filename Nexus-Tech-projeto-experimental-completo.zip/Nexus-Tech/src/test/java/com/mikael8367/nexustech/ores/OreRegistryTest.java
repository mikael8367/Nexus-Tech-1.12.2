package com.mikael8367.nexustech.ores;

import java.lang.reflect.Proxy;
import java.util.*;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.init.Bootstrap;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraftforge.oredict.OreDictionary;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.IForgeRegistryEntry;

/** Exercises actual Forge event handlers using capturing registries, without a running game. */
public final class OreRegistryTest {
    private static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }
    @SuppressWarnings("unchecked")
    private static <T extends IForgeRegistryEntry<T>> IForgeRegistry<T> capture(List<T> entries, Class<T> type) {
        return (IForgeRegistry<T>) Proxy.newProxyInstance(IForgeRegistry.class.getClassLoader(),
                new Class<?>[]{IForgeRegistry.class}, (proxy, method, args) -> {
                    if (method.getName().equals("register")) { entries.add((T) args[0]); return null; }
                    if (method.getName().equals("getRegistrySuperType")) return type;
                    throw new AssertionError("unexpected registry method: " + method.getName());
                });
    }
    private static void registered(String key, Item item) {
        ItemStack expected = new ItemStack(item);
        for (ItemStack entry : OreDictionary.getOres(key))
            if (OreDictionary.itemMatches(entry, expected, false)) return;
        throw new AssertionError("missing early OreDictionary entry " + key);
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        List<Block> blocks = new ArrayList<>(); List<Item> items = new ArrayList<>();
        OreRegistry.registerBlocks(new RegistryEvent.Register<>(new ResourceLocation("minecraft:blocks"), capture(blocks, Block.class)));
        OreRegistry.registerItems(new RegistryEvent.Register<>(new ResourceLocation("minecraft:items"), capture(items, Item.class)));
        check(blocks.size() == 10 && items.size() == 21, "registration counts");
        Set<ResourceLocation> blockIds = new HashSet<>(), itemIds = new HashSet<>();
        for (Block block : blocks) check(blockIds.add(block.getRegistryName()), "duplicate block");
        for (Item item : items) check(itemIds.add(item.getRegistryName()), "duplicate item");
        for (OreType type : OreType.values()) {
            Block ore = OreRegistry.ORES.get(type); Item ingot = OreRegistry.INGOTS.get(type);
            check(blocks.contains(ore) && items.contains(ingot), "registered " + type);
            check(ore.getRegistryName().equals(new ResourceLocation("nexustech", type.oreId())), "ore id");
            check(ingot.getRegistryName().equals(new ResourceLocation("nexustech", type.ingotId())), "ingot id");
            check(ore.getHarvestLevel(ore.getDefaultState()) == type.harvestLevel, "harvest tier");
            check("pickaxe".equals(ore.getHarvestTool(ore.getDefaultState())), "pickaxe");
            check(ore.getCreativeTabToDisplayOn() == NexusTech.CREATIVE_TAB && ingot.getCreativeTab() == NexusTech.CREATIVE_TAB, "creative tab");
            boolean found = false;
            for (Item item : items) if (item instanceof ItemBlock && ((ItemBlock)item).getBlock() == ore) {
                check(item.getRegistryName().equals(ore.getRegistryName()), "block item id");
                registered(type.oreKey(), item);
                if (type == OreType.ALUMINUM) registered("oreAluminium", item);
                found = true;
            }
            check(found, "block item " + type);
            registered(type.ingotKey(), ingot);
            if (type == OreType.ALUMINUM) registered("ingotAluminium", ingot);
        }
        registered("ingotSteel", OreRegistry.STEEL_INGOT);
        check(items.contains(OreRegistry.STEEL_INGOT) && OreRegistry.STEEL_INGOT.getCreativeTab() == NexusTech.CREATIVE_TAB, "steel item");
        // The capturing proxy does not install Forge's block-to-item map, so emulate
        // that registry callback in this isolated test JVM before init.
        java.lang.reflect.Field field = Item.class.getDeclaredField("BLOCK_TO_ITEM");
        field.setAccessible(true);
        Map<Block, Item> blockItems = (Map<Block, Item>) field.get(null);
        for (Item item : items) if (item instanceof ItemBlock)
            blockItems.put(((ItemBlock) item).getBlock(), item);
        OreRegistry.init();
        int count = FurnaceRecipes.instance().getSmeltingList().size();
        OreRegistry.init();
        check(count == FurnaceRecipes.instance().getSmeltingList().size(), "init must be idempotent");
        for (OreType type : OreType.values()) {
            ItemStack input = new ItemStack(OreRegistry.ORES.get(type));
            ItemStack result = FurnaceRecipes.instance().getSmeltingResult(input);
            check(result.getItem() == OreRegistry.INGOTS.get(type) && result.getCount() == 1, "smelting " + type);
            check(FurnaceRecipes.instance().getSmeltingExperience(result) == 0.7F, "smelting XP " + type);
        }
        System.out.println("PASS: ten blocks, block items, ingots, early ore dictionary entries, and ten smelting recipes");
    }
}
