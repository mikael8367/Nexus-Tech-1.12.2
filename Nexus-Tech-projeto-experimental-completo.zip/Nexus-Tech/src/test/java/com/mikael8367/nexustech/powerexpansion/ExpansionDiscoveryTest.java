package com.mikael8367.nexustech.powerexpansion;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Modifier;
import java.util.*;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.discovery.ASMDataTable;
import net.minecraftforge.fml.common.discovery.ContainerType;
import net.minecraftforge.fml.common.discovery.ModCandidate;
import net.minecraftforge.fml.common.discovery.asm.ASMModParser;
import net.minecraftforge.fml.common.discovery.asm.ModAnnotation.EnumHolder;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

/** Isolated ASM scan, not an actual Forge launch or registration lifecycle. */
public final class ExpansionDiscoveryTest {
    private static void ok(boolean value, String message) { if (!value) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        String[] names = {
            "com.mikael8367.nexustech.machinesexpansion.ExpansionRegistry",
            "com.mikael8367.nexustech.machinesexpansion.ExpansionClient",
            "com.mikael8367.nexustech.powerexpansion.PowerRegistry",
            "com.mikael8367.nexustech.powerexpansion.PowerClient"
        };
        ASMDataTable table = new ASMDataTable();
        File candidateRoot = new File(".");
        ModCandidate candidate = new ModCandidate(candidateRoot, candidateRoot, ContainerType.DIR);
        for (String name : names) {
            try (InputStream in = ExpansionDiscoveryTest.class.getClassLoader().getResourceAsStream(name.replace('.', '/') + ".class")) {
                ok(in != null, "missing bytecode " + name);
                ASMModParser parser = new ASMModParser(in);
                parser.validate();
                parser.sendToTable(table, candidate);
            }
        }
        Map<String, ASMDataTable.ASMData> found = new HashMap<>();
        for (ASMDataTable.ASMData data : table.getAll(Mod.EventBusSubscriber.class.getName())) found.put(data.getClassName(), data);
        ok(found.size() == 4, "expected four subscribers, got " + found.keySet());
        for (String name : names) {
            ASMDataTable.ASMData data = found.get(name);
            ok(data != null && "nexustech".equals(data.getAnnotationInfo().get("modid")), "missing/wrong modid " + name);
            Object side = data.getAnnotationInfo().get("value");
            if (name.endsWith("Client")) {
                ok(side instanceof List && ((List<?>)side).size() == 1 && ((EnumHolder)((List<?>)side).get(0)).getValue().equals("CLIENT"), "client side scan " + name);
            } else ok(side == null, "registry must be on both sides " + name);
            Class<?> cls = Class.forName(name, false, ExpansionDiscoveryTest.class.getClassLoader());
            Mod.EventBusSubscriber subscriber = cls.getAnnotation(Mod.EventBusSubscriber.class);
            ok(subscriber != null && subscriber.modid().equals("nexustech"), "reflection annotation " + name);
            int events = 0;
            for (java.lang.reflect.Method method : cls.getDeclaredMethods()) if (method.isAnnotationPresent(SubscribeEvent.class)) {
                ok(Modifier.isStatic(method.getModifiers()) && Modifier.isPublic(method.getModifiers()), "invalid event method " + method);
                events++;
            }
            ok(events == (name.endsWith("Client") ? 1 : 2), "wrong number of event methods " + name);
            if (name.endsWith("Client")) ok(Arrays.equals(subscriber.value(), new Side[]{Side.CLIENT}), "wrong client side " + name);
        }
        System.out.println("ExpansionDiscoveryTest OK: Forge ASM scan, modid, sides and event methods");
    }
}
