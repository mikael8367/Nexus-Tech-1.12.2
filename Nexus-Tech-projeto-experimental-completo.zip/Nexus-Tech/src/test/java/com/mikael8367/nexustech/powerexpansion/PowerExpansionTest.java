package com.mikael8367.nexustech.powerexpansion;

import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.Callable;
import com.mikael8367.nexustech.MachineTile;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldProviderSurface;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import sun.misc.Unsafe;

/** Executable isolated checks; never starts Minecraft or Gradle. */
public final class PowerExpansionTest {
    static void eq(int a, int b, String msg) { if (a != b) throw new AssertionError(msg + ": " + a + " != " + b); }
    static void ok(boolean x, String msg) { if (!x) throw new AssertionError(msg); }
    static final BlockPos ORIGIN = new BlockPos(0, 64, 0);
    static class FakeWorld extends World {
        Map<BlockPos,TileEntity> tiles; Set<BlockPos> unloaded; long time;
        boolean day, rain, sky; int forbidden;
        private FakeWorld() { super(null,null,null,null,false); }
        protected IChunkProvider createChunkProvider() { return null; }
        protected boolean isChunkLoaded(int x, int z, boolean allowEmpty) { return true; }
        public boolean isBlockLoaded(BlockPos p) { return !unloaded.contains(p); }
        public TileEntity getTileEntity(BlockPos p) { if (!isBlockLoaded(p)) { forbidden++; throw new AssertionError("unloaded tile read"); } return tiles.get(p); }
        public net.minecraft.block.state.IBlockState getBlockState(BlockPos p) { return Blocks.AIR.getDefaultState(); }
        public void markChunkDirty(BlockPos p, TileEntity t) { }
        public long getTotalWorldTime() { return time; }
        public boolean isDaytime() { return day; }
        public boolean isRaining() { return rain; }
        public boolean isThundering() { return false; }
        public boolean canSeeSky(BlockPos p) { return sky; }
        void put(BlockPos p, TileEntity t) { tiles.put(p,t); t.setWorld(this); t.setPos(p); }
    }
    static FakeWorld world() throws Exception {
        Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); Unsafe u=(Unsafe)f.get(null);
        FakeWorld w=(FakeWorld)u.allocateInstance(FakeWorld.class);
        w.tiles=new HashMap<>(); w.unloaded=new HashSet<>(); w.day=true; w.sky=true;
        u.putObject(w,u.objectFieldOffset(World.class.getField("provider")),new WorldProviderSurface() { @Override public boolean hasSkyLight() { return true; } });
        return w;
    }
    static IEnergyStorage cap(TileEntity t, EnumFacing side) { return t.getCapability(CapabilityEnergy.ENERGY, side); }
    static class Sink extends TileEntity implements IEnergyStorage {
        int energy, limit=1000; boolean fail, reenter; PowerTile.LargeSolar source;
        @Override public <T> T getCapability(Capability<T> c, EnumFacing f) { return c==CapabilityEnergy.ENERGY ? CapabilityEnergy.ENERGY.cast(this) : null; }
        public int receiveEnergy(int n, boolean simulate) {
            if(reenter) { source.update(); eq(cap(source,EnumFacing.UP).extractEnergy(50,false),0,"reentrant extraction blocked"); }
            int x=Math.min(limit,n); if(!simulate) energy+=x;
            if(fail) throw new IllegalStateException("mutated then failed"); return x;
        }
        public int extractEnergy(int n, boolean sim) {return 0;}
        public int getEnergyStored() {return energy;} public int getMaxEnergyStored() {return 100000;}
        public boolean canReceive() {return true;} public boolean canExtract() {return false;}
    }
    @SuppressWarnings("unchecked") static void setup() throws Exception {
        Bootstrap.register();
        Constructor<?> c=Capability.class.getDeclaredConstructors()[0]; c.setAccessible(true);
        CapabilityEnergy.ENERGY=(Capability<IEnergyStorage>)c.newInstance("test:energy",null,(Callable<IEnergyStorage>)() -> null);
        TileEntity.register("test:power_advanced",PowerTile.AdvancedBattery.class);
        TileEntity.register("test:power_elite",PowerTile.EliteBattery.class);
        TileEntity.register("test:power_solar",PowerTile.LargeSolar.class);
    }
    static void bufferChecks() {
        EnergyBuffer b=new EnergyBuffer(100,30,20);
        eq(b.receive(Integer.MAX_VALUE,true,0),30,"input simulate"); eq(b.stored(),0,"simulation no mutation");
        eq(b.receive(25,false,0),25,"input"); eq(b.receive(100,false,0),5,"shared input limit");
        eq(b.extract(15,false,0),15,"output"); eq(b.extract(100,false,0),5,"shared output limit");
        eq(b.receive(-1,false,1),0,"negative rejected"); eq(b.receive(100,false,1),30,"next tick");
        b.load(Integer.MAX_VALUE); eq(b.stored(),100,"nbt high clamped"); b.load(-20); eq(b.stored(),0,"nbt low clamped");
        b.generate(90); int r=b.extract(20,false,10); b.refundOutput(r-7); eq(b.stored(),83,"partial refund");
    }
    static void batteryChecks() throws Exception {
        FakeWorld w=world(); PowerTile.AdvancedBattery a=new PowerTile.AdvancedBattery(); w.put(ORIGIN,a);
        IEnergyStorage east=cap(a,EnumFacing.EAST), west=cap(a,EnumFacing.WEST);
        eq(east.receiveEnergy(3000,false),3000,"receive"); eq(west.receiveEnergy(3000,false),1000,"faces share limit");
        eq(east.receiveEnergy(1,true),0,"simulate shared exhausted budget");
        eq(east.extractEnergy(5000,false),4000,"extract limit"); eq(west.extractEnergy(1,false),0,"extract shares faces");
        w.time++; eq(east.receiveEnergy(1500,false),1500,"new tick");
        NBTTagCompound tag=a.writeToNBT(new NBTTagCompound()); PowerTile.AdvancedBattery restored=new PowerTile.AdvancedBattery();
        restored.readFromNBT(tag); eq(restored.buffer.stored(),1500,"world NBT roundtrip");
        tag.setInteger(PowerTile.ENERGY_KEY,Integer.MAX_VALUE); restored.readFromNBT(tag); eq(restored.buffer.stored(),1000000,"NBT clamp");
        a.harvesting=true; eq(east.extractEnergy(10,false),0,"harvest callback cannot extract");
        eq(east.receiveEnergy(10,false),0,"harvest callback cannot insert"); a.harvesting=false;
        w.tiles.remove(ORIGIN); eq(east.extractEnergy(10,false),0,"stale cached capability");
        FakeWorld remote=world(); Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); Unsafe u=(Unsafe)f.get(null);
        u.putBoolean(remote,u.objectFieldOffset(World.class.getField("isRemote")),true);
        PowerTile.EliteBattery e=new PowerTile.EliteBattery(); remote.put(ORIGIN,e); eq(cap(e,null).receiveEnergy(1,false),0,"client cannot mutate");
    }
    static void solarChecks() throws Exception {
        FakeWorld w=world(); PowerTile.LargeSolar s=new PowerTile.LargeSolar(); Sink sink=new Sink();
        w.put(ORIGIN,s); w.put(ORIGIN.east(),sink); sink.source=s; sink.reenter=true;
        s.update(); eq(sink.energy,64,"daylight generation and transfer"); eq(s.buffer.stored(),0,"conservation");
        sink.reenter=false; w.tiles.remove(ORIGIN.east()); w.time++; s.update(); eq(s.buffer.stored(),64,"stored without sink");
        w.day=false; w.time++; s.update(); eq(s.buffer.stored(),64,"night no generation"); eq(cap(s,EnumFacing.UP).extractEnergy(64,false),0,"night no output");
        w.day=true; w.sky=false; eq(cap(s,EnumFacing.UP).extractEnergy(64,false),0,"blocked sky no output");
        w.sky=true; w.rain=true; eq(cap(s,EnumFacing.UP).extractEnergy(64,false),0,"rain no output");
        w.rain=false; w.unloaded.add(ORIGIN.up()); s.update(); eq(w.forbidden,0,"unloaded sky not queried"); w.unloaded.clear();
        w.put(ORIGIN.east(),sink); sink.fail=true; sink.limit=1000; w.time++; s.update();
        eq(s.buffer.stored(),0,"uncertain transfer conservatively debited"); eq(sink.energy,192,"receiver mutated before throwing");
        FakeWorld p=world(); PowerTile.LargeSolar solar=new PowerTile.LargeSolar(); Sink limited=new Sink(); limited.limit=15;
        p.put(ORIGIN,solar); p.put(ORIGIN.east(),limited); solar.update();
        eq(limited.energy,15,"partial receive"); eq(solar.buffer.stored(),49,"rejected portion refunded");
        eq(solar.buffer.stored()+limited.energy,64,"partial transfer conservation");
    }
    @SuppressWarnings("unchecked") static void itemChecks() throws Exception {
        PowerBlock block=new PowerBlock("powerexpansion_test",PowerBlock.Type.ADVANCED);
        Field map=Item.class.getDeclaredField("BLOCK_TO_ITEM"); map.setAccessible(true);
        ((Map<Object,Object>)map.get(null)).put(block,new ItemBlock(block));
        FakeWorld w=world(); PowerTile.AdvancedBattery a=new PowerTile.AdvancedBattery();
        w.put(ORIGIN,a); a.buffer.load(123456);
        NonNullList<ItemStack> drops=NonNullList.create();
        block.getDrops(drops,w,ORIGIN,block.getDefaultState(),0);
        eq(drops.size(),1,"one battery drop"); eq(drops.get(0).getTagCompound().getInteger(PowerTile.ENERGY_KEY),123456,"drop retains FE");
        FakeWorld w2=world(); PowerTile.AdvancedBattery placed=new PowerTile.AdvancedBattery(); w2.put(ORIGIN,placed);
        block.onBlockPlacedBy(w2,ORIGIN,block.getDefaultState(),null,drops.get(0));
        eq(placed.buffer.stored(),123456,"placed block restores FE");
    }
    static void cableChecks() throws Exception {
        FakeWorld w=world(); PowerTile.LargeSolar s=new PowerTile.LargeSolar();
        MachineTile.Cable cable=new MachineTile.Cable(); PowerTile.AdvancedBattery battery=new PowerTile.AdvancedBattery();
        w.put(ORIGIN,s); w.put(ORIGIN.east(),cable); w.put(ORIGIN.east().east(),battery);
        s.update(); eq(battery.buffer.stored(),64,"solar pushes via real Nexus cable"); eq(s.buffer.stored(),0,"solar debited");
        IEnergyStorage wire=cap(cable,EnumFacing.NORTH);
        eq(wire.extractEnergy(40,true),40,"cable pull simulation"); eq(battery.buffer.stored(),64,"simulation conserves");
        eq(wire.extractEnergy(40,false),40,"cable pulls new battery"); eq(battery.buffer.stored(),24,"battery debited");
    }
    public static void main(String[] args) throws Exception { setup(); bufferChecks(); batteryChecks(); solarChecks(); itemChecks(); cableChecks(); System.out.println("PowerExpansionTest OK"); }
}
