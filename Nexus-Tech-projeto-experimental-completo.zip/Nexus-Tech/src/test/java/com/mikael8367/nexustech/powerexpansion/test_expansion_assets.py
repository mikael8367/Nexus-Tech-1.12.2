"""Static asset and localization checks for the two experimental expansions.
Run from repository root: python3 src/test/java/com/mikael8367/nexustech/powerexpansion/test_expansion_assets.py
This does not substitute for an actual Forge client/server test.
"""
import base64
import json
import struct
import unittest
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[7]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURE_SOURCES = ROOT / 'src/main/texture_sources/assets/nexustech'
BLOCKS = ['nexus_metal_press', 'nexus_alloy_smelter', 'powerexpansion_battery_advanced', 'powerexpansion_battery_elite', 'powerexpansion_solar_large']
ITEMS = ['nexus_copper_plate', 'nexus_tin_plate', 'nexus_bronze_ingot', 'nexus_brass_ingot']
RECIPES = BLOCKS + ['nexus_cable_from_alloys']
ORE_KEYS = {'ingotCopper', 'ingotTin', 'ingotZinc', 'ingotLead', 'ingotTitanium', 'ingotSilver', 'ingotAluminum', 'plateCopper', 'plateTin', 'ingotBronze', 'ingotBrass'}

class Assets(unittest.TestCase):
    def test_translations(self):
        keys = ['tile.nexustech.' + x + '.name' for x in BLOCKS] + ['item.nexustech.' + x + '.name' for x in ITEMS] + ['message.nexustech.powerexpansion.energy']
        for locale in ('en_us', 'pt_br'):
            lines = (ASSETS / 'lang' / (locale + '.lang')).read_text(encoding='utf-8').splitlines()
            for key in keys:
                values = [x.split('=', 1)[1] for x in lines if x.startswith(key + '=')]
                self.assertEqual(len(values), 1, (locale, key))
                self.assertTrue(values[0].strip(), (locale, key))
                if key.endswith('.energy'): self.assertEqual(values[0].count('%s'), 2)

    def test_models_and_textures(self):
        for name in BLOCKS:
            state = json.loads((ASSETS / 'blockstates' / (name + '.json')).read_text())
            self.assertEqual(state['variants']['normal']['model'], 'nexustech:' + name)
            model = json.loads((ASSETS / 'models/block' / (name + '.json')).read_text())
            item = json.loads((ASSETS / 'models/item' / (name + '.json')).read_text())
            self.assertEqual(item['parent'], 'nexustech:block/' + name)
            for texture in model.get('textures', {}).values():
                self.assertTrue(texture.startswith(('minecraft:', '#')), (name, texture))
        for name in ITEMS:
            model = json.loads((ASSETS / 'models/item' / (name + '.json')).read_text())
            self.assertEqual(model['textures']['layer0'], 'nexustech:items/' + name)
            png = ASSETS / 'textures/items' / (name + '.png')
            encoded = TEXTURE_SOURCES / 'textures/items' / (name + '.png.b64')
            sources = [path for path in (png, encoded) if path.is_file()]
            self.assertTrue(sources, f'Missing texture: {png} or {encoded}')
            for path in sources:
                with self.subTest(texture=name, source=str(path)):
                    data = path.read_bytes()
                    if path == encoded:
                        data = base64.b64decode(data.strip(), validate=True)
                    self.assertEqual(data[:8], b'\x89PNG\r\n\x1a\n')
                    pos = 8
                    kinds = []
                    while pos < len(data):
                        size = struct.unpack('>I', data[pos:pos+4])[0]
                        kind = data[pos+4:pos+8]; chunk = data[pos+8:pos+8+size]
                        crc = struct.unpack('>I', data[pos+8+size:pos+12+size])[0]
                        self.assertEqual(zlib.crc32(kind + chunk) & 0xffffffff, crc)
                        if kind == b'IHDR': self.assertEqual(struct.unpack('>II', chunk[:8]), (16, 16))
                        kinds.append(kind); pos += size + 12
                    self.assertEqual(pos, len(data)); self.assertIn(b'IDAT', kinds); self.assertEqual(kinds[-1], b'IEND')

    def test_recipes(self):
        used = set()
        for name in RECIPES:
            recipe = json.loads((ASSETS / 'recipes' / (name + '.json')).read_text())
            self.assertEqual(recipe['type'], 'forge:ore_shaped')
            pattern, key = recipe['pattern'], recipe['key']
            self.assertTrue(1 <= len(pattern) <= 3 and len({len(row) for row in pattern}) == 1 and 1 <= len(pattern[0]) <= 3)
            self.assertEqual(set(''.join(pattern)) - {' '}, set(key))
            for ingredient in key.values():
                if ingredient.get('type') == 'forge:ore_dict': used.add(ingredient['ore'])
            result = 'nexustech:energy_cable' if name == 'nexus_cable_from_alloys' else 'nexustech:' + name
            self.assertEqual(recipe['result']['item'], result)
            self.assertGreater(recipe['result'].get('count', 1), 0)
        self.assertTrue(used <= ORE_KEYS, used - ORE_KEYS)
        self.assertIn('ingotBrass', used)

if __name__ == '__main__':
    unittest.main(verbosity=2)
