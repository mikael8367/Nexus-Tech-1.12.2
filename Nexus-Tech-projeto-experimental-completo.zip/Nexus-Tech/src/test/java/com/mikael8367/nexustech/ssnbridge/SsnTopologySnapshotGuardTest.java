package com.mikael8367.nexustech.ssnbridge;

import com.mikael8367.nexustech.BridgeTile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.Callable;
import net.minecraft.init.Bootstrap;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldProviderSurface;
import net.minecraftforge.common.capabilities.Capability;
import sun.misc.Unsafe;

/** Tests use stand-ins; they do not establish an in-game SSN connection. */
public final class SsnTopologySnapshotGuardTest {
    private static void check(boolean v, String m) { if (!v) throw new AssertionError(m); }
    private static void state(SsnTopologySnapshotGuard.Result r, SsnTopologySnapshotGuard.State s) {
        check(r.state == s, "expected " + s + " got " + r.state);
        if (s != SsnTopologySnapshotGuard.State.ONE_MASTER) check(r.masterPos == null, "failure leaked a master");
    }
    static final class Unknown extends TileEntity {
        int calls;
        @Override public boolean hasCapability(Capability<?> c, EnumFacing face) { calls++; throw new AssertionError("unknown capability invoked"); }
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        Field f = Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); Unsafe unsafe = (Unsafe)f.get(null);
        SsnAdjacentProbeTest.FakeWorld w = (SsnAdjacentProbeTest.FakeWorld)unsafe.allocateInstance(SsnAdjacentProbeTest.FakeWorld.class);
        w.tiles = new HashMap<>(); w.states = new HashMap<>(); w.unloaded = new HashSet<>();
        unsafe.putObject(w, unsafe.objectFieldOffset(World.class.getField("provider")), new WorldProviderSurface());
        Constructor<?> ctor = Capability.class.getDeclaredConstructors()[0]; ctor.setAccessible(true);
        Capability<?> cap = (Capability<?>)ctor.newInstance("test:connectable", null, (Callable<Object>)() -> null);
        SsnAdjacentProbe.Api api = new SsnAdjacentProbe.Api(cap, SsnAdjacentProbeTest.Connectable.class,
            SsnAdjacentProbeTest.Position.class, SsnAdjacentProbeTest.Cable.class,
            SsnAdjacentProbeTest.Master.class, SsnAdjacentProbeTest.MasterApi.class);
        BlockPos o = new BlockPos(0,64,0), a = o.east(), b = a.east(), m = b.east();
        w.put(o, new BridgeTile());
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.NO_MASTER);
        SsnAdjacentProbeTest.Cable c = cable(w,a,cap), c2 = cable(w,b,cap);
        // A stale pointer is not a traversal result.
        c.con.master = new SsnAdjacentProbeTest.Position(0, o.west(80));
        w.put(m, new SsnAdjacentProbeTest.Master());
        SsnTopologySnapshotGuard.Result one = SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024);
        state(one, SsnTopologySnapshotGuard.State.ONE_MASTER); check(m.equals(one.masterPos), "actual master position");
        check(c.seen == EnumFacing.WEST, "entry face is opposite movement");
        // Cycle and duplicate paths must not inflate master count or loop.
        cable(w,o.south(),cap); cable(w,a.south(),cap); cable(w,b.south(),cap);
        one = SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024);
        state(one, SsnTopologySnapshotGuard.State.ONE_MASTER); check(one.exploredNodes == 7, "visited once in cycle");
        // A master beyond a master is explored conservatively, even though SSN stops there.
        BlockPos m2 = m.east(); w.put(m2, new SsnAdjacentProbeTest.Master());
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.MULTIPLE_MASTERS);
        w.tiles.remove(m2);
        // An isolated master does not count as reachable.
        w.put(o.west(4), new SsnAdjacentProbeTest.Master());
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.ONE_MASTER);
        w.unloaded.add(b.north()); state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.UNLOADED);
        w.unloaded.clear(); check(w.forbidden == 0, "no reads from unloaded positions");
        Unknown unknown = new Unknown(); w.put(o.up(), unknown);
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.UNKNOWN_TILE);
        check(unknown.calls == 0, "unknown capability untouched"); w.tiles.remove(o.up());
        w.states.put(o.up(), new Block(Material.IRON).setRegistryName("storagenetwork", "master").getDefaultState());
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.UNKNOWN_TILE);
        w.states.remove(o.up());
        BlockPos edge = new BlockPos(10, 255, 10); w.put(edge, new BridgeTile());
        state(SsnTopologySnapshotGuard.inspectPrepared(w,edge,api,1024), SsnTopologySnapshotGuard.State.INVALID_CONTEXT);
        w.tiles.remove(edge);
        c.con.self = new SsnAdjacentProbeTest.Position(1,a);
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.INCONSISTENT_CABLE);
        c.con.self = new SsnAdjacentProbeTest.Position(0,a); c.exposes = false;
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.INCONSISTENT_CABLE); c.exposes = true;
        c.con.throwsOnRead = true;
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.ERROR); c.con.throwsOnRead = false;
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,2), SsnTopologySnapshotGuard.State.TOO_LARGE);
        state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,0), SsnTopologySnapshotGuard.State.INVALID_CONTEXT);
        state(SsnTopologySnapshotGuard.inspect(null,o), SsnTopologySnapshotGuard.State.INVALID_CONTEXT);
        w.put(o, new Unknown()); state(SsnTopologySnapshotGuard.inspectPrepared(w,o,api,1024), SsnTopologySnapshotGuard.State.NOT_BRIDGE);
        check(c2.con.master == null, "read-only: no assignment to SSN connectable");
        System.out.println("SsnTopologySnapshotGuardTest passed");
    }
    private static SsnAdjacentProbeTest.Cable cable(SsnAdjacentProbeTest.FakeWorld w, BlockPos p, Capability<?> cap) {
        SsnAdjacentProbeTest.Cable c = new SsnAdjacentProbeTest.Cable(); c.cap = cap;
        c.con = new SsnAdjacentProbeTest.Connection(); c.con.self = new SsnAdjacentProbeTest.Position(0,p);
        w.put(p,c); return c;
    }
}
