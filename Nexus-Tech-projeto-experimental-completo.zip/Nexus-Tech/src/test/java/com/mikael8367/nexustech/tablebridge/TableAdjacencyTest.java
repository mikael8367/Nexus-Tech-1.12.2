package com.mikael8367.nexustech.tablebridge;

import com.mikael8367.nexustech.BridgeTile;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Bootstrap;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import sun.misc.Unsafe;

/** Isolated simulations, not a Forge server or a live ProjectE test. */
public final class TableAdjacencyTest {
    static final class FakeWorld extends World {
        Set<BlockPos> unloaded; BlockPos origin; IBlockState cable, table; TileEntity tile;
        boolean fail; int stateReads, tileReads;
        private FakeWorld() { super(null, null, null, null, false); }
        protected IChunkProvider createChunkProvider() { return null; }
        protected boolean isChunkLoaded(int x, int z, boolean empty) { return true; }
        @Override public boolean isBlockLoaded(BlockPos p) { return !unloaded.contains(p); }
        @Override public IBlockState getBlockState(BlockPos p) {
            if (unloaded.contains(p)) throw new AssertionError("unloaded block read");
            if (fail) throw new IllegalStateException("simulated failure");
            stateReads++;
            return origin.equals(p) ? cable : table;
        }
        @Override public TileEntity getTileEntity(BlockPos p) {
            if (unloaded.contains(p) || !origin.equals(p)) throw new AssertionError("unexpected tile read");
            tileReads++; return tile;
        }
    }
    static void equal(TableAdjacency.Result got, TableAdjacency.Result want, String label) {
        if (got != want) throw new AssertionError(label + ": " + got + " != " + want);
    }
    static TableAdjacency.Result probe(FakeWorld w, EnumFacing side, Block cable, Block table) {
        return TableAdjacency.inspectWithExpectedBlocks(w, w.origin, side, cable, table);
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        Field field = Unsafe.class.getDeclaredField("theUnsafe"); field.setAccessible(true);
        Unsafe unsafe = (Unsafe) field.get(null);
        FakeWorld w = (FakeWorld) unsafe.allocateInstance(FakeWorld.class);
        w.origin = new BlockPos(15, 64, 0); w.unloaded = new HashSet<>();
        Block cable = new Block(Material.IRON), table = new Block(Material.ROCK);
        w.cable = cable.getDefaultState(); w.table = table.getDefaultState();
        w.tile = new BridgeTile(); w.tile.setWorld(w); w.tile.setPos(w.origin);
        for (EnumFacing side : EnumFacing.values()) {
            equal(probe(w, side, cable, table), TableAdjacency.Result.ADJACENT_ONLY, "adjacent " + side);
            w.unloaded.add(w.origin.offset(side));
            int states = w.stateReads, tiles = w.tileReads;
            equal(probe(w, side, cable, table), TableAdjacency.Result.UNLOADED, "neighbor unloaded " + side);
            if (states != w.stateReads || tiles != w.tileReads) throw new AssertionError("unloaded reads");
            w.unloaded.clear();
        }
        w.unloaded.add(w.origin);
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.UNLOADED, "origin unloaded");
        w.unloaded.clear();
        // Removal, same registry-looking replacement, unload and reload are always reobserved.
        Block impostor = new Block(Material.ROCK).setRegistryName("projecte", "transmutation_table");
        w.table = impostor.getDefaultState();
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.NO_MATCH, "table replaced");
        w.table = table.getDefaultState();
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.ADJACENT_ONLY, "table restored");
        w.cable = new Block(Material.IRON).getDefaultState();
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.NO_MATCH, "cable replaced");
        w.cable = cable.getDefaultState();
        w.tile.invalidate();
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.NO_MATCH, "invalid tile");
        w.tile = new BridgeTile(); w.tile.setWorld(w); w.tile.setPos(w.origin.east());
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.NO_MATCH, "stale tile position");
        w.tile.setPos(w.origin); w.tile.setWorld(null);
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.NO_MATCH, "stale tile world");
        w.tile = null;
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.NO_MATCH, "missing cable tile");
        w.tile = new BridgeTile(); w.tile.setWorld(w); w.tile.setPos(w.origin);
        w.unloaded.add(w.origin.east());
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.UNLOADED, "unload after valid");
        w.unloaded.clear();
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.ADJACENT_ONLY, "reload");
        w.fail = true;
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.ERROR, "world failure");
        w.fail = false;
        equal(probe(w, null, cable, table), TableAdjacency.Result.INVALID_INPUT, "null direction");
        equal(TableAdjacency.inspectWithExpectedBlocks(w, new BlockPos(0, 255, 0), EnumFacing.UP, cable, table), TableAdjacency.Result.INVALID_INPUT, "outside height");
        equal(TableAdjacency.inspect(null, w.origin, EnumFacing.EAST), TableAdjacency.Result.INVALID_INPUT, "null world");
        equal(TableAdjacency.inspect(w, w.origin, EnumFacing.EAST), TableAdjacency.Result.INVALID_INPUT, "not a server world");
        unsafe.putBoolean(w, unsafe.objectFieldOffset(World.class.getField("isRemote")), true);
        equal(probe(w, EnumFacing.EAST, cable, table), TableAdjacency.Result.INVALID_INPUT, "client");
        System.out.println("TableAdjacencyTest PASS (simulated world only)");
    }
}
