#!/usr/bin/env python3
"""Static bridge-only model and layout checks; not a live render test."""
import base64
import io
import json
import re
import unittest
from pathlib import Path
from PIL import Image

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'build.gradle').exists())
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures'
JAVA = ROOT / 'src/main/java/com/mikael8367/nexustech'

class BridgeVisualTest(unittest.TestCase):
    def test_model_is_isolated_and_textures_are_valid(self):
        block = json.loads((ASSETS / 'models/block/storage_bridge.json').read_text())
        self.assertEqual(len(block['elements']), 1)
        body = block['elements'][0]
        self.assertEqual(body['from'], [5, 5, 5])
        self.assertEqual(body['to'], [11, 11, 11])
        self.assertEqual(set(body['faces']), {'down', 'up', 'north', 'south', 'west', 'east'})
        for face in body['faces'].values():
            self.assertNotIn('cullface', face)
            texture = block['textures'][face['texture'][1:]]
            self.assertTrue(texture.startswith('nexustech:'))
            source = TEXTURES / (texture.split(':')[1] + '.png.b64')
            with Image.open(io.BytesIO(base64.b64decode(source.read_bytes().strip(), validate=True))) as image:
                image.load()
                self.assertGreater(image.width, 0)
                self.assertGreater(image.height, 0)
                self.assertEqual(image.convert('RGBA').getextrema()[3], (255, 255))
        self.assertEqual(json.loads((ASSETS / 'models/item/storage_bridge.json').read_text())['parent'], 'nexustech:block/storage_bridge')
        self.assertEqual(json.loads((ASSETS / 'blockstates/storage_bridge.json').read_text())['variants']['normal']['model'], 'nexustech:storage_bridge')

    def test_compact_layout_and_no_misleading_wires(self):
        gui = (JAVA / 'BridgeGui.java').read_text()
        self.assertIn('xSize = 250; ySize = 216', gui)
        self.assertLessEqual(203 + 9, 216 - 3)
        self.assertIn('trimStringToWidth', gui)
        self.assertIn('Adjacencia nao e ligacao', gui)
        self.assertIn('risco aos controladores', gui)

if __name__ == '__main__':
    unittest.main()
