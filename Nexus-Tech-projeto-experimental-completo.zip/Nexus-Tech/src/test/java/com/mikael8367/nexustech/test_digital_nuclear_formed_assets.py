#!/usr/bin/env python3
"""Static visual contract checks; no Minecraft runtime required. Run with Python 3 + Pillow."""
import base64
import io
import itertools
import json
import unittest
from pathlib import Path

from PIL import Image

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'build.gradle').is_file())
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures'
DIRECTIONS = {'north': 0, 'east': 90, 'south': 180, 'west': 270}
NAMES = ('digital_mine_basic', 'digital_mine_advanced', 'digital_mine_casing',
         'nuclear_casing', 'nuclear_controller', 'nuclear_core')


def unique(pairs):
    result = {}
    for k, v in pairs:
        if k in result:
            raise ValueError('duplicate JSON key: ' + k)
        result[k] = v
    return result


def load(path):
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=unique)


def image(name):
    path = TEXTURES / (name + '.png.b64')
    raw = base64.b64decode(path.read_text(encoding='ascii').strip(), validate=True)
    with Image.open(io.BytesIO(raw)) as im:
        assert im.format == 'PNG'
        im.verify()
    with Image.open(io.BytesIO(raw)) as im:
        return im.convert('RGBA')


class FormedVisualAssetsTest(unittest.TestCase):
    def test_variants_exact_coverage_and_original_mappings(self):
        for name in NAMES:
            variants = load(ASSETS / 'blockstates' / (name + '.json'))['variants']
            expected = {}
            facings = (None,) if name == 'digital_mine_casing' else DIRECTIONS
            actives = ('false', 'true') if name.startswith('nuclear_') else (None,)
            for facing, active, formed in itertools.product(facings, actives, ('false', 'true')):
                props = {'formed': formed}
                if facing is not None:
                    props['facing'] = facing
                if active is not None:
                    props['active'] = active
                key = ','.join(k + '=' + props[k] for k in sorted(props))
                model = name + ('_active' if name == 'nuclear_controller' and active == 'true' else '')
                if formed == 'true':
                    model += '_formed'
                value = {'model': 'nexustech:' + model}
                if facing is not None and (name.startswith('nuclear_') or facing != 'north'):
                    value['y'] = DIRECTIONS[facing]
                expected[key] = value
            self.assertEqual(variants, expected, name)

    def test_formed_models_inherit_geometry_and_resolve_textures(self):
        parents = list(NAMES) + ['nuclear_controller_active']
        for name in parents:
            with self.subTest(model=name):
                base = load(ASSETS / 'models/block' / (name + '.json'))
                formed = load(ASSETS / 'models/block' / (name + '_formed.json'))
                self.assertEqual(formed['parent'], 'nexustech:block/' + name)
                self.assertEqual(set(formed), {'parent', 'textures'})
                self.assertTrue(set(formed['textures']).issubset(base['textures']))
                for key, texture in formed['textures'].items():
                    self.assertTrue(texture.startswith('nexustech:blocks/'))
                    new = image(texture.split(':', 1)[1])
                    old_texture = base['textures'][key]
                    while old_texture.startswith('#'):
                        old_texture = base['textures'][old_texture[1:]]
                    old = image(old_texture.split(':', 1)[1])
                    self.assertEqual(new.size, (32, 32))
                    self.assertEqual(old.size, (16, 16))
                    old = old.resize((32, 32), Image.Resampling.NEAREST)
                    before, after = old.tobytes(), new.tobytes()
                    changed = sum(before[i:i + 4] != after[i:i + 4] for i in range(0, len(before), 4))
                    self.assertGreater(changed, 0)
                    self.assertLess(changed, 256, 'keep the original machine identity')
                    self.assertEqual(new.crop((8, 8, 24, 24)).tobytes(),
                                     old.crop((8, 8, 24, 24)).tobytes())

    def test_inventory_keeps_original_models(self):
        for name in NAMES:
            self.assertEqual(load(ASSETS / 'models/item' / (name + '.json'))['parent'],
                             'nexustech:block/' + name)

    def test_active_controller_textures_remain_distinct(self):
        off = image('blocks/nuclear_controller_formed')
        on = image('blocks/nuclear_controller_active_formed')
        self.assertNotEqual(off.tobytes(), on.tobytes())
        self.assertNotEqual(off.crop((8, 8, 24, 24)).tobytes(),
                            on.crop((8, 8, 24, 24)).tobytes())


if __name__ == '__main__':
    unittest.main()
