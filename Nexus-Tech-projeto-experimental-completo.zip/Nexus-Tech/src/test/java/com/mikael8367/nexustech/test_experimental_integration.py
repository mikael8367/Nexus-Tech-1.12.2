#!/usr/bin/env python3
"""Static integration regressions; not a running Forge or multiplayer test."""
import re
import unittest
from pathlib import Path

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'build.gradle').exists())
JAVA = ROOT / 'src/main/java/com/mikael8367/nexustech'
ASSETS = ROOT / 'src/main/resources/assets/nexustech'

def read(path):
    return (JAVA / path).read_text(encoding='utf-8')

def method_id(path):
    match = re.search(r'GUI_ID\s*=\s*(\d+)', read(path))
    if not match:
        raise AssertionError('Missing GUI ID in ' + path)
    return int(match.group(1))

class ExperimentalIntegrationTest(unittest.TestCase):
    def test_gui_ids_unique_and_routes_preserved_on_both_sides(self):
        ids = [0, 1, method_id('digitalmine/DigitalMineRegistry.java'), method_id('nuclear/NuclearGuiHooks.java')]
        self.assertEqual(ids, [0, 1, 71, 8367])
        self.assertEqual(len(ids), len(set(ids)))
        for path, routes in [('ClientProxy.java', ('DigitalMineClient.gui', 'NuclearClient.gui', 'new BridgeGui', 'new MachineGui')),
                             ('MachineGuiHandler.java', ('DigitalMineGuiHooks.server', 'NuclearGuiHooks.server', 'new BridgeContainer', 'new MachineContainer'))]:
            source = read(path)
            for route in routes:
                self.assertEqual(source.count(route), 1, (path, route))
            self.assertIn('id == 1', source)
            self.assertIn('id != 0', source)
        self.assertNotIn('DigitalMineClient', read('MachineGuiHandler.java'))
        self.assertNotIn('NuclearClient', read('MachineGuiHandler.java'))

    def test_registered_tiles_blocks_and_lifecycle(self):
        main = read('NexusTech.java')
        for hook in ('ModRegistry.registerTiles()', 'DigitalMineRegistry.registerTiles()', 'OreRegistry.registerWorldGenerator()', 'OreRegistry.init()', 'registerGuiHandler('):
            self.assertEqual(main.count(hook), 1, hook)
        core = read('ModRegistry.java')
        for block in ('storage_bridge', 'energy_cable', 'solar_panel', 'coal_generator', 'electric_turbine', 'battery', 'electric_furnace', 'electric_crusher', 'electric_compressor', 'lava_generator'):
            self.assertIn('id("' + block + '")', core)
        self.assertIn('new EnergyCableBlock()', core)
        for path in ('digitalmine/DigitalMineRegistry.java', 'nuclear/NuclearRegistry.java', 'ores/OreRegistry.java'):
            self.assertIn('@Mod.EventBusSubscriber', read(path))
        for name in ('digital_mine_basic', 'digital_mine_advanced', 'digital_mine_casing', 'nuclear_controller', 'nuclear_casing', 'nuclear_core', 'copper_ore', 'uranium_ore', 'storage_bridge', 'energy_cable'):
            self.assertTrue((ASSETS / 'blockstates' / (name + '.json')).is_file(), name)

    def test_models_for_all_independent_registries(self):
        for path, token in [('ClientProxy.java', 'ModRegistry.BRIDGE'), ('digitalmine/DigitalMineClient.java', 'DigitalMineRegistry.BLOCKS'), ('nuclear/NuclearClient.java', 'NuclearRegistry.BLOCKS'), ('ores/OreClient.java', 'OreRegistry.ORES')]:
            self.assertIn(token, read(path))

    def test_bridge_is_not_storage_or_network_endpoint(self):
        tile = read('BridgeTile.java')
        self.assertRegex(tile, r'class\s+BridgeTile\s+extends\s+TileEntity\s*\{\s*\}')
        bridge = read('BridgeContainer.java')
        for forbidden in ('addSlotToContainer(', 'slotClick(', 'transferStackInSlot(', 'insertStack(', 'extractStack(', 'setEmc('):
            self.assertNotIn(forbidden, bridge)
        self.assertIn('BridgeEndpoint.inspect(', bridge)
        for path in ('BridgeTile.java', 'BridgeBlock.java', 'BridgeContainer.java'):
            for forbidden in ('IConnectableLink', 'INetworkMaster', 'ITEM_HANDLER_CAPABILITY', 'CapabilityEnergy'):
                self.assertNotIn(forbidden, read(path), (path, forbidden))

    def test_ore_and_fe_interfaces_remain_present(self):
        ore = read('ores/OreRegistry.java')
        for s in ('registerWorldGenerator', 'OreDictionary.registerOre', 'GameRegistry.addSmelting'):
            self.assertIn(s, ore)
        for path in ('digitalmine/DigitalMineTile.java', 'nuclear/NuclearController.java'):
            source = read(path)
            self.assertIn('CapabilityEnergy.ENERGY', source)
        self.assertIn('CapabilityEnergy.ENERGY', read('EnergyCableBlock.java'))

if __name__ == '__main__':
    unittest.main()
