#!/usr/bin/env python3
"""Check structure help translations without starting Gradle or Minecraft."""
import unittest
from pathlib import Path

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'build.gradle').is_file())
LANG = ROOT / 'src/main/resources/assets/nexustech/lang'
DIGITAL = 'chat.nexustech.digitalmine.build'
NUCLEAR = 'chat.nexustech.nuclear.build'

# These messages take no format arguments and are intended as one chat message.
EXPECTED_PARTS = {
    'en_us': {
        DIGITAL: ('solid 3 wide x 2 high x 3 deep', 'controller at the front center of the base',
                  'button facing out', 'other 17 blocks', 'Digital Mine Casings'),
        NUCLEAR: ('solid 3 wide x 5 high x 3 deep', 'controller at the front center of the base',
                  'button facing out', 'core in the center of layer 3 (counting from the base)',
                  'other 43 blocks', 'Nuclear Casings'),
    },
    'pt_br': {
        DIGITAL: ('estrutura preenchida de 3 de largura x 2 de altura x 3 de profundidade',
                  'controlador no centro da frente da base', 'botão voltado para fora',
                  'outros 17 blocos', 'Estrutura Digital Mine'),
        NUCLEAR: ('estrutura preenchida de 3 de largura x 5 de altura x 3 de profundidade',
                  'controlador no centro da frente da base', 'botão voltado para fora',
                  'núcleo no centro da camada 3 (contando da base)',
                  'outros 43 blocos', 'Revestimento nuclear'),
    },
}


class StructureMessagesTest(unittest.TestCase):
    def test_messages_and_format(self):
        for locale, keys in EXPECTED_PARTS.items():
            text = (LANG / (locale + '.lang')).read_text(encoding='utf-8')
            for key, parts in keys.items():
                with self.subTest(locale=locale, key=key):
                    # Verify exactly one well-formed key=value entry in each locale.
                    lines = [line for line in text.splitlines()
                             if line.partition('=')[0] == key]
                    self.assertEqual(len(lines), 1, f'{key} missing or duplicated')
                    _, separator, message = lines[0].partition('=')
                    self.assertEqual(separator, '=')
                    self.assertTrue(message.strip())
                    self.assertEqual(message, message.strip())
                    self.assertNotRegex(message, r'[%\r\n]|\\[nr]')
                    for part in parts:
                        self.assertIn(part, message)

    def test_block_counts(self):
        self.assertEqual(3 * 2 * 3 - 1, 17)
        self.assertEqual(3 * 5 * 3 - 2, 43)


if __name__ == '__main__':
    unittest.main()
