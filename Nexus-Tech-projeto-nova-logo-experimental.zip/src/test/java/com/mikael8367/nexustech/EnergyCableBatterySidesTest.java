package com.mikael8367.nexustech;

import com.mikael8367.nexustech.powerexpansion.PowerTile;
import net.minecraft.init.Blocks;
import net.minecraft.init.Bootstrap;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;

/** Isolated sided FE regressions; not a Minecraft client or real mod battery. */
public final class EnergyCableBatterySidesTest extends NexusEnergyTestSupport {
    static final net.minecraft.block.properties.PropertyBool[] P = {EnergyCableBlock.DOWN, EnergyCableBlock.UP,
        EnergyCableBlock.NORTH, EnergyCableBlock.SOUTH, EnergyCableBlock.WEST, EnergyCableBlock.EAST};
    // A third-party endpoint which provides a sided capability but does not
    // override TileEntity.hasCapability (same contract the network actually uses).
    static class GetOnlyBattery extends Endpoint {
        final EnumFacing face;
        GetOnlyBattery(EnumFacing face, int energy) { super(energy, true, true); this.face=face; }
        @Override public <T> T getCapability(Capability<T> cap, EnumFacing side) {
            return cap==CapabilityEnergy.ENERGY && side==face ? CapabilityEnergy.ENERGY.cast(this) : null;
        }
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        EnergyCableBlock block=new EnergyCableBlock();
        for (EnumFacing dir : EnumFacing.VALUES) {
            BlockPos neighbor=O.offset(dir);
            FakeWorld w=world(false); Cable cable=new Cable(); w.put(O,cable);
            GetOnlyBattery battery=new GetOnlyBattery(dir.getOpposite(), 0);
            w.states.put(neighbor,Blocks.STONE.getDefaultState()); w.put(neighbor,battery);
            ok(block.getActualState(block.getDefaultState(),w,O).getValue(P[dir.ordinal()]),"visual get-only "+dir);
            eq(battery.energy,0,"render doesn't transfer FE "+dir);
            int n=cap(cable,dir.getOpposite()).receiveEnergy(90,false);
            eq(n,90,"external battery receives "+dir); eq(battery.energy,90,"external battery credited "+dir);
            n=cap(cable,dir.getOpposite()).extractEnergy(40,false);
            eq(n,40,"external battery supplies "+dir); eq(battery.energy,50,"external battery debited "+dir);
            w.unloaded.add(neighbor);
            ok(!block.getActualState(block.getDefaultState(),w,O).getValue(P[dir.ordinal()]),"unloaded disconnected "+dir);
            eq(cap(cable,dir.getOpposite()).receiveEnergy(10,false),0,"no transfer unloaded "+dir);
            eq(w.forbiddenQueries,0,"no chunk loads "+dir);
            FakeWorld v=world(false); Cable wire=new Cable(); v.put(O,wire);
            PowerTile.AdvancedBattery advanced=new PowerTile.AdvancedBattery(); v.put(neighbor,advanced);
            v.states.put(neighbor,Blocks.STONE.getDefaultState());
            ok(block.getActualState(block.getDefaultState(),v,O).getValue(P[dir.ordinal()]),"advanced visual "+dir);
            eq(cap(wire,dir.getOpposite()).receiveEnergy(90,false),90,"advanced receives "+dir);
            eq(cap(advanced,dir.getOpposite()).getEnergyStored(),90,"advanced stored "+dir);
            eq(cap(wire,dir.getOpposite()).extractEnergy(40,false),40,"advanced supplies "+dir);
            eq(cap(advanced,dir.getOpposite()).getEnergyStored(),50,"advanced remaining "+dir);
        }
        System.out.println("EnergyCableBatterySidesTest PASS: six faces, get-only battery and advanced battery, visual and FE (simulated worlds)");
    }
}
