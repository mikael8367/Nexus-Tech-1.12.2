"""Regression checks for Forge 1.12 battery item and block resource paths.
Run: python3 src/test/java/com/mikael8367/nexustech/powerexpansion/test_battery_models.py
Static checks, not a substitute for a running Minecraft client.
"""
import base64
import json
import struct
import unittest
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[7]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
SOURCES = ROOT / 'src/main/texture_sources/assets/nexustech'
NAMES = ('battery', 'powerexpansion_battery_advanced', 'powerexpansion_battery_elite')

class BatteryModels(unittest.TestCase):
    def test_variants_items_and_textures(self):
        for name in NAMES:
            with self.subTest(battery=name):
                state = json.loads((ASSETS / 'blockstates' / (name + '.json')).read_text())
                for variant in ('normal', 'inventory'):
                    self.assertEqual(state['variants'][variant]['model'], 'nexustech:' + name)
                item = json.loads((ASSETS / 'models/item' / (name + '.json')).read_text())
                self.assertEqual(item['parent'], 'nexustech:block/' + name)
                model = json.loads((ASSETS / 'models/block' / (name + '.json')).read_text())
                textures = model['textures']
                for key in textures:
                    value, seen = textures[key], {key}
                    while value.startswith('#'):
                        key = value[1:]
                        self.assertNotIn(key, seen, 'Cyclic texture reference')
                        seen.add(key)
                        self.assertIn(key, textures, 'Unresolved texture reference')
                        value = textures[key]
                    namespace, path = value.split(':', 1)
                    self.assertIn(namespace, ('minecraft', 'nexustech'))
                    if namespace == 'nexustech':
                        png = ASSETS / 'textures' / (path + '.png')
                        encoded = SOURCES / 'textures' / (path + '.png.b64')
                        data = png.read_bytes() if png.is_file() else base64.b64decode(encoded.read_bytes().strip(), validate=True)
                        self.assertEqual(data[:8], b'\x89PNG\r\n\x1a\n')
                        pos, kinds = 8, []
                        while pos < len(data):
                            size = struct.unpack('>I', data[pos:pos+4])[0]
                            kind, chunk = data[pos+4:pos+8], data[pos+8:pos+8+size]
                            crc = struct.unpack('>I', data[pos+8+size:pos+12+size])[0]
                            self.assertEqual(zlib.crc32(kind + chunk) & 0xffffffff, crc)
                            kinds.append(kind)
                            pos += size + 12
                        self.assertEqual(pos, len(data))
                        self.assertIn(b'IDAT', kinds)
                        self.assertEqual(kinds[-1], b'IEND')

    def test_localizations(self):
        for locale in ('en_us', 'pt_br'):
            lines = (ASSETS / 'lang' / (locale + '.lang')).read_text(encoding='utf-8').splitlines()
            for name in NAMES:
                key = 'tile.nexustech.' + name + '.name='
                matches = [line[len(key):] for line in lines if line.startswith(key)]
                self.assertEqual(len(matches), 1, (locale, name))
                self.assertTrue(matches[0].strip())

if __name__ == '__main__':
    unittest.main(verbosity=2)
