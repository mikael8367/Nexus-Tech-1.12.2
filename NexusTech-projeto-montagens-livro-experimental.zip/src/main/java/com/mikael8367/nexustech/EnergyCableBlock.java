package com.mikael8367.nexustech;

import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.energy.CapabilityEnergy;

/** Visual-only connection properties. Metadata remains zero as before. */
public final class EnergyCableBlock extends MachineBlock {
    public static final PropertyBool DOWN = PropertyBool.create("down");
    public static final PropertyBool UP = PropertyBool.create("up");
    public static final PropertyBool NORTH = PropertyBool.create("north");
    public static final PropertyBool SOUTH = PropertyBool.create("south");
    public static final PropertyBool WEST = PropertyBool.create("west");
    public static final PropertyBool EAST = PropertyBool.create("east");
    private static final PropertyBool[] SIDES = { DOWN, UP, NORTH, SOUTH, WEST, EAST };

    public EnergyCableBlock() {
        super("energy_cable", MachineTile.Kind.CABLE);
        IBlockState state = blockState.getBaseState();
        for (PropertyBool side : SIDES) state = state.withProperty(side, false);
        setDefaultState(state);
    }

    @Override protected BlockStateContainer createBlockState() {
        return new BlockStateContainer(this, DOWN, UP, NORTH, SOUTH, WEST, EAST);
    }

    @Override public int getMetaFromState(IBlockState state) { return 0; }
    @Override public IBlockState getStateFromMeta(int meta) { return getDefaultState(); }

    @Override public IBlockState getActualState(IBlockState state, IBlockAccess access, BlockPos pos) {
        for (EnumFacing direction : EnumFacing.VALUES) {
            state = state.withProperty(SIDES[direction.ordinal()], connects(access, pos.offset(direction), direction));
        }
        return state;
    }

    private boolean connects(IBlockAccess access, BlockPos neighbor, EnumFacing direction) {
        // World can load chunks; only read loaded positions. Forge's ChunkCache
        // reads a snapshot. OptiFine 1.12.2 G5 wraps that cache in its own
        // IBlockAccess (it is NOT a ChunkCache); its tile getter uses CHECK.
        // Other unknown access implementations fail closed.
        if (access instanceof World) {
            if (!((World) access).isBlockLoaded(neighbor)) return false;
        } else if (!(access instanceof ChunkCache)
                && !access.getClass().getName().equals("net.optifine.override.ChunkCacheOF")) {
            return false;
        }
        try {
            IBlockState adjacent = access.getBlockState(neighbor);
            if (adjacent.getBlock() instanceof EnergyCableBlock) return true;
            // ChunkCache returns air for missing/out-of-range chunks; avoid tile
            // lookup there. On a cache use CHECK so rendering never creates tiles.
            if (adjacent.getMaterial() == Material.AIR) return false;
            TileEntity tile = access instanceof ChunkCache
                    ? ((ChunkCache) access).getTileEntity(neighbor, net.minecraft.world.chunk.Chunk.EnumCreateEntityType.CHECK)
                    : access.getTileEntity(neighbor);
            if (tile == null || tile.isInvalid()) return false;
            EnumFacing face = direction.getOpposite();
            // The network transfers through getCapability, not hasCapability.
            // Some third-party tiles implement only getCapability, so relying on
            // the advertisement alone produces an invisible but functional link.
            // Keep the advertisement first: some client-only multiblock proxies
            // intentionally advertise their synchronized form without exposing FE.
            return tile.hasCapability(CapabilityEnergy.ENERGY, face)
                    || tile.getCapability(CapabilityEnergy.ENERGY, face) != null;
        } catch (RuntimeException brokenEndpoint) {
            // Rendering must not crash because a third-party capability probe failed.
            return false;
        }
    }
}
