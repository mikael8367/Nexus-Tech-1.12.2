package com.mikael8367.nexustech;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Localized guide keys; independent of client GUI and Forge recipe registry. */
public final class GuideBookContent {
    private GuideBookContent() {}
    public static final class Chapter {
        public final String titleKey;
        public final List<String> pageKeys;
        private Chapter(String titleKey, String... pageKeys) {
            this.titleKey = titleKey;
            this.pageKeys = Collections.unmodifiableList(Arrays.asList(pageKeys.clone()));
        }
    }
    public static final List<Chapter> CHAPTERS = Collections.unmodifiableList(Arrays.asList(
        new Chapter("guide.nexustech.chapter.inicio", "guide.nexustech.page.inicio.0", "guide.nexustech.page.inicio.1", "guide.nexustech.page.inicio.2", "guide.nexustech.page.inicio.3", "guide.nexustech.page.inicio.4", "guide.nexustech.page.inicio.5"),
        new Chapter("guide.nexustech.chapter.minerios", "guide.nexustech.page.minerios.0", "guide.nexustech.page.minerios.1", "guide.nexustech.page.minerios.2", "guide.nexustech.page.minerios.3", "guide.nexustech.page.minerios.4", "guide.nexustech.page.minerios.5"),
        new Chapter("guide.nexustech.chapter.energia", "guide.nexustech.page.energia.0", "guide.nexustech.page.energia.1", "guide.nexustech.page.energia.2", "guide.nexustech.page.energia.3", "guide.nexustech.page.energia.4", "guide.nexustech.page.energia.5", "guide.nexustech.page.energia.6", "guide.nexustech.page.energia.7", "guide.nexustech.page.energia.8", "guide.nexustech.page.energia.9", "guide.nexustech.page.energia.10", "guide.nexustech.page.energia.11", "guide.nexustech.page.energia.12"),
        new Chapter("guide.nexustech.chapter.processamento", "guide.nexustech.page.processamento.0", "guide.nexustech.page.processamento.1", "guide.nexustech.page.processamento.2", "guide.nexustech.page.processamento.3", "guide.nexustech.page.processamento.4", "guide.nexustech.page.processamento.5", "guide.nexustech.page.processamento.6", "guide.nexustech.page.processamento.7", "guide.nexustech.page.processamento.8", "guide.nexustech.page.processamento.9", "guide.nexustech.page.processamento.10", "guide.nexustech.page.processamento.11", "guide.nexustech.page.processamento.12", "guide.nexustech.page.processamento.13", "guide.nexustech.page.processamento.14", "guide.nexustech.page.processamento.15", "guide.nexustech.page.processamento.16", "guide.nexustech.page.processamento.17", "guide.nexustech.page.processamento.18", "guide.nexustech.page.processamento.19"),
        new Chapter("guide.nexustech.chapter.automacao", "guide.nexustech.page.automacao.0", "guide.nexustech.page.automacao.1", "guide.nexustech.page.automacao.2", "guide.nexustech.page.automacao.3", "guide.nexustech.page.automacao.4", "guide.nexustech.page.automacao.5", "guide.nexustech.page.automacao.6", "guide.nexustech.page.automacao.7", "guide.nexustech.page.automacao.8", "guide.nexustech.page.automacao.9", "guide.nexustech.page.automacao.10", "guide.nexustech.page.automacao.11", "guide.nexustech.page.automacao.12", "guide.nexustech.page.automacao.13", "guide.nexustech.page.automacao.14", "guide.nexustech.page.automacao.15"),
        new Chapter("guide.nexustech.chapter.mina", "guide.nexustech.page.mina.0", "guide.nexustech.page.mina.1", "guide.nexustech.page.mina.2", "guide.nexustech.page.mina.3"),
        new Chapter("guide.nexustech.chapter.reator", "guide.nexustech.page.reator.0", "guide.nexustech.page.reator.1", "guide.nexustech.page.reator.2", "guide.nexustech.page.reator.3", "guide.nexustech.page.reator.4", "guide.nexustech.page.reator.5", "guide.nexustech.page.reator.6", "guide.nexustech.page.reator.7"),
        new Chapter("guide.nexustech.chapter.mobs", "guide.nexustech.page.mobs.0", "guide.nexustech.page.mobs.1", "guide.nexustech.page.mobs.2", "guide.nexustech.page.mobs.3", "guide.nexustech.page.mobs.4", "guide.nexustech.page.mobs.5"),
        new Chapter("guide.nexustech.chapter.equipamento", "guide.nexustech.page.equipamento.0", "guide.nexustech.page.equipamento.1", "guide.nexustech.page.equipamento.2", "guide.nexustech.page.equipamento.3", "guide.nexustech.page.equipamento.4", "guide.nexustech.page.equipamento.5", "guide.nexustech.page.equipamento.6", "guide.nexustech.page.equipamento.7", "guide.nexustech.page.equipamento.8", "guide.nexustech.page.equipamento.9", "guide.nexustech.page.equipamento.10"),
        new Chapter("guide.nexustech.chapter.ponte", "guide.nexustech.page.ponte.0")
    ));
}
