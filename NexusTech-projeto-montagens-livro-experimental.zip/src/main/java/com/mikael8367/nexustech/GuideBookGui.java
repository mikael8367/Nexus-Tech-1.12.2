package com.mikael8367.nexustech;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.crafting.ShapelessRecipes;
import net.minecraft.util.NonNullList;
import net.minecraftforge.common.crafting.IShapedRecipe;
import net.minecraftforge.oredict.ShapelessOreRecipe;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

/** Localized guide and read-only viewer of recipes registered with Forge. */
@SideOnly(Side.CLIENT)
public final class GuideBookGui extends GuiScreen {
    private final List<IRecipe> all = new ArrayList<IRecipe>();
    private final List<IRecipe> filtered = new ArrayList<IRecipe>();
    private GuiTextField search;
    private boolean recipes;
    private int chapter = -1, indexStart, page, part, x, panelWidth;
    // -1 means no selection, 0..8 a slot, and 9 the output.
    private int selectedSlot = -1;
    private int cachedChapter = -1, cachedPage = -1, cachedWidth = -1;
    private String cachedTranslation;
    private List<String> cachedLines;

    public GuideBookGui() {
        for (IRecipe r : ForgeRegistries.RECIPES) {
            if (r.getRegistryName() != null && NexusTech.MODID.equals(r.getRegistryName().getResourceDomain())) all.add(r);
        }
        all.sort(Comparator.comparing(r -> r.getRegistryName().toString()));
        filtered.addAll(all);
    }
    private String t(String suffix, Object... args) { return I18n.format("guide.nexustech." + suffix, args); }
    private int indexRows() { return Math.max(1, (height - 84) / 20); }
    private int linesPerScreen() { return Math.max(1, (height - 30 - 64) / (fontRenderer.FONT_HEIGHT + 1)); }
    private List<String> lines(int p) {
        String translation = I18n.format(GuideBookContent.CHAPTERS.get(chapter).pageKeys.get(p));
        int textWidth = Math.max(1, panelWidth - 12);
        if (cachedLines == null || cachedChapter != chapter || cachedPage != p || cachedWidth != textWidth || !translation.equals(cachedTranslation)) {
            cachedLines = fontRenderer.listFormattedStringToWidth(translation, textWidth);
            cachedChapter = chapter; cachedPage = p; cachedWidth = textWidth; cachedTranslation = translation;
        }
        return cachedLines;
    }
    private int partCount(int p) {
        return GuideBookNavigation.chunks(lines(p).size(), linesPerScreen());
    }
    @Override public void initGui() {
        Keyboard.enableRepeatEvents(true);
        cachedLines = null; // The font or available width may have changed on resize/reopen.
        String previous = search == null ? "" : search.getText();
        panelWidth = Math.max  (1, Math.min(310, width - 8)); x = (width - panelWidth) / 2;
        buttonList.clear();
        buttonList.add(new GuiButton(5, x + panelWidth - 22, 2, 22, 20, "X"));
        GuiButton assembly = new GuiButton(6, x + 3, 25, 100, 20, t("assembly"));
        assembly.visible = !recipes;
        buttonList.add(assembly);
        GuiButton index = new GuiButton(7, x + 108, 25, 78, 20, t("index"));
        index.visible = !recipes && chapter >= 0;
        buttonList.add(index);
        int y = height - 25, w = panelWidth / 5;
        buttonList.add(new GuiButton(0, x, y, w, 20, "<<"));
        buttonList.add(new GuiButton(1, x + w, y, w, 20, "<"));
        buttonList.add(new GuiButton(2, x + 2*w, y, w, 20, t(recipes ? "lessons" : "recipes")));
        buttonList.add(new GuiButton(3, x + 3*w, y, w, 20, ">"));
        buttonList.add(new GuiButton(4, x + 4*w, y, panelWidth - 4*w, 20, ">>"));
        if (!recipes && chapter < 0) {
            indexStart = Math.max(0, Math.min(indexStart, GuideBookNavigation.lastIndexStart(GuideBookContent.CHAPTERS.size(), indexRows())));
            for (int i = indexStart; i < Math.min(GuideBookContent.CHAPTERS.size(), indexStart + indexRows()); i++) {
                String title = I18n.format(GuideBookContent.CHAPTERS.get(i).titleKey);
                GuiButton chapterButton = new GuiButton(100 + i, x + 4, 52 + (i - indexStart) * 20, panelWidth - 8, 20,
                        fontRenderer.trimStringToWidth((i + 1) + ". " + title, Math.max(0, panelWidth - 16)));
                chapterButton.enabled = !GuideBookContent.CHAPTERS.get(i).pageKeys.isEmpty();
                buttonList.add(chapterButton);
            }
        }
        search = new GuiTextField(0, fontRenderer, x + 62, 25, Math.max(30, panelWidth - 64), 18);
        search.setMaxStringLength(64); search.setText(previous); search.setVisible(recipes);
    }
    @Override public void updateScreen() { if (search != null && recipes) search.updateCursorCounter(); }
    @Override public void onGuiClosed() { Keyboard.enableRepeatEvents(false); }
    @Override public boolean doesGuiPauseGame() { return false; }
    private void filter() {
        String query = search.getText().trim().toLowerCase(Locale.ROOT);
        filtered.clear();
        for (IRecipe r : all) {
            ItemStack out = r.getRecipeOutput();
            String name = out.isEmpty() ? "" : out.getDisplayName();
            if (query.isEmpty() || name.toLowerCase(Locale.ROOT).contains(query) || r.getRegistryName().toString().toLowerCase(Locale.ROOT).contains(query)) filtered.add(r);
        }
        page = 0; selectedSlot = -1;
    }
    @Override protected void actionPerformed(GuiButton b) {
        if (b.id == 5) { mc.displayGuiScreen(null); return; }
        if (b.id == 6) { mc.displayGuiScreen(new GuideStructureGui(this)); return; }
        if (b.id == 7) { chapter = -1; page = part = 0; initGui(); return; }
        if (b.id >= 100) {
            int chosen = b.id - 100;
            if (chosen < GuideBookContent.CHAPTERS.size() && !GuideBookContent.CHAPTERS.get(chosen).pageKeys.isEmpty()) {
                chapter = chosen; page = part = 0; initGui();
            }
            return;
        }
        if (b.id == 2) { recipes = !recipes; page = part = 0; selectedSlot = -1; if (!recipes) chapter = -1; initGui(); return; }
        if (recipes) {
            int step = b.id == 0 ? -10 : b.id == 1 ? -1 : b.id == 3 ? 1 : 10;
            page = Math.max(0, Math.min(Math.max(0, filtered.size() - 1), page + step)); selectedSlot = -1;
        } else if (chapter < 0) {
            int last = GuideBookNavigation.lastIndexStart(GuideBookContent.CHAPTERS.size(), indexRows());
            indexStart = b.id == 0 ? 0 : b.id == 4 ? last : Math.max(0, Math.min(last, indexStart + (b.id == 1 ? -indexRows() : indexRows())));
            initGui();
        } else {
            int pages = GuideBookContent.CHAPTERS.get(chapter).pageKeys.size();
            if (pages == 0) return;
            page = Math.max(0, Math.min(page, pages - 1));
            if (b.id == 0) { page = part = 0; }
            else if (b.id == 4) { page = pages - 1; part = partCount(page) - 1; }
            else {
                int previousParts = b.id == 1 && part <= 0 && page > 0 ? partCount(page - 1) : 1;
                int[] next = GuideBookNavigation.move(page, part, pages, partCount(page), previousParts, b.id == 1 ? -1 : 1);
                page = next[0]; part = next[1];
            }
        }
    }
    @Override protected void keyTyped(char ch, int key) throws IOException {
        if (recipes && search.isFocused() && key != Keyboard.KEY_ESCAPE) {
            String old = search.getText(); search.textboxKeyTyped(ch, key); if (!old.equals(search.getText())) filter();
        } else super.keyTyped(ch, key);
    }
    @Override protected void mouseClicked(int mx, int my, int button) throws IOException {
        super.mouseClicked(mx, my, button);
        if (recipes) {
            search.mouseClicked(mx, my, button);
            if (!filtered.isEmpty() && my >= 48 && my < 105) {
                for (int i = 0; i < 9; i++) {
                    int cx = x + 8 + (i % 3) * 19, cy = 48 + (i / 3) * 19;
                    if (mx >= cx && mx < cx + 18 && my >= cy && my < cy + 18) selectedSlot = i;
                }
                if (mx >= x + 104 && mx < x + 124 && my >= 67 && my < 87) selectedSlot = 9;
            }
        }
    }
    private boolean supported(IRecipe r) {
        if (r instanceof IShapedRecipe) {
            IShapedRecipe shaped = (IShapedRecipe) r;
            int w = shaped.getRecipeWidth(), h = shaped.getRecipeHeight();
            return w >= 1 && w <= 3 && h >= 1 && h <= 3 && r.getIngredients().size() == w * h;
        }
        return (r instanceof ShapelessRecipes || r instanceof ShapelessOreRecipe) && r.getIngredients().size() <= 9;
    }
    private ItemStack ingredient(IRecipe r, int slot, long ticks) {
        if (!supported(r)) return ItemStack.EMPTY;
        NonNullList<Ingredient> ingredients = r.getIngredients();
        int index = slot;
        if (r instanceof IShapedRecipe) {
            IShapedRecipe shaped = (IShapedRecipe) r;
            int w = shaped.getRecipeWidth(), h = shaped.getRecipeHeight();
            if (w < 1 || w > 3 || h < 1 || h > 3 || slot % 3 >= w || slot / 3 >= h) return ItemStack.EMPTY;
            index = (slot / 3) * w + slot % 3;
        }
        if (index < 0 || index >= ingredients.size()) return ItemStack.EMPTY;
        ItemStack[] options = ingredients.get(index).getMatchingStacks();
        if (options.length == 0) return ItemStack.EMPTY;
        return options[(int)((ticks / 40L) % options.length)];
    }
    // Keep long localized labels out of adjacent controls; hovering a stack shows its tooltip.
    private void boundedText(String text, int px, int py, int maxWidth, int bottom) {
        int lineHeight = fontRenderer.FONT_HEIGHT + 1;
        int capacity = Math.max(0, (bottom - py) / lineHeight);
        int availableWidth = Math.max(1, maxWidth);
        List<String> wrapped = fontRenderer.listFormattedStringToWidth(text, availableWidth);
        for (int i = 0; i < Math.min(capacity, wrapped.size()); i++) {
            String line = wrapped.get(i);
            if (i == capacity - 1 && wrapped.size() > capacity) {
                String dots = "...";
                line = fontRenderer.trimStringToWidth(line, Math.max(0, availableWidth - fontRenderer.getStringWidth(dots))) + dots;
            }
            fontRenderer.drawString(line, px, py + i * lineHeight, 0xffffff);
        }
    }
    private void stack(ItemStack s, int px, int py) {
        if (s.isEmpty()) return;
        RenderHelper.enableGUIStandardItemLighting();
        itemRender.renderItemAndEffectIntoGUI(s, px, py);
        itemRender.renderItemOverlayIntoGUI(fontRenderer, s, px, py, null);
        RenderHelper.disableStandardItemLighting();
    }
    @Override public void drawScreen(int mx, int my, float partial) {
        drawDefaultBackground();
        ItemStack hovered = ItemStack.EMPTY;
        String header;
        if (recipes) header = t("recipes") + "  " + (filtered.isEmpty() ? 0 : page + 1) + "/" + filtered.size();
        else if (chapter < 0) header = t("index");
        else header = I18n.format(GuideBookContent.CHAPTERS.get(chapter).titleKey);
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(header, Math.max(1, panelWidth - 46)), width / 2, 8, 0xffffff);
        if (!recipes && chapter >= 0) {
            int pages = GuideBookContent.CHAPTERS.get(chapter).pageKeys.size();
            if (pages == 0) { super.drawScreen(mx, my, partial); return; }
            page = Math.max(0, Math.min(page, pages - 1));
            List<String> text = lines(page);
            int count = GuideBookNavigation.chunks(text.size(), linesPerScreen());
            part = Math.max(0, Math.min(part, count - 1));
            String marker = (page + 1) + "/" + pages + (count > 1 ? "  (" + (part + 1) + "/" + count + ")" : "");
            drawCenteredString(fontRenderer, marker, width / 2, 51, 0xffffaa);
            int start = part * linesPerScreen();
            for (int i = start; i < Math.min(text.size(), start + linesPerScreen()); i++)
                fontRenderer.drawString(text.get(i), x + 6, 64 + (i - start) * (fontRenderer.FONT_HEIGHT + 1), 0xffffff);
        } else if (recipes) {
            fontRenderer.drawString(t("search"), x + 3, 30, 0xffffff); search.drawTextBox();
            if (filtered.isEmpty()) boundedText(t("empty"), x + 6, 52, panelWidth - 12, height - 25);
            else {
                IRecipe r = filtered.get(page);
                // Sample once per frame: selected label and icon show the same option.
                long ticks = net.minecraft.client.Minecraft.getSystemTime() / 50L;
                ItemStack selected = selectedSlot == 9 ? r.getRecipeOutput() : ItemStack.EMPTY;
                for (int i = 0; i < 9; i++) {
                    int cx = x + 8 + i % 3 * 19, cy = 48 + i / 3 * 19;
                    ItemStack current = ingredient(r, i, ticks);
                    if (selectedSlot == i) selected = current;
                    if (mx >= cx && mx < cx + 18 && my >= cy && my < cy + 18) hovered = current;
                    drawRect(cx, cy, cx + 18, cy + 18, 0xff555555); stack(current, cx + 1, cy + 1);
                }
                fontRenderer.drawString("->", x + 75, 73, 0xffffff);
                drawRect(x + 104, 67, x + 124, 87, 0xff555555); stack(r.getRecipeOutput(), x + 106, 69);
                if (mx >= x + 104 && mx < x + 124 && my >= 67 && my < 87) hovered = r.getRecipeOutput();
                String type = !supported(r) ? t("unsupported") : r instanceof IShapedRecipe ? t("shaped") : t("shapeless");
                boundedText(type, x + 130, 49, panelWidth - 135, 72);
                boundedText(r.getRecipeOutput().isEmpty() ? r.getRegistryName().toString() : r.getRecipeOutput().getDisplayName(), x + 130, 72, panelWidth - 135, 105);
                String label = selected.isEmpty() ? t("tap") : selected.getDisplayName();
                boundedText(label, x + 8, 110, panelWidth - 16, height - 25);
            }
        }
        super.drawScreen(mx, my, partial);
        if (!hovered.isEmpty()) renderToolTip(hovered, mx, my);
    }
}
