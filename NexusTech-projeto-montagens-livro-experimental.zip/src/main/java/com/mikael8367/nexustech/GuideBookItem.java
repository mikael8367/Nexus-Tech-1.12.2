package com.mikael8367.nexustech;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

/** Opens a client-only, read-only screen; no inventory or network operations. */
public final class GuideBookItem extends Item {
    public GuideBookItem() {
        setRegistryName(NexusTech.MODID, "guide_book");
        setUnlocalizedName(NexusTech.MODID + ".guide_book");
        setCreativeTab(NexusTech.CREATIVE_TAB);
        setMaxStackSize(1);
    }
    @Override public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (world.isRemote) NexusTech.proxy.openGuide();
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }
}
