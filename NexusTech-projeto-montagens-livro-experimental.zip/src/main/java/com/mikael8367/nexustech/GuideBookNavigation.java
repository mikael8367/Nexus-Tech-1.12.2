package com.mikael8367.nexustech;

/** Navigation independent of the client, for testable page boundaries. */
public final class GuideBookNavigation {
    private GuideBookNavigation() {}
    public static int chunks(int lineCount, int linesPerScreen) {
        int capacity = Math.max(1, linesPerScreen);
        int lines = Math.max(0, lineCount);
        return lines == 0 ? 1 : 1 + (lines - 1) / capacity;
    }
    public static int lastIndexStart(int itemCount, int rows) {
        return itemCount <= 0 ? 0 : ((itemCount - 1) / Math.max(1, rows)) * Math.max(1, rows);
    }
    public static int[] move(int page, int part, int[] parts, int direction) {
        if (parts.length == 0) return new int[] {0, 0};
        page = Math.max(0, Math.min(parts.length - 1, page));
        part = Math.max(0, Math.min(Math.max(1, parts[page]) - 1, part));
        return move(page, part, parts.length, parts[page], page > 0 ? parts[page - 1] : 1, direction);
    }
    // Only the current and preceding page need to be wrapped, even for large chapters.
    public static int[] move(int page, int part, int pageCount, int currentParts, int previousParts, int direction) {
        if (pageCount <= 0) return new int[] {0, 0};
        page = Math.max(0, Math.min(pageCount - 1, page));
        part = Math.max(0, Math.min(Math.max(1, currentParts) - 1, part));
        if (direction > 0) {
            if (part < Math.max(1, currentParts) - 1) part++;
            else if (page < pageCount - 1) { page++; part = 0; }
        } else if (direction < 0) {
            if (part > 0) part--;
            else if (page > 0) { page--; part = Math.max(1, previousParts) - 1; }
        }
        return new int[] {page, part};
    }
}
