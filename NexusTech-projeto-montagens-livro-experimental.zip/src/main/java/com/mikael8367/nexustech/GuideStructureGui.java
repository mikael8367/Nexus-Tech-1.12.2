package com.mikael8367.nexustech;

import com.mikael8367.nexustech.digitalmine.DigitalMineRegistry;
import com.mikael8367.nexustech.nuclear.NuclearRegistry;
import com.mikael8367.nexustech.powerexpansion.SolarArrayRegistry;
import java.io.IOException;
import net.minecraft.block.Block;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

/** Local assembly guide; never reads or changes the world. */
@SideOnly(Side.CLIENT)
public final class GuideStructureGui extends GuiScreen {
    private final GuiScreen parent;
    private int kind, layer;
    private boolean advanced, overview = false;
    private int left, panel;
    private int uiWidth, uiHeight;
    private float uiScale, uiX, uiY;
    private static final int LAYER_STEP = 64, DIAGRAM_WIDTH = 108, LAYER_HEIGHT = 60;
    static final int GRID_LEFT = 8, GRID_TOP = 70, GRID_CELL = 34, LEGEND_LEFT = 121;

    public GuideStructureGui(GuiScreen parent) { this.parent = parent; }
    private int layers() { return kind == 0 ? 2 : kind == 1 ? 5 : 4; }
    private String text(String key, Object... args) { return I18n.format("guide.nexustech.structure." + key, args); }
    @Override public boolean doesGuiPauseGame() { return false; }
    // Launchers may report a logical screen smaller than vanilla's 320x240.
    // Scale a virtual canvas and invert the same transform for input.
    static float canvasScale(int width, int height) {
        return Math.min(1F, Math.min(Math.max(1, width) / 320F, Math.max(1, height) / 240F));
    }
    static int canvasDimension(int dimension, float scale) { return (int) (dimension / scale); }
    static int canvasMouse(int position, float offset, float scale) { return (int) Math.floor((position - offset) / scale); }
    @Override public void initGui() {
        uiScale = canvasScale(width, height);
        uiWidth = canvasDimension(width, uiScale);
        uiHeight = canvasDimension(height, uiScale);
        uiX = (width - uiWidth * uiScale) / 2F;
        uiY = (height - uiHeight * uiScale) / 2F;
        panel = Math.max(0, Math.min(320, uiWidth - 8));
        left = (uiWidth - panel) / 2;
        buttonList.clear();
        int quarter = panel / 4;
        String[] names = {text("mine"), text("reactor"), text("solar"), text("back")};
        for (int i = 0; i < 4; i++)
            buttonList.add(new GuiButton(i, left + i * quarter, 16,
                    i == 3 ? panel - 3 * quarter : quarter, 20, fitButton(names[i], i == 3 ? panel - 3 * quarter : quarter)));
        buttonList.add(new GuiButton(4, left, uiHeight - 23, quarter, 20, fitButton(text("previous"), quarter)));
        buttonList.add(new GuiButton(5, left + quarter, uiHeight - 23, quarter, 20, fitButton(text("next"), quarter)));
        buttonList.add(new GuiButton(6, left + 2 * quarter, uiHeight - 23, quarter, 20, ""));
        buttonList.add(new GuiButton(7, left + 3 * quarter, uiHeight - 23, panel - 3 * quarter, 20, ""));
        refreshButtons();
    }
    private String fitButton(String value, int w) { return fontRenderer.trimStringToWidth(value, Math.max(0, w - 8)); }
    private void refreshButtons() {
        buttonList.get(4).enabled = !overview && layer > 0;
        buttonList.get(5).enabled = !overview && layer + 1 < layers();
        GuiButton variant = buttonList.get(6);
        variant.visible = kind == 0;
        variant.displayString = fitButton(text(advanced ? "advanced" : "basic"), panel / 4);
        // The label says where the button will take the user.
        buttonList.get(7).displayString = fitButton(text(overview ? "to_layers" : kind == 2 ? "to_overview" : "to_summary"), panel - 3 * (panel / 4));
    }
    @Override protected void mouseClicked(int x, int y, int button) throws IOException {
        super.mouseClicked(canvasMouse(x, uiX, uiScale), canvasMouse(y, uiY, uiScale), button);
    }
    @Override protected void mouseReleased(int x, int y, int state) {
        super.mouseReleased(canvasMouse(x, uiX, uiScale), canvasMouse(y, uiY, uiScale), state);
    }
    @Override protected void actionPerformed(GuiButton b) {
        if (b.id == 3) { mc.displayGuiScreen(parent); return; }
        if (b.id < 3) { kind = b.id; layer = 0; overview = kind == 2; }
        if (b.id == 4 && !overview && layer > 0) layer--;
        if (b.id == 5 && !overview && layer + 1 < layers()) layer++;
        if (b.id == 6 && kind == 0) advanced = !advanced;
        if (b.id == 7) overview = !overview;
        refreshButtons();
    }
    @Override protected void keyTyped(char c, int code) throws IOException {
        if (code == Keyboard.KEY_ESCAPE) mc.displayGuiScreen(parent);
        else super.keyTyped(c, code);
    }

    // x is controller-relative right; depth grows behind its facing. Both the
    // mine and reactor are solid, including all interior cells.
    private Block blockAt(int x, int depth) { return blockAt(x, depth, layer); }
    private Block blockAt(int x, int depth, int y) {
        if (kind == 0) {
            if (y == 0 && x == 0 && depth == 0)
                return advanced ? DigitalMineRegistry.ADVANCED : DigitalMineRegistry.BASIC;
            return DigitalMineRegistry.CASING;
        }
        if (kind == 1) {
            if (y == 0 && x == 0 && depth == 0) return NuclearRegistry.CONTROLLER;
            if (y == 2 && x == 0 && depth == 1) return NuclearRegistry.CORE;
            return NuclearRegistry.CASING;
        }
        if (y == 3) return SolarArrayRegistry.MODULE;
        if (x != 0 || depth != 1) return null;
        return y == 0 ? SolarArrayRegistry.ARRAY : SolarArrayRegistry.POLE;
    }
    private void icon(Block block, int x, int y) {
        if (block != null) itemRender.renderItemAndEffectIntoGUI(new ItemStack(block), x, y);
    }
    private void legend(Block block, int count, int y) {
        ItemStack stack = new ItemStack(block);
        GlStateManager.pushMatrix();
        GlStateManager.translate(left + 4, y - 1, 0);
        GlStateManager.scale(0.65F, 0.65F, 1F);
        RenderHelper.enableGUIStandardItemLighting();
        itemRender.renderItemAndEffectIntoGUI(stack, 0, 0);
        RenderHelper.disableStandardItemLighting();
        GlStateManager.popMatrix();
        GlStateManager.disableDepth();
        GlStateManager.color(1, 1, 1, 1);
        String name = count + "x " + stack.getDisplayName();
        fontRenderer.drawString(fontRenderer.trimStringToWidth(name, Math.max(0, panel - 20)), left + 17, y, 0xffffff);
    }
    // Exploded layers are aligned vertically. The gaps are intentional: a solid
    // exterior would hide the reactor core and most of the blocks inside.
    static int diagramHeight(int count) { return LAYER_HEIGHT + (count - 1) * LAYER_STEP; }
    static float diagramScale(int panelWidth, int availableHeight, int count) {
        return Math.max(0, Math.min(1.5F, Math.min((panelWidth - 8) / (float) DIAGRAM_WIDTH,
                availableHeight / (float) diagramHeight(count))));
    }
    private void drawLayer(int y, int offset) {
        RenderHelper.enableGUIStandardItemLighting();
        for (int row = -3; row <= 1; row++) for (int x = -1; x <= 1; x++) {
            int d = x - row;
            if (d < 0 || d > 2) continue;
            icon(blockAt(x, d, y), 8 + (x + d + 1) * 19, offset + 4 + (x - d + 3) * 10);
        }
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableDepth();
        GlStateManager.color(1, 1, 1, 1);
        // The marker is at the front edge of each plane, not on a rotated icon.
        if (kind != 2) fontRenderer.drawStringWithShadow("F", 16, offset + 51, 0xffff55);
    }
    // Top view, standing inside and looking toward the controller's outward front.
    // Thus the back is on top, front on bottom, and +x is the controller's right.
    static int gridDepth(int row) { return 2 - row; }
    static int gridRight(int column) { return column - 1; }

    private int wrapped(String value, int x, int y, int w, int color) {
        java.util.List<String> lines = fontRenderer.listFormattedStringToWidth(value, Math.max(1, w));
        for (int i = 0; i < Math.min(2, lines.size()); i++) {
            String line = lines.get(i);
            if (i == 1 && lines.size() > 2) line = fontRenderer.trimStringToWidth(line, Math.max(0, w - fontRenderer.getStringWidth("..."))) + "...";
            fontRenderer.drawString(line, x, y, color);
            y += 10;
        }
        return y;
    }

    private int gridLegend(Block block, String symbol, String position, int count, int x, int y, int w) {
        fontRenderer.drawString(symbol + " " + count + "x", x, y, 0xffff55);
        y = wrapped(new ItemStack(block).getDisplayName(), x + 30, y, w - 30, 0xffffff);
        return wrapped(position, x + 30, y, w - 30, 0xffcc99) + 4;
    }

    private void drawGridGuide() {
        String name = text(kind == 0 ? "mine" : "reactor");
        String title = overview ? text("summary_title", name) : text("title_layer", name, layer + 1, layers());
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(title, panel), uiWidth / 2, 4, 0xffffff);
        Block controller = kind == 0 ? (advanced ? DigitalMineRegistry.ADVANCED : DigitalMineRegistry.BASIC) : NuclearRegistry.CONTROLLER;
        Block casing = kind == 0 ? DigitalMineRegistry.CASING : NuclearRegistry.CASING;
        if (overview) {
            drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(text("summary_help"), panel), uiWidth / 2, 43, 0xffffaa);
            int x = left + 16, y = 62, w = panel - 32;
            y = gridLegend(controller, "C", text("pos_controller"), 1, x, y, w);
            if (kind == 1) y = gridLegend(NuclearRegistry.CORE, "N", text("pos_core"), 1, x, y, w);
            gridLegend(casing, "R", text("pos_rest"), kind == 0 ? 17 : 43, x, y, w);
            return;
        }
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(text("grid_top"), panel), uiWidth / 2, 40, 0xffffaa);
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(text("grid_orientation"), panel), uiWidth / 2, 51, 0xffffaa);
        int gx = left + GRID_LEFT, gy = GRID_TOP, cell = GRID_CELL;
        for (int row = 0; row < 3; row++) for (int col = 0; col < 3; col++) {
            Block block = blockAt(gridRight(col), gridDepth(row));
            int x = gx + col * cell, y = gy + row * cell;
            String symbol = block == controller ? "C" : kind == 1 && block == NuclearRegistry.CORE ? "N" : "R";
            drawRect(x, y, x + cell - 2, y + cell - 2, 0xff8a8a8a);
            drawRect(x + 1, y + 1, x + cell - 3, y + cell - 3, 0xff303030);
            GlStateManager.pushMatrix();
            GlStateManager.translate(x + 4, y + 4, 0);
            GlStateManager.scale(1.5F, 1.5F, 1);
            RenderHelper.enableGUIStandardItemLighting();
            icon(block, 0, 0);
            RenderHelper.disableStandardItemLighting();
            GlStateManager.popMatrix();
            GlStateManager.disableDepth();
            GlStateManager.color(1, 1, 1, 1);
            // A dark backing keeps the letter readable over bright item textures.
            drawRect(x + 1, y + 1, x + 10, y + 12, 0xff171717);
            fontRenderer.drawStringWithShadow(symbol, x + 2, y + 2, 0xffff55);
        }
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(text("grid_front"), 100), gx + 50, gy + 103, 0xffff55);
        int x = left + LEGEND_LEFT, y = GRID_TOP, w = panel - LEGEND_LEFT - 4;
        if (layer == 0) y = gridLegend(controller, "C", text("pos_front_center"), 1, x, y, w);
        if (kind == 1 && layer == 2) y = gridLegend(NuclearRegistry.CORE, "N", text("pos_middle"), 1, x, y, w);
        boolean special = layer == 0 || (kind == 1 && layer == 2);
        gridLegend(casing, "R", text(special ? "pos_other_cells" : "pos_all_cells"), special ? 8 : 9, x, y, w);
    }
    @Override public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        GlStateManager.pushMatrix();
        GlStateManager.translate(uiX, uiY, 0);
        GlStateManager.scale(uiScale, uiScale, 1);
        mouseX = canvasMouse(mouseX, uiX, uiScale);
        mouseY = canvasMouse(mouseY, uiY, uiScale);
        if (kind != 2) {
            drawGridGuide();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.color(1, 1, 1, 1);
            super.drawScreen(mouseX, mouseY, partialTicks);
            GlStateManager.popMatrix();
            return;
        }
        String name = text(kind == 0 ? "mine" : kind == 1 ? "reactor" : "solar");
        String title = overview ? text("title_overview", name) : text("title_layer", name, layer + 1, layers());
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(title, panel), uiWidth / 2, 4, 0xffffff);
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(text("models"), panel), uiWidth / 2, 40, 0xffffaa);
        String hint = kind == 2 ? text("solar_hint") : text("front_hint");
        drawCenteredString(fontRenderer, fontRenderer.trimStringToWidth(hint, panel), uiWidth / 2, 50, 0xffffaa);

        int top = 62, bottom = uiHeight - 65;
        int count = overview ? layers() : 1;
        float scale = diagramScale(panel, Math.max(0, bottom - top), count);
        if (scale > 0) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(uiWidth / 2.0F - DIAGRAM_WIDTH * scale / 2,
                    top + ((bottom - top) - diagramHeight(count) * scale) / 2, 0);
            GlStateManager.scale(scale, scale, 1);
            if (overview) {
                for (int y = layers() - 1; y >= 0; y--) drawLayer(y, (layers() - 1 - y) * LAYER_STEP);
            } else drawLayer(layer, 0);
            GlStateManager.popMatrix();
        }
        int y = uiHeight - 61;
        if (kind == 0) {
            legend(advanced ? DigitalMineRegistry.ADVANCED : DigitalMineRegistry.BASIC, 1, y);
            legend(DigitalMineRegistry.CASING, 17, y + 11);
        } else if (kind == 1) {
            legend(NuclearRegistry.CONTROLLER, 1, y);
            legend(NuclearRegistry.CORE, 1, y + 11);
            legend(NuclearRegistry.CASING, 43, y + 22);
        } else {
            legend(SolarArrayRegistry.ARRAY, 1, y);
            legend(SolarArrayRegistry.POLE, 2, y + 11);
            legend(SolarArrayRegistry.MODULE, 9, y + 22);
        }
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.color(1, 1, 1, 1);
        super.drawScreen(mouseX, mouseY, partialTicks);
        GlStateManager.popMatrix();
    }
}
