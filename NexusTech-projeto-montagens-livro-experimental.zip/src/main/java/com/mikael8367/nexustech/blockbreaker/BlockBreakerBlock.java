package com.mikael8367.nexustech.blockbreaker;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class BlockBreakerBlock extends Block {
    public static final PropertyDirection FACING=BlockHorizontal.FACING;
    BlockBreakerBlock() {
        super(Material.IRON);
        setRegistryName(NexusTech.MODID,"block_breaker"); setUnlocalizedName(NexusTech.MODID+".block_breaker");
        setCreativeTab(NexusTech.CREATIVE_TAB); setHardness(4); setResistance(12); setHarvestLevel("pickaxe",1);
        setDefaultState(blockState.getBaseState().withProperty(FACING,EnumFacing.NORTH));
    }
    @Override protected BlockStateContainer createBlockState(){return new BlockStateContainer(this,FACING);}
    @Override public IBlockState getStateFromMeta(int meta){return getDefaultState().withProperty(FACING,EnumFacing.getHorizontal(meta & 3));}
    @Override public int getMetaFromState(IBlockState state){return state.getValue(FACING).getHorizontalIndex();}
    @Override public IBlockState getStateForPlacement(World w, BlockPos p, EnumFacing f, float x,float y,float z,int meta,EntityLivingBase placer,EnumHand hand){return getDefaultState().withProperty(FACING,placer.getHorizontalFacing().getOpposite());}
    @Override public boolean hasTileEntity(IBlockState state){return true;}
    @Override public TileEntity createTileEntity(World w,IBlockState state){return new BlockBreakerTile();}
    @Override public void onBlockPlacedBy(World w,BlockPos pos,IBlockState state,EntityLivingBase placer,ItemStack stack){
        if(!w.isRemote && placer instanceof EntityPlayer && w.getTileEntity(pos) instanceof BlockBreakerTile)
            ((BlockBreakerTile)w.getTileEntity(pos)).setOwner((EntityPlayer)placer);
    }
    @Override public boolean onBlockActivated(World w,BlockPos pos,IBlockState state,EntityPlayer player,EnumHand hand,EnumFacing side,float x,float y,float z){
        if(!w.isRemote && w.getTileEntity(pos) instanceof BlockBreakerTile && ((BlockBreakerTile)w.getTileEntity(pos)).authorized(player))
            player.openGui(NexusTech.INSTANCE,BlockBreakerRegistry.GUI_ID,w,pos.getX(),pos.getY(),pos.getZ());
        return true;
    }
    @Override public void breakBlock(World w,BlockPos pos,IBlockState state){
        TileEntity t=w.getTileEntity(pos);
        if(!w.isRemote && t instanceof BlockBreakerTile){
            ItemStack stack=((BlockBreakerTile)t).drain();
            if(!stack.isEmpty())BlockBreakerRecovery.get(w).enqueue(pos,stack);
        }
        super.breakBlock(w,pos,state);
    }
}
