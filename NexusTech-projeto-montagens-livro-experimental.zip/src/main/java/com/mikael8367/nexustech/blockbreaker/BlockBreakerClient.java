package com.mikael8367.nexustech.blockbreaker;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid=NexusTech.MODID,value=Side.CLIENT)
public final class BlockBreakerClient {
    @SubscribeEvent public static void models(ModelRegistryEvent e){Item item=Item.getItemFromBlock(BlockBreakerRegistry.BLOCK);ModelLoader.setCustomModelResourceLocation(item,0,new ModelResourceLocation(item.getRegistryName(),"inventory"));}
    public static Object gui(int id,EntityPlayer p,World w,int x,int y,int z){
        if(id!=BlockBreakerRegistry.GUI_ID || p==null || w==null || !w.isRemote || p.world!=w)return null;
        BlockPos pos=new BlockPos(x,y,z);if(!w.isBlockLoaded(pos))return null;TileEntity tile=w.getTileEntity(pos);
        if(!(tile instanceof BlockBreakerTile))return null;
        BlockBreakerContainer c=new BlockBreakerContainer(p.inventory,(BlockBreakerTile)tile);
        return c.canInteractWith(p)?new BlockBreakerGui(p.inventory,(BlockBreakerTile)tile):null;
    }
    private BlockBreakerClient(){}
}
