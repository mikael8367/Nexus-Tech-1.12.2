package com.mikael8367.nexustech.blockbreaker;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;

public final class BlockBreakerContainer extends Container {
    private final BlockBreakerTile tile;
    private int lastEnergy=-1, lastStatus=-1;
    BlockBreakerContainer(InventoryPlayer inv,BlockBreakerTile t){
        tile=t;
        addSlotToContainer(new SlotItemHandler(t.tool,0,80,31){
            @Override public boolean isItemValid(ItemStack s){return BlockBreakerTile.validTool(s);}
            @Override public int getItemStackLimit(ItemStack s){return 1;}
            @Override public int getSlotStackLimit(){return 1;}
            @Override public void putStack(ItemStack s){if(s.isEmpty() || BlockBreakerTile.validTool(s))super.putStack(s);}
        });
        for(int r=0;r<3;r++)for(int c=0;c<9;c++)addSlotToContainer(new Slot(inv,9+r*9+c,8+c*18,85+r*18));
        for(int c=0;c<9;c++)addSlotToContainer(new Slot(inv,c,8+c*18,143));
    }
    @Override public boolean canInteractWith(EntityPlayer p){
        if(p==null || tile.getWorld()==null || p.world!=tile.getWorld() || tile.isInvalid() || !p.world.isBlockLoaded(tile.getPos()) || p.world.getTileEntity(tile.getPos())!=tile || p.getDistanceSq(tile.getPos().getX()+.5,tile.getPos().getY()+.5,tile.getPos().getZ()+.5)>64)return false;
        return p.world.isRemote || tile.authorized(p);
    }
    @Override public ItemStack slotClick(int id,int button,ClickType type,EntityPlayer p){
        if(!canInteractWith(p) || (!p.world.isRemote && p.openContainer!=this))return ItemStack.EMPTY;
        if(type!=ClickType.PICKUP && type!=ClickType.QUICK_MOVE && type!=ClickType.THROW)return ItemStack.EMPTY;
        if(id < -999 || id>=inventorySlots.size() || (id<0 && id!=-999))return ItemStack.EMPTY;
        return super.slotClick(id,button,type,p);
    }
    @Override public ItemStack transferStackInSlot(EntityPlayer p,int index){
        if(!canInteractWith(p) || index<0 || index>=inventorySlots.size())return ItemStack.EMPTY;
        Slot slot=inventorySlots.get(index);if(!slot.getHasStack())return ItemStack.EMPTY;
        ItemStack stack=slot.getStack(), original=stack.copy();
        if(index==0){if(!mergeItemStack(stack,1,37,true))return ItemStack.EMPTY;}
        else {if(!BlockBreakerTile.validTool(stack) || !mergeItemStack(stack,0,1,false))return ItemStack.EMPTY;}
        if(stack.isEmpty())slot.putStack(ItemStack.EMPTY);else slot.onSlotChanged();
        slot.onTake(p,stack);return original;
    }
    @Override public void addListener(IContainerListener listener){super.addListener(listener);listener.sendWindowProperty(this,0,tile.energy());listener.sendWindowProperty(this,1,tile.status());}
    @Override public void detectAndSendChanges(){
        super.detectAndSendChanges();
        if(lastEnergy!=tile.energy()){for(IContainerListener l:listeners)l.sendWindowProperty(this,0,tile.energy());lastEnergy=tile.energy();}
        if(lastStatus!=tile.status()){for(IContainerListener l:listeners)l.sendWindowProperty(this,1,tile.status());lastStatus=tile.status();}
    }
    @Override public void updateProgressBar(int id,int value){if(id==0)tile.clientEnergy(value & 65535);else if(id==1)tile.clientStatus(value);}
}
