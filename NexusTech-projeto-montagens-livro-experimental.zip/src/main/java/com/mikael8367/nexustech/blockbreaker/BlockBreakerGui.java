package com.mikael8367.nexustech.blockbreaker;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)
public final class BlockBreakerGui extends GuiContainer {
    private final BlockBreakerTile tile;
    BlockBreakerGui(InventoryPlayer inv,BlockBreakerTile t){super(new BlockBreakerContainer(inv,t));tile=t;xSize=176;ySize=167;}
    @Override protected void drawGuiContainerForegroundLayer(int x,int y){
        fontRenderer.drawString(I18n.format("gui.nexustech.block_breaker.title"),8,6,4210752);
        fontRenderer.drawString("FE: "+tile.energy()+" / 10000",8,54,4210752);
        if(tile.status()==BlockBreakerTile.STATUS_AMBIGUOUS){
            boolean pt=mc.getLanguageManager().getCurrentLanguage().getLanguageCode().startsWith("pt");
            fontRenderer.drawString(pt ? "PARADO: ferramenta incerta!" : "STOPPED: tool uncertain!",8,65,11141120);
            fontRenderer.drawString(pt ? "Veja log e inventarios" : "Check log and inventories",8,74,11141120);
        } else if(tile.status()==BlockBreakerTile.STATUS_FAULT)
            fontRenderer.drawString(I18n.format("gui.nexustech.block_breaker.fault"),8,74,11141120);
    }
    @Override protected void drawGuiContainerBackgroundLayer(float partial,int x,int y){
        mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/container/generic_54.png"));
        net.minecraft.client.renderer.GlStateManager.color(1.0F,1.0F,1.0F,1.0F);
        drawTexturedModalRect(guiLeft,guiTop,0,0,176,80);
        // Hide the chest's unused grid; only the tool slot is interactive here.
        drawRect(guiLeft+7,guiTop+17,guiLeft+169,guiTop+80,0xffc6c6c6);
        // drawRect changes the GL color; restore it before drawing the texture.
        net.minecraft.client.renderer.GlStateManager.color(1.0F,1.0F,1.0F,1.0F);
        // Source y=135 aligns vanilla inventory slots (y=140) with container y=85.
        drawTexturedModalRect(guiLeft,guiTop+80,0,135,176,87);
        drawTexturedModalRect(guiLeft+79,guiTop+30,7,17,18,18);
    }
    @Override public void drawScreen(int x,int y,float partial){drawDefaultBackground();super.drawScreen(x,y,partial);renderHoveredToolTip(x,y);}
}
