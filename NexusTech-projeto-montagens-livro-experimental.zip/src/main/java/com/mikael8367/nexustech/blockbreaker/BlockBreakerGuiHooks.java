package com.mikael8367.nexustech.blockbreaker;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
public final class BlockBreakerGuiHooks {
    public static Object server(int id,EntityPlayer player,World world,int x,int y,int z){
        if(id!=BlockBreakerRegistry.GUI_ID || player==null || world==null || world.isRemote || player.world!=world)return null;
        BlockPos pos=new BlockPos(x,y,z);if(!world.isBlockLoaded(pos))return null;
        TileEntity tile=world.getTileEntity(pos);
        if(!(tile instanceof BlockBreakerTile) || !((BlockBreakerTile)tile).authorized(player))return null;
        return new BlockBreakerContainer(player.inventory,(BlockBreakerTile)tile);
    }
    private BlockBreakerGuiHooks(){}
}
