package com.mikael8367.nexustech.blockbreaker;

import com.mikael8367.nexustech.NexusTech;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Recheck after other break handlers have had the opportunity to change the target. */
@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class BlockBreakerHarvestGuard {
    private static final class Action {
        final BlockBreakerTile tile; final BlockPos pos; final IBlockState state;
        Action(BlockBreakerTile t,BlockPos p,IBlockState s){tile=t;pos=p.toImmutable();state=s;}
    }
    private static final Map<EntityPlayer,Action> actions=new IdentityHashMap<>();
    static void begin(EntityPlayer p,BlockBreakerTile t,BlockPos pos,IBlockState state){
        if(actions.containsKey(p))throw new IllegalStateException("reentrant fake player");
        actions.put(p,new Action(t,pos,state));
    }
    static void end(EntityPlayer p){actions.remove(p);}
    @SubscribeEvent(priority=EventPriority.LOWEST,receiveCanceled=true)
    public static void onBreak(BlockEvent.BreakEvent e){
        Action a=actions.get(e.getPlayer());
        if(a!=null && (e.getWorld()!=a.tile.getWorld() || !e.getPos().equals(a.pos) || !a.tile.harvestStillSafe(a.pos,a.state,e.getPlayer())))e.setCanceled(true);
    }
    private BlockBreakerHarvestGuard(){}
}
