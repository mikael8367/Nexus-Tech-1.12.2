package com.mikael8367.nexustech.blockbreaker;

import com.mikael8367.nexustech.NexusTech;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Refused item spawns are retried; ambiguous exceptions are quarantined, never duplicated. */
@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class BlockBreakerRecovery extends WorldSavedData {
    private static final String KEY="nexustech_blockbreaker_recovery";
    private static final class Entry {
        final BlockPos pos; final ItemStack item;
        Entry(BlockPos p,ItemStack s){pos=p.toImmutable();item=s.copy();}
    }
    private final List<Entry> pending=new ArrayList<>(),quarantine=new ArrayList<>();
    // Incident records contain no item: an uncertain original must never be minted.
    private final List<BlockPos> ambiguous=new ArrayList<>();
    void noteAmbiguous(BlockPos pos){ambiguous.add(pos.toImmutable());markDirty();}
    private int next; private boolean delivering;
    public BlockBreakerRecovery(){super(KEY);}
    public BlockBreakerRecovery(String name){super(name);}
    static BlockBreakerRecovery get(World world){
        MapStorage storage=world.getPerWorldStorage();
        BlockBreakerRecovery data=(BlockBreakerRecovery)storage.getOrLoadData(BlockBreakerRecovery.class,KEY);
        if(data==null){data=new BlockBreakerRecovery(KEY);storage.setData(KEY,data);}return data;
    }
    void enqueue(BlockPos pos,ItemStack item){if(!item.isEmpty()){pending.add(new Entry(pos,item));markDirty();}}
    void retry(World world){
        if(delivering || pending.isEmpty())return;delivering=true;
        try {
            int budget=Math.min(64,pending.size());
            while(budget-- > 0 && !pending.isEmpty()){
                if(next>=pending.size())next=0;Entry e=pending.get(next);
                if(!world.isBlockLoaded(e.pos)){next++;continue;}
                pending.remove(next);quarantine.add(e);markDirty();
                try {
                    boolean ok=world.spawnEntity(new EntityItem(world,e.pos.getX()+.5,e.pos.getY()+.5,e.pos.getZ()+.5,e.item.copy()));
                    if(ok)quarantine.remove(e);else{quarantine.remove(e);pending.add(e);}markDirty();
                } catch(RuntimeException uncertain){ /* quarantine until manual recovery */ }
            }
        } finally {delivering=false;}
    }
    @SubscribeEvent public static void onWorldTick(TickEvent.WorldTickEvent e){
        if(!e.world.isRemote && e.phase==TickEvent.Phase.END && e.world.getTotalWorldTime()%20==0)get(e.world).retry(e.world);
    }
    private static void readEntries(NBTTagList list,List<Entry> into){for(int i=0;i<list.tagCount();i++){
        NBTTagCompound n=list.getCompoundTagAt(i);ItemStack s=new ItemStack(n.getCompoundTag("Item"));
        if(!s.isEmpty())into.add(new Entry(new BlockPos(n.getInteger("X"),n.getInteger("Y"),n.getInteger("Z")),s));
    }}
    private static NBTTagList writeEntries(List<Entry> entries){NBTTagList list=new NBTTagList();for(Entry e:entries){
        NBTTagCompound n=new NBTTagCompound();n.setInteger("X",e.pos.getX());n.setInteger("Y",e.pos.getY());n.setInteger("Z",e.pos.getZ());n.setTag("Item",e.item.writeToNBT(new NBTTagCompound()));list.appendTag(n);
    }return list;}
    @Override public void readFromNBT(NBTTagCompound n){pending.clear();quarantine.clear();ambiguous.clear();next=0;readEntries(n.getTagList("Pending",10),pending);readEntries(n.getTagList("Quarantine",10),quarantine);
        NBTTagList a=n.getTagList("AmbiguousTools",10);for(int i=0;i<a.tagCount();i++){NBTTagCompound e=a.getCompoundTagAt(i);ambiguous.add(new BlockPos(e.getInteger("X"),e.getInteger("Y"),e.getInteger("Z")));}}
    @Override public NBTTagCompound writeToNBT(NBTTagCompound n){n.setTag("Pending",writeEntries(pending));n.setTag("Quarantine",writeEntries(quarantine));
        NBTTagList a=new NBTTagList();for(BlockPos p:ambiguous){NBTTagCompound e=new NBTTagCompound();e.setInteger("X",p.getX());e.setInteger("Y",p.getY());e.setInteger("Z",p.getZ());a.appendTag(e);}n.setTag("AmbiguousTools",a);return n;}
}
