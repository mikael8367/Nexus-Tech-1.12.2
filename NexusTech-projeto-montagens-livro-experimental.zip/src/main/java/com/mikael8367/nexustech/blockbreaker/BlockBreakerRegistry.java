package com.mikael8367.nexustech.blockbreaker;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class BlockBreakerRegistry {
    public static final int GUI_ID=8372;
    public static final BlockBreakerBlock BLOCK=new BlockBreakerBlock();
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e) {
        e.getRegistry().register(BLOCK);
        GameRegistry.registerTileEntity(BlockBreakerTile.class, new ResourceLocation(NexusTech.MODID,"block_breaker"));
    }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> e) {
        e.getRegistry().register(new ItemBlock(BLOCK).setRegistryName(BLOCK.getRegistryName()));
    }
    private BlockBreakerRegistry() {}
}
