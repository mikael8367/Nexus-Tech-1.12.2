package com.mikael8367.nexustech.blockbreaker;

import java.util.UUID;
import java.nio.charset.StandardCharsets;
import com.mojang.authlib.GameProfile;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;
import net.minecraft.world.GameType;
import net.minecraft.world.WorldType;
import net.minecraft.network.EnumPacketDirection;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.Packet;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.ItemStackHandler;

/** Single-target automatic breaker, using a machine-specific synthetic player. */
public final class BlockBreakerTile extends TileEntity implements ITickable {
    static final int CAPACITY=10000, RECEIVE=200, COST=100;
    private int energy;
    private UUID owner;
    private String ownerName="";
    private boolean draining, mining, fault, ambiguousTool;
    private int delay;
    private MachinePlayer actor;
    private static final org.apache.logging.log4j.Logger LOG=org.apache.logging.log4j.LogManager.getLogger("NexusTech-BlockBreaker");
    final ItemStackHandler tool=new ItemStackHandler(1){
        @Override public int getSlotLimit(int slot){return 1;}
        @Override public boolean isItemValid(int slot,ItemStack s){return slot==0 && validTool(s);}
        @Override protected void onContentsChanged(int slot){markDirty();}
    };
    static boolean validTool(ItemStack s){return s!=null && !s.isEmpty() && s.getCount()==1 && s.isItemStackDamageable() && s.getItem().getToolClasses(s).contains("pickaxe");}
    boolean live(){return world!=null && !world.isRemote && !isInvalid() && !draining && world.isBlockLoaded(pos) && world.getTileEntity(pos)==this;}
    void setOwner(EntityPlayer player){if(live() && owner==null && player!=null){owner=player.getUniqueID();ownerName=player.getGameProfile().getName();markDirty();}}
    boolean authorized(EntityPlayer p){return live() && !mining && p!=null && p.world==world && owner!=null && owner.equals(p.getUniqueID()) && p.getDistanceSq(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5)<=64;}
    int energy(){return energy;}
    void clientEnergy(int value){if(world!=null && world.isRemote)energy=Math.max(0,Math.min(CAPACITY,value));}
    ItemStack drain(){
        if(draining)return ItemStack.EMPTY;
        draining=true;
        if(mining)return ItemStack.EMPTY; // the operation returns the actual post-harvest hand once
        ItemStack result=tool.getStackInSlot(0).copy();tool.setStackInSlot(0,ItemStack.EMPTY);return result;
    }
    private final IEnergyStorage power=new IEnergyStorage(){
        public int receiveEnergy(int amount,boolean simulate){if(!live() || mining || amount<=0)return 0; int n=Math.min(amount,Math.min(RECEIVE,CAPACITY-energy));if(!simulate && n>0){energy+=n;markDirty();}return n;}
        public int extractEnergy(int amount,boolean simulate){return 0;}
        public int getEnergyStored(){return energy;}
        public int getMaxEnergyStored(){return CAPACITY;}
        public boolean canExtract(){return false;}
        public boolean canReceive(){return live();}
    };
    @Override public boolean hasCapability(Capability<?> c,@Nullable EnumFacing side){return c==CapabilityEnergy.ENERGY || super.hasCapability(c,side);}
    @Override public <T> T getCapability(Capability<T> c,@Nullable EnumFacing side){return c==CapabilityEnergy.ENERGY ? CapabilityEnergy.ENERGY.cast(power) : super.getCapability(c,side);}

    static GameProfile machineProfile(UUID owner,int dimension,BlockPos machine){
        UUID raw=UUID.nameUUIDFromBytes(("nexustech:block_breaker:"+owner+":"+dimension+":"+machine.toLong()).getBytes(StandardCharsets.UTF_8));
        // Distinct version namespace from normal online and offline player UUIDs.
        UUID id=new UUID((raw.getMostSignificantBits() & ~0xf000L) | 0x8000L,raw.getLeastSignificantBits());
        if(id.equals(owner))id=new UUID(id.getMostSignificantBits(),id.getLeastSignificantBits()^1L);
        return new GameProfile(id,"NT"+id.toString().replace("-","").substring(0,14));
    }
    static final class MachinePlayer extends FakePlayer {
        MachinePlayer(WorldServer w,GameProfile profile){
            super(w,profile);
            new NetHandlerPlayServer(w.getMinecraftServer(),new NetworkManager(EnumPacketDirection.SERVERBOUND),this){
                @Override public void sendPacket(Packet<?> packet){}
            };
            interactionManager.setGameType(GameType.SURVIVAL);
        }
        @Override public Vec3d getPositionVector(){return new Vec3d(posX,posY,posZ);}
    }
    // EntityPlayerMP searches around world spawn. Do not allow construction to
    // load spawn chunks, and reject unknown providers and world types.
    static boolean safeFakeConstruction(WorldServer w){
        Class<?> p=w.provider.getClass();
        if(p!=net.minecraft.world.WorldProviderSurface.class && p!=net.minecraft.world.WorldProviderHell.class && p!=net.minecraft.world.WorldProviderEnd.class)return false;
        WorldType t=w.getWorldType();
        if(t!=WorldType.DEFAULT && t!=WorldType.FLAT && t!=WorldType.LARGE_BIOMES && t!=WorldType.AMPLIFIED && t!=WorldType.CUSTOMIZED && t!=WorldType.DEBUG_ALL_BLOCK_STATES && t!=WorldType.DEFAULT_1_1)return false;
        BlockPos spawn=w.provider.getSpawnPoint();
        if(!w.getWorldBorder().contains(spawn))return false;
        int fuzz=t.getSpawnFuzz(w,w.getMinecraftServer());
        if(fuzz<0 || fuzz>64)return false;
        int r=fuzz+16;
        return w.isAreaLoaded(new BlockPos(spawn.getX()-r,0,spawn.getZ()-r),new BlockPos(spawn.getX()+r,255,spawn.getZ()+r));
    }
    @Override public void update(){
        if(!live() || mining || fault || owner==null || !(world instanceof WorldServer))return;
        if(delay>0){delay--;return;} delay=19;
        if(energy<COST || !validTool(tool.getStackInSlot(0)))return;
        mining=true;
        try {
            IBlockState state=world.getBlockState(pos);
            if(!(state.getBlock() instanceof BlockBreakerBlock))return;
            BlockPos target=pos.offset(state.getValue(BlockBreakerBlock.FACING));
            if(!safeTarget(target,null))return;
            WorldServer serverWorld=(WorldServer)world;
            GameProfile profile=machineProfile(owner,world.provider.getDimension(),pos);
            if(serverWorld.getMinecraftServer().getPlayerList().getPlayerByUUID(profile.getId())!=null)return;
            if(actor==null || actor.world!=world || actor.dimension!=world.provider.getDimension() || !actor.getUniqueID().equals(profile.getId())){
                if(!safeFakeConstruction(serverWorld))return;
                actor=new MachinePlayer(serverWorld,profile);
            }
            actor.setPosition(target.getX()+.5,target.getY()+.5,target.getZ()+.5);
            if(actor.world!=world || actor.dimension!=world.provider.getDimension())return;
            harvestChecked(actor,target);
        } catch(RuntimeException failure){
            fail(failure);
        } finally {mining=false;}
    }

    private void fail(RuntimeException failure){
        fault=true; markDirty(); LOG.error("Block breaker at {} stopped after an uncertain failure",pos,failure);
    }
    void harvestChecked(FakePlayer player,BlockPos target){
        try {harvest(player,target);} catch(RuntimeException failure){fail(failure);}
    }

    static final int STATUS_ACTIVE=0, STATUS_FAULT=1, STATUS_AMBIGUOUS=2;
    int status(){return ambiguousTool ? STATUS_AMBIGUOUS : fault ? STATUS_FAULT : STATUS_ACTIVE;}
    void clientStatus(int value){if(world!=null && world.isRemote){fault=value!=STATUS_ACTIVE;ambiguousTool=value==STATUS_AMBIGUOUS;}}
    // Called only while mining is locked. The real hand and tile share the same stack.
    void harvest(FakePlayer player,BlockPos target){
        final ItemStack original=tool.getStackInSlot(0);
        player.inventory.currentItem=0;
        player.inventory.setInventorySlotContents(0,original);
        boolean result=false, completed=false, guardStarted=false, charged=false;
        try {
            // Even these checks invoke mod code and may replace the hand.
            if(!safeTarget(target,player) || !live())return;
            IBlockState expected=world.getBlockState(target);
            energy-=COST;charged=true;markDirty();
            if(!harvestStillSafe(target,expected,player)){completed=true;return;}
            BlockBreakerHarvestGuard.begin(player,this,target,expected);
            guardStarted=true;
            result=player.interactionManager.tryHarvestBlock(target);
            completed=true;
        } finally {
            if(guardStarted)BlockBreakerHarvestGuard.end(player);
            if(charged && completed && !result){energy=Math.min(CAPACITY,energy+COST);markDirty();}
            reconcileHand(player,original);
        }
    }
    private void reconcileHand(FakePlayer player,ItemStack original){
        ItemStack hand=player.inventory.getStackInSlot(0), current=tool.getStackInSlot(0);
        boolean originalInPlayer=false;
        for(int i=0;i<player.inventory.getSizeInventory();i++)
            if(player.inventory.getStackInSlot(i)==original && !original.isEmpty())originalInPlayer=true;
        boolean displaced=player.inventory.currentItem!=0 || (hand!=original && !(hand.isEmpty() && original.isEmpty()));
        boolean changedTile=current!=original && !(current.isEmpty() && original.isEmpty());
        if(displaced || changedTile){
            fault=true;ambiguousTool=true;markDirty();
            LOG.error("Block breaker at {} stopped: callback changed hand/tool; original {} in fake inventory. Inspect external inventories before manual recovery",pos,originalInPlayer ? "is" : "is not");
            BlockBreakerRecovery.get(world).noteAmbiguous(pos);
        }
        // The old tile reference alone does not establish ownership after a callback.
        java.util.IdentityHashMap<ItemStack,Boolean> seen=new java.util.IdentityHashMap<>();
        java.util.List<ItemStack> owned=new java.util.ArrayList<>();
        for(int i=0;i<player.inventory.getSizeInventory();i++){
            ItemStack s=player.inventory.getStackInSlot(i);
            player.inventory.setInventorySlotContents(i,ItemStack.EMPTY);
            if(!s.isEmpty() && seen.put(s,Boolean.TRUE)==null)owned.add(s);
        }
        tool.setStackInSlot(0,ItemStack.EMPTY);
        if(current!=original && !current.isEmpty() && seen.put(current,Boolean.TRUE)==null)owned.add(current);
        for(ItemStack s:owned){
            if(!draining && live() && tool.getStackInSlot(0).isEmpty() && validTool(s))tool.setStackInSlot(0,s);
            else BlockBreakerRecovery.get(world).enqueue(pos,s);
        }
        markDirty();
    }
    boolean safeTarget(BlockPos target,@Nullable EntityPlayer player){
        if(!live() || !world.isBlockLoaded(target) || !world.getWorldBorder().contains(target))return false;
        IBlockState state=world.getBlockState(target);
        if(state.getBlock().isAir(state,world,target) || state.getMaterial().isLiquid() || state.getBlockHardness(world,target)<0 || state.getBlock().hasTileEntity(state) || world.getTileEntity(target)!=null)return false;
        return player==null || (world.isBlockModifiable(player,target) && state.getBlock().canHarvestBlock(world,target,player));
    }
    boolean harvestStillSafe(BlockPos target,IBlockState expected,EntityPlayer player){
        if(!mining || !live())return false;
        IBlockState machine=world.getBlockState(pos);
        return machine.getBlock() instanceof BlockBreakerBlock && pos.offset(machine.getValue(BlockBreakerBlock.FACING)).equals(target)
            && safeTarget(target,player) && world.getBlockState(target).equals(expected) && player.getHeldItemMainhand()==tool.getStackInSlot(0) && validTool(player.getHeldItemMainhand());
    }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound n){
        super.writeToNBT(n);n.setInteger("Energy",energy);if(owner!=null)n.setUniqueId("Owner",owner);else {n.removeTag("OwnerMost");n.removeTag("OwnerLeast");}if(ownerName!=null && !ownerName.isEmpty())n.setString("OwnerName",ownerName);else n.removeTag("OwnerName");n.setBoolean("Fault",fault);n.setBoolean("AmbiguousTool",ambiguousTool);
        ItemStack stack=tool.getStackInSlot(0);if(!stack.isEmpty())n.setTag("Pick",stack.writeToNBT(new NBTTagCompound()));else n.removeTag("Pick");return n;
    }
    @Override public void readFromNBT(NBTTagCompound n){
        super.readFromNBT(n);energy=Math.max(0,Math.min(CAPACITY,n.getInteger("Energy")));owner=n.hasUniqueId("Owner")?n.getUniqueId("Owner"):null;ownerName=n.getString("OwnerName");ambiguousTool=n.getBoolean("AmbiguousTool");fault=n.getBoolean("Fault") || ambiguousTool;
        tool.setStackInSlot(0,ItemStack.EMPTY);
        // Preserve legacy or changed modded items for manual removal; validTool still gates mining.
        if(n.hasKey("Pick",10)){ItemStack stack=new ItemStack(n.getCompoundTag("Pick"));if(!stack.isEmpty())tool.setStackInSlot(0,stack);}
        draining=false;mining=false;delay=0;actor=null;
    }
}
