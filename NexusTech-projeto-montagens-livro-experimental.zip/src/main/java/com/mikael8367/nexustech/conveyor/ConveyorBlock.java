package com.mikael8367.nexustech.conveyor;

import com.mikael8367.nexustech.NexusTech;
import com.mikael8367.nexustech.crusher.CrusherBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

/** A belt is driven solely by the server's normal entity/block collision pass. */
public final class ConveyorBlock extends Block {
    public static final PropertyDirection FACING = BlockHorizontal.FACING;
    static final double HEIGHT = 2.0 / 16.0, SPEED = 0.12;
    private static final AxisAlignedBB BOX = new AxisAlignedBB(0, 0, 0, 1, HEIGHT, 1);

    ConveyorBlock() {
        super(Material.IRON);
        setRegistryName(NexusTech.MODID, "conveyor_belt");
        setUnlocalizedName(NexusTech.MODID + ".conveyor_belt");
        setCreativeTab(NexusTech.CREATIVE_TAB);
        setHardness(2.0F); setResistance(6.0F); setHarvestLevel("pickaxe", 0);
        fullBlock = false; setLightOpacity(0); useNeighborBrightness = true;
        setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
    }
    @Override public boolean isOpaqueCube(IBlockState state) { return false; }
    @Override public boolean isFullCube(IBlockState state) { return false; }
    @Override public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess world, BlockPos pos) { return BOX; }
    @Override protected BlockStateContainer createBlockState() { return new BlockStateContainer(this, FACING); }
    @Override public IBlockState getStateFromMeta(int meta) { return getDefaultState().withProperty(FACING, EnumFacing.getHorizontal(meta & 3)); }
    @Override public int getMetaFromState(IBlockState state) { return state.getValue(FACING).getHorizontalIndex(); }
    @Override public IBlockState getStateForPlacement(World world, BlockPos pos, EnumFacing face, float x, float y, float z, int meta, EntityLivingBase placer, EnumHand hand) {
        return getDefaultState().withProperty(FACING, placer.getHorizontalFacing());
    }

    static boolean accepts(boolean living, boolean item, boolean player, boolean sneaking,
                           boolean dead, boolean noClip, boolean riding, boolean hasPassengers) {
        return (living || item) && !(player && sneaking) && !dead && !noClip && !riding && !hasPassengers;
    }
    static boolean onSurface(AxisAlignedBB bb, BlockPos pos) {
        double centerX = (bb.minX + bb.maxX) * 0.5, centerZ = (bb.minZ + bb.maxZ) * 0.5;
        double feet = bb.minY - pos.getY();
        // One belt owns the center; prevents competing impulses at seams and wall-side contact.
        return centerX >= pos.getX() && centerX < pos.getX() + 1 && centerZ >= pos.getZ() && centerZ < pos.getZ() + 1
            && feet >= HEIGHT - 0.001 && feet <= HEIGHT + 0.001;
    }
    @Override public void onEntityCollidedWithBlock(World world, BlockPos pos, IBlockState state, Entity entity) {
        if (world.isRemote || !accepts(entity instanceof EntityLivingBase, entity instanceof EntityItem,
            entity instanceof EntityPlayer, entity.isSneaking(), entity.isDead, entity.noClip,
            entity.isRiding(), entity.isBeingRidden()) || !onSurface(entity.getEntityBoundingBox(), pos)) return;
        // onGround can be false during horizontal-only player moves even with feet
        // exactly on the surface. Height tolerance and vertical speed reject jumps.
        if (entity.motionY > 0.01) return;
        EnumFacing direction = state.getValue(FACING);
        AxisAlignedBB next = entity.getEntityBoundingBox().offset(direction.getFrontOffsetX() * SPEED, 0, direction.getFrontOffsetZ() * SPEED);
        // Do not drive a bounding box into an unloaded chunk or outside the world border.
        net.minecraft.world.border.WorldBorder border = world.getWorldBorder();
        if (next.minX < border.minX() || next.maxX > border.maxX()
            || next.minZ < border.minZ() || next.maxZ > border.maxZ()) return;
        int minX = net.minecraft.util.math.MathHelper.floor(next.minX + 0.001);
        int maxX = net.minecraft.util.math.MathHelper.floor(next.maxX - 0.001);
        int minZ = net.minecraft.util.math.MathHelper.floor(next.minZ + 0.001);
        int maxZ = net.minecraft.util.math.MathHelper.floor(next.maxZ - 0.001);
        for (int x = minX; x <= maxX; x++) for (int z = minZ; z <= maxZ; z++) {
            BlockPos target = new BlockPos(x, pos.getY(), z);
            if (!world.isBlockLoaded(target) || !world.getWorldBorder().contains(target)) return;
        }
        // Items have no automatic step height. Lift at the near edge of a same-level
        // crusher only, and only if both the vertical and raised forward paths are clear.
        BlockPos ahead = pos.offset(direction);
        AxisAlignedBB bb = entity.getEntityBoundingBox();
        double dx = direction.getFrontOffsetX() * SPEED, dz = direction.getFrontOffsetZ() * SPEED;
        double lift = CrusherBlock.BASE_HEIGHT - HEIGHT + 0.002;
        if (world.isBlockLoaded(ahead) && border.contains(ahead)
            && world.getBlockState(ahead).getBlock() instanceof CrusherBlock
            && next.maxX > ahead.getX() && next.minX < ahead.getX()+1
            && next.maxZ > ahead.getZ() && next.minZ < ahead.getZ()+1
            && world.getCollisionBoxes(entity, bb.expand(0, lift, 0)).isEmpty()
            && world.getCollisionBoxes(entity, bb.offset(0, lift, 0).expand(dx, 0, dz)).isEmpty()) {
            entity.motionY = Math.max(entity.motionY, 0.20);
        }
        entity.motionX = dx;
        entity.motionZ = dz;
        // EntityTrackerEntry sends a velocity packet to observers AND to a player itself.
        entity.velocityChanged = true;
    }
}
