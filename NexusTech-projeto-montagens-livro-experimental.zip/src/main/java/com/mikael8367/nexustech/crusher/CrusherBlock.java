package com.mikael8367.nexustech.crusher;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.*; import net.minecraft.block.material.Material; import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem; import net.minecraft.entity.player.EntityPlayer; import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity; import net.minecraft.util.*; import net.minecraft.util.math.BlockPos; import net.minecraft.util.math.AxisAlignedBB; import net.minecraft.world.World; import net.minecraft.world.IBlockAccess;
public final class CrusherBlock extends Block {
 public static final double BASE_HEIGHT=4.0/16.0;
 private static final AxisAlignedBB BASE=new AxisAlignedBB(0,0,0,1,BASE_HEIGHT,1);
 CrusherBlock(){super(Material.IRON); setRegistryName(NexusTech.MODID,"crusher_spikes");setUnlocalizedName(NexusTech.MODID+".crusher_spikes");setCreativeTab(NexusTech.CREATIVE_TAB);setHardness(4);setResistance(12);setHarvestLevel("pickaxe",1);fullBlock=false;setLightOpacity(0);useNeighborBrightness=true;}
 @Override public boolean isOpaqueCube(IBlockState state){return false;}
 @Override public boolean isFullCube(IBlockState state){return false;}
 @Override public AxisAlignedBB getBoundingBox(IBlockState state,IBlockAccess world,BlockPos pos){return BASE;}
 @Override public boolean hasTileEntity(IBlockState s){return true;}
 @Override public TileEntity createTileEntity(World w,IBlockState s){return new CrusherTile();}
 @Override public boolean onBlockActivated(World w,BlockPos p,IBlockState s,EntityPlayer pl,EnumHand h,EnumFacing side,float x,float y,float z){if(!w.isRemote && w.getTileEntity(p) instanceof CrusherTile && pl.getDistanceSq(p.getX()+.5,p.getY()+.5,p.getZ()+.5)<=64) pl.openGui(NexusTech.INSTANCE,CrusherRegistry.GUI_ID,w,p.getX(),p.getY(),p.getZ()); return true;}
 @Override public void breakBlock(World w,BlockPos p,IBlockState s){TileEntity t=w.getTileEntity(p); if(!w.isRemote && t instanceof CrusherTile) for(ItemStack item:((CrusherTile)t).drain()) if(!item.isEmpty())w.spawnEntity(new EntityItem(w,p.getX()+.5,p.getY()+.5,p.getZ()+.5,item)); super.breakBlock(w,p,s);}
}
