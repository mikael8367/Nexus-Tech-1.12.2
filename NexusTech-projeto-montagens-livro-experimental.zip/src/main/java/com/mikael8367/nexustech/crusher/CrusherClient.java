package com.mikael8367.nexustech.crusher;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation; import net.minecraft.entity.player.EntityPlayer; import net.minecraft.item.Item; import net.minecraft.tileentity.TileEntity; import net.minecraft.util.math.BlockPos; import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent; import net.minecraftforge.client.model.ModelLoader; import net.minecraftforge.fml.common.Mod; import net.minecraftforge.fml.common.eventhandler.SubscribeEvent; import net.minecraftforge.fml.relauncher.*;
@SideOnly(Side.CLIENT) @Mod.EventBusSubscriber(modid=NexusTech.MODID,value=Side.CLIENT)
public final class CrusherClient {
 @SubscribeEvent public static void models(ModelRegistryEvent e){Item b=Item.getItemFromBlock(CrusherRegistry.BLOCK);ModelLoader.setCustomModelResourceLocation(b,0,new ModelResourceLocation(b.getRegistryName(),"inventory"));for(Item item:CrusherRegistry.CARDS)ModelLoader.setCustomModelResourceLocation(item,0,new ModelResourceLocation(item.getRegistryName(),"inventory"));}
 public static Object gui(int id,EntityPlayer p,World w,int x,int y,int z){if(id!=CrusherRegistry.GUI_ID||p==null||w==null||!w.isRemote||p.world!=w)return null;BlockPos pos=new BlockPos(x,y,z);if(!w.isBlockLoaded(pos))return null;TileEntity t=w.getTileEntity(pos);if(!(t instanceof CrusherTile))return null;CrusherContainer c=new CrusherContainer(p.inventory,(CrusherTile)t);return c.canInteractWith(p)?new CrusherGui(p.inventory,(CrusherTile)t):null;}
 private CrusherClient(){}
}
