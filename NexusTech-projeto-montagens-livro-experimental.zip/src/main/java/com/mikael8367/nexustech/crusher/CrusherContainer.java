package com.mikael8367.nexustech.crusher;
import net.minecraft.entity.player.*; import net.minecraft.inventory.*; import net.minecraft.item.ItemStack; import net.minecraftforge.items.SlotItemHandler;
public final class CrusherContainer extends Container {
 final CrusherTile tile; private int lastEnergy=-1,lastEnabled=-1,lastPlayers=-1;
 public CrusherContainer(InventoryPlayer inv,CrusherTile t){tile=t;
  for(int i=0;i<4;i++){final int slot=i;addSlotToContainer(new SlotItemHandler(t.cards,i,35+i*27,30){
   @Override public boolean isItemValid(ItemStack s){return CrusherTile.valid(slot,s);}
   @Override public int getItemStackLimit(ItemStack s){return 10;}
   @Override public int getSlotStackLimit(){return 10;}
   @Override public void onSlotChanged(){super.onSlotChanged();tile.markDirty();}
   @Override public void putStack(ItemStack s){if(s.isEmpty() || (CrusherTile.valid(slot,s) && s.getCount()<=10)){super.putStack(s);}}
  });}
  for(int r=0;r<3;r++)for(int c=0;c<9;c++)addSlotToContainer(new Slot(inv,9+r*9+c,8+c*18,95+r*18));
  for(int c=0;c<9;c++)addSlotToContainer(new Slot(inv,c,8+c*18,153));
 }
 @Override public boolean canInteractWith(EntityPlayer p){return p!=null && tile.getWorld()!=null && p.world==tile.getWorld() && !tile.isInvalid() && tile.getWorld().isBlockLoaded(tile.getPos()) && tile.getWorld().getTileEntity(tile.getPos())==tile && p.getDistanceSq(tile.getPos().getX()+.5,tile.getPos().getY()+.5,tile.getPos().getZ()+.5)<=64;}
 @Override public boolean enchantItem(EntityPlayer p,int id){if(p.world.isRemote || p.openContainer!=this || !canInteractWith(p) || (id!=0 && id!=1))return false;tile.toggle(id);detectAndSendChanges();return true;}
 @Override public ItemStack slotClick(int id,int button,ClickType type,EntityPlayer p){if(!canInteractWith(p) || (!p.world.isRemote && p.openContainer!=this))return ItemStack.EMPTY; if(type!=ClickType.PICKUP && type!=ClickType.QUICK_MOVE && type!=ClickType.THROW)return ItemStack.EMPTY; if(id< -999 || id>=inventorySlots.size() || (id<0 && id!=-999))return ItemStack.EMPTY;return super.slotClick(id,button,type,p);}
 @Override public ItemStack transferStackInSlot(EntityPlayer p,int index){if(!canInteractWith(p)||index<0||index>=inventorySlots.size())return ItemStack.EMPTY;Slot slot=inventorySlots.get(index);if(!slot.getHasStack())return ItemStack.EMPTY;ItemStack stack=slot.getStack(),original=stack.copy();
  if(index<4){if(!mergeItemStack(stack,4,40,true))return ItemStack.EMPTY;if(stack.isEmpty())slot.putStack(ItemStack.EMPTY);else slot.onSlotChanged();}
  else {int target=-1;for(int i=0;i<4;i++)if(CrusherTile.valid(i,stack)){target=i;break;}if(target<0)return ItemStack.EMPTY;ItemStack rem=tile.cards.insertItem(target,stack,false);if(rem.getCount()==stack.getCount())return ItemStack.EMPTY;slot.putStack(rem);slot.onSlotChanged();}
  slot.onTake(p,stack);return original;
 }
 private void sync(IContainerListener l){l.sendWindowProperty(this,0,tile.energy());l.sendWindowProperty(this,1,tile.enabled()?1:0);l.sendWindowProperty(this,2,tile.players()?1:0);}
 @Override public void addListener(IContainerListener l){super.addListener(l);sync(l);}
 @Override public void detectAndSendChanges(){super.detectAndSendChanges();int a=tile.energy(),b=tile.enabled()?1:0,c=tile.players()?1:0;if(a!=lastEnergy||b!=lastEnabled||c!=lastPlayers){for(IContainerListener l:listeners)sync(l);lastEnergy=a;lastEnabled=b;lastPlayers=c;}}
 @Override public void updateProgressBar(int id,int v){if(id>=0&&id<=2)tile.clientField(id,v&65535);}
}
