package com.mikael8367.nexustech.crusher;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LootingLevelEvent;
import net.minecraftforge.fml.common.Mod; import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import com.mikael8367.nexustech.NexusTech;
@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class CrusherDamage extends DamageSource {
 final int loot;
 CrusherDamage(int l,boolean fire){super("nexustech_crusher"); loot=Math.max(0,Math.min(5,l));if(fire)setFireDamage();}
 @SubscribeEvent public static void looting(LootingLevelEvent e){if(e.getDamageSource() instanceof CrusherDamage)e.setLootingLevel(((CrusherDamage)e.getDamageSource()).loot);}
}
