package com.mikael8367.nexustech.crusher;
import java.io.IOException; import net.minecraft.client.gui.GuiButton; import net.minecraft.client.gui.inventory.GuiContainer; import net.minecraft.client.resources.I18n; import net.minecraft.entity.player.InventoryPlayer; import net.minecraft.util.ResourceLocation; import net.minecraftforge.fml.relauncher.*;
@SideOnly(Side.CLIENT)
public final class CrusherGui extends GuiContainer {
 private final CrusherTile tile;
 CrusherGui(InventoryPlayer inv,CrusherTile t){super(new CrusherContainer(inv,t));tile=t;xSize=176;ySize=177;}
 @Override public void initGui(){super.initGui();buttonList.clear();buttonList.add(new GuiButton(0,guiLeft+8,guiTop+55,75,20,""));buttonList.add(new GuiButton(1,guiLeft+90,guiTop+55,78,20,""));}
 @Override protected void actionPerformed(GuiButton b)throws IOException{if((b.id==0||b.id==1)&&mc.playerController!=null)mc.playerController.sendEnchantPacket(inventorySlots.windowId,b.id);}
 @Override protected void drawGuiContainerForegroundLayer(int mx,int my){fontRenderer.drawString(I18n.format("gui.nexustech.crusher.title"),8,6,4210752);fontRenderer.drawString("FE: "+tile.energy()+" / 10000",8,79,4210752); String[] names={"D","L","F","E"};for(int i=0;i<4;i++)fontRenderer.drawString(names[i],40+i*27,20,4210752);}
 @Override protected void drawGuiContainerBackgroundLayer(float pt,int mx,int my){mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/container/generic_54.png"));net.minecraft.client.renderer.GlStateManager.color(1.0F,1.0F,1.0F,1.0F);drawTexturedModalRect(guiLeft,guiTop,0,0,176,90);drawRect(guiLeft+7,guiTop+17,guiLeft+169,guiTop+90,0xffc6c6c6);net.minecraft.client.renderer.GlStateManager.color(1.0F,1.0F,1.0F,1.0F);drawTexturedModalRect(guiLeft,guiTop+90,0,135,176,87);for(int i=0;i<4;i++)drawTexturedModalRect(guiLeft+34+i*27,guiTop+29,7,17,18,18);buttonList.get(0).displayString=I18n.format(tile.enabled()?"gui.nexustech.crusher.on":"gui.nexustech.crusher.off");buttonList.get(1).displayString=I18n.format(tile.players()?"gui.nexustech.crusher.players_on":"gui.nexustech.crusher.players_off");}
 @Override public void drawScreen(int x,int y,float pt){drawDefaultBackground();super.drawScreen(x,y,pt);renderHoveredToolTip(x,y);}
}
