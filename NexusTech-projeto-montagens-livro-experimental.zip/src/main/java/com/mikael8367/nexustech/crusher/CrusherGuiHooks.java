package com.mikael8367.nexustech.crusher;
import net.minecraft.entity.player.EntityPlayer; import net.minecraft.tileentity.TileEntity; import net.minecraft.util.math.BlockPos; import net.minecraft.world.World;
public final class CrusherGuiHooks {
 public static Object server(int id,EntityPlayer p,World w,int x,int y,int z){if(id!=CrusherRegistry.GUI_ID||p==null||w==null||w.isRemote||p.world!=w)return null;BlockPos pos=new BlockPos(x,y,z);if(!w.isBlockLoaded(pos))return null;TileEntity t=w.getTileEntity(pos);if(!(t instanceof CrusherTile))return null;CrusherContainer c=new CrusherContainer(p.inventory,(CrusherTile)t);return c.canInteractWith(p)?c:null;}
 private CrusherGuiHooks(){}
}
