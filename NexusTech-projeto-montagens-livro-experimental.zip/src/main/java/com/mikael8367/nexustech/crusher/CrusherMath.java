package com.mikael8367.nexustech.crusher;
/** Pure bounded balancing functions. */
public final class CrusherMath {
 public static int level(int n){return Math.max(0,Math.min(10,n));}
 public static int cost(int efficiency){return Math.max(2,20-level(efficiency)*2);}
 public static float damage(int level){return 2.0f+level(level);}
 public static int looting(int level){return (level(level)+1)/2;}
 private CrusherMath(){}
}
