package com.mikael8367.nexustech.crusher;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.*;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class CrusherRegistry {
 public static final int GUI_ID=8370;
 public static final CrusherBlock BLOCK=new CrusherBlock();
 public static final Item[] CARDS=new Item[4];
 static { String[] names={"damage","loot","fire","efficiency"}; for(int i=0;i<4;i++) CARDS[i]=new Item().setRegistryName(NexusTech.MODID,"crusher_card_"+names[i]).setUnlocalizedName(NexusTech.MODID+".crusher_card_"+names[i]).setCreativeTab(NexusTech.CREATIVE_TAB); }
 @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e){e.getRegistry().register(BLOCK); GameRegistry.registerTileEntity(CrusherTile.class,new ResourceLocation(NexusTech.MODID,"crusher_spikes"));}
 @SubscribeEvent public static void items(RegistryEvent.Register<Item> e){e.getRegistry().register(new ItemBlock(BLOCK).setRegistryName(BLOCK.getRegistryName())); for(Item i:CARDS)e.getRegistry().register(i);}
 private CrusherRegistry(){}
}
