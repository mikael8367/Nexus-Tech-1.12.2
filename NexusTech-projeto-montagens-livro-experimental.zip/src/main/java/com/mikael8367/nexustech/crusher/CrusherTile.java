package com.mikael8367.nexustech.crusher;
import java.util.*; import javax.annotation.Nullable;
import net.minecraft.entity.EntityLivingBase; import net.minecraft.entity.player.EntityPlayer; import net.minecraft.item.ItemStack; import net.minecraft.nbt.NBTTagCompound; import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity; import net.minecraft.util.*; import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.common.capabilities.Capability; import net.minecraftforge.energy.*; import net.minecraftforge.items.*;
public final class CrusherTile extends TileEntity implements ITickable {
 static final int CAPACITY=10000, RECEIVE=500, INTERVAL=20, MAX_TARGETS=8;
 private int energy; private boolean enabled=true, players=false, draining=false;
 // Ephemeral cursor prevents a stable crowd from monopolizing the eight attempts.
 private int targetCursor;
 private boolean updating; // Prevent attack callbacks from reentering the batch.
 final ItemStackHandler cards=new ItemStackHandler(4){
  @Override public int getSlotLimit(int s){return 10;}
  @Override public boolean isItemValid(int s,ItemStack item){return valid(s,item);}
  @Override protected void onContentsChanged(int s){markDirty();}
 };
 static boolean valid(int s,ItemStack i){return s>=0 && s<4 && !i.isEmpty() && i.getItem()==CrusherRegistry.CARDS[s] && !i.hasTagCompound();}
 boolean live(){return world!=null && !world.isRemote && !isInvalid() && world.isBlockLoaded(pos) && world.getTileEntity(pos)==this && !draining;}
 private final IEnergyStorage power=new IEnergyStorage(){
  public int receiveEnergy(int n,boolean sim){if(!live()||n<=0)return 0; int v=Math.min(n,Math.min(RECEIVE,CAPACITY-energy)); if(!sim && v>0){energy+=v;markDirty();}return v;}
  public int extractEnergy(int n,boolean sim){return 0;} public int getEnergyStored(){return energy;} public int getMaxEnergyStored(){return CAPACITY;} public boolean canExtract(){return false;} public boolean canReceive(){return true;}
 };
 @Override public boolean hasCapability(Capability<?> c,@Nullable EnumFacing f){return c==CapabilityEnergy.ENERGY || super.hasCapability(c,f);}
 @Override public <T> T getCapability(Capability<T> c,@Nullable EnumFacing f){if(c==CapabilityEnergy.ENERGY)return CapabilityEnergy.ENERGY.cast(power);return super.getCapability(c,f);}
 int level(int i){ItemStack s=cards.getStackInSlot(i);return valid(i,s)?CrusherMath.level(s.getCount()):0;}
 int energy(){return energy;} boolean enabled(){return enabled;} boolean players(){return players;}
 void clientField(int id,int value){if(world==null || !world.isRemote)return; if(id==0)energy=Math.max(0,Math.min(CAPACITY,value));else if(id==1)enabled=value!=0;else if(id==2)players=value!=0;}
 void toggle(int id){if(!live())return; if(id==0)enabled=!enabled;else if(id==1)players=!players;else return;markDirty();}
 List<ItemStack> drain(){List<ItemStack> out=new ArrayList<>();if(draining)return out; draining=true; for(int i=0;i<4;i++){ItemStack s=cards.getStackInSlot(i).copy();cards.setStackInSlot(i,ItemStack.EMPTY); if(!s.isEmpty())out.add(s);}return out;}
 static AxisAlignedBB attackRange(net.minecraft.util.math.BlockPos p){return new AxisAlignedBB(p.getX(),p.getY()+CrusherBlock.BASE_HEIGHT,p.getZ(),p.getX()+1,p.getY()+1,p.getZ()+1);}
 static boolean inAttackRange(AxisAlignedBB bb,net.minecraft.util.math.BlockPos p){
  // Contact is determined by the entity's actual hitbox, not its center: a
  // wide mob or player can overlap the spikes while centered outside the block.
  // Keep the feet-height guard so mobs merely standing beside the base stay safe.
  return bb.minY>=p.getY()+CrusherBlock.BASE_HEIGHT-0.001 && bb.intersects(attackRange(p));
 }
 @Override public void update(){if(updating||!live() || !enabled || world.getTotalWorldTime()%INTERVAL!=Math.floorMod(pos.hashCode(),INTERVAL))return; updating=true;try {int cost=CrusherMath.cost(level(3)); if(energy<cost)return;
  AxisAlignedBB range=attackRange(pos);
  List<EntityLivingBase> targets=world.getEntitiesWithinAABB(EntityLivingBase.class,range);
  int attempts=0, size=targets.size(); if(size==0){targetCursor=0;return;} int index=targetCursor%size;
  for(int scanned=0;scanned<size;scanned++){if(attempts>=MAX_TARGETS || energy<cost || !live() || !enabled)break; EntityLivingBase e=targets.get(index);index=(index+1)%size; if(e.isDead || e.getHealth()<=0 || (e instanceof EntityPlayer && !players) || !inAttackRange(e.getEntityBoundingBox(),pos))continue; attempts++;targetCursor=index; energy-=cost;markDirty(); if(!live()||!enabled)return; int fire=level(2); CrusherDamage source=new CrusherDamage(CrusherMath.looting(level(1)),fire>0); boolean accepted=e.attackEntityFrom(source,CrusherMath.damage(level(0))+(fire>0 ? fire*0.25f : 0)); if(!accepted && live()){energy=Math.min(CAPACITY,energy+cost);markDirty();} }
 } finally {updating=false;}
 }
 @Override public NBTTagCompound writeToNBT(NBTTagCompound n){super.writeToNBT(n);n.setInteger("Energy",energy);n.setBoolean("Enabled",enabled);n.setBoolean("Players",players);n.setTag("Cards",cards.serializeNBT());return n;}
 @Override public void readFromNBT(NBTTagCompound n){super.readFromNBT(n);energy=Math.max(0,Math.min(CAPACITY,n.getInteger("Energy"))); enabled=!n.hasKey("Enabled")||n.getBoolean("Enabled"); players=n.hasKey("Players")&&n.getBoolean("Players");for(int i=0;i<4;i++)cards.setStackInSlot(i,ItemStack.EMPTY); if(n.hasKey("Cards",10)){NBTTagList list=n.getCompoundTag("Cards").getTagList("Items",10);boolean[] seen=new boolean[4];for(int j=0;j<Math.min(list.tagCount(),16);j++){NBTTagCompound item=list.getCompoundTagAt(j);int slot=item.getInteger("Slot");if(slot<0||slot>=4||seen[slot])continue;seen[slot]=true;ItemStack s=new ItemStack(item);if(valid(slot,s)&&s.getCount()<=10)cards.setStackInSlot(slot,s);}} draining=false;}
}
