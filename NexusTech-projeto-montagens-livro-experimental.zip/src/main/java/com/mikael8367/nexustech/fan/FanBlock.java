package com.mikael8367.nexustech.fan;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.*; import net.minecraft.block.material.Material; import net.minecraft.block.properties.PropertyDirection; import net.minecraft.block.state.*; import net.minecraft.entity.EntityLivingBase; import net.minecraft.entity.player.EntityPlayer; import net.minecraft.tileentity.TileEntity; import net.minecraft.util.*; import net.minecraft.util.math.BlockPos; import net.minecraft.world.World;
public final class FanBlock extends Block {
 public static final PropertyDirection FACING=BlockHorizontal.FACING;
 FanBlock(){super(Material.IRON);setRegistryName(NexusTech.MODID,"fan");setUnlocalizedName(NexusTech.MODID+".fan");setCreativeTab(NexusTech.CREATIVE_TAB);setHardness(3);setResistance(10);setHarvestLevel("pickaxe",1);setDefaultState(blockState.getBaseState().withProperty(FACING,EnumFacing.NORTH));}
 @Override protected BlockStateContainer createBlockState(){return new BlockStateContainer(this,FACING);}
 @Override public IBlockState getStateFromMeta(int m){return getDefaultState().withProperty(FACING,EnumFacing.getHorizontal(m&3));}
 @Override public int getMetaFromState(IBlockState s){return s.getValue(FACING).getHorizontalIndex();}
 @Override public IBlockState getStateForPlacement(World w,BlockPos p,EnumFacing f,float x,float y,float z,int m,EntityLivingBase e,EnumHand h){return getDefaultState().withProperty(FACING,e.getHorizontalFacing());}
 @Override public boolean hasTileEntity(IBlockState s){return true;}
 @Override public TileEntity createTileEntity(World w,IBlockState s){return new FanTile();}
 @Override public boolean onBlockActivated(World w,BlockPos p,IBlockState s,EntityPlayer pl,EnumHand h,EnumFacing side,float x,float y,float z){if(!w.isRemote && w.getTileEntity(p) instanceof FanTile && pl.getDistanceSq(p.getX()+.5,p.getY()+.5,p.getZ()+.5)<=64)pl.openGui(NexusTech.INSTANCE,FanRegistry.GUI_ID,w,p.getX(),p.getY(),p.getZ());return true;}
}
