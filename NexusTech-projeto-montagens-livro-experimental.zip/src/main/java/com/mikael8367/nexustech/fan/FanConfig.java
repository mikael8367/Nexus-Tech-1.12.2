package com.mikael8367.nexustech.fan;
import com.mikael8367.nexustech.NexusTech; import net.minecraftforge.common.config.Config;
@Config(modid=NexusTech.MODID,name="nexustech-fan") public final class FanConfig {
 @Config.Comment("Base FE per active tick; level upgrades add 25% each. Clamped at runtime.") @Config.RangeInt(min=1,max=1000) public static int baseCost=20;
 private FanConfig(){}
}
