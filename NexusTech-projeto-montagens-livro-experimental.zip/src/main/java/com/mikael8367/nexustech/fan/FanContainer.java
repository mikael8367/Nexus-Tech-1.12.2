package com.mikael8367.nexustech.fan;
import net.minecraft.entity.player.*; import net.minecraft.inventory.*;
public final class FanContainer extends Container {
 final FanTile tile;private final int[] last={-1,-1,-1,-1};
 public FanContainer(InventoryPlayer inv,FanTile t){tile=t;for(int r=0;r<3;r++)for(int c=0;c<9;c++)addSlotToContainer(new Slot(inv,9+r*9+c,8+c*18,91+r*18));for(int c=0;c<9;c++)addSlotToContainer(new Slot(inv,c,8+c*18,149));}
 @Override public boolean canInteractWith(EntityPlayer p){return p!=null&&tile.getWorld()!=null&&p.world==tile.getWorld()&&!tile.isInvalid()&&tile.getWorld().isBlockLoaded(tile.getPos())&&tile.getWorld().getTileEntity(tile.getPos())==tile&&p.getDistanceSq(tile.getPos().getX()+.5,tile.getPos().getY()+.5,tile.getPos().getZ()+.5)<=64;}
 @Override public boolean enchantItem(EntityPlayer p,int id){if(p.world.isRemote||p.openContainer!=this||!canInteractWith(p)||id<0||id>2)return false;tile.adjust(id);detectAndSendChanges();return true;}
 @Override public net.minecraft.item.ItemStack slotClick(int id,int button,ClickType type,EntityPlayer p){if(!canInteractWith(p)||(!p.world.isRemote&&p.openContainer!=this)||id< -999||id>=inventorySlots.size()||(id<0&&id!=-999))return net.minecraft.item.ItemStack.EMPTY;return super.slotClick(id,button,type,p);}
 private void sync(IContainerListener l){for(int i=0;i<4;i++)l.sendWindowProperty(this,i,tile.field(i));}
 @Override public void addListener(IContainerListener l){super.addListener(l);sync(l);}
 @Override public void detectAndSendChanges(){super.detectAndSendChanges();boolean changed=false;for(int i=0;i<4;i++){int v=tile.field(i);if(last[i]!=v){last[i]=v;changed=true;}}if(changed)for(IContainerListener l:listeners)sync(l);}
 @Override public void updateProgressBar(int id,int v){if(id>=0&&id<4)tile.clientField(id,v&65535);}
}
