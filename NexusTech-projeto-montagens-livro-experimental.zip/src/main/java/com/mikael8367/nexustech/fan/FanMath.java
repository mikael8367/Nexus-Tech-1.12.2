package com.mikael8367.nexustech.fan;
final class FanMath {
 static int clamp(int n,int lo,int hi){return Math.max(lo,Math.min(hi,n));}
 static int cost(int base,int speed,int range){return clamp(base,1,1000)*(4+clamp(speed,0,2)+clamp(range,0,3))/4;}
 static int distance(int range){return 2+2*clamp(range,0,3);}
 static double speed(int level){return .12+.08*clamp(level,0,2);}
 private FanMath(){}
}
