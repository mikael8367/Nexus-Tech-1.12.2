package com.mikael8367.nexustech.fan;
import com.mikael8367.nexustech.NexusTech; import net.minecraft.block.Block; import net.minecraft.item.*; import net.minecraft.util.ResourceLocation; import net.minecraftforge.event.RegistryEvent; import net.minecraftforge.fml.common.Mod; import net.minecraftforge.fml.common.eventhandler.SubscribeEvent; import net.minecraftforge.fml.common.registry.GameRegistry;
@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class FanRegistry {
 public static final int GUI_ID=8371; public static final FanBlock BLOCK=new FanBlock();
 @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e){e.getRegistry().register(BLOCK);GameRegistry.registerTileEntity(FanTile.class,new ResourceLocation(NexusTech.MODID,"fan"));}
 @SubscribeEvent public static void items(RegistryEvent.Register<Item> e){e.getRegistry().register(new ItemBlock(BLOCK).setRegistryName(BLOCK.getRegistryName()));}
 private FanRegistry(){}
}
