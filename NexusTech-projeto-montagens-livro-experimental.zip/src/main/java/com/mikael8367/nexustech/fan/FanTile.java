package com.mikael8367.nexustech.fan;
import java.util.List; import javax.annotation.Nullable;
import net.minecraft.entity.*; import net.minecraft.entity.item.EntityItem; import net.minecraft.nbt.NBTTagCompound; import net.minecraft.tileentity.TileEntity; import net.minecraft.util.*; import net.minecraft.util.math.*; import net.minecraftforge.common.capabilities.Capability; import net.minecraftforge.energy.*;
public final class FanTile extends TileEntity implements ITickable {
 static final int CAPACITY=10000, RECEIVE=500, MAX_TARGETS=16; private int energy,speedLevel,rangeLevel; private boolean enabled=true;
 // Not persisted: used only to rotate the bounded batch across a stable crowd.
 private int targetCursor;
 // External world/entity callbacks may reenter update; never run overlapping batches.
 private boolean updating;
 boolean live(){return world!=null&&!world.isRemote&&!isInvalid()&&world.isBlockLoaded(pos)&&world.getTileEntity(pos)==this;}
 private final IEnergyStorage power=new IEnergyStorage(){public int receiveEnergy(int n,boolean sim){if(!live()||n<=0)return 0;int v=Math.min(n,Math.min(RECEIVE,CAPACITY-energy));if(!sim&&v>0){energy+=v;markDirty();}return v;} public int extractEnergy(int n,boolean sim){return 0;} public int getEnergyStored(){return energy;} public int getMaxEnergyStored(){return CAPACITY;} public boolean canExtract(){return false;} public boolean canReceive(){return true;}};
 @Override public boolean hasCapability(Capability<?> c,@Nullable EnumFacing f){return c==CapabilityEnergy.ENERGY||super.hasCapability(c,f);}
 @Override public <T>T getCapability(Capability<T> c,@Nullable EnumFacing f){return c==CapabilityEnergy.ENERGY?CapabilityEnergy.ENERGY.cast(power):super.getCapability(c,f);}
 int field(int i){switch(i){case 0:return energy;case 1:return enabled?1:0;case 2:return speedLevel;case 3:return rangeLevel;default:return 0;}}
 void clientField(int i,int v){if(world==null||!world.isRemote)return;switch(i){case 0:energy=FanMath.clamp(v,0,CAPACITY);break;case 1:enabled=v!=0;break;case 2:speedLevel=FanMath.clamp(v,0,2);break;case 3:rangeLevel=FanMath.clamp(v,0,3);}}
 void adjust(int id){if(!live())return;switch(id){case 0:enabled=!enabled;break;case 1:speedLevel=(speedLevel+1)%3;break;case 2:rangeLevel=(rangeLevel+1)%4;break;default:return;}markDirty();}
 @Override public void update(){if(updating||!live()||!enabled)return; updating=true;try {int cost=FanMath.cost(FanConfig.baseCost,speedLevel,rangeLevel);if(energy<cost)return;
  final int initialSpeed=speedLevel,initialRange=rangeLevel;
  net.minecraft.block.state.IBlockState state=world.getBlockState(pos);if(state.getBlock()!=FanRegistry.BLOCK)return;EnumFacing f=state.getValue(FanBlock.FACING);int dx=f.getFrontOffsetX(),dz=f.getFrontOffsetZ(),range=FanMath.distance(rangeLevel);
  // Stop before unloaded chunks: this machine never loads terrain to push entities.
  int clear=0;for(int i=1;i<=range;i++){BlockPos q=pos.offset(f,i);if(!world.isBlockLoaded(q)||!world.getWorldBorder().contains(q))break;
   // A full cube closes the whole air corridor, including when an entity's centre is inside it.
   if(world.getBlockState(q).isFullCube())break;clear++;}if(clear==0)return;
  final AxisAlignedBB box=new AxisAlignedBB(pos.offset(f)).expand(dx*(clear-1),0,dz*(clear-1));
  // Count eligible entities while limiting allocations and ray traces to a rotating batch.
  // Forge still scans the chunk's entity lists; this does not bound that scan itself.
  final int start=targetCursor;final int[] eligible={0};
  List<Entity> targets=world.getEntitiesWithinAABB(Entity.class,box,new com.google.common.base.Predicate<Entity>(){
   private int accepted;
   @Override public boolean apply(@Nullable Entity e){if(e==null||(!(e instanceof EntityLivingBase)&&!(e instanceof EntityItem))||e.isDead||e.noClip||e.isRiding()||e.isBeingRidden()||e.posX<box.minX||e.posX>=box.maxX||e.posZ<box.minZ||e.posZ>=box.maxZ)return false;int index=eligible[0]++;if(index<start||accepted>=MAX_TARGETS)return false;accepted++;return true;}
  });
  if(eligible[0]==0||start>=eligible[0]||start+targets.size()>=eligible[0])targetCursor=0;else targetCursor=start+targets.size();
  boolean paid=false;int inspected=0;
  Vec3d origin=new Vec3d(pos.getX()+.5+dx*.501,pos.getY()+.5,pos.getZ()+.5+dz*.501);
  for(Entity e:targets){if(inspected++>=MAX_TARGETS)break;if(!(e instanceof EntityLivingBase)&&!(e instanceof EntityItem))continue;if(e.isDead||e.noClip||e.isRiding()||e.isBeingRidden())continue;
   if(e.posX<box.minX||e.posX>=box.maxX||e.posZ<box.minZ||e.posZ>=box.maxZ)continue;
   double targetY=Math.max(pos.getY()+.01,Math.min(pos.getY()+.99,(e.getEntityBoundingBox().minY+e.getEntityBoundingBox().maxY)*.5));Vec3d dest=new Vec3d(e.posX,targetY,e.posZ);if(!world.isBlockLoaded(new BlockPos(dest))||world.rayTraceBlocks(origin,dest,false,true,false)!=null)continue;
  // A block/ray/entity callback can remove, rotate or reconfigure this tile.
  if(!live()||!enabled||speedLevel!=initialSpeed||rangeLevel!=initialRange||world.getBlockState(pos)!=state)return;
  double v=FanMath.speed(initialSpeed),current=dx!=0?e.motionX*dx:e.motionZ*dz;if(current>=v)continue;
  if(!paid){if(energy<cost)return;energy-=cost;markDirty();paid=true;}
  if(!live()||!enabled||speedLevel!=initialSpeed||rangeLevel!=initialRange||world.getBlockState(pos)!=state)return;
  if(dx!=0)e.motionX=dx*v;else e.motionZ=dz*v;e.velocityChanged=true;
 }
 } finally {updating=false;}
 }
 @Override public NBTTagCompound writeToNBT(NBTTagCompound n){super.writeToNBT(n);n.setInteger("Energy",energy);n.setBoolean("Enabled",enabled);n.setInteger("Speed",speedLevel);n.setInteger("Range",rangeLevel);return n;}
 @Override public void readFromNBT(NBTTagCompound n){super.readFromNBT(n);energy=FanMath.clamp(n.getInteger("Energy"),0,CAPACITY);enabled=!n.hasKey("Enabled")||n.getBoolean("Enabled");speedLevel=FanMath.clamp(n.getInteger("Speed"),0,2);rangeLevel=FanMath.clamp(n.getInteger("Range"),0,3);}
}
