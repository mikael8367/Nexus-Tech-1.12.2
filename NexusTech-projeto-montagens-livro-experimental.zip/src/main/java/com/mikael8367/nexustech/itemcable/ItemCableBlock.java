package com.mikael8367.nexustech.itemcable;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.items.CapabilityItemHandler;

public final class ItemCableBlock extends Block {
 static final PropertyBool DOWN=PropertyBool.create("down"), UP=PropertyBool.create("up"), NORTH=PropertyBool.create("north"), SOUTH=PropertyBool.create("south"), WEST=PropertyBool.create("west"), EAST=PropertyBool.create("east");
 static final PropertyBool[] SIDES={DOWN,UP,NORTH,SOUTH,WEST,EAST};
 private static final AxisAlignedBB BOX=new AxisAlignedBB(0.375,0.375,0.375,0.625,0.625,0.625);
 final boolean extractor;
 ItemCableBlock(boolean extractor){super(Material.IRON);this.extractor=extractor;String id=extractor?"item_extractor_cable":"item_cable";setRegistryName(NexusTech.MODID,id);setUnlocalizedName(NexusTech.MODID+"."+id);setCreativeTab(NexusTech.CREATIVE_TAB);setHardness(2);setResistance(6);setHarvestLevel("pickaxe",0);setLightOpacity(0);IBlockState s=blockState.getBaseState();for(PropertyBool p:SIDES)s=s.withProperty(p,false);setDefaultState(s);}
 @Override protected BlockStateContainer createBlockState(){return new BlockStateContainer(this,DOWN,UP,NORTH,SOUTH,WEST,EAST);}
 @Override public int getMetaFromState(IBlockState state){return 0;}
 @Override public IBlockState getStateFromMeta(int meta){return getDefaultState();}
 @Override public boolean isOpaqueCube(IBlockState s){return false;}
 @Override public boolean isFullCube(IBlockState s){return false;}
 @Override public AxisAlignedBB getBoundingBox(IBlockState s,IBlockAccess w,BlockPos p){return BOX;}
 @Override public boolean hasTileEntity(IBlockState state){return true;}
 @Override public TileEntity createTileEntity(World w,IBlockState s){return new ItemCableTile();}
 @Override public void breakBlock(World w,BlockPos p,IBlockState s){
  if(!w.isRemote){TileEntity te=w.getTileEntity(p);if(te instanceof ItemCableTile){ItemCableTile t=(ItemCableTile)te;if(!t.held.isEmpty()){ItemCableRecovery.get(w).add(p,t.held,t.fault);t.held=net.minecraft.item.ItemStack.EMPTY;t.markDirty();}}}
  super.breakBlock(w,p,s);
 }
 @Override public IBlockState getActualState(IBlockState state,IBlockAccess w,BlockPos p){for(EnumFacing side:EnumFacing.VALUES)state=state.withProperty(SIDES[side.ordinal()],connected(w,p,side));return state;}
 static TileEntity peek(IBlockAccess w,BlockPos p){
  if(w instanceof World && !((World)w).isBlockLoaded(p))return null;
  if(w instanceof ChunkCache)return ((ChunkCache)w).getTileEntity(p,Chunk.EnumCreateEntityType.CHECK);
  if(!(w instanceof World) && !w.getClass().getName().equals("net.optifine.override.ChunkCacheOF"))return null;
  return w.getTileEntity(p);
 }
 static boolean connected(IBlockAccess w,BlockPos p,EnumFacing f){try{
  TileEntity self=peek(w,p);if(!(self instanceof ItemCableTile)||((ItemCableTile)self).blocked(f))return false;
  TileEntity other=peek(w,p.offset(f));if(other==null||other.isInvalid())return false;
  if(other instanceof ItemCableTile)return w.getBlockState(p.offset(f)).getBlock() instanceof ItemCableBlock&&!((ItemCableTile)other).blocked(f.getOpposite());
  World world=other.getWorld();
  return world!=null&&world.isBlockLoaded(p.offset(f))&&world.getTileEntity(p.offset(f))==other
    &&ItemCableNetwork.acceptedEndpoint(world,p.offset(f),f.getOpposite());
 }catch(RuntimeException ex){return false;}}
}
