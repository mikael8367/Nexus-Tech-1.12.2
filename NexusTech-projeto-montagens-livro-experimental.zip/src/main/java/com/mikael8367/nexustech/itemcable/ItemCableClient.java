package com.mikael8367.nexustech.itemcable;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid=NexusTech.MODID,value=Side.CLIENT)
public final class ItemCableClient {
 @SubscribeEvent public static void models(ModelRegistryEvent e){for(ItemCableBlock b:new ItemCableBlock[]{ItemCableRegistry.CABLE,ItemCableRegistry.EXTRACTOR}){Item i=Item.getItemFromBlock(b);ModelLoader.setCustomModelResourceLocation(i,0,new ModelResourceLocation(i.getRegistryName(),"inventory"));}}
 private ItemCableClient(){}
}
