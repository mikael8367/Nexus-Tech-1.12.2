package com.mikael8367.nexustech.itemcable;

import java.util.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.items.wrapper.InvWrapper;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

/** No FE integration. All access and transport occur on the logical server. */
public final class ItemCableNetwork {
 private static final int MAX_CABLES=128, PER_TICK=4;
 private static final Map<World,Budget> BUDGETS=new WeakHashMap<>();
 private static boolean busy;
 // Positions, not tile references: a weak world key must not be retained by its value.
 private static class Budget{long time=Long.MIN_VALUE;int used;final LinkedHashMap<BlockPos,Long> waiting=new LinkedHashMap<>();}
 private static final class End {final BlockPos cable,pos;final EnumFacing side;End(BlockPos c,EnumFacing s){cable=c;side=s;pos=c.offset(s);}}
 private ItemCableNetwork(){}
 /** true iff the face was toggled; false on invalid, remote, unloaded or denied. */
 public static boolean toggleConnection(World world,BlockPos pos,EnumFacing side,EntityPlayer player){
  return toggleConnection(world,pos,side,player,EnumHand.MAIN_HAND);
 }
 public static boolean toggleConnection(World world,BlockPos pos,EnumFacing side,EntityPlayer player,EnumHand hand){
  if(world==null||world.isRemote||pos==null||side==null||player==null||hand==null||busy||player.world!=world||player.isSpectator())return false;
  BlockPos np=pos.offset(side);
  if(!permitted(world,pos,np,side,player,hand))return false;
  ItemCableTile a=cable(world,pos), b=cable(world,np);
  if(a==null || (b==null && endpoint(world,np,side.getOpposite())==null))return false;
  // Check both blocks even for direct API callers; prohibit reentrant toggles.
  busy=true;
  try{
   if(!allowed(player,hand,pos,side)||!allowed(player,hand,np,side.getOpposite()))return false;
   if(player.world!=world||player.isSpectator()||!permitted(world,pos,np,side,player,hand)||cable(world,pos)!=a)return false;
   if(b!=null ? cable(world,np)!=b : endpoint(world,np,side.getOpposite())==null)return false;
   boolean block=!a.blocked(side);a.setBlocked(side,block);
   if(b!=null)b.setBlocked(side.getOpposite(),block);
   world.notifyNeighborsOfStateChange(pos,world.getBlockState(pos).getBlock(),false);
   if(b!=null)world.notifyNeighborsOfStateChange(np,world.getBlockState(np).getBlock(),false);
   return true;
  }finally{busy=false;}
 }
 private static boolean permitted(World w,BlockPos a,BlockPos b,EnumFacing side,EntityPlayer p,EnumHand hand){
  return w.isBlockLoaded(a)&&w.isBlockLoaded(b)&&w.getWorldBorder().contains(a)&&w.getWorldBorder().contains(b)
    &&w.isBlockModifiable(p,a)&&w.isBlockModifiable(p,b)&&p.canPlayerEdit(a,side,p.getHeldItem(hand))&&p.canPlayerEdit(b,side.getOpposite(),p.getHeldItem(hand));
 }
 private static boolean allowed(EntityPlayer p,EnumHand hand,BlockPos pos,EnumFacing face){
  PlayerInteractEvent.RightClickBlock event=ForgeHooks.onRightClickBlock(p,hand,pos,face,new Vec3d(pos).addVector(.5,.5,.5));
  return !event.isCanceled()&&event.getUseBlock()!=Event.Result.DENY&&event.getUseItem()!=Event.Result.DENY;
 }
 static void tick(ItemCableTile t){
  World w=t.getWorld();long time=w.getTotalWorldTime();
  Budget b=BUDGETS.get(w);if(b==null){b=new Budget();BUDGETS.put(w,b);}
  if(b.time!=time){if(time<b.time)b.waiting.clear();b.time=time;b.used=0;}
  BlockPos pos=t.getPos().toImmutable();
  // A missed budget slot remains queued instead of losing to the same earlier
  // tiles forever when their phases collide. Updating the value keeps FIFO order.
  long epoch=Math.floorDiv(time,20L);int phase=(int)Math.floorMod((long)pos.hashCode()+epoch*7L,20L);
  if(b.waiting.containsKey(pos)||Math.floorMod(time,20L)==phase)b.waiting.put(pos,time);
  if(b.waiting.isEmpty()||busy)return;
  // Abandoned/unloaded requests cannot hold up everyone else. Work is bounded.
  int cleanup=16;
  while(!b.waiting.isEmpty()&&cleanup-->0){
   Map.Entry<BlockPos,Long> first=b.waiting.entrySet().iterator().next();
   ItemCableTile head=cable(w,first.getKey());
   if(time-first.getValue()<=40&&head!=null&&!head.fault&&head.held.isEmpty()&&w.getBlockState(first.getKey()).getBlock()==ItemCableRegistry.EXTRACTOR)break;
   b.waiting.remove(first.getKey());
  }
  if(b.waiting.isEmpty()||!b.waiting.keySet().iterator().next().equals(pos)||b.used>=PER_TICK)return;
  b.waiting.remove(pos);b.used++;busy=true;
  try{transfer(t);}catch(RuntimeException ex){t.fault=true;t.markDirty();org.apache.logging.log4j.LogManager.getLogger("NexusTech item cable").error("Item cable fault at "+t.getPos()+"; stopped to avoid replay",ex);}finally{busy=false;}
 }
 private static ItemCableTile cable(World w,BlockPos p){if(!w.isBlockLoaded(p)||!w.getWorldBorder().contains(p))return null;TileEntity t=w.getTileEntity(p);return t instanceof ItemCableTile&&!t.isInvalid()&&(w.getBlockState(p).getBlock() instanceof ItemCableBlock)?(ItemCableTile)t:null;}
 private static List<End> destinations(ItemCableTile start){
  World w=start.getWorld();ArrayDeque<BlockPos> q=new ArrayDeque<>();Set<BlockPos> seen=new HashSet<>();List<End> ends=new ArrayList<>();q.add(start.getPos().toImmutable());seen.add(start.getPos().toImmutable());
  while(!q.isEmpty()){
   BlockPos p=q.remove();ItemCableTile c=cable(w,p);if(c==null)return null;boolean gray=w.getBlockState(p).getBlock()==ItemCableRegistry.CABLE;
   for(EnumFacing f:EnumFacing.VALUES){if(c.blocked(f))continue;BlockPos next=p.offset(f);
    // Do not guess what exists beyond an unloaded border.
    if(!w.isBlockLoaded(next)||!w.getWorldBorder().contains(next))return null;
    ItemCableTile other=cable(w,next);
    if(other!=null){if(other.blocked(f.getOpposite()))continue;if(seen.add(next.toImmutable())){if(seen.size()>MAX_CABLES)return null;q.add(next.toImmutable());}}
    else if(gray&&w.getTileEntity(next)!=null)ends.add(new End(p,f));
   }
  }
  return ends;
 }
 // Reject double chests, custom wrappers and subclasses: simulations cannot prove
 // independence or transactional behavior of arbitrary Forge handlers.
 private static IItemHandler endpoint(World w,BlockPos p,EnumFacing face){
  if(!w.isBlockLoaded(p))return null;TileEntity t=w.getTileEntity(p);if(t==null||t.isInvalid()||t instanceof ItemCableTile)return null;
  if(t.getClass()==TileEntityChest.class){if(((TileEntityChest)t).getLootTable()!=null)return null;for(EnumFacing f:EnumFacing.HORIZONTALS){BlockPos n=p.offset(f);if(!w.isBlockLoaded(n)||!w.getWorldBorder().contains(n))return null;if(w.getTileEntity(n) instanceof TileEntityChest)return null;}}
  IItemHandler h=t.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,face);
  if(h==null)return null;
  if(t.getClass()==TileEntityChest.class)return h.getClass()==InvWrapper.class&&((InvWrapper)h).getInv()==t?h:null;
  return h.getClass()==ItemStackHandler.class?h:null;
 }
 // Single-chest capability wrappers can be freshly allocated on every query.
 private static boolean equivalent(IItemHandler a,IItemHandler b){
  return a==b || (a!=null&&b!=null&&a.getClass()==InvWrapper.class&&b.getClass()==InvWrapper.class
    &&((InvWrapper)a).getInv().getClass()==TileEntityChest.class&&((InvWrapper)a).getInv()==((InvWrapper)b).getInv());
 }
 static boolean acceptedEndpoint(World w,BlockPos p,EnumFacing f){return endpoint(w,p,f)!=null;}
 private static boolean same(ItemStack a,ItemStack b){return !a.isEmpty()&&!b.isEmpty()&&ItemStack.areItemsEqual(a,b)&&ItemStack.areItemStackTagsEqual(a,b);}
 private static void transfer(ItemCableTile t){
  World w=t.getWorld();List<End> ends=destinations(t);if(ends==null||ends.isEmpty())return;
  EnumFacing src=EnumFacing.VALUES[t.sourceCursor%6];t.sourceCursor=(t.sourceCursor+1)&0x7fffffff;t.markDirty();if(t.blocked(src))return;
  BlockPos sp=t.getPos().offset(src);if(!w.isBlockLoaded(sp))return;IItemHandler from=endpoint(w,sp,src.getOpposite());if(from==null)return;
  int ns=from.getSlots();if(ns<=0||ns>4096)return;int ss=t.sourceSlots[src.ordinal()]%ns;t.sourceSlots[src.ordinal()]=(t.sourceSlots[src.ordinal()]+1)&0x7fffffff;
  ItemStack probe=from.extractItem(ss,1,true);if(probe==null||probe.isEmpty()||probe.getCount()!=1)return;
  int attempts=Math.min(8,ends.size());int begin=t.destinationCursor%ends.size();t.destinationCursor=(t.destinationCursor+attempts)&0x7fffffff;t.markDirty();
  for(int i=0;i<attempts;i++){
   End e=ends.get((begin+i)%ends.size());if(e.pos.equals(sp))continue;
   IItemHandler to=endpoint(w,e.pos,e.side.getOpposite());if(to==null||equivalent(to,from))continue;
   int nd=to.getSlots();if(nd<=0||nd>4096)continue;String key=e.cable.toLong()+":"+e.side.ordinal();if(t.targetSlots.size()>768)t.targetSlots.clear();int count=t.targetSlots.containsKey(key)?t.targetSlots.get(key):0;int ds=count%nd;t.targetSlots.put(key,(count+1)&0x7fffffff);t.markDirty();
   ItemStack remainder=to.insertItem(ds,probe.copy(),true);if(remainder==null||!remainder.isEmpty())continue;
   // Re-probe topology and identity immediately before mutation; if anything changed, abort.
   List<End> current=destinations(t);if(!t.live()||current==null||t.blocked(src)||!equivalent(endpoint(w,sp,src.getOpposite()),from)||!equivalent(endpoint(w,e.pos,e.side.getOpposite()),to)||!contains(current,e))return;
   ItemStack again=from.extractItem(ss,1,true);if(again==null||again.getCount()!=1||!same(probe,again))return;
   remainder=to.insertItem(ds,again.copy(),true);if(remainder==null||!remainder.isEmpty())return;
   t.fault=true;t.markDirty(); // A failure during external mutation is never retried automatically.
   if(!t.live())return;
   ItemStack extracted=from.extractItem(ss,1,false);
   if(extracted==null||extracted.isEmpty()){return;}
   t.held=extracted.copy();t.markDirty();
   if(!t.live()){ItemCableRecovery.get(w).add(t.getPos(),t.held,true);t.held=ItemStack.EMPTY;return;}
   if(extracted.getCount()!=1||!same(probe,extracted))return;
   ItemStack left=to.insertItem(ds,extracted.copy(),false);
   if(left==null)return;
   if(left.isEmpty()){t.held=ItemStack.EMPTY;t.fault=false;t.markDirty();return;}
   if(left.getCount()==1&&same(extracted,left)){t.held=left.copy();t.fault=false;t.markDirty();} // confirmed remainder, recover by breaking cable
   return;
  }
 }
 private static boolean contains(List<End> all,End e){for(End x:all)if(x.cable.equals(e.cable)&&x.side==e.side)return true;return false;}
}
