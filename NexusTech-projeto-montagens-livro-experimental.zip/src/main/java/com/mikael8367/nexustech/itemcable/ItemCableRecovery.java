package com.mikael8367.nexustech.itemcable;
import com.mikael8367.nexustech.NexusTech;
import java.util.*;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.*;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** Confirmed leftovers survive cable destruction. Ambiguous entries are evidence, never replayed. */
@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class ItemCableRecovery extends WorldSavedData {
 private static final String KEY="nexustech_item_cable_recovery";
 private final List<NBTTagCompound> ready=new ArrayList<>(), quarantine=new ArrayList<>();
 private boolean busy;private int cursor;
 public ItemCableRecovery(){super(KEY);}public ItemCableRecovery(String name){super(name);}
 static ItemCableRecovery get(World w){MapStorage s=w.getPerWorldStorage();ItemCableRecovery d=(ItemCableRecovery)s.getOrLoadData(ItemCableRecovery.class,KEY);if(d==null){d=new ItemCableRecovery(KEY);s.setData(KEY,d);}return d;}
 void add(BlockPos p,ItemStack stack,boolean uncertain){if(stack.isEmpty())return;NBTTagCompound n=new NBTTagCompound();n.setLong("Pos",p.toLong());n.setTag("Stack",stack.writeToNBT(new NBTTagCompound()));(uncertain?quarantine:ready).add(n);markDirty();}
 @Override public void readFromNBT(NBTTagCompound n){ready.clear();quarantine.clear();load(n.getTagList("Ready",10),ready);load(n.getTagList("Quarantine",10),quarantine);}
 private static void load(NBTTagList l,List<NBTTagCompound> out){for(int i=0;i<l.tagCount();i++)out.add(l.getCompoundTagAt(i).copy());}
 private static NBTTagList write(List<NBTTagCompound> entries){NBTTagList l=new NBTTagList();for(NBTTagCompound n:entries)l.appendTag(n.copy());return l;}
 @Override public NBTTagCompound writeToNBT(NBTTagCompound n){n.setTag("Ready",write(ready));n.setTag("Quarantine",write(quarantine));return n;}
 private void retry(World w){if(busy||ready.isEmpty()||!w.getGameRules().getBoolean("doTileDrops"))return;busy=true;try{
  int count=Math.min(4,ready.size());while(count-->0&&!ready.isEmpty()){
   cursor=Math.floorMod(cursor,ready.size());NBTTagCompound n=ready.get(cursor);BlockPos p=BlockPos.fromLong(n.getLong("Pos"));if(!w.isBlockLoaded(p)){cursor++;continue;}
   ItemStack stack=new ItemStack(n.getCompoundTag("Stack"));if(stack.isEmpty()){ready.remove(cursor);markDirty();continue;}
   ready.remove(cursor);quarantine.add(n);markDirty();
   try{boolean ok=w.spawnEntity(new EntityItem(w,p.getX()+.5,p.getY()+.5,p.getZ()+.5,stack));if(ok)quarantine.remove(n);else{quarantine.remove(n);ready.add(n);}markDirty();}catch(RuntimeException ex){/* Effect unknown: never respawn automatically. */}
  }
 }finally{busy=false;}}
 @SubscribeEvent public static void worldTick(TickEvent.WorldTickEvent e){if(!e.world.isRemote&&e.phase==TickEvent.Phase.END&&e.world.getTotalWorldTime()%20==0)get(e.world).retry(e.world);}
}
