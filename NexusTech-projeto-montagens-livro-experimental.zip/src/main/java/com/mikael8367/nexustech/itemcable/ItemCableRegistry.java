package com.mikael8367.nexustech.itemcable;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class ItemCableRegistry {
 public static final ItemCableBlock CABLE=new ItemCableBlock(false), EXTRACTOR=new ItemCableBlock(true);
 @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e){
  e.getRegistry().register(CABLE);e.getRegistry().register(EXTRACTOR);
  GameRegistry.registerTileEntity(ItemCableTile.class,new ResourceLocation(NexusTech.MODID,"item_cable"));
 }
 @SubscribeEvent public static void items(RegistryEvent.Register<Item> e){
  e.getRegistry().register(new ItemBlock(CABLE).setRegistryName(CABLE.getRegistryName()));
  e.getRegistry().register(new ItemBlock(EXTRACTOR).setRegistryName(EXTRACTOR.getRegistryName()));
 }
 private ItemCableRegistry(){}
}
