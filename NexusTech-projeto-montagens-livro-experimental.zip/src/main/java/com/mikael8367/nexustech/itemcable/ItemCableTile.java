package com.mikael8367.nexustech.itemcable;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;

public final class ItemCableTile extends TileEntity implements ITickable {
 int blockedMask, sourceCursor, destinationCursor;
 final int[] sourceSlots=new int[6];
 final java.util.Map<String,Integer> targetSlots=new java.util.HashMap<>();
 boolean fault;
 ItemStack held=ItemStack.EMPTY;
 boolean blocked(EnumFacing f){return (blockedMask&(1<<f.ordinal()))!=0;}
 void setBlocked(EnumFacing f,boolean b){int bit=1<<f.ordinal();blockedMask=b?blockedMask|bit:blockedMask&~bit;markDirty();if(world!=null){world.notifyBlockUpdate(pos,world.getBlockState(pos),world.getBlockState(pos),3);world.markBlockRangeForRenderUpdate(pos,pos);}}
 boolean live(){return world!=null&&!world.isRemote&&!isInvalid()&&world.isBlockLoaded(pos)&&world.getTileEntity(pos)==this;}
 @Override public void update(){if(live()&&!fault&&held.isEmpty()&&world.getBlockState(pos).getBlock()==ItemCableRegistry.EXTRACTOR)ItemCableNetwork.tick(this);}
 @Override public NBTTagCompound writeToNBT(NBTTagCompound n){super.writeToNBT(n);n.setInteger("Blocked",blockedMask);n.setInteger("SourceCursor",sourceCursor);n.setIntArray("SourceSlots",sourceSlots);n.setInteger("DestinationCursor",destinationCursor);n.setBoolean("Fault",fault);if(!held.isEmpty())n.setTag("Held",held.writeToNBT(new NBTTagCompound()));return n;}
 @Override public void readFromNBT(NBTTagCompound n){super.readFromNBT(n);blockedMask=n.getInteger("Blocked")&63;sourceCursor=n.getInteger("SourceCursor")&0x7fffffff;int[] saved=n.getIntArray("SourceSlots");for(int i=0;i<6;i++)sourceSlots[i]=i<saved.length?(saved[i]&0x7fffffff):0;destinationCursor=n.getInteger("DestinationCursor")&0x7fffffff;targetSlots.clear();fault=n.getBoolean("Fault");held=n.hasKey("Held",10)?new ItemStack(n.getCompoundTag("Held")):ItemStack.EMPTY;}
 @Override public NBTTagCompound getUpdateTag(){return writeToNBT(new NBTTagCompound());}
 @Override public SPacketUpdateTileEntity getUpdatePacket(){return new SPacketUpdateTileEntity(pos,0,getUpdateTag());}
 @Override public void onDataPacket(NetworkManager manager,SPacketUpdateTileEntity packet){readFromNBT(packet.getNbtCompound());}
}
