package com.mikael8367.nexustech.mobcard;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityList;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = NexusTech.MODID, value = Side.CLIENT)
public final class MobCardClient {
    private MobCardClient() { }
    @SubscribeEvent public static void models(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(MobCardEvents.CARD, 0, new ModelResourceLocation(MobCardEvents.CARD.getRegistryName(), "inventory"));
    }
    private static boolean pt() {
        return "pt_br".equalsIgnoreCase(Minecraft.getMinecraft().getLanguageManager().getCurrentLanguage().getLanguageCode());
    }
    private static String mobName(ResourceLocation mob) {
        String translation = EntityList.getTranslationName(mob);
        if (translation == null) return mob.toString();
        String key = "entity." + translation + ".name";
        String result = I18n.format(key);
        return key.equals(result) ? mob.toString() : result;
    }
    private static String progress(ItemStack stack) {
        ResourceLocation mob = MobCardItem.getMob(stack);
        if (mob == null) return pt() ? "Cartão de mobs: sem registro válido" : "Mob Card: no valid record";
        String status = MobCardItem.isReady(stack) ? (pt() ? " - pronto" : " - ready") : "";
        return (pt() ? "Cartão: " : "Card: ") + mobName(mob) + " " + MobCardItem.getKills(stack) + "/" + MobCardItem.required(mob) + status;
    }
    @SubscribeEvent public static void tooltip(ItemTooltipEvent event) {
        if (!(event.getItemStack().getItem() instanceof MobCardItem)) return;
        if (!event.getToolTip().isEmpty()) event.getToolTip().set(0, pt() ? "Cartão de mobs" : "Mob Card");
        event.getToolTip().add(progress(event.getItemStack()));
        event.getToolTip().add(pt() ? "Na mão secundária: abata diretamente para registrar." : "Off hand: kill directly to record." );
    }
    @SubscribeEvent public static void hud(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.HOTBAR) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.gameSettings.hideGUI || mc.gameSettings.showDebugInfo) return;
        ItemStack stack = mc.player.getHeldItemOffhand();
        if (stack.isEmpty() || !(stack.getItem() instanceof MobCardItem)) return;
        mc.fontRenderer.drawStringWithShadow(progress(stack), 5, 5, 0xFFFFFF);
    }
}
