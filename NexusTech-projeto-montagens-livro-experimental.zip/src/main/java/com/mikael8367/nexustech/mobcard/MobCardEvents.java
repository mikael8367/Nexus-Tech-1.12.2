package com.mikael8367.nexustech.mobcard;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.util.EntityDamageSource;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class MobCardEvents {
    public static final MobCardItem CARD = new MobCardItem();
    private MobCardEvents() { }
    @SubscribeEvent public static void register(RegistryEvent.Register<Item> e) { e.getRegistry().register(CARD); }
    @SubscribeEvent(priority = EventPriority.LOWEST) public static void death(LivingDeathEvent e) {
        if (e.isCanceled() || e.getEntityLiving().world.isRemote) return;
        if (e.getSource().isProjectile() || e.getSource().isExplosion() ||
            (e.getSource() instanceof EntityDamageSource && ((EntityDamageSource)e.getSource()).getIsThornsDamage())) return;
        Entity killer = e.getSource().getTrueSource();
        if (!(killer instanceof EntityPlayerMP) || killer instanceof FakePlayer || e.getSource().getImmediateSource() != killer) return;
        EntityPlayerMP player = (EntityPlayerMP) killer;
        if (player.world != e.getEntityLiving().world) return;
        ItemStack card = player.getHeldItemOffhand();
        if (MobCardItem.recordKill(card, EntityList.getKey(e.getEntityLiving()))) {
            player.inventory.markDirty();
            // -2 updates the raw player-inventory slot even with another GUI open.
            // Offhand is inventory index 40 (container index 45 is different).
            player.connection.sendPacket(new SPacketSetSlot(-2, 40, card.copy()));
            player.inventoryContainer.detectAndSendChanges();
            if (player.openContainer != player.inventoryContainer) player.openContainer.detectAndSendChanges();
        }
    }
}
