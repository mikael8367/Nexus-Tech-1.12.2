package com.mikael8367.nexustech.mobcard;

import com.mikael8367.nexustech.NexusTech;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.translation.I18n;
import net.minecraftforge.common.util.Constants;

/** The card stores only a whitelisted entity ID and a bounded integer, never entity NBT. */
public final class MobCardItem extends Item {
    private static final String DATA = "NexusMobCard";
    private static final Map<String, Integer> LIMITS;
    static {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (String name : new String[]{"pig", "cow", "sheep", "chicken", "rabbit", "zombie", "skeleton", "spider", "creeper", "slime", "magma_cube"}) m.put("minecraft:" + name, 20);
        for (String name : new String[]{"enderman", "blaze", "witch", "cave_spider"}) m.put("minecraft:" + name, 10);
        m.put("minecraft:ghast", 5);
        LIMITS = Collections.unmodifiableMap(m);
    }
    public MobCardItem() {
        setRegistryName(NexusTech.MODID, "mob_card");
        setUnlocalizedName(NexusTech.MODID + ".mob_card");
        setCreativeTab(NexusTech.CREATIVE_TAB);
        setMaxStackSize(1);
    }
    @Override public String getItemStackDisplayName(ItemStack stack) {
        String key = "item.nexustech.mob_card.name";
        String translated = I18n.translateToLocal(key);
        return key.equals(translated) ? "Mob Card" : translated;
    }
    /** Zero means unsupported. Accepts only canonical IDs in the fixed allowlist. */
    public static int required(@Nullable ResourceLocation id) {
        Integer n = id == null ? null : LIMITS.get(id.toString());
        return n == null ? 0 : n;
    }
    private static boolean isCard(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.getItem() instanceof MobCardItem && stack.getCount() == 1;
    }
    private static boolean hasData(ItemStack stack) {
        return isCard(stack) && stack.hasTagCompound() && stack.getTagCompound().hasKey(DATA);
    }
    private static NBTTagCompound validData(ItemStack stack) {
        if (!hasData(stack) || !stack.getTagCompound().hasKey(DATA, Constants.NBT.TAG_COMPOUND)) return null;
        NBTTagCompound data = stack.getTagCompound().getCompoundTag(DATA);
        if (!data.hasKey("mob", Constants.NBT.TAG_STRING) || !data.hasKey("kills", Constants.NBT.TAG_INT)) return null;
        String name = data.getString("mob");
        // Check the exact string before constructing a ResourceLocation; no attacker-controlled parser input.
        Integer need = LIMITS.get(name);
        int kills = data.getInteger("kills");
        return need != null && kills >= 1 && kills <= need ? data : null;
    }
    /** Returns the fixed mob for valid bound cards, whether complete or not; otherwise null. */
    @Nullable public static ResourceLocation getMob(ItemStack stack) {
        NBTTagCompound data = validData(stack);
        return data == null ? null : new ResourceLocation(data.getString("mob"));
    }
    public static boolean isReady(ItemStack stack) {
        NBTTagCompound data = validData(stack);
        return data != null && data.getInteger("kills") == LIMITS.get(data.getString("mob"));
    }
    public static int getKills(ItemStack stack) {
        NBTTagCompound data = validData(stack);
        return data == null ? 0 : data.getInteger("kills");
    }
    /** Called on server only: bind on first eligible kill, otherwise increment only matching mob. */
    static boolean recordKill(ItemStack stack, @Nullable ResourceLocation mob) {
        int need = required(mob);
        if (!isCard(stack) || need == 0) return false;
        NBTTagCompound data = validData(stack);
        if (data == null) {
            // A malformed state must never be silently treated as a blank card.
            if (hasData(stack)) return false;
            data = new NBTTagCompound();
            data.setString("mob", mob.toString());
            data.setInteger("kills", 1);
            if (!stack.hasTagCompound()) stack.setTagCompound(new NBTTagCompound());
            stack.getTagCompound().setTag(DATA, data);
            return true;
        }
        if (!data.getString("mob").equals(mob.toString()) || data.getInteger("kills") >= need) return false;
        data.setInteger("kills", data.getInteger("kills") + 1);
        return true;
    }
}
