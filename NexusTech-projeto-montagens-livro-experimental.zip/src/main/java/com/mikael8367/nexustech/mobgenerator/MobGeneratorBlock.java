package com.mikael8367.nexustech.mobgenerator;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class MobGeneratorBlock extends Block {
    MobGeneratorBlock() {
        super(Material.IRON); setRegistryName(NexusTech.MODID,"mob_generator");
        setUnlocalizedName(NexusTech.MODID+".mob_generator"); setCreativeTab(NexusTech.CREATIVE_TAB);
        setHardness(4); setResistance(12); setHarvestLevel("pickaxe",1);
    }
    @Override public boolean hasTileEntity(IBlockState s) { return true; }
    @Override public TileEntity createTileEntity(World w,IBlockState s) { return new MobGeneratorTile(); }
    @Override public boolean onBlockActivated(World w,BlockPos p,IBlockState s,EntityPlayer player,EnumHand hand,EnumFacing side,float x,float y,float z) {
        if (!w.isRemote && w.getTileEntity(p) instanceof MobGeneratorTile)
            player.openGui(NexusTech.INSTANCE,MobGeneratorRegistry.GUI_ID,w,p.getX(),p.getY(),p.getZ());
        return true;
    }
    @Override public void breakBlock(World w,BlockPos p,IBlockState s) {
        TileEntity te=w.getTileEntity(p);
        if (!w.isRemote && te instanceof MobGeneratorTile) {
            ItemStack stack=((MobGeneratorTile)te).drainCard();
            if (!stack.isEmpty()) w.spawnEntity(new EntityItem(w,p.getX()+.5,p.getY()+.5,p.getZ()+.5,stack));
        }
        super.breakBlock(w,p,s);
    }
}
