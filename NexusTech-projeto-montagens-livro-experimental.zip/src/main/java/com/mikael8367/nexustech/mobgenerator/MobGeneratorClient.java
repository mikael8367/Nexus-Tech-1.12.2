package com.mikael8367.nexustech.mobgenerator;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid=NexusTech.MODID,value=Side.CLIENT)
public final class MobGeneratorClient {
    private MobGeneratorClient() {}
    @SubscribeEvent public static void models(ModelRegistryEvent e) {
        Item item=Item.getItemFromBlock(MobGeneratorRegistry.BLOCK);
        ModelLoader.setCustomModelResourceLocation(item,0,new ModelResourceLocation(item.getRegistryName(),"inventory"));
    }
    /** Delegate the existing client proxy's GUI_ID to gui(). */
    public static Object gui(int id,EntityPlayer p,World w,int x,int y,int z) {
        BlockPos pos=new BlockPos(x,y,z);
        if(id!=MobGeneratorRegistry.GUI_ID || p==null || w==null || !w.isRemote || p.world!=w || !w.isBlockLoaded(pos)) return null;
        TileEntity t=w.getTileEntity(pos);
        if(!(t instanceof MobGeneratorTile)) return null;
        MobGeneratorContainer c=new MobGeneratorContainer(p.inventory,(MobGeneratorTile)t);
        return c.canInteractWith(p)?new MobGeneratorGui(p.inventory,(MobGeneratorTile)t):null;
    }
}
