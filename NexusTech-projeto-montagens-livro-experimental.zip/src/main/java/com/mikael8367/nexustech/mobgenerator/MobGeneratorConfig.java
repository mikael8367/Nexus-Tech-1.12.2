package com.mikael8367.nexustech.mobgenerator;
import com.mikael8367.nexustech.NexusTech;
import net.minecraftforge.common.config.Config;

@Config(modid=NexusTech.MODID, name="nexustech-mob-generator")
public final class MobGeneratorConfig {
    private MobGeneratorConfig() {}
    @Config.Comment("Forge Energy per successful spawn (capacity is 100000 FE).")
    @Config.RangeInt(min=1,max=100000) public static int cost = 4000;
    @Config.Comment("Ticks between attempts, minimum 100 for performance.")
    @Config.RangeInt(min=100,max=72000) public static int interval = 200;
    @Config.Comment("Maximum living mobs within 8 blocks, minimum 1 and maximum 24.")
    @Config.RangeInt(min=1,max=24) public static int nearbyLimit = 12;
}
