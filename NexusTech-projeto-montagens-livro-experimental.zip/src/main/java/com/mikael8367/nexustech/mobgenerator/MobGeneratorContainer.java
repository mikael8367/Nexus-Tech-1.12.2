package com.mikael8367.nexustech.mobgenerator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;

public final class MobGeneratorContainer extends Container {
    private final MobGeneratorTile tile;
    private int last=-1;
    public MobGeneratorContainer(InventoryPlayer inv,MobGeneratorTile t) {
        tile=t;
        addSlotToContainer(new SlotItemHandler(t.items(),0,80,39) {
            @Override public boolean isItemValid(ItemStack s) { return !tile.isBusy() && MobGeneratorTile.validCard(s); }
            @Override public int getItemStackLimit(ItemStack s) { return 1; }
            @Override public boolean canTakeStack(EntityPlayer p) { return !tile.isBusy(); }
            @Override public void putStack(ItemStack s) { tile.guiSet(s); onSlotChanged(); }
            @Override public ItemStack decrStackSize(int n) { return tile.guiExtract(n); }
        });
        for(int r=0;r<3;r++) for(int c=0;c<9;c++) addSlotToContainer(new Slot(inv,c+r*9+9,8+c*18,84+r*18));
        for(int c=0;c<9;c++) addSlotToContainer(new Slot(inv,c,8+c*18,142));
    }
    @Override public boolean canInteractWith(EntityPlayer p) {
        return tile.getWorld()!=null && p.world==tile.getWorld() && !tile.isInvalid()
          && tile.getWorld().isBlockLoaded(tile.getPos()) && tile.getWorld().getTileEntity(tile.getPos())==tile
          && p.getDistanceSq(tile.getPos().getX()+.5,tile.getPos().getY()+.5,tile.getPos().getZ()+.5)<=64;
    }
    private void send(IContainerListener l,int v) { l.sendWindowProperty(this,0,v&65535); l.sendWindowProperty(this,1,(v>>>16)&65535); }
    @Override public void addListener(IContainerListener l) { super.addListener(l); send(l,tile.getEnergy()); }
    @Override public void detectAndSendChanges() { super.detectAndSendChanges(); int v=tile.getEnergy(); if(v!=last){for(IContainerListener l:listeners)send(l,v);last=v;} }
    @Override public void updateProgressBar(int id,int v) {
        int old=tile.getEnergy(); if(id==0) tile.setClientEnergy((old&0xffff0000)|(v&65535));
        else if(id==1) tile.setClientEnergy((old&65535)|((v&65535)<<16));
    }
    @Override public ItemStack slotClick(int slotId,int dragType,net.minecraft.inventory.ClickType type,EntityPlayer player) {
        return tile.isBusy() ? ItemStack.EMPTY : super.slotClick(slotId,dragType,type,player);
    }
    @Override public ItemStack transferStackInSlot(EntityPlayer player,int index) {
        if(tile.isBusy() || index<0 || index>=inventorySlots.size()) return ItemStack.EMPTY;
        Slot slot=inventorySlots.get(index); if(!slot.getHasStack()) return ItemStack.EMPTY;
        ItemStack stack=slot.getStack(), original=stack.copy();
        if(index==0) { if(!mergeItemStack(stack,1,37,true)) return ItemStack.EMPTY; }
        else if(!MobGeneratorTile.validCard(stack) || !mergeItemStack(stack,0,1,false)) return ItemStack.EMPTY;
        if(stack.isEmpty()) slot.putStack(ItemStack.EMPTY); else slot.onSlotChanged();
        if(stack.getCount()==original.getCount()) return ItemStack.EMPTY;
        slot.onTake(player,stack); return original;
    }
}
