package com.mikael8367.nexustech.mobgenerator;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)
public final class MobGeneratorGui extends GuiContainer {
    private final MobGeneratorTile tile;
    public MobGeneratorGui(InventoryPlayer inv,MobGeneratorTile t) { super(new MobGeneratorContainer(inv,t)); tile=t; xSize=176; ySize=166; }
    @Override protected void drawGuiContainerForegroundLayer(int x,int y) {
        fontRenderer.drawString(I18n.format("tile.nexustech.mob_generator.name"),8,6,0x404040);
        fontRenderer.drawString("FE: "+tile.getEnergy()+" / "+MobGeneratorTile.CAPACITY,8,19,0x404040);
        fontRenderer.drawString(I18n.format("container.inventory"),8,72,0x404040);
    }
    private void slot(int x,int y) { drawRect(guiLeft+x-1,guiTop+y-1,guiLeft+x+17,guiTop+y+17,0xff555555); drawRect(guiLeft+x,guiTop+y,guiLeft+x+16,guiTop+y+16,0xff8b8b8b); }
    @Override protected void drawGuiContainerBackgroundLayer(float p,int x,int y) {
        drawRect(guiLeft,guiTop,guiLeft+xSize,guiTop+ySize,0xff373737);
        drawRect(guiLeft+2,guiTop+2,guiLeft+xSize-2,guiTop+ySize-2,0xffc6c6c6);
        slot(80,39); for(int r=0;r<3;r++)for(int c=0;c<9;c++)slot(8+c*18,84+r*18);
        for(int c=0;c<9;c++)slot(8+c*18,142);
    }
    @Override public void drawScreen(int x,int y,float partial) { drawDefaultBackground(); super.drawScreen(x,y,partial); renderHoveredToolTip(x,y); }
}
