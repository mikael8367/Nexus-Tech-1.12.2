package com.mikael8367.nexustech.mobgenerator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
/** Delegate the existing server GUI handler's GUI_ID to server(). */
public final class MobGeneratorGuiHooks {
    private MobGeneratorGuiHooks() {}
    public static Object server(int id,EntityPlayer p,World w,int x,int y,int z) {
        BlockPos pos=new BlockPos(x,y,z);
        if(id!=MobGeneratorRegistry.GUI_ID || p==null || w==null || w.isRemote || p.world!=w || !w.isBlockLoaded(pos)) return null;
        TileEntity t=w.getTileEntity(pos); if(!(t instanceof MobGeneratorTile)) return null;
        MobGeneratorContainer c=new MobGeneratorContainer(p.inventory,(MobGeneratorTile)t);
        return c.canInteractWith(p)?c:null;
    }
}
