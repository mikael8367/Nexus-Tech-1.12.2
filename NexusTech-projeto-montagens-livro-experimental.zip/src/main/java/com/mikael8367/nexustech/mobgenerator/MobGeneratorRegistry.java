package com.mikael8367.nexustech.mobgenerator;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class MobGeneratorRegistry {
    public static final int GUI_ID = 8368;
    public static final MobGeneratorBlock BLOCK = new MobGeneratorBlock();
    private MobGeneratorRegistry() {}
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e) {
        e.getRegistry().register(BLOCK);
        GameRegistry.registerTileEntity(MobGeneratorTile.class, new ResourceLocation(NexusTech.MODID, "mob_generator"));
    }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> e) {
        e.getRegistry().register(new ItemBlock(BLOCK).setRegistryName(BLOCK.getRegistryName()));
    }
}
