package com.mikael8367.nexustech.mobgenerator;
import com.mikael8367.nexustech.mobcard.MobCardItem;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

/** Server-authoritative single-card generator. Nothing from the card is deserialized into the mob. */
public final class MobGeneratorTile extends TileEntity implements ITickable {
    public static final int CAPACITY=100000, RECEIVE_RATE=1000, RADIUS=8;
    private static final Set<String> SAFE = new HashSet<>(Arrays.asList(
        "pig","cow","sheep","chicken","rabbit","zombie","skeleton","creeper","spider",
        "slime","magma_cube","enderman","blaze","witch","cave_spider","ghast"));
    private int energy, cooldown=200;
    private boolean busy;
    private final ItemStackHandler inventory = new ItemStackHandler(1) {
        @Override public int getSlotLimit(int slot) { return 1; }
        @Override public boolean isItemValid(int slot,ItemStack s) { return slot==0 && validCard(s); }
        @Override protected void onContentsChanged(int slot) { markDirty(); }
    };
    static boolean validCard(ItemStack s) { return !s.isEmpty() && s.getItem() instanceof MobCardItem; }
    boolean isBusy() { return busy; }
    void guiSet(ItemStack s) {
        if (busy || world==null || (!world.isRemote && !live())) return;
        if (!s.isEmpty() && (!validCard(s) || s.getCount()!=1)) return;
        inventory.setStackInSlot(0,s.copy());
    }
    ItemStack guiExtract(int amount) {
        if (busy || world==null || (!world.isRemote && !live()) || amount<=0) return ItemStack.EMPTY;
        return inventory.extractItem(0,amount,false);
    }
    private boolean live() { return world!=null && !world.isRemote && !isInvalid() && world.isBlockLoaded(pos) && world.getTileEntity(pos)==this; }
    private final IItemHandler items=new IItemHandler() {
        public int getSlots() { return 1; }
        public ItemStack getStackInSlot(int slot) { return slot==0 ? inventory.getStackInSlot(0).copy() : ItemStack.EMPTY; }
        public int getSlotLimit(int slot) { return slot==0 ? 1 : 0; }
        public boolean isItemValid(int slot,ItemStack s) { return slot==0 && validCard(s); }
        public ItemStack insertItem(int slot,ItemStack s,boolean sim) {
            if (!live() || busy || slot!=0 || !validCard(s)) return s;
            return inventory.insertItem(0,s,sim);
        }
        public ItemStack extractItem(int slot,int amount,boolean sim) {
            if (!live() || busy || slot!=0 || amount<=0) return ItemStack.EMPTY;
            return inventory.extractItem(0,amount,sim);
        }
    };
    private final IEnergyStorage power=new IEnergyStorage() {
        public int receiveEnergy(int amount,boolean simulate) {
            if (!live() || busy || amount<=0) return 0;
            int n=Math.min(Math.min(amount,RECEIVE_RATE),CAPACITY-energy);
            if (!simulate && n>0) { energy+=n; markDirty(); }
            return n;
        }
        public int extractEnergy(int n,boolean sim) { return 0; }
        public int getEnergyStored() { return energy; }
        public int getMaxEnergyStored() { return CAPACITY; }
        public boolean canExtract() { return false; }
        public boolean canReceive() { return true; }
    };
    public int getEnergy() { return energy; }
    public static int cost() { return Math.max(1,Math.min(CAPACITY,MobGeneratorConfig.cost)); }
    public static int interval() { return Math.max(100,Math.min(72000,MobGeneratorConfig.interval)); }
    public static int limit() { return Math.max(1,Math.min(24,MobGeneratorConfig.nearbyLimit)); }
    IItemHandler items() { return items; }
    ItemStack drainCard() {
        ItemStack s=inventory.getStackInSlot(0).copy();
        inventory.setStackInSlot(0,ItemStack.EMPTY); return s;
    }
    private boolean areaLoaded() {
        // Also covers all collision/spawn checks around the allowlisted vanilla entities.
        // AABB starts at pos and ends at pos+1; vanilla entity lookup extends it by two more blocks.
        int minX=(pos.getX()-RADIUS-2)>>4, maxX=(pos.getX()+RADIUS+3)>>4;
        int minZ=(pos.getZ()-RADIUS-2)>>4, maxZ=(pos.getZ()+RADIUS+3)>>4;
        for (int x=minX;x<=maxX;x++) for (int z=minZ;z<=maxZ;z++)
            if (!world.isBlockLoaded(new BlockPos((x<<4),pos.getY(),(z<<4)))) return false;
        return pos.getY()>=1 && pos.getY()<=250;
    }
    static boolean permitted(ResourceLocation id) {
        if (id==null) return false;
        String text=id.toString();
        return text.startsWith("minecraft:") && SAFE.contains(text.substring("minecraft:".length()));
    }
    private static boolean vanillaClass(ResourceLocation id,Entity e) {
        switch (id.toString()) {
        case "minecraft:pig": return e.getClass()==net.minecraft.entity.passive.EntityPig.class;
        case "minecraft:cow": return e.getClass()==net.minecraft.entity.passive.EntityCow.class;
        case "minecraft:sheep": return e.getClass()==net.minecraft.entity.passive.EntitySheep.class;
        case "minecraft:chicken": return e.getClass()==net.minecraft.entity.passive.EntityChicken.class;
        case "minecraft:rabbit": return e.getClass()==net.minecraft.entity.passive.EntityRabbit.class;
        case "minecraft:zombie": return e.getClass()==net.minecraft.entity.monster.EntityZombie.class;
        case "minecraft:skeleton": return e.getClass()==net.minecraft.entity.monster.EntitySkeleton.class;
        case "minecraft:creeper": return e.getClass()==net.minecraft.entity.monster.EntityCreeper.class;
        case "minecraft:spider": return e.getClass()==net.minecraft.entity.monster.EntitySpider.class;
        case "minecraft:slime": return e.getClass()==net.minecraft.entity.monster.EntitySlime.class;
        case "minecraft:magma_cube": return e.getClass()==net.minecraft.entity.monster.EntityMagmaCube.class;
        case "minecraft:enderman": return e.getClass()==net.minecraft.entity.monster.EntityEnderman.class;
        case "minecraft:blaze": return e.getClass()==net.minecraft.entity.monster.EntityBlaze.class;
        case "minecraft:witch": return e.getClass()==net.minecraft.entity.monster.EntityWitch.class;
        case "minecraft:cave_spider": return e.getClass()==net.minecraft.entity.monster.EntityCaveSpider.class;
        case "minecraft:ghast": return e.getClass()==net.minecraft.entity.monster.EntityGhast.class;
        default: return false;
        }
    }
    @Override public void update() {
        if (!live() || busy) return;
        if (cooldown>0) { cooldown--; if (cooldown%20==0) markDirty(); if (cooldown>0) return; }
        cooldown=interval(); markDirty();
        if (energy<cost() || !areaLoaded()) return;
        ItemStack card=inventory.getStackInSlot(0);
        if (!validCard(card) || !MobCardItem.isReady(card)) return;
        ResourceLocation id=MobCardItem.getMob(card);
        if (!permitted(id)) return;
        World w=world; BlockPos p=pos.toImmutable();
        AxisAlignedBB bounds=new AxisAlignedBB(p).grow(RADIUS);
        if (w.getEntitiesWithinAABB(EntityLiving.class,bounds).size()>=limit()) return;
        busy=true;
        try {
            Entity candidate=EntityList.createEntityByIDFromName(id,w);
            if (!(candidate instanceof EntityLiving) || candidate instanceof EntityPlayer || !vanillaClass(id,candidate)) return;
            EntityLiving mob=(EntityLiving)candidate;
            if (mob instanceof IMob && w.getDifficulty()==EnumDifficulty.PEACEFUL) return;
            mob.setLocationAndAngles(p.getX()+.5,p.getY()+1,p.getZ()+.5,0,0);
            // Apply the vanilla slime size before testing its final collision box.
            if (mob instanceof net.minecraft.entity.monster.EntitySlime) mob.onInitialSpawn(w.getDifficultyForLocation(p.up()), null);
            if (mob.getClass()==net.minecraft.entity.monster.EntitySkeleton.class) mob.setItemStackToSlot(net.minecraft.inventory.EntityEquipmentSlot.MAINHAND, new ItemStack(net.minecraft.init.Items.BOW));
            if (!mob.isNotColliding()) return;
            if (!live() || world!=w || !pos.equals(p) || !areaLoaded() || energy<cost()) return;
            // Reserve before invoking spawn events; capability and inventory are locked against re-entry.
            int charge=cost(); energy-=charge; markDirty();
            boolean spawned=false;
            try { spawned=w.spawnEntity(mob); }
            finally {
                // In case a foreign event throws after adding it, never refund an existing entity.
                if (!spawned && !w.loadedEntityList.contains(mob) && live() && world==w && pos.equals(p)) {
                    energy=Math.min(CAPACITY,energy+charge); markDirty();
                }
            }
        } finally { busy=false; }
    }
    @Override public boolean hasCapability(Capability<?> cap,@Nullable EnumFacing side) {
        return cap==CapabilityEnergy.ENERGY || cap==CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability(cap,side);
    }
    @Nullable @Override public <T> T getCapability(Capability<T> cap,@Nullable EnumFacing side) {
        if (cap==CapabilityEnergy.ENERGY) return CapabilityEnergy.ENERGY.cast(power);
        if (cap==CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(items);
        return super.getCapability(cap,side);
    }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound n) {
        super.writeToNBT(n); n.setInteger("Energy",energy); n.setInteger("Cooldown",cooldown); n.setTag("Card",inventory.serializeNBT()); return n;
    }
    @Override public void readFromNBT(NBTTagCompound n) {
        super.readFromNBT(n); energy=Math.max(0,Math.min(CAPACITY,n.getInteger("Energy")));
        cooldown=Math.max(0,Math.min(72000,n.getInteger("Cooldown")));
        // Never trust a serialized handler Size (which can allocate huge arrays or remove slot 0).
        net.minecraft.nbt.NBTTagList list=n.getCompoundTag("Card").getTagList("Items",10);
        ItemStack s=ItemStack.EMPTY;
        if (list.tagCount()==1 && list.getCompoundTagAt(0).getInteger("Slot")==0)
            s=new ItemStack(list.getCompoundTagAt(0));
        if (!validCard(s) || s.getCount()!=1) s=ItemStack.EMPTY;
        inventory.setStackInSlot(0,s);
    }
    @Override public NBTTagCompound getUpdateTag() { return writeToNBT(new NBTTagCompound()); }
    @Nullable @Override public SPacketUpdateTileEntity getUpdatePacket() { return new SPacketUpdateTileEntity(pos,0,getUpdateTag()); }
    @Override public void onDataPacket(NetworkManager n,SPacketUpdateTileEntity pkt) { readFromNBT(pkt.getNbtCompound()); }
    void setClientEnergy(int n) { if (world!=null && world.isRemote) energy=n; }
}
