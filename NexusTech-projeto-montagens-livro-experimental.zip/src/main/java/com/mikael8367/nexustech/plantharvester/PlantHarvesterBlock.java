package com.mikael8367.nexustech.plantharvester;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class PlantHarvesterBlock extends Block {
 PlantHarvesterBlock() { super(Material.IRON); setRegistryName(NexusTech.MODID,"plant_harvester"); setUnlocalizedName(NexusTech.MODID+".plant_harvester"); setCreativeTab(NexusTech.CREATIVE_TAB); setHardness(3); setResistance(10); setHarvestLevel("pickaxe",1); }
 @Override public boolean hasTileEntity(IBlockState s) { return true; }
 @Override public TileEntity createTileEntity(World w,IBlockState s) { return new PlantHarvesterTile(); }
 @Override public void onBlockPlacedBy(World w,BlockPos p,IBlockState s,EntityLivingBase e,ItemStack stack) { if (!w.isRemote && e instanceof EntityPlayer && w.getTileEntity(p) instanceof PlantHarvesterTile) ((PlantHarvesterTile)w.getTileEntity(p)).setOwner((EntityPlayer)e); }
 @Override public boolean onBlockActivated(World w,BlockPos p,IBlockState s,EntityPlayer player,EnumHand hand,EnumFacing side,float x,float y,float z) { if (!w.isRemote && hand==EnumHand.MAIN_HAND && w.getTileEntity(p) instanceof PlantHarvesterTile) { PlantHarvesterTile tile=(PlantHarvesterTile)w.getTileEntity(p); if(tile.authorized(player)&&!tile.recoveryInteraction(player,player.isSneaking()))player.openGui(NexusTech.INSTANCE,PlantHarvesterRegistry.GUI_ID,w,p.getX(),p.getY(),p.getZ()); } return true; }
 @Override public void breakBlock(World w,BlockPos p,IBlockState s) { TileEntity te=w.getTileEntity(p); if (!w.isRemote && te instanceof PlantHarvesterTile) ((PlantHarvesterTile)te).removed(); super.breakBlock(w,p,s); }
}
