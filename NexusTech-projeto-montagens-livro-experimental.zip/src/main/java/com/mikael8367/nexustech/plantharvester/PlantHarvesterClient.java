package com.mikael8367.nexustech.plantharvester;
import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT) @Mod.EventBusSubscriber(modid=NexusTech.MODID,value=Side.CLIENT)
public final class PlantHarvesterClient {
 private PlantHarvesterClient(){}
 @SubscribeEvent public static void models(ModelRegistryEvent e){Item block=Item.getItemFromBlock(PlantHarvesterRegistry.BLOCK);ModelLoader.setCustomModelResourceLocation(block,0,new ModelResourceLocation(block.getRegistryName(),"inventory"));Item u=PlantHarvesterRegistry.UPGRADE;ModelLoader.setCustomModelResourceLocation(u,0,new ModelResourceLocation(u.getRegistryName(),"inventory"));}
 public static Object gui(int id,EntityPlayer p,World w,int x,int y,int z){BlockPos pos=new BlockPos(x,y,z);if(id!=PlantHarvesterRegistry.GUI_ID||!w.isBlockLoaded(pos))return null;TileEntity t=w.getTileEntity(pos);return t instanceof PlantHarvesterTile?new PlantHarvesterGui(p.inventory,(PlantHarvesterTile)t):null;}
}
