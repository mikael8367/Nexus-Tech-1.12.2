package com.mikael8367.nexustech.plantharvester;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;

public final class PlantHarvesterContainer extends Container {
 final PlantHarvesterTile tile; private int last=-1;
 PlantHarvesterContainer(InventoryPlayer player,PlantHarvesterTile tile){this.tile=tile;
  for(int r=0;r<3;r++)for(int c=0;c<9;c++)addSlotToContainer(new SlotItemHandler(tile.inv,r*9+c,8+c*18,30+r*18){@Override public boolean isItemValid(ItemStack s){return false;} @Override public int getItemStackLimit(ItemStack s){return Math.min(64,s.getMaxStackSize());}});
  addSlotToContainer(new SlotItemHandler(tile.inv,27,152,94){@Override public boolean isItemValid(ItemStack s){return s.getItem()==PlantHarvesterRegistry.UPGRADE;} @Override public int getSlotStackLimit(){return 50;} @Override public int getItemStackLimit(ItemStack s){return Math.min(50,s.getMaxStackSize());}});
  for(int r=0;r<3;r++)for(int c=0;c<9;c++)addSlotToContainer(new Slot(player,9+c+r*9,8+c*18,132+r*18));
  for(int c=0;c<9;c++)addSlotToContainer(new Slot(player,c,8+c*18,190));
 }
 @Override public boolean canInteractWith(EntityPlayer p){return !tile.busy&&tile.getWorld()!=null&&p.world==tile.getWorld()&&!tile.isInvalid()&&tile.getWorld().isBlockLoaded(tile.getPos())&&tile.getWorld().getTileEntity(tile.getPos())==tile&&(p.world.isRemote||tile.authorized(p))&&p.getDistanceSq(tile.getPos().getX()+.5,tile.getPos().getY()+.5,tile.getPos().getZ()+.5)<=64;}
 @Override public ItemStack slotClick(int i,int drag,net.minecraft.inventory.ClickType type,EntityPlayer p){
  if(tile.getWorld()!=null&&tile.getWorld().isRemote)return super.slotClick(i,drag,type,p);
  if(type==net.minecraft.inventory.ClickType.QUICK_MOVE)return transferStackInSlot(p,i);
  if(!canInteractWith(p)||!tile.beginOperation())return ItemStack.EMPTY;
  try{return super.slotClick(i,drag,type,p);}finally{tile.endOperation();}
 }
 @Override public ItemStack transferStackInSlot(EntityPlayer p,int i){
  if(tile.getWorld()!=null&&tile.getWorld().isRemote)return transferImpl(p,i);
  if(!canInteractWith(p)||!tile.beginOperation())return ItemStack.EMPTY;
  try{return transferImpl(p,i);}finally{tile.endOperation();}
 }
 private ItemStack transferImpl(EntityPlayer p,int i){
  if(i<0||i>=inventorySlots.size())return ItemStack.EMPTY;Slot slot=inventorySlots.get(i);if(!slot.getHasStack())return ItemStack.EMPTY;
  ItemStack s=slot.getStack(),old=s.copy();
  if(i<28){if(!mergeItemStack(s,28,64,true))return ItemStack.EMPTY;}
  else if(s.getItem()==PlantHarvesterRegistry.UPGRADE){
   // Use the handler's own limit for the upgrade slot.
   ItemStack left=tile.inv.insertItem(27,s.copy(),false);int moved=s.getCount()-left.getCount();if(moved<=0)return ItemStack.EMPTY;s.shrink(moved);
  }else if(i<55){if(!mergeItemStack(s,55,64,false))return ItemStack.EMPTY;}
  else if(!mergeItemStack(s,28,55,false))return ItemStack.EMPTY;
  if(s.isEmpty())slot.putStack(ItemStack.EMPTY);else slot.onSlotChanged();tile.markDirty();
  if(s.getCount()==old.getCount())return ItemStack.EMPTY;slot.onTake(p,s);return old;
 }
 @Override public void addListener(IContainerListener l){super.addListener(l);l.sendWindowProperty(this,0,tile.energy&65535);l.sendWindowProperty(this,1,tile.energy>>>16);}
 @Override public void detectAndSendChanges(){super.detectAndSendChanges();if(last!=tile.energy){for(IContainerListener l:listeners){l.sendWindowProperty(this,0,tile.energy&65535);l.sendWindowProperty(this,1,tile.energy>>>16);}last=tile.energy;}}
 @Override public void updateProgressBar(int id,int v){if(id==0)tile.energy=(tile.energy&0xffff0000)|(v&65535);if(id==1)tile.energy=(tile.energy&65535)|((v&65535)<<16);}
}
