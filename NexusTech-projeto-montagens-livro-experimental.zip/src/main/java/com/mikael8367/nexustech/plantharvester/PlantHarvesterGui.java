package com.mikael8367.nexustech.plantharvester;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)
public final class PlantHarvesterGui extends GuiContainer {
 private final PlantHarvesterTile tile;
 public PlantHarvesterGui(InventoryPlayer p,PlantHarvesterTile t){super(new PlantHarvesterContainer(p,t));tile=t;xSize=176;ySize=214;}
 @Override protected void drawGuiContainerForegroundLayer(int x,int y){fontRenderer.drawString(I18n.format("tile.nexustech.plant_harvester.name"),8,6,0x404040);fontRenderer.drawString("FE: "+tile.energy+" / "+PlantHarvesterTile.CAPACITY,8,18,0x404040);fontRenderer.drawString(I18n.format("plantharvester.upgrades",tile.upgrades()),8,99,0x404040);}
 @Override protected void drawGuiContainerBackgroundLayer(float partial,int x,int y){drawRect(guiLeft,guiTop,guiLeft+176,guiTop+214,0xff373737);drawRect(guiLeft+2,guiTop+2,guiLeft+174,guiTop+212,0xffc6c6c6);for(int r=0;r<3;r++)for(int c=0;c<9;c++){slot(8+c*18,30+r*18);slot(8+c*18,132+r*18);}slot(152,94);for(int c=0;c<9;c++)slot(8+c*18,190);}
 private void slot(int x,int y){drawRect(guiLeft+x-1,guiTop+y-1,guiLeft+x+17,guiTop+y+17,0xff555555);drawRect(guiLeft+x,guiTop+y,guiLeft+x+16,guiTop+y+16,0xff8b8b8b);}
 @Override public void drawScreen(int x,int y,float p){drawDefaultBackground();super.drawScreen(x,y,p);renderHoveredToolTip(x,y);}
}
