package com.mikael8367.nexustech.plantharvester;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
public final class PlantHarvesterGuiHooks {
 private PlantHarvesterGuiHooks(){}
 public static Object server(int id,EntityPlayer p,World w,int x,int y,int z){BlockPos pos=new BlockPos(x,y,z);if(id!=PlantHarvesterRegistry.GUI_ID||!w.isBlockLoaded(pos))return null;TileEntity t=w.getTileEntity(pos);if(!(t instanceof PlantHarvesterTile))return null;PlantHarvesterContainer c=new PlantHarvesterContainer(p.inventory,(PlantHarvesterTile)t);return c.canInteractWith(p)?c:null;}
}
