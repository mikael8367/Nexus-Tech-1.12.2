package com.mikael8367.nexustech.plantharvester;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid=NexusTech.MODID)
public final class PlantHarvesterRegistry {
 public static final int GUI_ID=8373;
 public static final PlantHarvesterBlock BLOCK=new PlantHarvesterBlock();
 public static final Item UPGRADE=new Item().setRegistryName(NexusTech.MODID,"plant_harvester_upgrade").setUnlocalizedName(NexusTech.MODID+".plant_harvester_upgrade").setCreativeTab(NexusTech.CREATIVE_TAB);
 private PlantHarvesterRegistry() {}
 @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> e) {
  e.getRegistry().register(BLOCK);
  GameRegistry.registerTileEntity(PlantHarvesterTile.class,new ResourceLocation(NexusTech.MODID,"plant_harvester"));
 }
 @SubscribeEvent public static void items(RegistryEvent.Register<Item> e) {
  e.getRegistry().register(new ItemBlock(BLOCK).setRegistryName(BLOCK.getRegistryName())); e.getRegistry().register(UPGRADE);
 }
}
