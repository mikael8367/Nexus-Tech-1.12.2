package com.mikael8367.nexustech.plantharvester;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;
import java.nio.charset.StandardCharsets;
import javax.annotation.Nullable;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.IPlantable;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Bounded, server-only crop harvesting. Unknown/unsafe crops are skipped. */
public final class PlantHarvesterTile extends TileEntity implements ITickable {
 private static final Logger LOG=LogManager.getLogger("NexusTech/PlantHarvester");
 static final int CAPACITY=100000, COST=200, RADIUS=4, OUTPUT=27, UPGRADE_SLOT=27;
 int energy, cursor, delay, pushSource; final int[] pushCursor=new int[6]; boolean busy, removal; private UUID owner; private String ownerName="";
 private final List<ItemStack> pending=new ArrayList<>();
 private ItemStack uncertain=ItemStack.EMPTY; private BlockPos uncertainAt;
 private UUID recoveryConfirmation;
 private int failureLogCooldown;
 public final ItemStackHandler inv=new ItemStackHandler(28) {
  @Override public boolean isItemValid(int slot,ItemStack stack) { return slot>=0 && (slot<OUTPUT || (slot==UPGRADE_SLOT && !stack.isEmpty() && stack.getItem()==PlantHarvesterRegistry.UPGRADE)); }
  // Forge 1.12 ItemStackHandler.insertItem does not consult isItemValid.
  @Override public ItemStack insertItem(int slot,ItemStack stack,boolean simulate) { return isItemValid(slot,stack)?super.insertItem(slot,stack,simulate):stack; }
  @Override public int getSlotLimit(int slot) { return slot==UPGRADE_SLOT?50:64; }
  @Override protected void onContentsChanged(int slot) { markDirty(); }
 };
 private final IEnergyStorage storage=new IEnergyStorage() {
  public int receiveEnergy(int amount,boolean simulate) { if(!live()||busy||amount<=0)return 0; int n=Math.min(Math.min(amount,2000),CAPACITY-energy); if(!simulate&&n>0){energy+=n;markDirty();} return n; }
  public int extractEnergy(int amount,boolean simulate){return 0;}
  public int getEnergyStored(){return energy;} public int getMaxEnergyStored(){return CAPACITY;}
  public boolean canExtract(){return false;} public boolean canReceive(){return true;}
 };
 // Expose only output extraction; return copies and block callback reentry.
 private final IItemHandler outputHandler=new IItemHandler() {
  public int getSlots(){return OUTPUT;}
  public ItemStack getStackInSlot(int slot){return slot>=0&&slot<OUTPUT&&live()&&!busy?inv.getStackInSlot(slot).copy():ItemStack.EMPTY;}
  public int getSlotLimit(int slot){return 64;}
  public ItemStack insertItem(int slot,ItemStack stack,boolean simulate){return stack;}
  public ItemStack extractItem(int slot,int amount,boolean simulate){
   if(!live()||busy||slot<0||slot>=OUTPUT||amount<=0)return ItemStack.EMPTY;
   busy=true;try{return inv.extractItem(slot,amount,simulate);}finally{busy=false;finishRemoval();}
  }
 };
 boolean beginOperation(){if(!live()||busy)return false;busy=true;return true;}
 void endOperation(){busy=false;finishRemoval();}
 void setOwner(EntityPlayer p){owner=p.getUniqueID();ownerName=p.getName();markDirty();}
 boolean authorized(EntityPlayer p){return owner!=null && (owner.equals(p.getUniqueID())||p.canUseCommand(2,""));}
 boolean recoveryInteraction(EntityPlayer p, boolean confirm) {
  if(!authorized(p)||!live()||busy||uncertain.isEmpty())return false;
  if(!confirm){recoveryConfirmation=null;p.sendMessage(new TextComponentString("Colhedora: transferência incerta de "+uncertain.getCount()+"x "+uncertain.getItem().getRegistryName()+" para "+(uncertainAt==null?"local desconhecido":uncertainAt.toString())+". Saída automática pausada. Confira o destino; agache e interaja duas vezes para guardar a evidência e liberar a saída, sem devolver itens."));return false;}
  if(!p.getUniqueID().equals(recoveryConfirmation)){recoveryConfirmation=p.getUniqueID();p.sendMessage(new TextComponentString("Colhedora: confira o destino. Agache e interaja novamente para confirmar a quarentena; nenhum item será devolvido."));return true;}
  busy=true;try {PlantHarvesterRecovery.get(world).quarantine(uncertainAt==null?pos:uncertainAt,uncertain);uncertain=ItemStack.EMPTY;uncertainAt=null;recoveryConfirmation=null;markDirty();p.sendMessage(new TextComponentString("Colhedora: evidência guardada em quarentena; saída liberada. Nenhum item foi devolvido."));}finally{busy=false;finishRemoval();}return true;
 }
 static GameProfile machineProfile(UUID owner,int dimension,BlockPos machine) {
  UUID id=UUID.nameUUIDFromBytes(("nexustech:plant_harvester:"+owner+":"+dimension+":"+machine.toLong()).getBytes(StandardCharsets.UTF_8));
  return new GameProfile(id,"NT"+id.toString().replace("-","").substring(0,14));
 }
 static final class MachinePlayer extends FakePlayer {
  MachinePlayer(WorldServer world,GameProfile profile){super(world,profile);}
  // Forge 1.12 FakePlayer returns (0,0,0) regardless of setPosition.
  @Override public Vec3d getPositionVector(){return new Vec3d(posX,posY,posZ);}
 }
 // EntityPlayerMP's constructor calls the provider's randomized spawn and collision
 // checks. Preflight their whole vanilla spawn-fuzz area without loading chunks;
 // custom providers/types have unknown constructor behavior and fail closed.
 static boolean safeFakeConstruction(WorldServer w) {
  Class<?> provider=w.provider.getClass();
  if(provider!=net.minecraft.world.WorldProviderSurface.class && provider!=net.minecraft.world.WorldProviderHell.class && provider!=net.minecraft.world.WorldProviderEnd.class)return false;
  net.minecraft.world.WorldType type=w.getWorldType();
  if(type!=net.minecraft.world.WorldType.DEFAULT && type!=net.minecraft.world.WorldType.FLAT && type!=net.minecraft.world.WorldType.LARGE_BIOMES && type!=net.minecraft.world.WorldType.AMPLIFIED && type!=net.minecraft.world.WorldType.CUSTOMIZED && type!=net.minecraft.world.WorldType.DEBUG_ALL_BLOCK_STATES && type!=net.minecraft.world.WorldType.DEFAULT_1_1)return false;
  BlockPos spawn=w.provider.getSpawnPoint();
  if(!w.getWorldBorder().contains(spawn))return false;
  int fuzz=type.getSpawnFuzz(w,w.getMinecraftServer());
  if(fuzz<0||fuzz>64)return false;
  int r=fuzz+16;
  return w.isAreaLoaded(new BlockPos(spawn.getX()-r,0,spawn.getZ()-r),new BlockPos(spawn.getX()+r,255,spawn.getZ()+r));
 }
 static FakePlayer machinePlayer(WorldServer world,GameProfile profile,BlockPos target) {
  FakePlayer player=new MachinePlayer(world,profile);
  player.setPosition(target.getX()+.5,target.getY()+.5,target.getZ()+.5);return player;
 }
 static IBlockState replantState(net.minecraft.world.World world,BlockPos p,BlockCrops crop,IPlantable plant) {
  // getPlant is foreign code and may read both positions.
  if(!world.isBlockLoaded(p)||!world.isBlockLoaded(p.down()))return null;
  IBlockState state=plant.getPlant(world,p);
  if(!world.isBlockLoaded(p)||!world.isBlockLoaded(p.down())||state==null||state.getBlock()!=crop||crop.hasTileEntity(state)||crop.isMaxAge(state))return null;
  IBlockState soil=world.getBlockState(p.down());
  if(!soil.getBlock().canSustainPlant(soil,world,p.down(),EnumFacing.UP,plant))return null;
  return world.isBlockLoaded(p)&&world.isBlockLoaded(p.down())&&world.getBlockState(p.down())==soil?state:null;
 }
 boolean live(){return world!=null&&!world.isRemote&&!isInvalid()&&!removal&&world.isBlockLoaded(pos)&&world.getTileEntity(pos)==this;}
 int upgrades(){ItemStack s=inv.getStackInSlot(UPGRADE_SLOT);return s.isEmpty()||s.getItem()!=PlantHarvesterRegistry.UPGRADE?0:Math.min(50,s.getCount());}
 int period(){return 20-upgrades()*15/50;}
 @Override public boolean hasCapability(Capability<?> c,@Nullable EnumFacing side){return c==CapabilityEnergy.ENERGY||c==CapabilityItemHandler.ITEM_HANDLER_CAPABILITY||super.hasCapability(c,side);}
 @Override public <T> T getCapability(Capability<T> c,@Nullable EnumFacing side){if(c==CapabilityEnergy.ENERGY)return CapabilityEnergy.ENERGY.cast(storage);if(c==CapabilityItemHandler.ITEM_HANDLER_CAPABILITY)return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(outputHandler);return super.getCapability(c,side);}
 @Override public void update(){
  if(!live()||busy||owner==null)return;
  busy=true; try {
   if(failureLogCooldown>0)failureLogCooldown--;
   // Pending after an interrupted transaction is ambiguous; never replay it.
   if(!pending.isEmpty()){for(ItemStack s:pending)PlantHarvesterRecovery.get(world).quarantine(pos,s);pending.clear();markDirty();if(!live())return;}
   pushOne(); if(!live())return;
   if(delay>0){delay--;return;} delay=period()-1;
   if(energy<COST||!world.getGameRules().getBoolean("doTileDrops"))return;
   for(int budget=0;budget<8&&live();budget++){
    int n=cursor; cursor=(cursor+1)%81; markDirty();
    BlockPos target=pos.add(n%9-RADIUS,0,n/9-RADIUS);
    try {
     if(target.equals(pos)||!world.isBlockLoaded(target)||!world.isBlockLoaded(target.down())||!world.getWorldBorder().contains(target))continue;
     IBlockState state=world.getBlockState(target);
     if(!(state.getBlock() instanceof BlockCrops)||state.getBlock().hasTileEntity(state)||world.getTileEntity(target)!=null)continue;
     BlockCrops crop=(BlockCrops)state.getBlock();
     if(crop.isMaxAge(state)&&harvest(target,state,crop))break;
    } catch(RuntimeException ex) {
     // Foreign block/event code may throw after side effects. Stop this tick;
     // reserved outputs, if any, are quarantined on the next tick or removal.
     if(failureLogCooldown==0){LOG.warn("Harvest failed at {} (machine {}); ambiguous outputs will not be replayed",target,pos,ex);failureLogCooldown=200;}
     break;
    }
   }
  } finally {busy=false;finishRemoval();}
 }
 private boolean valid(BlockPos p,IBlockState s){return live()&&energy>=COST&&world.isBlockLoaded(p)&&world.isBlockLoaded(p.down())&&world.getBlockState(p)==s;}
 private boolean harvest(BlockPos p,IBlockState mature,BlockCrops crop){
  if(!(world instanceof WorldServer)||!valid(p,mature)||!safeFakeConstruction((WorldServer)world))return false;
  FakePlayer fake=machinePlayer((WorldServer)world,machineProfile(owner,world.provider.getDimension(),pos),p);
  if(!world.isBlockModifiable(fake,p))return false;
  BlockEvent.BreakEvent be=new BlockEvent.BreakEvent(world,p,mature,fake);
  if(MinecraftForge.EVENT_BUS.post(be)||!valid(p,mature))return false;
  NonNullList<ItemStack> drops=NonNullList.create(); crop.getDrops(drops,world,p,mature,0);
  if(!valid(p,mature))return false;
  float chance=ForgeEventFactory.fireBlockHarvesting(drops,world,p,mature,0,1.0F,false,fake);
  if(!valid(p,mature))return false;
  if(drops.size()>256)return false;
  List<ItemStack> chosen=new ArrayList<>();
  for(ItemStack d:drops)if(d!=null&&!d.isEmpty()&&world.rand.nextFloat()<chance)chosen.add(d.copy());
  ItemStack seed=ItemStack.EMPTY; IBlockState young=null;
  for(ItemStack d:chosen){
   if(!(d.getItem() instanceof IPlantable))continue;
   IPlantable plant=(IPlantable)d.getItem(); IBlockState plantState=replantState(world,p,crop,plant);
   if(!valid(p,mature)||plantState==null||plantState==mature)continue;
   young=plantState;seed=d.copy(); seed.setCount(1); d.shrink(1); break;
  }
  if(seed.isEmpty()||young==null||!valid(p,mature)||!fits(chosen))return false;
  // Synthetic preflight: event sees the existing mature state, because the crop
  // is reset in-place rather than removed and replaced. Cancellation fails closed.
  BlockSnapshot snapshot=new BlockSnapshot(world,p,mature);
  BlockEvent.PlaceEvent pe=new BlockEvent.PlaceEvent(snapshot,world.getBlockState(p.down()),fake,EnumHand.MAIN_HAND);
  if(MinecraftForge.EVENT_BUS.post(pe)||!valid(p,mature)||!world.isBlockModifiable(fake,p))return false;
  // Listeners may have changed the soil or the seed's planting behavior.
  if(replantState(world,p,crop,(IPlantable)seed.getItem())!=young||!valid(p,mature))return false;
  // Queue before state change: reentrant controller removal is deferred.
  for(ItemStack d:chosen)if(!d.isEmpty())pending.add(d.copy());
  energy-=COST; markDirty();
  // markDirty may invoke foreign callbacks and remove or replace the tile.
  if(!live()||!world.isBlockLoaded(p)||!world.isBlockLoaded(p.down())||world.getBlockState(p)!=mature
    ||replantState(world,p,crop,(IPlantable)seed.getItem())!=young
    ||!live()||!world.isBlockLoaded(p)||!world.isBlockLoaded(p.down())||world.getBlockState(p)!=mature){pending.clear();energy=Math.min(CAPACITY,energy+COST);markDirty();return false;}
  boolean changed=world.setBlockState(p,young,3);
  if(!changed){ pending.clear(); energy=Math.min(CAPACITY,energy+COST); markDirty(); return false; }
  // A callback could have replaced or unloaded the crop. Withhold outputs in
  // that case rather than manufacture drops from an unverified mutation.
  if(!world.isBlockLoaded(p)||world.getBlockState(p)!=young){pending.clear();return false;}
  flushPending(); return true;
 }
 private boolean fits(List<ItemStack> items){ItemStackHandler copy=new ItemStackHandler(OUTPUT); for(int i=0;i<OUTPUT;i++)copy.setStackInSlot(i,inv.getStackInSlot(i).copy()); for(ItemStack d:items){ItemStack left=d.copy();for(int i=0;i<OUTPUT&&!left.isEmpty();i++)left=copy.insertItem(i,left,false); if(!left.isEmpty())return false;}return true;}
 private void flushPending(){for(ItemStack d:pending){ItemStack left=d.copy();for(int i=0;i<OUTPUT&&!left.isEmpty();i++)left=inv.insertItem(i,left,false); if(!left.isEmpty())PlantHarvesterRecovery.get(world).enqueue(pos,left);}pending.clear();markDirty();}
 // A reservation and persistent quarantine prevent replay after a broken or
 // throwing foreign handler. No retry of an ambiguous insertion is safe.
 private void pushOne(){
  if(!uncertain.isEmpty())return;
  int source=-1;for(int i=0;i<OUTPUT;i++){int n=(pushSource+i)%OUTPUT;if(!inv.getStackInSlot(n).isEmpty()){source=n;break;}} if(source<0)return; pushSource=(source+1)%OUTPUT;
  for(EnumFacing face:EnumFacing.VALUES){
   BlockPos q=pos.offset(face);if(!world.isBlockLoaded(q))continue;TileEntity t=world.getTileEntity(q);if(t==null||t==this||t.isInvalid())continue;
   try {IItemHandler h=t.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,face.getOpposite()); if(h==null||!live()||world.getTileEntity(q)!=t)continue; int count=Math.min(256,h.getSlots());
    if(count<=0)continue; int start=Math.floorMod(pushCursor[face.ordinal()]++,count);
    for(int k=0;k<Math.min(2,count)&&live();k++){int slot=(start+k)%count;
     ItemStack original=inv.getStackInSlot(source).copy();if(original.isEmpty())return;
     recoveryConfirmation=null;uncertain=inv.extractItem(source,original.getCount(),false);uncertainAt=q;markDirty();
     // Extraction/dirty callbacks may have removed the controller. Do not
     // start a foreign transfer after removal; return the reserved stack first.
     if(!live()||world.getTileEntity(q)!=t||t.isInvalid()){
      ItemStack reserved=uncertain;uncertain=ItemStack.EMPTY;uncertainAt=null;
      ItemStack left=inv.insertItem(source,reserved,false);if(!left.isEmpty())PlantHarvesterRecovery.get(world).enqueue(pos,left);
      markDirty();return;
     }
     ItemStack arg=uncertain.copy(); ItemStack left=h.insertItem(slot,arg,false);
     if(left==null||!ItemStack.areItemStacksEqual(arg,uncertain)||(!left.isEmpty()&&(!left.isItemEqual(uncertain)||!ItemStack.areItemStackTagsEqual(left,uncertain)||left.getCount()>uncertain.getCount())))return;
     int accepted=uncertain.getCount()-left.getCount();
     if(!left.isEmpty()){ItemStack remainder=inv.insertItem(source,left.copy(),false);if(!remainder.isEmpty())PlantHarvesterRecovery.get(world).enqueue(pos,remainder);}
     uncertain=ItemStack.EMPTY;uncertainAt=null;markDirty();
     if(accepted>0||!live())return;
    }
   }catch(RuntimeException ex){return;}
  }
 }
 void removed(){removal=true;if(!busy)finishRemoval();}
 private void finishRemoval(){if(!removal||world==null||world.isRemote)return; PlantHarvesterRecovery recovery=PlantHarvesterRecovery.get(world);for(int i=0;i<inv.getSlots();i++){ItemStack s=inv.extractItem(i,64,false);if(!s.isEmpty())recovery.enqueue(pos,s);}for(ItemStack s:pending)recovery.quarantine(pos,s);pending.clear();if(!uncertain.isEmpty()){recovery.quarantine(uncertainAt==null?pos:uncertainAt,uncertain);uncertain=ItemStack.EMPTY;}removal=false;}
 @Override public NBTTagCompound writeToNBT(NBTTagCompound n){super.writeToNBT(n);n.setInteger("Energy",energy);n.setInteger("Cursor",cursor);n.setInteger("Delay",delay);n.setTag("Inventory",inv.serializeNBT());if(owner!=null){n.setUniqueId("Owner",owner);n.setString("OwnerName",ownerName);}NBTTagList list=new NBTTagList();for(ItemStack s:pending)list.appendTag(s.writeToNBT(new NBTTagCompound()));n.setTag("Pending",list);if(!uncertain.isEmpty()){n.setTag("Uncertain",uncertain.writeToNBT(new NBTTagCompound()));if(uncertainAt!=null)n.setLong("UncertainPos",uncertainAt.toLong());}return n;}
 @Override public void readFromNBT(NBTTagCompound n){super.readFromNBT(n);energy=Math.max(0,Math.min(CAPACITY,n.getInteger("Energy")));cursor=Math.floorMod(n.getInteger("Cursor"),81);delay=Math.max(0,Math.min(20,n.getInteger("Delay")));NBTTagCompound inventory=n.getCompoundTag("Inventory").copy();inventory.setInteger("Size",28);inv.deserializeNBT(inventory);owner=n.hasUniqueId("Owner")?n.getUniqueId("Owner"):null;ownerName=n.getString("OwnerName");pending.clear();NBTTagList l=n.getTagList("Pending",10);for(int i=0;i<l.tagCount()&&i<256;i++){ItemStack s=new ItemStack(l.getCompoundTagAt(i));if(!s.isEmpty())pending.add(s);}uncertain=n.hasKey("Uncertain",10)?new ItemStack(n.getCompoundTag("Uncertain")):ItemStack.EMPTY;uncertainAt=n.hasKey("UncertainPos")?BlockPos.fromLong(n.getLong("UncertainPos")):null;}
}
