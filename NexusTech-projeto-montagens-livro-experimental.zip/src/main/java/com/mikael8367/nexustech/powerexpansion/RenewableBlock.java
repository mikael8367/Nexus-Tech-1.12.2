package com.mikael8367.nexustech.powerexpansion;

import com.mikael8367.nexustech.NexusTech;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Normal block drops carry no energy; breaking or explosions lose the buffer. */
public final class RenewableBlock extends Block {
    private final boolean wind;
    RenewableBlock(String name, boolean wind) {
        super(Material.IRON);
        this.wind = wind;
        setRegistryName(NexusTech.MODID, name);
        setUnlocalizedName(NexusTech.MODID + "." + name);
        setCreativeTab(NexusTech.CREATIVE_TAB);
        setHardness(3.0F); setResistance(10.0F);
    }
    @Override public boolean hasTileEntity(IBlockState state) { return true; }
    @Override public TileEntity createTileEntity(World world, IBlockState state) {
        return wind ? new RenewableTile.Wind() : new RenewableTile.Hydro();
    }
    @Override public void onBlockPlacedBy(World world, BlockPos pos, IBlockState state,
                                          @Nullable EntityLivingBase placer, ItemStack stack) {
        super.onBlockPlacedBy(world, pos, state, placer, stack);
        if (!world.isRemote && world.isBlockLoaded(pos)) {
            TileEntity tile = world.getTileEntity(pos);
            if (tile instanceof RenewableTile) ((RenewableTile) tile).restoreItemEnergy(null);
        }
    }
}
