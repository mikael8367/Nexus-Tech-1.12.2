package com.mikael8367.nexustech.powerexpansion;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class RenewableRegistry {
    public static final RenewableBlock WIND = new RenewableBlock("wind_generator", true);
    public static final RenewableBlock HYDRO = new RenewableBlock("hydro_generator", false);
    public static final Block[] BLOCKS = { WIND, HYDRO };
    private RenewableRegistry() { }
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> event) {
        for (Block block : BLOCKS) event.getRegistry().register(block);
        GameRegistry.registerTileEntity(RenewableTile.Wind.class, new ResourceLocation(NexusTech.MODID, "wind_generator"));
        GameRegistry.registerTileEntity(RenewableTile.Hydro.class, new ResourceLocation(NexusTech.MODID, "hydro_generator"));
    }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> event) {
        for (Block block : BLOCKS) event.getRegistry().register(new ItemBlock(block).setRegistryName(block.getRegistryName()));
    }
}
