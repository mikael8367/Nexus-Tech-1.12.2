package com.mikael8367.nexustech.powerexpansion;

import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;

/** Output-only renewable generators. Energy is deliberately lost on block removal. */
public abstract class RenewableTile extends PowerTile implements ITickable {
    private long lastTick = Long.MIN_VALUE;
    private boolean updating;
    private boolean placed;
    protected RenewableTile() { super(16000, 0, 128); }
    protected abstract boolean conditions();
    protected abstract int rate();
    protected abstract RenewableBlock block();

    // A retained capability must not provide FE after its block is replaced,
    // even if a world/mod briefly keeps the old tile at the same position.
    @Override boolean outputAllowed() { return world.getBlockState(pos).getBlock() == block(); }

    public static final class Wind extends RenewableTile {
        protected RenewableBlock block() { return RenewableRegistry.WIND; }
        protected int rate() { return 24; }
        protected boolean conditions() {
            BlockPos above = pos.up();
            return pos.getY() >= 80 && pos.getY() + 1 < world.getActualHeight()
                    && world.provider.hasSkyLight() && world.isBlockLoaded(above) && world.canSeeSky(above);
        }
    }
    public static final class Hydro extends RenewableTile {
        protected RenewableBlock block() { return RenewableRegistry.HYDRO; }
        protected int rate() { return 32; }
        protected boolean conditions() {
            int flows = 0;
            for (EnumFacing side : EnumFacing.HORIZONTALS) {
                BlockPos p = pos.offset(side);
                if (!world.isBlockLoaded(p)) return false;
                IBlockState state = world.getBlockState(p);
                if (state.getMaterial() == Material.WATER && state.getBlock() instanceof BlockLiquid) {
                    int level = state.getValue(BlockLiquid.LEVEL);
                    // Vanilla levels 8..15 are falling (flowing) water, not sources.
                    if (level > 0) flows++;
                }
            }
            return flows >= 2;
        }
    }
    @Override public void update() {
        if (updating || pushing || !live() || world.getBlockState(pos).getBlock() != block()) return;
        updating = true;
        try {
            long now = world.getTotalWorldTime();
            if (lastTick != now) {
                lastTick = now;
                if (conditions()) buffer.generate(rate());
                markDirty();
            }
            if (live()) push();
        } finally { updating = false; }
    }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        super.writeToNBT(nbt);
        nbt.setLong("RenewableLastTick", lastTick);
        buffer.writeOutputBudget(nbt);
        return nbt;
    }
    @Override public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        lastTick = nbt.hasKey("RenewableLastTick", 4) ? nbt.getLong("RenewableLastTick") : Long.MIN_VALUE;
        buffer.readOutputBudget(nbt);
    }
    @Override void restoreItemEnergy(NBTTagCompound ignored) {
        if (placed || world == null || world.isRemote) return;
        placed = true;
        // Discard all ItemBlock BlockEntityTag state, including a forged buffer.
        buffer.load(0);
        lastTick = world.getTotalWorldTime();
        NBTTagCompound budget = new NBTTagCompound();
        budget.setLong("SolarArrayOutputTick", lastTick);
        budget.setInteger("SolarArrayOutputUsed", 128);
        buffer.readOutputBudget(budget);
        markDirty();
    }
}
