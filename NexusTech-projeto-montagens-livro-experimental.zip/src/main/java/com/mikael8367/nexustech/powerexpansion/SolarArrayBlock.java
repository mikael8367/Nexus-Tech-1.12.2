package com.mikael8367.nexustech.powerexpansion;

import com.mikael8367.nexustech.NexusTech;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

/** Parts have their own collision/selection boxes and stay entirely in their own block cells. */
public final class SolarArrayBlock extends Block {
    enum Part { CONTROLLER, POLE, MODULE }
    private static final AxisAlignedBB POLE_BOX = new AxisAlignedBB(0.375, 0, 0.375, 0.625, 1, 0.625);
    private static final AxisAlignedBB MODULE_BOX = new AxisAlignedBB(0, 0, 0, 1, 0.125, 1);
    private final Part part;
    SolarArrayBlock(String name, Part part) {
        super(Material.IRON);
        this.part = part;
        setRegistryName(NexusTech.MODID, name);
        setUnlocalizedName(NexusTech.MODID + "." + name);
        setCreativeTab(NexusTech.CREATIVE_TAB);
        setHardness(3.0F); setResistance(10.0F);
        if (part != Part.CONTROLLER) { fullBlock = false; setLightOpacity(0); }
    }
    @Override public boolean isOpaqueCube(IBlockState state) { return part == Part.CONTROLLER; }
    @Override public boolean isFullCube(IBlockState state) { return part == Part.CONTROLLER; }
    @Override public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess access, BlockPos pos) {
        return part == Part.POLE ? POLE_BOX : part == Part.MODULE ? MODULE_BOX : FULL_BLOCK_AABB;
    }
    @Override public boolean hasTileEntity(IBlockState state) { return part == Part.CONTROLLER; }
    @Override public TileEntity createTileEntity(World world, IBlockState state) {
        return part == Part.CONTROLLER ? new SolarArrayTile() : null;
    }
    @Override public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player,
                                                EnumHand hand, EnumFacing face, float x, float y, float z) {
        if (part != Part.CONTROLLER) return false;
        if (!world.isRemote && world.isBlockLoaded(pos)) {
            TileEntity tile = world.getTileEntity(pos);
            if (tile instanceof SolarArrayTile) {
                SolarArrayTile solar = (SolarArrayTile) tile;
                player.sendStatusMessage(new TextComponentTranslation("message.nexustech.solar_array.status",
                        solar.buffer.stored(), solar.buffer.capacity(),
                        new TextComponentTranslation("message.nexustech.solar_array." + solar.status().key)), false);
            }
        }
        return true;
    }
    @Override public void onBlockPlacedBy(World world, BlockPos pos, IBlockState state,
                                          @Nullable EntityLivingBase placer, ItemStack stack) {
        super.onBlockPlacedBy(world, pos, state, placer, stack);
        if (part == Part.CONTROLLER && !world.isRemote && world.isBlockLoaded(pos)) {
            TileEntity tile = world.getTileEntity(pos);
            if (tile instanceof SolarArrayTile) ((SolarArrayTile) tile).restoreItemEnergy(stack.getTagCompound());
        }
    }
    @Override public void getDrops(NonNullList<ItemStack> drops, IBlockAccess access, BlockPos pos,
                                   IBlockState state, int fortune) {
        if (part != Part.CONTROLLER) { super.getDrops(drops, access, pos, state, fortune); return; }
        ItemStack stack = new ItemStack(this);
        // Loot previews and explosions do not copy live energy. Only the actual player
        // harvest may claim it, once, after FE access has been frozen.
        if (access instanceof World && !((World) access).isRemote && ((World) access).isBlockLoaded(pos)) {
            TileEntity tile = access.getTileEntity(pos);
            if (tile instanceof SolarArrayTile) {
                SolarArrayTile solar = (SolarArrayTile) tile;
                if (solar.harvesting && !solar.dropClaimed) {
                    solar.dropClaimed = true;
                    // Snapshot only our own energy and rate-limit fields, before debiting.
                    // Include the guards even for an empty controller.
                    NBTTagCompound tag = solar.writeItemState();
                    solar.buffer.load(0); solar.markDirty();
                    stack.setTagCompound(tag);
                }
            }
        }
        drops.add(stack);
    }
    @Override public boolean removedByPlayer(IBlockState state, World world, BlockPos pos,
                                              EntityPlayer player, boolean willHarvest) {
        if (part != Part.CONTROLLER || !willHarvest) return super.removedByPlayer(state, world, pos, player, willHarvest);
        onBlockHarvested(world, pos, state, player);
        return true;
    }
    @Override public void harvestBlock(World world, EntityPlayer player, BlockPos pos, IBlockState state,
                                       @Nullable TileEntity tile, ItemStack tool) {
        if (part != Part.CONTROLLER) { super.harvestBlock(world, player, pos, state, tile, tool); return; }
        // A stale or repeated harvest callback must not drop another controller or
        // remove a replacement installed by another mod. Never load a chunk here.
        if (world.isRemote || !world.isBlockLoaded(pos) || world.getBlockState(pos).getBlock() != this
                || world.getTileEntity(pos) != tile) return;
        SolarArrayTile solar = tile instanceof SolarArrayTile ? (SolarArrayTile) tile : null;
        if (solar != null && solar.harvesting) return; // nested callbacks cannot issue a second drop
        if (solar != null) { solar.harvesting = true; solar.dropClaimed = false; }
        EntityPlayer previousHarvester = harvesters.get();
        try {
            super.harvestBlock(world, player, pos, state, tile, tool);
        } finally {
            // A harvest event can throw after a drop was handed off. Do not leave
            // the original block available for a second harvest in that case.
            try {
                if (world.isBlockLoaded(pos) && world.getBlockState(pos).getBlock() == this
                        && world.getTileEntity(pos) == tile) world.setBlockToAir(pos);
            } finally {
                if (solar != null) solar.harvesting = false;
                // Forge's superclass does not restore this ThreadLocal on an
                // exception or after a nested harvest of a different controller.
                if (previousHarvester == null) harvesters.remove();
                else harvesters.set(previousHarvester);
            }
        }
    }
    @Override public boolean canSilkHarvest(World world, BlockPos pos, IBlockState state, EntityPlayer player) {
        return part != Part.CONTROLLER && super.canSilkHarvest(world, pos, state, player);
    }
}
