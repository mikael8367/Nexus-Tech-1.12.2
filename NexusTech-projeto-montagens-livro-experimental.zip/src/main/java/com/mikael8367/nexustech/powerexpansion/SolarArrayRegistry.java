package com.mikael8367.nexustech.powerexpansion;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

/** All parts are ordinary, individually placed blocks, never fake or automatically placed. */
@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class SolarArrayRegistry {
    public static final SolarArrayBlock ARRAY = new SolarArrayBlock("nexus_solar_array", SolarArrayBlock.Part.CONTROLLER);
    public static final SolarArrayBlock POLE = new SolarArrayBlock("nexus_solar_array_pole", SolarArrayBlock.Part.POLE);
    public static final SolarArrayBlock MODULE = new SolarArrayBlock("nexus_solar_array_module", SolarArrayBlock.Part.MODULE);
    public static final Block[] BLOCKS = { ARRAY, POLE, MODULE };
    private SolarArrayRegistry() { }
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> event) {
        for (Block block : BLOCKS) event.getRegistry().register(block);
        GameRegistry.registerTileEntity(SolarArrayTile.class, new ResourceLocation(NexusTech.MODID, "nexus_solar_array"));
    }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> event) {
        for (Block block : BLOCKS) {
            ItemBlock item = new ItemBlock(block);
            item.setRegistryName(block.getRegistryName());
            if (block == ARRAY) item.setMaxStackSize(1); // distinct charged controllers
            event.getRegistry().register(item);
        }
    }
}
