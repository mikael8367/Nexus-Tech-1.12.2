package com.mikael8367.nexustech.powerexpansion;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;

/** One controller per 3x3 roof. Parts never store energy and no blocks are created or removed. */
public final class SolarArrayTile extends PowerTile implements ITickable {
    public static final int GENERATION = 576; // nine existing large panels at 64 FE/t
    public static final int CAPACITY = 73728; // nine existing 8192-FE buffers
    public static final int OUTPUT = 4608; // nine existing 512-FE/t outputs, shared across faces
    private boolean updating;
    private boolean itemStateRestored;
    boolean dropClaimed;
    private long lastProductionTick = Long.MIN_VALUE;

    enum Status {
        ACTIVE("active"), INCOMPLETE("incomplete"), UNLOADED("unloaded"),
        OVERLAP("overlap"), NO_SUN("no_sun"), OBSTRUCTED("obstructed");
        final String key;
        Status(String key) { this.key = key; }
    }
    public SolarArrayTile() { super(CAPACITY, 0, OUTPUT); }

    /** Pure inspection. In particular, don't force-load neighboring chunks or modify the world. */
    Status status() {
        if (!live()) return Status.UNLOADED;
        int top = pos.getY() + 3;
        if (pos.getY() < 0 || top + 1 >= world.getActualHeight()) return Status.INCOMPLETE;
        if (world.getBlockState(pos).getBlock() != SolarArrayRegistry.ARRAY) return Status.INCOMPLETE;
        for (int y = 1; y <= 2; y++) {
            BlockPos p = pos.up(y);
            if (!world.isBlockLoaded(p)) return Status.UNLOADED;
            if (world.getBlockState(p).getBlock() != SolarArrayRegistry.POLE) return Status.INCOMPLETE;
        }
        // A second controller with an overlapping 3x3 roof would otherwise share modules
        // and manufacture extra power. Even incomplete controllers reserve their footprint.
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
            if (x == 0 && z == 0) continue;
            BlockPos p = pos.add(x, 0, z);
            if (!world.isBlockLoaded(p)) return Status.UNLOADED;
            if (world.getBlockState(p).getBlock() == SolarArrayRegistry.ARRAY) return Status.OVERLAP;
        }
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
            BlockPos panel = pos.add(x, 3, z);
            if (!world.isBlockLoaded(panel)) return Status.UNLOADED;
            if (world.getBlockState(panel).getBlock() != SolarArrayRegistry.MODULE) return Status.INCOMPLETE;
        }
        if (!world.provider.hasSkyLight() || !world.isDaytime() || world.isRaining() || world.isThundering())
            return Status.NO_SUN;
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
            BlockPos sky = pos.add(x, 4, z);
            if (!world.isBlockLoaded(sky)) return Status.UNLOADED;
            if (!world.canSeeSky(sky)) return Status.OBSTRUCTED;
        }
        return Status.ACTIVE;
    }

    @Override public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        super.writeToNBT(nbt);
        nbt.setLong("SolarArrayLastProductionTick", lastProductionTick);
        buffer.writeOutputBudget(nbt);
        return nbt;
    }

    @Override public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        lastProductionTick = nbt.hasKey("SolarArrayLastProductionTick", 4)
                ? nbt.getLong("SolarArrayLastProductionTick") : Long.MIN_VALUE;
        buffer.readOutputBudget(nbt);
    }

    /** Only these four fields travel with an actual harvested controller. */
    NBTTagCompound writeItemState() {
        NBTTagCompound tag = new NBTTagCompound();
        tag.setInteger(ENERGY_KEY, buffer.stored());
        tag.setLong("SolarArrayLastProductionTick", lastProductionTick);
        buffer.writeOutputBudget(tag);
        return tag;
    }

    @Override void restoreItemEnergy(NBTTagCompound tag) {
        if (itemStateRestored) return; // repeated placement callbacks cannot replay a charged stack
        itemStateRestored = true;
        // ItemBlock may already have applied an arbitrary BlockEntityTag. Discard
        // that state completely and accept only the dedicated top-level fields.
        buffer.load(tag == null ? 0 : tag.getInteger(ENERGY_KEY));
        int used = OUTPUT; // missing or malformed budgets fail closed for this tick
        if (tag != null && tag.hasKey("SolarArrayLastProductionTick", 4)
                && tag.hasKey("SolarArrayOutputTick", 4) && tag.hasKey("SolarArrayOutputUsed", 3)) {
            int saved = tag.getInteger("SolarArrayOutputUsed");
            if (saved >= 0 && saved <= OUTPUT) used = saved;
        }
        // World clocks can differ between dimensions. Apply the saved usage to
        // the placement tick even when the source clock differs; conservatively
        // defer generation until the next tick, including for old/plain items.
        long now = world.getTotalWorldTime();
        lastProductionTick = now;
        NBTTagCompound budget = new NBTTagCompound();
        budget.setLong("SolarArrayOutputTick", now);
        budget.setInteger("SolarArrayOutputUsed", used);
        buffer.readOutputBudget(budget);
        markDirty();
    }

    @Override public void update() {
        if (updating || pushing || !live()) return;
        updating = true;
        try {
            long now = world.getTotalWorldTime();
            if (now != lastProductionTick) {
                lastProductionTick = now;
                if (status() == Status.ACTIVE) buffer.generate(GENERATION);
                // Even at night or with a full buffer, persist the once-per-tick guard.
                markDirty();
            }
            // Stored energy remains extractable in darkness or if the structure is broken.
            if (live()) push();
        } finally { updating = false; }
    }
}
