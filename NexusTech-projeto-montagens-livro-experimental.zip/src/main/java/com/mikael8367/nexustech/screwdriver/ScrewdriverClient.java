package com.mikael8367.nexustech.screwdriver;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = NexusTech.MODID, value = Side.CLIENT)
public final class ScrewdriverClient {
    @SubscribeEvent
    public static void models(ModelRegistryEvent event) {
        ModelLoader.setCustomModelResourceLocation(ScrewdriverRegistry.SCREWDRIVER, 0,
                new ModelResourceLocation(ScrewdriverRegistry.SCREWDRIVER.getRegistryName(), "inventory"));
    }
    private ScrewdriverClient() { }
}
