package com.mikael8367.nexustech.screwdriver;

import com.mikael8367.nexustech.itemcable.ItemCableNetwork;
import com.mikael8367.nexustech.itemcable.ItemCableBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Uses the normal Forge right-click path; only the server changes connections. */
public final class ScrewdriverItem extends Item {
    public ScrewdriverItem() {
        setMaxStackSize(1);
    }

    @Override
    public EnumActionResult onItemUseFirst(EntityPlayer player, World world, BlockPos pos,
                                           EnumFacing side, float hitX, float hitY, float hitZ,
                                           EnumHand hand) {
        if (world == null || player == null || pos == null || side == null || hand == null)
            return EnumActionResult.PASS;
        ItemStack stack = player.getHeldItem(hand);
        if (stack.isEmpty() || stack.getItem() != this || player.isSpectator())
            return EnumActionResult.PASS;
        if (!world.isBlockLoaded(pos) || !(world.getBlockState(pos).getBlock() instanceof ItemCableBlock))
            return EnumActionResult.PASS;
        // Only predict clicks on item cables: Forge sends its ordinary use-on-block packet,
        // and consuming the click prevents the second hand from toggling it back.
        if (world.isRemote) return EnumActionResult.SUCCESS;
        BlockPos neighbor = pos.offset(side);
        if (player.world != world || !world.isBlockLoaded(neighbor)
                || !world.getWorldBorder().contains(pos) || !world.getWorldBorder().contains(neighbor)
                || !world.isBlockModifiable(player, pos) || !world.isBlockModifiable(player, neighbor)
                || !player.canPlayerEdit(pos, side, stack)
                || !player.canPlayerEdit(neighbor, side.getOpposite(), stack))
            return EnumActionResult.PASS;
        // The API must validate the type, both endpoints and permissions, persist and sync.
        return ItemCableNetwork.toggleConnection(world, pos, side, player, hand)
                ? EnumActionResult.SUCCESS : EnumActionResult.PASS;
    }
}
