package com.mikael8367.nexustech.screwdriver;

import com.mikael8367.nexustech.NexusTech;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** A denied block interaction must not turn into an allowed screwdriver use. */
@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class ScrewdriverProtection {
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void respectBlockDenial(PlayerInteractEvent.RightClickBlock event) {
        if (event.getItemStack().getItem() instanceof ScrewdriverItem
                && event.getUseBlock() == Event.Result.DENY) {
            event.setUseItem(Event.Result.DENY);
        }
    }
    private ScrewdriverProtection() { }
}
