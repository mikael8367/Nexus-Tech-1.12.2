package com.mikael8367.nexustech.screwdriver;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class ScrewdriverRegistry {
    public static final Item SCREWDRIVER = new ScrewdriverItem()
            .setRegistryName(NexusTech.MODID, "screwdriver")
            .setUnlocalizedName("screwdriver")
            .setCreativeTab(NexusTech.CREATIVE_TAB);

    @SubscribeEvent
    public static void register(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(SCREWDRIVER);
    }
    private ScrewdriverRegistry() { }
}
