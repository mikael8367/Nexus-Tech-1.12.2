package com.mikael8367.nexustech.techarmor;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = NexusTech.MODID, value = Side.CLIENT)
public final class TechArmorClient {
    private static ModelBiped outer;
    private static ModelBiped inner;
    private TechArmorClient() { }
    @SubscribeEvent public static void models(ModelRegistryEvent event) {
        for (Item item : TechArmorRegistry.ITEMS)
            ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
    }
    public static ModelBiped model(EntityEquipmentSlot slot) {
        if (outer == null) outer = new ExoModel(1.0F, false);
        if (inner == null) inner = new ExoModel(0.5F, true);
        return slot == EntityEquipmentSlot.LEGS ? inner : outer;
    }
    private static final class ExoModel extends ModelBiped {
        ExoModel(float scale, boolean legs) {
            super(scale, 0, 64, 32);
            if (legs) {
                // Kneecaps sit only 0.15 pixels above the inner armor shell.
                box(bipedRightLeg, 32, 0, -1.5F, 3, -2.65F, 3, 2, 1);
                box(bipedLeftLeg, 32, 0, -1.5F, 3, -2.65F, 3, 2, 1);
            } else {
                // All additions are thin in relief and attached to the moving biped parts.
                box(bipedHead, 32, 0, -3, -6, -5.15F, 6, 2, 1);
                box(bipedBody, 32, 0, -2, 3, -3.15F, 4, 3, 1);
                box(bipedRightArm, 32, 0, -3, -2, -3.15F, 3, 2, 1);
                box(bipedLeftArm, 32, 0, 0, -2, -3.15F, 3, 2, 1);
                box(bipedRightLeg, 32, 0, -1.5F, 8, -3.15F, 3, 3, 1);
                box(bipedLeftLeg, 32, 0, -1.5F, 8, -3.15F, 3, 3, 1);
            }
        }
        @Override public void render(Entity entity, float limbSwing, float limbSwingAmount,
                                     float ageInTicks, float netHeadYaw, float headPitch, float scale) {
            // The extra vanilla hat cube consumes our detail atlas and otherwise covers the helmet.
            bipedHeadwear.showModel = false;
            super.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
        }
        private void box(ModelRenderer parent, int u, int v, float x, float y, float z, int w, int h, int d) {
            ModelRenderer part = new ModelRenderer(this, u, v);
            part.addBox(x, y, z, w, h, d);
            parent.addChild(part);
        }
    }
}
