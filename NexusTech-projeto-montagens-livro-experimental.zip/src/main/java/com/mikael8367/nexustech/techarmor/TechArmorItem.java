package com.mikael8367.nexustech.techarmor;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import java.util.Map;
import java.util.WeakHashMap;

public final class TechArmorItem extends ItemArmor {
    // Weak keys do not keep disconnected players alive; only the exact effect we created is refreshed.
    private static final Map<EntityPlayer, PotionEffect> OWN_EFFECTS = new WeakHashMap<EntityPlayer, PotionEffect>();
    TechArmorItem(String id, EntityEquipmentSlot slot) {
        super(TechArmorRegistry.MATERIAL, 0, slot);
        setRegistryName(NexusTech.MODID, id);
        setUnlocalizedName(id);
        setCreativeTab(NexusTech.CREATIVE_TAB);
    }
    @Override public void onArmorTick(World world, EntityPlayer player, ItemStack stack) {
        // Never remove an effect, and do not extend one created by another source.
        if (world.isRemote || armorType != EntityEquipmentSlot.HEAD) return;
        PotionEffect active = player.getActivePotionEffect(MobEffects.NIGHT_VISION);
        if (TechArmorPolicy.shouldApplyNightVision(false, true, active != null)) {
            PotionEffect created = new PotionEffect(MobEffects.NIGHT_VISION, 330, 0, true, false);
            player.addPotionEffect(created);
            if (player.getActivePotionEffect(MobEffects.NIGHT_VISION) == created) OWN_EFFECTS.put(player, created);
        } else if (active == OWN_EFFECTS.get(player) && active.getAmplifier() == 0 &&
                   active.getIsAmbient() && !active.doesShowParticles() && active.getDuration() <= 230) {
            // Retain enough time to prevent the vanilla end-of-effect blinking.
            player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 330, 0, true, false));
        }
    }
    @Override public String getArmorTexture(ItemStack stack, Entity entity, EntityEquipmentSlot slot, String type) {
        String part = slot == EntityEquipmentSlot.HEAD ? "helmet" : slot == EntityEquipmentSlot.CHEST ? "chestplate" :
            slot == EntityEquipmentSlot.LEGS ? "leggings" : "boots";
        return "nexustech:textures/models/armor/techarmor_" + part + ".png";
    }
    @Override @SideOnly(Side.CLIENT)
    public ModelBiped getArmorModel(EntityLivingBase entity, ItemStack stack, EntityEquipmentSlot slot, ModelBiped original) {
        return TechArmorClient.model(slot);
    }
}
