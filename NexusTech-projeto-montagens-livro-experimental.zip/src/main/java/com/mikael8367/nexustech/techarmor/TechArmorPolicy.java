package com.mikael8367.nexustech.techarmor;

/** Pure predicates: avoid modifying other mods' existing potion effects. */
public final class TechArmorPolicy {
    private TechArmorPolicy() { }
    public static boolean shouldApplyNightVision(boolean remote, boolean helmet, boolean alreadyActive) {
        return !remote && helmet && !alreadyActive;
    }
}
