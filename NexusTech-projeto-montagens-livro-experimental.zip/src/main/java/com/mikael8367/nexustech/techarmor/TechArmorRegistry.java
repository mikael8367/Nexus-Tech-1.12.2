package com.mikael8367.nexustech.techarmor;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class TechArmorRegistry {
    public static final ItemArmor.ArmorMaterial MATERIAL = EnumHelper.addArmorMaterial(
        "NEXUSTECH_TECHARMOR", "nexustech:techarmor", 45, new int[] {5, 8, 10, 5}, 20,
        SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 4.0F);
    public static final TechArmorItem HELMET = new TechArmorItem("techarmor_helmet", EntityEquipmentSlot.HEAD);
    public static final TechArmorItem CHEST = new TechArmorItem("techarmor_chestplate", EntityEquipmentSlot.CHEST);
    public static final TechArmorItem LEGS = new TechArmorItem("techarmor_leggings", EntityEquipmentSlot.LEGS);
    public static final TechArmorItem BOOTS = new TechArmorItem("techarmor_boots", EntityEquipmentSlot.FEET);
    public static final Item[] ITEMS = {HELMET, CHEST, LEGS, BOOTS};
    private TechArmorRegistry() { }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> event) {
        for (Item item : ITEMS) event.getRegistry().register(item);
    }
}
