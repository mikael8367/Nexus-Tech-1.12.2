package com.mikael8367.nexustech.techitems;

import com.mikael8367.nexustech.NexusTech;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Crafting components only; none provide machine or energy behavior. */
@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class TechItemsRegistry {
    private static final String[] IDS = {
            "techitem_copper_circuit_board",
            "techitem_tin_circuit_board",
            "techitem_aluminum_circuit_board",
            "techitem_silver_circuit_board",
            "techitem_lead_circuit_board",
            "techitem_copper_coil",
            "techitem_tin_coil",
            "techitem_aluminum_coil",
            "techitem_silver_coil",
            "techitem_lead_coil",
            "techitem_copper_gear",
            "techitem_tin_gear",
            "techitem_aluminum_gear",
            "techitem_silver_gear",
            "techitem_lead_gear",
            "techitem_copper_frame",
            "techitem_tin_frame",
            "techitem_aluminum_frame",
            "techitem_silver_frame",
            "techitem_lead_frame",
            "techitem_copper_conductor",
            "techitem_tin_conductor",
            "techitem_aluminum_conductor",
            "techitem_silver_conductor",
            "techitem_lead_conductor",
            "techitem_copper_contact",
            "techitem_tin_contact",
            "techitem_aluminum_contact",
            "techitem_silver_contact",
            "techitem_lead_contact",
            "techitem_copper_mesh",
            "techitem_tin_mesh",
            "techitem_aluminum_mesh",
            "techitem_silver_mesh",
            "techitem_lead_mesh",
            "techitem_copper_casing",
            "techitem_tin_casing",
            "techitem_aluminum_casing",
            "techitem_silver_casing",
            "techitem_lead_casing",
            "techitem_copper_panel",
            "techitem_tin_panel",
            "techitem_aluminum_panel",
            "techitem_silver_panel",
            "techitem_lead_panel",
            "techitem_copper_rotor",
            "techitem_tin_rotor",
            "techitem_aluminum_rotor",
            "techitem_silver_rotor",
            "techitem_lead_rotor"
    };
    public static final List<Item> ITEMS;
    static {
        List<Item> items = new ArrayList<Item>();
        for (String id : IDS) {
            items.add(new Item().setRegistryName(NexusTech.MODID, id)
                .setUnlocalizedName(id).setCreativeTab(NexusTech.CREATIVE_TAB));
        }
        ITEMS = Collections.unmodifiableList(items);
    }
    private TechItemsRegistry() { }
    @SubscribeEvent public static void registerItems(RegistryEvent.Register<Item> event) {
        for (Item item : ITEMS) event.getRegistry().register(item);
    }
}
