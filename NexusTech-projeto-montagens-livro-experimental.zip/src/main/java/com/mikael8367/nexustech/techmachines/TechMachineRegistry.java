package com.mikael8367.nexustech.techmachines;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class TechMachineRegistry {
    public static final TechMachineBlock SAWMILL = new TechMachineBlock("techmachines_sawmill", 0);
    public static final TechMachineBlock COMPOSTER = new TechMachineBlock("techmachines_composter", 1);
    public static final TechMachineBlock PUMP = new TechMachineBlock("techmachines_water_bottler", 2);
    public static final Block[] BLOCKS = { SAWMILL, COMPOSTER, PUMP };
    private TechMachineRegistry() { }
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> event) {
        for (Block block : BLOCKS) event.getRegistry().register(block);
        GameRegistry.registerTileEntity(TechMachineTile.Sawmill.class, new ResourceLocation(NexusTech.MODID, "techmachines_sawmill"));
        GameRegistry.registerTileEntity(TechMachineTile.Composter.class, new ResourceLocation(NexusTech.MODID, "techmachines_composter"));
        GameRegistry.registerTileEntity(TechMachineTile.WaterBottler.class, new ResourceLocation(NexusTech.MODID, "techmachines_water_bottler"));
    }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> event) {
        for (Block block : BLOCKS) event.getRegistry().register(new ItemBlock(block).setRegistryName(block.getRegistryName()));
    }
}
