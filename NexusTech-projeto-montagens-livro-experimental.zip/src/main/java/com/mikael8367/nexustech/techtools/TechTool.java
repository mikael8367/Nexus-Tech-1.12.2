package com.mikael8367.nexustech.techtools;

import java.util.Collections;
import java.util.UUID;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;

/** Each extra block is harvested by the normal server interaction manager. */
public final class TechTool extends ItemTool {
    enum Kind { PICKAXE, AXE, SHOVEL }
    private final Kind kind;
    private static final ThreadLocal<Boolean> EXPANDING = new ThreadLocal<Boolean>();
    static final String ID = "TechToolId", SPEED = "TechToolSpeed", AREA = "TechToolArea";

    TechTool(Kind kind) {
        super(3.0F, -2.8F, ToolMaterial.DIAMOND, Collections.emptySet());
        this.kind = kind;
        setHarvestLevel(kind == Kind.PICKAXE ? "pickaxe" : kind == Kind.AXE ? "axe" : "shovel", 3);
    }
    static int speed(ItemStack stack) {
        int n = stack.hasTagCompound() ? stack.getTagCompound().getInteger(SPEED) : 0;
        return n >= 0 && n <= 2 ? n : 0;
    }
    static int area(ItemStack stack) {
        int n = stack.hasTagCompound() ? stack.getTagCompound().getInteger(AREA) : 0;
        return n >= 0 && n <= 2 ? n : 0;
    }
    static UUID id(ItemStack stack) {
        return stack.hasTagCompound() && stack.getTagCompound().hasUniqueId(ID)
                ? stack.getTagCompound().getUniqueId(ID) : null;
    }
    @Override public void onUpdate(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (!world.isRemote && id(stack) == null) {
            if (!stack.hasTagCompound()) stack.setTagCompound(new NBTTagCompound());
            stack.getTagCompound().setUniqueId(ID, UUID.randomUUID());
        }
    }
    private boolean appropriate(IBlockState s) {
        Material m = s.getMaterial();
        switch (kind) {
            case PICKAXE: return m == Material.ROCK || m == Material.IRON || m == Material.ANVIL;
            case AXE: return m == Material.WOOD || m == Material.PLANTS || m == Material.VINE;
            default: return m == Material.GROUND || m == Material.GRASS || m == Material.SAND || m == Material.SNOW || m == Material.CRAFTED_SNOW || m == Material.CLAY;
        }
    }
    @Override public boolean canHarvestBlock(IBlockState state) {
        return (kind == Kind.PICKAXE && appropriate(state)) || (kind == Kind.SHOVEL && (state.getBlock() == net.minecraft.init.Blocks.SNOW || state.getBlock() == net.minecraft.init.Blocks.SNOW_LAYER));
    }
    @Override public float getDestroySpeed(ItemStack stack, IBlockState state) {
        if (!appropriate(state)) return 1.0F;
        return new float[] { 4.0F, 6.0F, 8.0F }[speed(stack)];
    }
    @Override public boolean onBlockDestroyed(ItemStack stack, World world, IBlockState state, BlockPos pos, EntityLivingBase living) {
        boolean result = super.onBlockDestroyed(stack, world, state, pos, living);
        if (!world.isRemote && living instanceof EntityPlayerMP && !Boolean.TRUE.equals(EXPANDING.get()) && !stack.isEmpty() && appropriate(state)) {
            EntityPlayerMP player = (EntityPlayerMP) living;
            int mode = area(stack);
            float hardness = state.getBlockHardness(world, pos);
            if (mode != 0 && !player.capabilities.isCreativeMode && hardness >= 0 && Float.isFinite(hardness) && id(stack) != null)
                TechToolsQueue.enqueue(player, stack, this, world, pos, mode, hardness);
        }
        return result;
    }
    void expand(ItemStack stack, World world, BlockPos pos, EntityPlayerMP player, int mode, float hardness) {
        EXPANDING.set(Boolean.TRUE);
        try {
            int minX = mode == 1 ? 0 : -1, maxX = mode == 1 ? 0 : 1;
            int minY = mode == 1 ? 0 : -1, maxY = 1;
            int minZ = mode == 1 ? 0 : -1, maxZ = mode == 1 ? 0 : 1;
            for (int x = minX; x <= maxX; x++) for (int y = minY; y <= maxY; y++) for (int z = minZ; z <= maxZ; z++) {
                if (x == 0 && y == 0 && z == 0) continue;
                if (stack.isEmpty() || player.getHeldItemMainhand() != stack) return;
                BlockPos p = pos.add(x, y, z);
                if (!world.isBlockLoaded(p) || !world.getWorldBorder().contains(p) || !world.isBlockModifiable(player, p) || !player.canPlayerEdit(p, EnumFacing.UP, stack)) continue;
                IBlockState s = world.getBlockState(p);
                float h = s.getBlockHardness(world, p);
                if (!appropriate(s) || h < 0 || !Float.isFinite(h) || h > hardness || s.getBlock().hasTileEntity(s) || !ForgeHooks.canHarvestBlock(s.getBlock(), player, world, p)) continue;
                Vec3d eyes = player.getPositionEyes(1.0F), center = new Vec3d(p).addVector(0.5, 0.5, 0.5);
                double reach = player.interactionManager.getBlockReachDistance();
                if (eyes.squareDistanceTo(center) > reach * reach) continue;
                RayTraceResult hit = world.rayTraceBlocks(eyes, center, false, true, false);
                if (hit == null || hit.typeOfHit != RayTraceResult.Type.BLOCK || !p.equals(hit.getBlockPos())) continue;
                player.interactionManager.tryHarvestBlock(p);
            }
        } finally { EXPANDING.remove(); }
    }
}
