package com.mikael8367.nexustech.techtools;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public final class TechToolsNetwork {
    static final SimpleNetworkWrapper CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel("nexus_techtools");
    private static boolean initialized;
    static void init() {
        if (!initialized) {
            CHANNEL.registerMessage(Handler.class, Config.class, 0, Side.SERVER);
            initialized = true;
        }
    }
    public static final class Config implements IMessage {
        int slot, speed, area; long most, least;
        public Config() { }
        Config(int slot, UUID id, int speed, int area) {
            this.slot = slot; this.most = id.getMostSignificantBits(); this.least = id.getLeastSignificantBits(); this.speed = speed; this.area = area;
        }
        @Override public void fromBytes(ByteBuf b) { slot = b.readInt(); most = b.readLong(); least = b.readLong(); speed = b.readInt(); area = b.readInt(); }
        @Override public void toBytes(ByteBuf b) { b.writeInt(slot); b.writeLong(most); b.writeLong(least); b.writeInt(speed); b.writeInt(area); }
    }
    public static final class Handler implements IMessageHandler<Config, IMessage> {
        @Override public IMessage onMessage(final Config m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            // Reject malformed values before scheduling work on the world thread.
            if (m.slot < 0 || m.slot > 8 || m.speed < 0 || m.speed > 2 || m.area < 0 || m.area > 2) return null;
            p.getServerWorld().addScheduledTask(() -> {
                if (p.isDead || p.openContainer != p.inventoryContainer || p.inventory.currentItem != m.slot) return;
                ItemStack held = p.getHeldItemMainhand();
                if (held.isEmpty() || !(held.getItem() instanceof TechTool)) return;
                UUID actual = TechTool.id(held);
                if (actual == null || actual.getMostSignificantBits() != m.most || actual.getLeastSignificantBits() != m.least) return;
                NBTTagCompound tag = held.getTagCompound();
                tag.setInteger(TechTool.SPEED, m.speed); tag.setInteger(TechTool.AREA, m.area);
                p.inventory.markDirty();
                p.inventoryContainer.detectAndSendChanges();
            });
            return null;
        }
    }
    private TechToolsNetwork() { }
}
