package com.mikael8367.nexustech.techtools;

import com.mikael8367.nexustech.NexusTech;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/** onBlockDestroyed runs BEFORE removeBlock; defer until the following player tick. */
@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class TechToolsQueue {
    private static final Map<EntityPlayerMP, Job> JOBS = new WeakHashMap<EntityPlayerMP, Job>();
    static void enqueue(EntityPlayerMP player, ItemStack stack, TechTool tool, World world, BlockPos pos, int mode, float hardness) {
        // At most one expansion per player per tick, never retain the player in the value.
        JOBS.put(player, new Job(stack, tool, world, pos.toImmutable(), mode, hardness));
    }
    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) event.player;
        Job j = JOBS.remove(p);
        if (j == null || p.isDead || p.capabilities.isCreativeMode || p.world != j.world || p.getHeldItemMainhand() != j.stack || j.stack.isEmpty() || j.stack.getItem() != j.tool || !j.world.isBlockLoaded(j.pos) || !j.world.isAirBlock(j.pos)) return;
        Vec3d eye = p.getPositionEyes(1), center = new Vec3d(j.pos).addVector(0.5, 0.5, 0.5);
        double reach = p.interactionManager.getBlockReachDistance();
        if (eye.squareDistanceTo(center) > reach * reach) return;
        j.tool.expand(j.stack, j.world, j.pos, p, j.mode, j.hardness);
    }
    private static final class Job {
        final ItemStack stack; final TechTool tool; final World world; final BlockPos pos; final int mode; final float hardness;
        Job(ItemStack s, TechTool t, World w, BlockPos p, int m, float h) {stack=s;tool=t;world=w;pos=p;mode=m;hardness=h;}
    }
    private TechToolsQueue() { }
}
