package com.mikael8367.nexustech.techtools;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class TechToolsRegistry {
    public static final Item PICKAXE = create("techtool_pickaxe", TechTool.Kind.PICKAXE);
    public static final Item AXE = create("techtool_axe", TechTool.Kind.AXE);
    public static final Item SHOVEL = create("techtool_shovel", TechTool.Kind.SHOVEL);
    private static Item create(String id, TechTool.Kind kind) {
        return new TechTool(kind).setRegistryName(NexusTech.MODID, id).setUnlocalizedName(id).setCreativeTab(NexusTech.CREATIVE_TAB);
    }
    @SubscribeEvent public static void register(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(PICKAXE, AXE, SHOVEL);
        TechToolsNetwork.init();
    }
    private TechToolsRegistry() { }
}
