package com.mikael8367.nexustech.utilitymachines;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;

/** Self-registering: no manual proxy or main registry calls. */
@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class UtilityMachinesRegistry {
    public static final Block RECYCLER = new UtilityMachineBlock("utility_recycler", 0);
    public static final Block PURIFIER = new UtilityMachineBlock("utility_purifier", 1);
    private static final Block[] BLOCKS = { RECYCLER, PURIFIER };
    private UtilityMachinesRegistry() { }
    @SubscribeEvent public static void blocks(RegistryEvent.Register<Block> event) {
        for (Block block : BLOCKS) event.getRegistry().register(block);
        GameRegistry.registerTileEntity(UtilityMachineTile.Recycler.class, new ResourceLocation(NexusTech.MODID, "utility_recycler"));
        GameRegistry.registerTileEntity(UtilityMachineTile.Purifier.class, new ResourceLocation(NexusTech.MODID, "utility_purifier"));
    }
    @SubscribeEvent public static void items(RegistryEvent.Register<Item> event) {
        for (Block block : BLOCKS) event.getRegistry().register(new ItemBlock(block).setRegistryName(block.getRegistryName()));
    }
    @SideOnly(Side.CLIENT)
    @Mod.EventBusSubscriber(modid = NexusTech.MODID, value = Side.CLIENT)
    public static final class ClientModels {
        private ClientModels() { }
        @SubscribeEvent public static void models(ModelRegistryEvent event) {
            for (Block block : BLOCKS) {
                Item item = Item.getItemFromBlock(block);
                ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
            }
        }
    }
}
