#!/usr/bin/env python3
"""Static checks of the fan's own resource references and integration points."""
from pathlib import Path
import base64, json, struct, zlib

root = Path(__file__).resolve().parents[3]
assets = root / 'src/main/resources/assets/nexustech'
textures = root / 'src/main/texture_sources/assets/nexustech/textures/blocks'

def load(path):
    return json.loads((assets / path).read_text(encoding='utf-8'))

state = load('blockstates/fan.json')['variants']
assert set(state) == {'facing=north', 'facing=east', 'facing=south', 'facing=west'}
for direction, angle in [('north', 0), ('east', 90), ('south', 180), ('west', 270)]:
    variant = state['facing=' + direction]
    assert variant['model'] == 'nexustech:fan' and variant.get('y', 0) == angle
model = load('models/block/fan.json')
assert model['parent'] == 'block/cube'
assert model['textures']['north'] == 'nexustech:blocks/fan_front'
assert all(model['textures'][s] == 'nexustech:blocks/fan_side' for s in ['south','east','west','up','down','particle'])
assert load('models/item/fan.json')['parent'] == 'nexustech:block/fan'
for name in ('fan_front', 'fan_side'):
    data = base64.b64decode((textures / (name + '.png.b64')).read_bytes().strip(), validate=True)
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    offset = 8; seen = []; compressed = b''
    while offset < len(data):
        size = struct.unpack('>I', data[offset:offset+4])[0]
        typ = data[offset+4:offset+8]; body = data[offset+8:offset+8+size]
        assert len(body) == size
        crc = struct.unpack('>I', data[offset+8+size:offset+12+size])[0]
        assert zlib.crc32(typ + body) & 0xffffffff == crc
        seen.append(typ)
        if typ == b'IHDR':
            width, height = struct.unpack('>II', body[:8]); assert width > 0 and height > 0
        if typ == b'IDAT': compressed += body
        offset += 12 + size
        if typ == b'IEND': break
    assert offset == len(data) and seen[0] == b'IHDR' and seen[-1] == b'IEND' and zlib.decompress(compressed)
recipe = load('recipes/fan.json')
assert recipe['type'] == 'minecraft:crafting_shaped' and recipe['pattern'] == ['IRI','RCR','III']
assert recipe['key'] == {'I': {'item':'minecraft:iron_ingot'}, 'R': {'item':'nexustech:techitem_copper_rotor'}, 'C': {'item':'minecraft:redstone'}}
assert recipe['result'] == {'item':'nexustech:fan'}
assert '"techitem_copper_rotor"' in (root / 'src/main/java/com/mikael8367/nexustech/techitems/TechItemsRegistry.java').read_text()
keys = {'tile.nexustech.fan.name','gui.nexustech.fan.title','gui.nexustech.fan.on','gui.nexustech.fan.off','gui.nexustech.fan.speed','gui.nexustech.fan.range'}
for language in ('en_us', 'pt_br'):
    entries = dict(line.split('=', 1) for line in (assets / 'lang' / (language + '.lang')).read_text(encoding='utf-8').splitlines() if '=' in line and not line.startswith('#'))
    assert keys <= entries.keys() and all(entries[k] for k in keys)
    assert '%s' in entries['gui.nexustech.fan.speed'] and '%s' in entries['gui.nexustech.fan.range']
source = root / 'src/main/java/com/mikael8367/nexustech'
assert 'FanGuiHooks.server' in (source / 'MachineGuiHandler.java').read_text()
assert 'FanClient.gui' in (source / 'ClientProxy.java').read_text()
print('validate_fan_resources PASS (static checks, not Forge recipe loading)')
