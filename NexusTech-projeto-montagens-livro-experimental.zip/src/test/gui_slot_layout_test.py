"""Static GUI/container contract plus pixel regression against a local vanilla 1.12.2 client.

Run: python src/test/gui_slot_layout_test.py
Set MC_CLIENT_JAR to the local Minecraft client jar for the optional pixel test.
No game window or Minecraft runtime is required.
"""
import io
import os
import re
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
JAVA = ROOT / 'src/main/java/com/mikael8367/nexustech'


def read(path):
    return (JAVA / path).read_text(encoding='utf8')


def compact(text):
    return re.sub(r'\s+', '', text)


class GuiSlotsTest(unittest.TestCase):
    # Texture coordinates are verified against vanilla's 1.12.2 client jar below.
    # Slot centers have top-lefts at (8,140), (8,158), (8,176), (8,198).
    def test_chest_texture_inventory_alignment_and_no_phantom_grid(self):
        for name, top, player_y, hot_y in [('blockbreaker/BlockBreaker',80,85,143),
                                           ('crusher/Crusher',90,95,153),
                                           ('fan/Fan',86,91,149)]:
            with self.subTest(name=name):
                gui = compact(read(name+'Gui.java'))
                cont = compact(read(name+'Container.java'))
                self.assertIn('drawTexturedModalRect(guiLeft,guiTop,0,0,176,%d)' % top, gui)
                match = re.search(r'drawTexturedModalRect\(guiLeft,guiTop\+(\d+),0,(\d+),176,(\d+)\)', gui)
                self.assertIsNotNone(match)
                dest, source, height = map(int, match.groups())
                self.assertEqual(dest, top)
                self.assertEqual(height, 87)
                self.assertIn('drawRect(guiLeft+7,guiTop+17,guiLeft+169,guiTop+%d,0xffc6c6c6)' % top, gui)
                self.assertIn('GlStateManager.color(1.0F,1.0F,1.0F,1.0F)', gui)
                self.assertIn('8+c*18,%d+r*18' % player_y, cont)
                self.assertIn('8+c*18,%d' % hot_y, cont)
                self.assertEqual([dest + y - source for y in (140,158,176,198)],
                                 [player_y,player_y+18,player_y+36,hot_y])
                # Reproduce the original error explicitly; it must be 9 px.
                self.assertEqual(dest+140-126-player_y, 9)
                self.assertGreaterEqual(source+height, 215)  # bottom slot border

    def test_player_inventory_count_indices_coordinates_and_bounds(self):
        cases = [
            ('MachineContainer.java',166,'col+row*9+9','8+col*18,84+row*18','player,col,8+col*18,142',84,142),
            ('blockbreaker/BlockBreakerContainer.java',167,'9+r*9+c','8+c*18,85+r*18','inv,c,8+c*18,143',85,143),
            ('crusher/CrusherContainer.java',177,'9+r*9+c','8+c*18,95+r*18','inv,c,8+c*18,153',95,153),
            ('fan/FanContainer.java',173,'9+r*9+c','8+c*18,91+r*18','inv,c,8+c*18,149',91,149),
            ('mobgenerator/MobGeneratorContainer.java',166,'c+r*9+9','8+c*18,84+r*18','inv,c,8+c*18,142',84,142),
            ('digitalmine/DigitalMineContainer.java',222,'9+col+row*9','8+col*18,140+row*18','player,col,8+col*18,198',140,198),
            ('plantharvester/PlantHarvesterContainer.java',214,'9+c+r*9','8+c*18,132+r*18','player,c,8+c*18,190',132,190),
            ('nuclear/NuclearContainer.java',221,'c+r*9+9','8+c*18,NuclearGuiLayout.PLAYER_SLOT_Y+r*18','player,c,8+c*18,NuclearGuiLayout.HOTBAR_Y',139,197),
        ]
        for path,height,index,rows,hot,first,last in cases:
            with self.subTest(path=path):
                c=compact(read(path))
                self.assertIn(index,c); self.assertIn(rows,c); self.assertIn(hot,c)
                # 27+9 slots, indices 9..35 then 0..8, no overlapping hitboxes.
                coords=[(8+c*18,first+r*18) for r in range(3) for c in range(9)] + [(8+c*18,last) for c in range(9)]
                indices=[9+r*9+c for r in range(3) for c in range(9)] + list(range(9))
                self.assertEqual(sorted(indices),list(range(36)))
                for i,(x,y) in enumerate(coords):
                    self.assertTrue(0 <= x and x+16 <= 176 and 0 <= y and y+16 <= height)
                    for xx,yy in coords[i+1:]:
                        self.assertTrue(x+16<=xx or xx+16<=x or y+16<=yy or yy+16<=y)
        layout=compact(read('nuclear/NuclearGuiLayout.java'))
        self.assertIn('INVENTORY_TOP=125,PLAYER_SLOT_Y=INVENTORY_TOP+14,HOTBAR_Y=INVENTORY_TOP+72',layout)

    def test_other_gui_draws_match_containers(self):
        for gui, snippets in {
            'MachineGui.java':['drawTexturedModalRect(guiLeft,guiTop,0,0,xSize,ySize)', 'guiLeft+79,guiTop+34,55,16,18,18','guiLeft+55,guiTop+16,55,16,18,18','guiLeft+115,guiTop+34,55,16,18,18'],
            'mobgenerator/MobGeneratorGui.java':['slot(80,39)','slot(8+c*18,84+r*18)','slot(8+c*18,142)'],
            'digitalmine/DigitalMineGui.java':['slotBackground(8+18*col,32+18*row)','slotBackground(8+18*col,140+18*row)','slotBackground(8+18*col,198)'],
            'plantharvester/PlantHarvesterGui.java':['slot(8+c*18,30+r*18)','slot(8+c*18,132+r*18)','slot(152,94)','slot(8+c*18,190)'],
            'nuclear/NuclearGui.java':['guiTop+NuclearGuiLayout.INVENTORY_TOP,0,126,176,96','NuclearGuiLayout.MACHINE_SLOT_Y-1'],
        }.items():
            for snippet in snippets:
                with self.subTest(gui=gui, snippet=snippet): self.assertIn(snippet,compact(read(gui)))

    def test_machine_slots_and_transfer_boundaries(self):
        contracts = {
            'MachineContainer.java':['MachineSlot(tile,0,80,35)','MachineSlot(tile,0,56,17)','MachineSlot(tile,1,116,35)','machineSlots+27,machineSlots+36','machineSlots,machineSlots+27'],
            'blockbreaker/BlockBreakerContainer.java':['SlotItemHandler(t.tool,0,80,31)','mergeItemStack(stack,1,37,true)','mergeItemStack(stack,0,1,false)'],
            'crusher/CrusherContainer.java':['SlotItemHandler(t.cards,i,35+i*27,30)','mergeItemStack(stack,4,40,true)'],
            'digitalmine/DigitalMineContainer.java':['SlotItemHandler(tile.inventory,row*9+col,8+col*18,32+row*18)','mergeItemStack(stack,27,63,true)','mergeItemStack(stack,54,63,false)','mergeItemStack(stack,27,54,false)'],
            'plantharvester/PlantHarvesterContainer.java':['SlotItemHandler(tile.inv,r*9+c,8+c*18,30+r*18)','SlotItemHandler(tile.inv,27,152,94)','mergeItemStack(s,28,64,true)','mergeItemStack(s,55,64,false)','mergeItemStack(s,28,55,false)'],
            'mobgenerator/MobGeneratorContainer.java':['SlotItemHandler(t.items(),0,80,39)','mergeItemStack(stack,1,37,true)','mergeItemStack(stack,0,1,false)'],
            'nuclear/NuclearContainer.java':['SafeSlot(tile,0,8,NuclearGuiLayout.MACHINE_SLOT_Y)','SafeSlot(tile,1,30,NuclearGuiLayout.MACHINE_SLOT_Y)','SafeSlot(tile,2,52,NuclearGuiLayout.MACHINE_SLOT_Y)','mergeItemStack(s,3,39,true)','mergeItemStack(s,30,39,false)','mergeItemStack(s,3,30,false)']}
        for path, snippets in contracts.items():
            for snippet in snippets:
                with self.subTest(path=path,snippet=snippet): self.assertIn(snippet,compact(read(path)))

    def test_gui_ids_unique_and_routed_both_sides(self):
        refs=['crusher.CrusherRegistry','fan.FanRegistry','blockbreaker.BlockBreakerRegistry',
              'plantharvester.PlantHarvesterRegistry','mobgenerator.MobGeneratorRegistry',
              'digitalmine.DigitalMineRegistry','nuclear.NuclearGuiHooks']
        server=read('MachineGuiHandler.java'); client=read('ClientProxy.java'); ids=[0,1]
        for ref in refs:
            self.assertIn(ref+'.GUI_ID',server); self.assertIn(ref+'.GUI_ID',client)
            path=ref.replace('.','/')+'.java'
            ids.append(int(re.search(r'GUI_ID\s*=\s*(\d+)',read(path)).group(1)))
        self.assertEqual(len(ids),len(set(ids)))

    def test_vanilla_texture_pixels(self):
        jar = os.environ.get('MC_CLIENT_JAR')
        if not jar: self.skipTest('set MC_CLIENT_JAR to vanilla 1.12.2 client jar')
        from PIL import Image, ImageDraw
        with zipfile.ZipFile(jar) as z:
            tex=Image.open(io.BytesIO(z.read('assets/minecraft/textures/gui/container/generic_54.png'))).convert('RGBA')
            furnace=Image.open(io.BytesIO(z.read('assets/minecraft/textures/gui/container/furnace.png'))).convert('RGBA')
        self.assertEqual(tex.size,(256,256))
        furnace_frame=furnace.crop((7,83,25,101)).tobytes()
        for y in (83,101,119,141):
            for c in range(9): self.assertEqual(furnace.crop((7+18*c,y,25+18*c,y+18)).tobytes(),furnace_frame)
        # Every vanilla inventory slot has the same 18x18 frame, including hotbar.
        frame=tex.crop((7,139,25,157)).tobytes()
        for y in (139,157,175,197):
            for c in range(9): self.assertEqual(tex.crop((7+18*c,y,25+18*c,y+18)).tobytes(),frame)
        for top, height, machine in [(80,167,[(79,30)]),(90,177,[(34+i*27,29) for i in range(4)]),(86,173,[])]:
            image=Image.new('RGBA',(176,height))
            image.paste(tex.crop((0,0,176,top)),(0,0))
            ImageDraw.Draw(image).rectangle((7,17,168,top-1),fill=(198,198,198,255))
            image.paste(tex.crop((0,135,176,222)),(0,top))
            for x,y in machine: image.paste(tex.crop((7,17,25,35)),(x,y))
            for y in (top+4,top+22,top+40,top+62):
                for c in range(9): self.assertEqual(image.crop((7+18*c,y,25+18*c,y+18)).tobytes(),frame)
            # Chest slot in the old top panel is erased, not a phantom slot.
            self.assertEqual(image.getpixel((8,18)),(198,198,198,255))

if __name__=='__main__': unittest.main(verbosity=2)
