#!/usr/bin/env python3
"""Resource and side-isolation regressions for the read-only guide."""
import base64, json, pathlib, struct
root = pathlib.Path(__file__).resolve().parents[2]
assets = root / 'src/main/resources/assets/nexustech'
source = root / 'src/main/java/com/mikael8367/nexustech'
r = json.loads((assets / 'recipes/guide_book.json').read_text())
assert r['type'] == 'minecraft:crafting_shaped'
assert r['pattern'] == ['B','R','I']
assert [r['key'][x]['item'] for x in 'BRI'] == ['minecraft:book','minecraft:redstone','minecraft:iron_ingot']
assert r['result']['item'] == 'nexustech:guide_book'
assert r['result'].get('count', 1) == 1
for p in (assets / 'recipes').glob('*.json'):
    if p.name == 'guide_book.json': continue
    other = json.loads(p.read_text())
    assert not (other.get('pattern') == r['pattern'] and other.get('key') == r['key']), p
    assert other.get('result', {}).get('item') != 'nexustech:guide_book', (p, 'duplicate guide recipe')
registry = (source/'ModRegistry.java').read_text()
item = (source/'GuideBookItem.java').read_text()
assert 'new GuideBookItem()' in registry and 'register(GUIDE_BOOK)' in registry
assert 'setRegistryName(NexusTech.MODID, "guide_book")' in item
model = json.loads((assets / 'models/item/guide_book.json').read_text())
assert model['textures']['layer0'] == 'nexustech:items/guide_book'
b = base64.b64decode((root / 'src/main/texture_sources/assets/nexustech/textures/items/guide_book.png.b64').read_text())
assert b[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',b[16:24]) == (16,16)
for lang in ('pt_br','en_us'):
    lines=(assets / ('lang/'+lang+'.lang')).read_text().splitlines()
    d=dict(x.split('=',1) for x in lines if '=' in x)
    for key in ['item.nexustech.guide_book.name','guide.nexustech.title','guide.nexustech.recipes','guide.nexustech.lessons','guide.nexustech.search','guide.nexustech.empty','guide.nexustech.shaped','guide.nexustech.shapeless','guide.nexustech.unsupported','guide.nexustech.tap'] + ['guide.nexustech.lesson.'+str(i) for i in range(10)]:
        assert d.get(key), (lang,key)
book=(source/'GuideBookItem.java').read_text(); proxy=(source/'CommonProxy.java').read_text(); gui=(source/'GuideBookGui.java').read_text()
assert 'net.minecraft.client' not in book and 'net.minecraft.client' not in proxy
assert 'if (world.isRemote) NexusTech.proxy.openGuide()' in book
assert 'ForgeRegistries.RECIPES' in gui and 'getMatchingStacks()' in gui and 'getRecipeWidth()' in gui
assert 'displayGuiScreen(null)' in gui and 'setInventorySlotContents' not in gui and 'sendToServer' not in gui
assert 'GUIDE_BOOK' in (source/'ModRegistry.java').read_text()
# Every full chapter/page key must resolve in both languages.
import re
content=(source/'GuideBookContent.java').read_text()
keys=re.findall(r'"(guide\.nexustech\.(?:chapter|page)\.[^"]+)"', content)
assert len([k for k in keys if '.chapter.' in k]) == 10
assert len([k for k in keys if '.page.' in k]) == 91
assert len(keys) == len(set(keys)), 'duplicate guide key'
chapters = re.findall(r'new Chapter\("guide\.nexustech\.chapter\.([^"]+)", ([^\n]+)\)', content)
assert len(chapters) == 10
for chapter, pages in chapters:
    indexes = [int(i) for i in re.findall(r'guide\.nexustech\.page\.' + re.escape(chapter) + r'\.(\d+)', pages)]
    assert indexes and indexes == list(range(len(indexes))), (chapter, indexes)
for lang in ('pt_br','en_us'):
    lines=(assets / ('lang/'+lang+'.lang')).read_text().splitlines()
    d=dict(x.split('=',1) for x in lines if '=' in x)
    guide_keys=[x.split('=',1)[0] for x in lines if x.startswith('guide.nexustech.') and '=' in x]
    assert len(guide_keys) == len(set(guide_keys)), (lang, 'duplicate guide translation')
    for key in keys + ['guide.nexustech.index', 'guide.nexustech.assembly']:
        assert d.get(key), (lang,key)
        assert '%' not in d[key], (lang, key, 'unexpected format placeholder')
# Tutorials must stay aligned with the registered recipes and safety-critical code.
recipes = assets / 'recipes'
for kind in ('pickaxe', 'axe', 'shovel'):
    recipe = json.loads((recipes / ('techtool_' + kind + '.json')).read_text())
    assert recipe['result']['item'] == 'nexustech:techtool_' + kind
    assert recipe['key']['D']['item'] == 'minecraft:diamond_' + kind
    assert recipe['pattern'] == [' D ', 'CVC', ' S ']
    assert recipe['key']['C']['item'] == 'nexustech:techitem_copper_circuit_board'
    assert recipe['key']['V']['item'] == 'nexustech:techitem_silver_gear'
    assert recipe['key']['S']['item'] == 'nexustech:techitem_copper_frame'
extractor = json.loads((recipes / 'item_extractor_cable.json').read_text())
assert {x['item'] for x in extractor['ingredients']} == {'nexustech:item_cable', 'minecraft:hopper', 'minecraft:dye'}
assert next(x for x in extractor['ingredients'] if x['item'] == 'minecraft:dye')['data'] == 4
network = (source/'itemcable/ItemCableNetwork.java').read_text()
assert 'MAX_CABLES=128' in network and 'else if(gray&&' in network
assert 't.getClass()==TileEntityChest.class' in network and 'getLootTable()!=null' in network
reactor = (source/'nuclear/NuclearController.java').read_text()
assert 'SCRAM=1000, RESET=400, OUTPUT=400' in reactor and 'x==0&&y==2&&d==1' in reactor
assert 'FE_PER_TICK=200' in reactor and 'OUTPUT-outputThisTick' in reactor
assert 'NuclearRegistry.FUEL || s.getItem()==OreRegistry.INGOTS.get(OreType.URANIUM)' in reactor
assert 3*3*5-2 == 43
for lang, expected in (
    ('pt_br', {'reator.1': ['43', 'fora', 'terceira'], 'reator.2': ['urânio Nexus', 'Ligar'],
               'inicio.0': ['1 livro normal em cima', '1 redstone no meio', '1 lingote de ferro embaixo', 'mesma coluna'],
               'automacao.10': ['origem', 'extrator azul', 'cabo cinza', 'destino'],
               'automacao.14': ['máquinas Nexus'], 'equipamento.5': ['techtool_pickaxe', 'techtool_axe', 'techtool_shovel']}),
    ('en_us', {'reator.1': ['43', 'outward', 'third'], 'reator.2': ['Nexus uranium', 'On'],
               'inicio.0': ['1 vanilla book on top', '1 redstone dust in the middle', '1 iron ingot at the bottom', 'one crafting-table column'],
               'automacao.10': ['source', 'blue extractor', 'gray cable', 'destination'],
               'automacao.14': ['Nexus machines'], 'equipamento.5': ['techtool_pickaxe', 'techtool_axe', 'techtool_shovel']})):
    lines=(assets / ('lang/'+lang+'.lang')).read_text().splitlines()
    d=dict(x.split('=',1) for x in lines if '=' in x)
    for page, terms in expected.items():
        for term in terms: assert term in d['guide.nexustech.page.'+page], (lang, page, term)
# New devices: check registry names, recipe grids, implementation and bilingual text together.
for name, pattern, items in (
    ('wind_generator', ['IRI', 'IGI', ' C '], {'I':'minecraft:iron_ingot', 'R':'minecraft:redstone', 'G':'nexustech:coal_generator', 'C':'minecraft:feather'}),
    ('hydro_generator', ['IRI', 'IGI', ' C '], {'I':'minecraft:iron_ingot', 'R':'minecraft:redstone', 'G':'nexustech:coal_generator', 'C':'minecraft:water_bucket'}),
    ('utility_recycler', ['IRI', 'MCM', 'IRI'], {'I':'minecraft:iron_ingot', 'R':'minecraft:redstone', 'M':'minecraft:iron_bars', 'C':'minecraft:hopper'}),
    ('utility_purifier', ['IRI', 'MCM', 'IRI'], {'I':'minecraft:iron_ingot', 'R':'minecraft:redstone', 'M':'minecraft:glass', 'C':'minecraft:cauldron'})):
    recipe = json.loads((recipes / (name + '.json')).read_text())
    assert recipe['type'] == 'minecraft:crafting_shaped' and recipe['pattern'] == pattern
    assert {k:v['item'] for k,v in recipe['key'].items()} == items
    assert recipe['result']['item'] == 'nexustech:' + name
renewable = (source/'powerexpansion/RenewableTile.java').read_text()
for term in ('super(16000, 0, 128)', 'return 24;', 'return 32;', 'pos.getY() >= 80',
             'world.provider.hasSkyLight()', 'world.canSeeSky(above)', 'EnumFacing.HORIZONTALS',
             'if (level > 0) flows++', 'flows >= 2', 'buffer.generate(rate())'):
    assert term in renewable, term
utility = (source/'utilitymachines/UtilityMachineTile.java').read_text()
block = (source/'utilitymachines/UtilityMachineBlock.java').read_text()
for term in ('CAPACITY = 20000, RATE = 1000, COST = 20, TIME = 80', 'Blocks.GLASS_PANE',
             'Blocks.IRON_BARS', 'Blocks.GLASS', 'Items.IRON_INGOT', 'Items.ROTTEN_FLESH',
             'Items.LEATHER', 'kind == 0 ? 4 : 2', 's.hasTagCompound()', 's.getMetadata() != 0',
             'if (!fits(result))', 'energy < COST', 'energy -= COST', '++progress >= TIME'):
    assert term in utility, term
for term in ('inv.insertItem(0, held, false)', 'player.isSneaking() ? 0 : 1', 'message.nexustech.utilitymachines.energy'):
    assert term in block, term
assert 'return h.getClass()==ItemStackHandler.class?h:null;' in network
assert 'private final IItemHandler access = new IItemHandler()' in utility
assert 'ITEM_HANDLER_CAPABILITY.cast(access)' in utility
for lang, expected in (
    ('pt_br', {'energia.9':['24 FE/t', 'Y 80', 'céu'], 'energia.10':['32 FE/t', 'duas faces', 'corrente'],
               'energia.11':['16.000 FE', '128 FE/t', 'quebrar'], 'energia.12':['wind_generator','hydro_generator'],
               'processamento.15':['4 painéis', '4 grades', '1 lingote'], 'processamento.16':['2 carnes podres', '1 couro'],
               'processamento.17':['mão vazia', 'agachado'], 'processamento.18':['80 ticks', '20 FE/t', '1.600 FE', '20.000 FE', 'NBT'],
               'processamento.19':['utility_recycler', 'utility_purifier', 'cabo de itens Nexus']}),
    ('en_us', {'energia.9':['24 FE/t', 'Y 80', 'sky'], 'energia.10':['32 FE/t', 'two different horizontal sides', 'flowing water'],
               'energia.11':['16,000 FE', '128 FE/t', 'breaking'], 'energia.12':['wind_generator','hydro_generator'],
               'processamento.15':['4 vanilla glass panes', '4 vanilla iron bars', '1 iron ingot'], 'processamento.16':['2 vanilla rotten flesh', '1 leather'],
               'processamento.17':['empty hand', 'sneak'], 'processamento.18':['80 working ticks', '20 FE/t', '1,600 FE', '20,000 FE', 'NBT'],
               'processamento.19':['utility_recycler', 'utility_purifier', 'Nexus item cable']})):
    lines=(assets / ('lang/'+lang+'.lang')).read_text().splitlines()
    d=dict(x.split('=',1) for x in lines if '=' in x)
    required = ['tile.nexustech.'+name+'.name' for name in ('wind_generator','hydro_generator','utility_recycler','utility_purifier')]
    required += ['tooltip.nexustech.utilitymachines.'+suffix for suffix in ('0','1','controls','controls2')]
    required += ['message.nexustech.utilitymachines.energy']
    for key in required:
        assert sum(line.startswith(key+'=') for line in lines) == 1 and d.get(key), (lang,key)
    assert re.findall(r'%[a-zA-Z]', d['message.nexustech.utilitymachines.energy']) == ['%s', '%s']
    for page, terms in expected.items():
        for term in terms: assert term in d['guide.nexustech.page.'+page], (lang,page,term)
assert 'I18n.format(GuideBookContent.CHAPTERS.get(chapter).pageKeys.get(p))' in gui
assert 'selectedSlot == i) selected = current' in gui
# Verify the built resource, not just its base64 source. processResources must run first.
built=root/'build/resources/main/assets/nexustech/textures/items/guide_book.png'
assert built.is_file() and built.read_bytes() == b, 'PNG missing or stale in processed resources'
print('PASS guide book resources, translations and static side isolation')
