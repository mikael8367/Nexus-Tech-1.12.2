package com.mikael8367.nexustech;

import java.lang.reflect.Field;
import java.util.HashMap;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Bootstrap;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ChunkCache;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.items.CapabilityItemHandler;
import sun.misc.Unsafe;

/** Baseline: a diagnostic observer is not a connected network cable. */
public final class BridgeVisualBaselineTest extends NexusEnergyTestSupport {
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        Field f = Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true);
        EnergyCableVisualTest.unsafe = (Unsafe) f.get(null);
        BridgeBlock block = ModRegistry.BRIDGE;
        IBlockState base = block.getDefaultState();
        ok(base.getPropertyKeys().isEmpty(), "no directional state currently exists");
        eq(block.getBlockState().getValidStates().size(), 1, "one state");
        eq(block.getMetaFromState(base), 0, "metadata unchanged");
        ok(block.getStateFromMeta(0).equals(base), "metadata round-trip");
        BridgeTile tile = new BridgeTile();
        // The standalone Forge runtime may not initialize the item token.
        // Use an independent capability token rather than silently skip the test.
        java.lang.reflect.Constructor<?> ctor = net.minecraftforge.common.capabilities.Capability.class.getDeclaredConstructors()[0];
        ctor.setAccessible(true);
        net.minecraftforge.common.capabilities.Capability<?> items = (net.minecraftforge.common.capabilities.Capability<?>) ctor.newInstance(
                "test:items", null, (java.util.concurrent.Callable<Object>) () -> null);
        for (EnumFacing face : EnumFacing.VALUES) {
            ok(!tile.hasCapability(CapabilityEnergy.ENERGY, face), "no FE advertisement " + face);
            ok(tile.getCapability(CapabilityEnergy.ENERGY, face) == null, "no FE transfer " + face);
            ok(!tile.hasCapability(items, face) && tile.getCapability(items, face) == null, "no independent item capability " + face);
            if (CapabilityItemHandler.ITEM_HANDLER_CAPABILITY != null)
                ok(!tile.hasCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, face)
                        && tile.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, face) == null, "no Forge item capability " + face);
        }
        BlockPos p = EnergyCableVisualTest.POS;
        EnergyCableVisualTest.VisualWorld world = EnergyCableVisualTest.world();
        for (int mask = 0; mask < 64; mask++) {
            world.states.clear();
            for (EnumFacing face : EnumFacing.VALUES)
                if ((mask & (1 << face.ordinal())) != 0) world.states.put(p.offset(face), base);
            int reads = world.stateReads;
            ok(block.getActualState(base, world, p).equals(base), "no network connection mask " + mask);
            eq(world.stateReads, reads, "no neighbor inspection mask " + mask);
        }
        EnergyCableVisualTest.VisualWorld cw = EnergyCableVisualTest.world();
        EnergyCableVisualTest.SnapshotChunk chunk = (EnergyCableVisualTest.SnapshotChunk) EnergyCableVisualTest.unsafe.allocateInstance(EnergyCableVisualTest.SnapshotChunk.class);
        chunk.states = new HashMap<>(); chunk.tiles = new HashMap<BlockPos, TileEntity>();
        cw.chunks.put("0:0", chunk); chunk.states.put(p.west(), base);
        ChunkCache cache = new ChunkCache(cw, p.add(-1,-1,-1), p.add(1,1,1), 0);
        int reads = cw.chunkReads;
        ok(block.getActualState(base, cache, p).equals(base), "Forge ChunkCache baseline");
        ok(block.getActualState(base, new net.optifine.override.ChunkCacheOF(cache), p).equals(base), "OptiFine-shaped wrapper baseline");
        eq(cw.chunkReads, reads, "no chunk loading during visual lookup");
        eq(chunk.tileReads, 0, "no tile creation or lookup");
        System.out.println("BridgeVisualBaselineTest PASS (diagnostic-only baseline; no live render)");
    }
}
