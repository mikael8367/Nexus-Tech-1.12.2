package com.mikael8367.nexustech;

import com.google.gson.*;
import java.io.FileReader;
import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.block.Block;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Bootstrap;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import sun.misc.Unsafe;

/** Visual tests in simulated client worlds and a real ChunkCache, not a running client. */
public final class EnergyCableVisualTest extends NexusEnergyTestSupport {
    static final PropertyBool[] PROPS = {EnergyCableBlock.DOWN, EnergyCableBlock.UP,
            EnergyCableBlock.NORTH, EnergyCableBlock.SOUTH, EnergyCableBlock.WEST, EnergyCableBlock.EAST};
    static final String[] NAMES = {"down", "up", "north", "south", "west", "east"};
    static final BlockPos POS = new BlockPos(15, 64, 15);
    static Unsafe unsafe;
    static class VisualWorld extends World {
        Map<BlockPos,IBlockState> states; Map<BlockPos,TileEntity> tiles; Set<BlockPos> unloaded;
        Map<String,Chunk> chunks; int stateReads, tileReads, chunkReads;
        BlockPos throwingState, throwingTile;
        private VisualWorld() { super(null,null,null,null,true); }
        protected IChunkProvider createChunkProvider() { return null; }
        protected boolean isChunkLoaded(int x,int z,boolean allowEmpty) { return true; }
        public boolean isBlockLoaded(BlockPos p) { return !unloaded.contains(p); }
        public IBlockState getBlockState(BlockPos p) {
            if (unloaded.contains(p)) throw new AssertionError("unloaded state " + p);
            if (p.equals(throwingState)) throw new IllegalStateException("bad state read");
            stateReads++; return states.containsKey(p) ? states.get(p) : Blocks.AIR.getDefaultState();
        }
        public TileEntity getTileEntity(BlockPos p) {
            if (unloaded.contains(p)) throw new AssertionError("unloaded tile " + p);
            if (p.equals(throwingTile)) throw new IllegalStateException("bad tile read");
            tileReads++; return tiles.get(p);
        }
        public Chunk getChunkFromChunkCoords(int x, int z) { chunkReads++; return chunks.get(x+":"+z); }
    }
    static class SnapshotChunk extends Chunk {
        Map<BlockPos,IBlockState> states; Map<BlockPos,TileEntity> tiles;
        int tileReads;
        SnapshotChunk(World w, int x, int z) { super(w,x,z); }
        public boolean isEmptyBetween(int a,int b) { return false; }
        public IBlockState getBlockState(BlockPos p) { return states.containsKey(p) ? states.get(p) : Blocks.AIR.getDefaultState(); }
        public TileEntity getTileEntity(BlockPos p, Chunk.EnumCreateEntityType type) {
            ok(type == Chunk.EnumCreateEntityType.CHECK, "cache must not create tiles");
            tileReads++; return tiles.get(p);
        }
    }
    static class Sided extends TileEntity {
        EnumFacing exposed; int checks; EnumFacing last; int energy = 450, itemCount = 19, emc = 733;
        Sided(EnumFacing face) { exposed = face; }
        @Override public boolean hasCapability(Capability<?> cap, EnumFacing face) {
            checks++; last = face; return cap == CapabilityEnergy.ENERGY && face == exposed;
        }
        @Override public <T> T getCapability(Capability<T> cap, EnumFacing face) {
            // No storage is exposed on the unadvertised face. Visual probing
            // must never call receiveEnergy/extractEnergy.
            return null;
        }
    }
    static VisualWorld world() throws Exception {
        VisualWorld w=(VisualWorld) unsafe.allocateInstance(VisualWorld.class);
        w.states=new HashMap<>(); w.tiles=new HashMap<>(); w.unloaded=new HashSet<>(); w.chunks=new HashMap<>();
        unsafe.putBoolean(w,unsafe.objectFieldOffset(World.class.getField("isRemote")),true); return w;
    }
    static void mask(IBlockState state, int mask, String what) {
        for (int i=0;i<6;i++) ok(state.getValue(PROPS[i]) == ((mask & (1<<i))!=0), what+" "+NAMES[i]);
    }
    static JsonObject json(String path) throws Exception {
        try(FileReader reader=new FileReader("src/main/resources/assets/nexustech/"+path)) {
            return new JsonParser().parse(reader).getAsJsonObject();
        }
    }
    static void assets() throws Exception {
        JsonArray parts=json("blockstates/energy_cable.json").getAsJsonArray("multipart");
        eq(parts.size(),7,"one center and six arms");
        JsonObject center=parts.get(0).getAsJsonObject();
        ok(!center.has("when"),"center always visible");
        ok(center.getAsJsonObject("apply").get("model").getAsString().equals("nexustech:energy_cable_center"),"center model");
        Set<String> found=new HashSet<>();
        for(int i=1;i<parts.size();i++) {
            JsonObject part=parts.get(i).getAsJsonObject(), when=part.getAsJsonObject("when");
            eq(when.entrySet().size(),1,"one condition per arm");
            String name=when.entrySet().iterator().next().getKey();
            ok(Arrays.asList(NAMES).contains(name) && found.add(name),"unique face");
            ok(when.get(name).getAsString().equals("true"),"only enabled arms");
            ok(part.getAsJsonObject("apply").get("model").getAsString().equals("nexustech:energy_cable_"+name),"matching model");
        }
        JsonObject model=json("models/block/energy_cable_center.json");
        JsonObject centerElement=model.getAsJsonArray("elements").get(0).getAsJsonObject();
        eq(model.getAsJsonArray("elements").size(),1,"one center cube");
        ok(centerElement.getAsJsonArray("from").toString().equals("[6,6,6]") && centerElement.getAsJsonArray("to").toString().equals("[10,10,10]"),"center dimensions");
        eq(centerElement.getAsJsonObject("faces").entrySet().size(),6,"center has all faces");
        JsonArray old=json("models/block/energy_cable.json").getAsJsonArray("elements");
        String[] oldOrder={"west","east","down","up","north","south"};
        String[] from={"[0,6,6]","[10,6,6]","[6,0,6]","[6,10,6]","[6,6,0]","[6,6,10]"};
        String[] to={"[6,10,10]","[16,10,10]","[10,6,10]","[10,16,10]","[10,10,6]","[10,10,16]"};
        for(int i=0;i<6;i++) {
            JsonArray arm=json("models/block/energy_cable_"+oldOrder[i]+".json").getAsJsonArray("elements");
            eq(arm.size(),1,"single arm"); ok(arm.get(0).equals(old.get(i)),"preserved geometry " + oldOrder[i]);
            JsonObject element=arm.get(0).getAsJsonObject();
            ok(element.getAsJsonArray("from").toString().equals(from[i]),"arm starts on correct axis " + oldOrder[i]);
            ok(element.getAsJsonArray("to").toString().equals(to[i]),"arm ends on correct axis " + oldOrder[i]);
            JsonObject end=element.getAsJsonObject("faces").getAsJsonObject(oldOrder[i]);
            ok(end != null && end.get("cullface").getAsString().equals(oldOrder[i]),"end face orientation " + oldOrder[i]);
        }
        ok(json("models/item/energy_cable.json").get("parent").getAsString().equals("nexustech:block/energy_cable"),"item model unchanged");
    }
    static void realMultipartSelectors(EnergyCableBlock cable) throws Exception {
        net.minecraft.client.renderer.block.model.ModelBlockDefinition definition;
        try (FileReader reader = new FileReader("src/main/resources/assets/nexustech/blockstates/energy_cable.json")) {
            definition = net.minecraft.client.renderer.block.model.ModelBlockDefinition.parseFromReader(reader);
        }
        ok(definition.hasMultipartData(), "Minecraft parses multipart");
        java.util.List<net.minecraft.client.renderer.block.model.multipart.Selector> selectors = definition.getMultipartData().getSelectors();
        eq(selectors.size(), 7, "Minecraft selector count");
        java.util.Map<IBlockState, net.minecraft.client.renderer.block.model.ModelResourceLocation> mapped =
                new net.minecraft.client.renderer.block.statemap.DefaultStateMapper().putStateModelLocations(cable);
        eq(mapped.size(), 64, "default mapper registers all actual states");
        for (IBlockState state : cable.getBlockState().getValidStates()) {
            ok(mapped.containsKey(state), "state mapped");
            int expected = 1;
            for (PropertyBool prop : PROPS) if (state.getValue(prop)) expected++;
            int selected = 0;
            for (net.minecraft.client.renderer.block.model.multipart.Selector selector : selectors)
                if (selector.getPredicate(cable.getBlockState()).apply(state)) selected++;
            eq(selected, expected, "actual Minecraft predicates " + state);
        }
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); unsafe=(Unsafe)f.get(null);
        EnergyCableBlock cable=new EnergyCableBlock(); IBlockState base=cable.getDefaultState();
        eq(base.getPropertyKeys().size(),6,"cable properties"); eq(cable.getBlockState().getValidStates().size(),64,"all combinations");
        for(int i=0;i<6;i++) ok(base.getPropertyKeys().contains(PROPS[i]) && PROPS[i].getName().equals(NAMES[i]),"property " + NAMES[i]);
        mask(base,0,"default");
        for(IBlockState s:cable.getBlockState().getValidStates()) {
            eq(cable.getMetaFromState(s),0,"no state saved"); mask(cable.getStateFromMeta(cable.getMetaFromState(s)),0,"metadata reset");
        }
        VisualWorld w=world(); mask(cable.getActualState(base,w,POS),0,"isolated client");
        for(int i=0;i<6;i++) {
            EnumFacing dir=EnumFacing.VALUES[i]; BlockPos p=POS.offset(dir);
            w.states.put(p,base); mask(cable.getActualState(base,w,POS),1<<i,"cable " + dir);
            w.states.remove(p); mask(cable.getActualState(base.withProperty(PROPS[i],true),w,POS),0,"cable removal clears stale " + dir);
            w.states.put(p,Blocks.STONE.getDefaultState()); Sided sided=new Sided(dir.getOpposite()); w.tiles.put(p,sided);
            mask(cable.getActualState(base,w,POS),1<<i,"sided FE " + dir);
            ok(sided.last==dir.getOpposite(),"opposite face " + dir);
            eq(sided.energy,450,"energy unchanged"); eq(sided.itemCount,19,"items unchanged"); eq(sided.emc,733,"EMC unchanged");
            sided.exposed=dir; mask(cable.getActualState(base,w,POS),0,"wrong face " + dir);
            sided.exposed=dir.getOpposite(); w.unloaded.add(p);
            mask(cable.getActualState(base,w,POS),0,"unloaded " + dir);
            w.unloaded.clear(); mask(cable.getActualState(base,w,POS),1<<i,"loaded again " + dir);
            w.tiles.remove(p); mask(cable.getActualState(base,w,POS),0,"non-energy block " + dir);
            w.states.remove(p);
        }
        // Every visible combination must be recalculated, even from a stale input state.
        for(int bits=0;bits<64;bits++) {
            w.states.clear();
            for(int i=0;i<6;i++) if((bits & (1<<i))!=0) w.states.put(POS.offset(EnumFacing.VALUES[i]),base);
            mask(cable.getActualState(cable.getBlockState().getValidStates().get(0),w,POS),bits,"combination " + bits);
        }
        w.states.remove(POS.north()); mask(cable.getActualState(base,w,POS),63 ^ (1<<2),"one disconnected");
        w.states.clear(); w.tiles.clear();
        // Exercise a real Nexus machine inventory and energy, not just counters on the stub.
        MachineTile.Generator generator=new MachineTile.Generator(); generator.energy=517;
        generator.inventory.setStackInSlot(0,new net.minecraft.item.ItemStack(net.minecraft.init.Items.COAL,13));
        w.states.put(POS.east(),ModRegistry.GENERATOR.getDefaultState()); w.tiles.put(POS.east(),generator);
        mask(cable.getActualState(base,w,POS),1<<5,"real Nexus machine");
        eq(generator.energy,517,"real machine FE unchanged");
        eq(generator.inventory.getStackInSlot(0).getCount(),13,"real machine items unchanged");
        ok(generator.inventory.getStackInSlot(0).getItem()==net.minecraft.init.Items.COAL,"real machine item type unchanged");
        // One failed neighbor lookup must not discard the entire actual state.
        // The vanilla dispatcher otherwise catches the exception and renders the
        // original all-false metadata state, hiding even unrelated cable arms.
        w.states.clear(); w.tiles.clear(); w.states.put(POS.east(), base);
        w.throwingState=POS.down();
        mask(cable.getActualState(base,w,POS),1<<5,"state lookup failure isolates face");
        w.throwingState=null; w.states.put(POS.down(),Blocks.STONE.getDefaultState());
        w.throwingTile=POS.down();
        mask(cable.getActualState(base,w,POS),1<<5,"tile lookup failure isolates face");
        w.throwingTile=null; w.states.clear(); w.states.put(POS.east(),ModRegistry.GENERATOR.getDefaultState());
        // A broken or invalid third-party capability must not crash client rendering.
        TileEntity broken = new TileEntity() {
            @Override public boolean hasCapability(Capability<?> cap, EnumFacing face) {
                throw new IllegalStateException("broken visual capability");
            }
        };
        w.tiles.put(POS.east(), broken);
        mask(cable.getActualState(base,w,POS),0,"throwing FE probe fails closed");
        Sided invalid = new Sided(EnumFacing.WEST); invalid.invalidate();
        w.tiles.put(POS.east(), invalid);
        mask(cable.getActualState(base,w,POS),0,"invalid FE tile fails closed");
        // A tile that does not expose FE is not a visual connection.
        w.tiles.put(POS.east(),new BridgeTile());
        mask(cable.getActualState(base,w,POS),0,"non-energy tile");
        for(MachineBlock other:ModRegistry.BLOCKS) if(other != ModRegistry.CABLE) {
            eq(other.getDefaultState().getPropertyKeys().size(),0,"other block states unchanged");
        }
        // Exercise the genuine 1.12 ChunkCache getters, including its null chunk.
        VisualWorld cw=world(); SnapshotChunk chunk=(SnapshotChunk)unsafe.allocateInstance(SnapshotChunk.class);
        chunk.states=new HashMap<>(); chunk.tiles=new HashMap<>();
        cw.chunks.put("0:0",chunk); // east and south chunks deliberately missing
        BlockPos west=POS.west(), east=POS.east();
        chunk.states.put(west,Blocks.STONE.getDefaultState()); Sided endpoint=new Sided(EnumFacing.EAST); chunk.tiles.put(west,endpoint);
        ChunkCache cache=new ChunkCache(cw,POS.add(-1,-1,-1),POS.add(1,1,1),0);
        int reads=cw.chunkReads; mask(cable.getActualState(base,cache,POS),1<<4,"ChunkCache client and unloaded chunks");
        net.optifine.override.ChunkCacheOF of = new net.optifine.override.ChunkCacheOF(cache);
        mask(cable.getActualState(base,of,POS),1<<4,"OptiFine-shaped wrapper exposes sided FE");
        chunk.states.put(POS.north(),base);
        mask(cable.getActualState(base,of,POS),(1<<4)|(1<<2),"OptiFine-shaped wrapper exposes cable and FE");
        chunk.states.remove(POS.north());
        eq(cw.chunkReads,reads,"no chunk retrieval while calculating state"); eq(cw.stateReads,0,"cache does not query world state"); eq(cw.tileReads,0,"cache does not query world tile");
        chunk.states.remove(west); mask(cable.getActualState(base,cache,POS),0,"cache disconnect");
        ok(cache.getBlockState(east).getMaterial()==net.minecraft.block.material.Material.AIR,"missing cache chunk is air");
        assets(); realMultipartSelectors(cable);
        System.out.println("EnergyCableVisualTest PASS (simulated client and ChunkCache; no live rendering)");
    }
}
