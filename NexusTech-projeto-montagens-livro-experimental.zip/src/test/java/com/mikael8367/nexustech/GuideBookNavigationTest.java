package com.mikael8367.nexustech;

import java.util.Arrays;

public final class GuideBookNavigationTest {
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static void at(int[] actual, int page, int part) {
        check(Arrays.equals(actual, new int[]{page, part}), Arrays.toString(actual));
    }
    public static void main(String[] args) {
        check(!GuideBookContent.CHAPTERS.isEmpty(), "no chapters");
        int pageCount = 0;
        for (GuideBookContent.Chapter chapter : GuideBookContent.CHAPTERS) {
            check(!chapter.titleKey.isEmpty() && !chapter.pageKeys.isEmpty(), "empty chapter");
            pageCount += chapter.pageKeys.size();
        }
        check(pageCount >= GuideBookContent.CHAPTERS.size(), "missing pages");
        check(GuideBookNavigation.chunks(0, 5) == 1, "empty text");
        check(GuideBookNavigation.chunks(10, 5) == 2, "exact fit");
        check(GuideBookNavigation.chunks(11, 5) == 3, "partial page");
        check(GuideBookNavigation.chunks(3, 0) == 3, "small screens");
        check(GuideBookNavigation.chunks(Integer.MAX_VALUE, Integer.MAX_VALUE) == 1, "chunk overflow");
        check(GuideBookNavigation.chunks(Integer.MAX_VALUE, 2) == 1073741824, "large chunk count");
        check(GuideBookNavigation.lastIndexStart(0, 0) == 0, "empty index");
        check(GuideBookNavigation.lastIndexStart(21, 10) == 20, "partial last index");
        check(GuideBookNavigation.lastIndexStart(20, 10) == 10, "full last index");
        check(GuideBookNavigation.lastIndexStart(3, 0) == 2, "small index");
        // All wrapped lines appear exactly once as the viewport size changes.
        for (int lines = 0; lines < 100; lines++) {
            for (int capacity = 1; capacity < 20; capacity++) {
                int seen = 0;
                for (int chunk = 0; chunk < GuideBookNavigation.chunks(lines, capacity); chunk++) {
                    int start = chunk * capacity;
                    for (int i = start; i < Math.min(lines, start + capacity); i++) {
                        check(i == seen, "lost or repeated line");
                        seen++;
                    }
                }
                check(seen == lines, "missing final lines");
            }
        }
        // GUI's lazy navigation must match the full-array implementation.
        int[] varied = {1, 4, 2, 3};
        for (int pg = 0; pg < varied.length; pg++) for (int pt = 0; pt < varied[pg]; pt++)
            for (int dir = -1; dir <= 1; dir++) {
                int[] expectedLazy = GuideBookNavigation.move(pg, pt, varied, dir);
                int previous = pg > 0 && pt == 0 && dir < 0 ? varied[pg - 1] : 1;
                at(GuideBookNavigation.move(pg, pt, varied.length, varied[pg], previous, dir), expectedLazy[0], expectedLazy[1]);
            }
        at(GuideBookNavigation.move(0, 0, 0, 1, 1, 1), 0, 0);
        int[] counts = {2, 1, 3};
        int[] p = {0, 0};
        int[][] expected = {{0,1}, {1,0}, {2,0}, {2,1}, {2,2}, {2,2}};
        for (int[] e : expected) { p = GuideBookNavigation.move(p[0], p[1], counts, 1); at(p, e[0], e[1]); }
        int[][] reverse = {{2,1}, {2,0}, {1,0}, {0,1}, {0,0}, {0,0}};
        for (int[] e : reverse) { p = GuideBookNavigation.move(p[0], p[1], counts, -1); at(p, e[0], e[1]); }
        at(GuideBookNavigation.move(2, 99, counts, 0), 2, 2);
        at(GuideBookNavigation.move(0, 0, new int[0], 1), 0, 0);
        System.out.println("PASS guide chapter and page navigation");
    }
}
