package com.mikael8367.nexustech;

import com.mikael8367.nexustech.digitalmine.DigitalMineRegistry;
import com.mikael8367.nexustech.nuclear.NuclearRegistry;
import com.mikael8367.nexustech.powerexpansion.SolarArrayRegistry;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.block.Block;
import net.minecraft.init.Bootstrap;

/** Checks the actual diagram cells; this is not a rendering or in-game test. */
public final class GuideStructureGuiTest {
    private static void compareValidatorFixtures(GuideStructureGui gui, Field kind, Field layer, Method cell) throws Exception {
        for (int k=0; k<2; k++) {
            String pkg=k==0 ? "digitalmine.DigitalMineTest" : "nuclear.NuclearReactorTest";
            Class<?> fixture=Class.forName("com.mikael8367.nexustech."+pkg);
            Class<?> worldType=Class.forName("com.mikael8367.nexustech."+pkg+"$TestWorld");
            Method world=fixture.getDeclaredMethod("world"); world.setAccessible(true);
            Method build=k==0 ? fixture.getDeclaredMethod("assemble",worldType,net.minecraft.util.math.BlockPos.class,net.minecraft.util.EnumFacing.class)
                    : fixture.getDeclaredMethod("build",worldType,net.minecraft.util.EnumFacing.class);
            build.setAccessible(true);
            for (net.minecraft.util.EnumFacing front : net.minecraft.util.EnumFacing.HORIZONTALS) {
                net.minecraft.world.World w=(net.minecraft.world.World)world.invoke(null);
                net.minecraft.util.math.BlockPos origin=k==0 ? new net.minecraft.util.math.BlockPos(20,64,20) : new net.minecraft.util.math.BlockPos(0,64,0);
                Object controller=k==0 ? build.invoke(null,w,origin,front) : build.invoke(null,w,front);
                if (k==0 && !((com.mikael8367.nexustech.digitalmine.DigitalMineTile)controller).structureValid())
                    throw new AssertionError("Mine fixture failed validator");
                if (k==1 && ((com.mikael8367.nexustech.nuclear.NuclearController)controller).validateStructure()!=1)
                    throw new AssertionError("Reactor fixture failed validator");
                kind.setInt(gui,k);
                for (int y=0; y<(k==0?2:5); y++) {
                    layer.setInt(gui,y);
                    for (int row=0;row<3;row++) for (int col=0;col<3;col++) {
                        int x=GuideStructureGui.gridRight(col), d=GuideStructureGui.gridDepth(row);
                        net.minecraft.util.math.BlockPos p=origin.offset(front.getOpposite(),d).offset(front.rotateY(),x).up(y);
                        if (cell.invoke(gui,x,d)!=w.getBlockState(p).getBlock())
                            throw new AssertionError("Validator fixture mismatch "+k+"/"+front+"/"+y+"/"+row+"/"+col);
                    }
                }
            }
        }
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        GuideStructureGui gui = new GuideStructureGui(null);
        Field kind = GuideStructureGui.class.getDeclaredField("kind"); kind.setAccessible(true);
        Field layer = GuideStructureGui.class.getDeclaredField("layer"); layer.setAccessible(true);
        Field advanced = GuideStructureGui.class.getDeclaredField("advanced"); advanced.setAccessible(true);
        Method cell = GuideStructureGui.class.getDeclaredMethod("blockAt", int.class, int.class); cell.setAccessible(true);
        for (int k=0; k<3; k++) for (int v=0; v<(k==0?2:1); v++) {
            kind.setInt(gui,k); advanced.setBoolean(gui,v==1);
            for (int y=0; y<(k==0?2:k==1?5:4); y++) {
                layer.setInt(gui,y);
                for(int x=-1;x<=1;x++) for(int d=0;d<3;d++) {
                    Block want;
                    if (k==0) want=y==0 && x==0 && d==0 ? (v==0?DigitalMineRegistry.BASIC:DigitalMineRegistry.ADVANCED) : DigitalMineRegistry.CASING;
                    else if (k==1) want=y==0 && x==0 && d==0 ? NuclearRegistry.CONTROLLER : y==2 && x==0 && d==1 ? NuclearRegistry.CORE : NuclearRegistry.CASING;
                    else want=y==3 ? SolarArrayRegistry.MODULE : x==0 && d==1 ? (y==0?SolarArrayRegistry.ARRAY:SolarArrayRegistry.POLE) : null;
                    if (cell.invoke(gui,x,d)!=want) throw new AssertionError("Mismatch " + k+"/"+v+"/"+y+"/"+x+"/"+d);
                }
            }
        }
        // All overview cells use the same model as their corresponding layer.
        Method overviewCell = GuideStructureGui.class.getDeclaredMethod("blockAt", int.class, int.class, int.class);
        overviewCell.setAccessible(true);
        for (int k=0; k<3; k++) for (int v=0; v<(k==0?2:1); v++) {
            kind.setInt(gui,k); advanced.setBoolean(gui,v==1);
            int n=k==0?2:k==1?5:4, nonempty=0, core=0;
            for (int y=0; y<n; y++) {
                layer.setInt(gui,y);
                for(int x=-1;x<=1;x++) for(int d=0;d<3;d++) {
                    Block block=(Block) overviewCell.invoke(gui,x,d,y);
                    if (block!=cell.invoke(gui,x,d)) throw new AssertionError("Overview mismatch");
                    if (block!=null) nonempty++;
                    if (k==1 && block==NuclearRegistry.CORE) core++;
                }
            }
            if (nonempty!=(k==0?18:k==1?45:12) || (k==1 && core!=1))
                throw new AssertionError("Wrong overview counts: " + k + "/" + nonempty + "/" + core);
        }
        // The visible top-view grid must use the validators' controller-relative
        // transform for every direction, including front, back, left and right.
        advanced.setBoolean(gui, false);
        net.minecraft.util.math.BlockPos origin = new net.minecraft.util.math.BlockPos(20, 64, 20);
        for (net.minecraft.util.EnumFacing front : net.minecraft.util.EnumFacing.HORIZONTALS) {
            for (int row=0; row<3; row++) for (int col=0; col<3; col++) {
                int d=GuideStructureGui.gridDepth(row), x=GuideStructureGui.gridRight(col);
                if (d!=2-row || x!=col-1) throw new AssertionError("Grid orientation");
                net.minecraft.util.math.BlockPos validator = com.mikael8367.nexustech.nuclear.NuclearController.at(origin, front, x, 0, d);
                net.minecraft.util.math.BlockPos expected = origin.offset(front.getOpposite(), 2-row).offset(front.rotateY(), col-1);
                if (!validator.equals(expected)) throw new AssertionError("Grid/world transform " + front);
                for (int k=0; k<2; k++) {
                    kind.setInt(gui,k); layer.setInt(gui,0);
                    Block b=(Block)cell.invoke(gui,x,d);
                    if (row==2 && col==1 && b!=(k==0?DigitalMineRegistry.BASIC:NuclearRegistry.CONTROLLER))
                        throw new AssertionError("Controller must be front center");
                }
            }
        }
        kind.setInt(gui,1); layer.setInt(gui,2);
        if (cell.invoke(gui,GuideStructureGui.gridRight(1),GuideStructureGui.gridDepth(1))!=NuclearRegistry.CORE)
            throw new AssertionError("Reactor core must be grid center on layer 3");
        compareValidatorFixtures(gui, kind, layer, cell);
        // 854x480 at GUI scale 2 gives 427x240; also check the minimum
        // vanilla logical width. The front label must remain above the buttons.
        for (int width : new int[]{320, 427, 854}) {
            int panel=Math.min(320,width-8);
            if (GuideStructureGui.GRID_LEFT + 3*GuideStructureGui.GRID_CELL > GuideStructureGui.LEGEND_LEFT)
                throw new AssertionError("Grid overlaps legend");
            if (GuideStructureGui.GRID_TOP + 103 + 9 >= 240-23)
                throw new AssertionError("Front label overlaps buttons");
            if (panel - GuideStructureGui.LEGEND_LEFT - 4 < 150)
                throw new AssertionError("Legend too narrow");
        }
        // Scaled launcher screens: transformed controls stay on-screen, do not
        // overlap, and physical button centers map back inside the same button.
        for (int[] size : new int[][] {{160,120},{200,150},{240,180},{320,240},{427,240},{854,480},{240,320}}) {
            int sw=size[0], sh=size[1];
            float s=GuideStructureGui.canvasScale(sw,sh);
            int vw=GuideStructureGui.canvasDimension(sw,s), vh=GuideStructureGui.canvasDimension(sh,s);
            float ox=(sw-vw*s)/2, oy=(sh-vh*s)/2;
            if (vw<319 || vh<239 || ox < -0.01f || oy < -0.01f || ox+vw*s>sw+0.01f || oy+vh*s>sh+0.01f)
                throw new AssertionError("Canvas bounds " + sw+"x"+sh);
            int panel=Math.min(320,vw-8), left=(vw-panel)/2, quarter=panel/4;
            for (int row=0; row<2; row++) for (int i=0; i<4; i++) {
                int bx=left+i*quarter, by=row==0?16:vh-23, bw=i==3?panel-3*quarter:quarter;
                if (bx<0 || by<0 || bx+bw>vw || by+20>vh || (i<3 && bx+bw>left+(i+1)*quarter))
                    throw new AssertionError("Button bounds");
                int px=Math.round(ox+(bx+bw/2f)*s), py=Math.round(oy+(by+10)*s);
                int mx=GuideStructureGui.canvasMouse(px,ox,s), my=GuideStructureGui.canvasMouse(py,oy,s);
                if (mx<bx || mx>=bx+bw || my<by || my>=by+20) throw new AssertionError("Button touch transform");
            }
            if (GuideStructureGui.GRID_TOP+103+9>=vh-23 || 62+3*(2*10+2*10+4)>=vh-23)
                throw new AssertionError("Grid or maximum wrapped summary collides with bottom buttons");
        }
        // Solar retains its original exploded overview, with disjoint planes.
        for (int n=1; n<=5; n++) for (int[] size : new int[][] {{320,240},{480,270},{640,480}}) {
            int panel=Math.min(320,size[0]-8), available=size[1]-65-62;
            float scale=GuideStructureGui.diagramScale(panel,available,n);
            if (!(scale>0) || GuideStructureGui.diagramHeight(n)*scale>available+0.001f || 108*scale>panel-8+0.001f)
                throw new AssertionError("Diagram bounds " + n);
            if (n>1 && GuideStructureGui.diagramHeight(n)-GuideStructureGui.diagramHeight(n-1)<60)
                throw new AssertionError("Layers overlap");
        }
        if (GuideStructureGui.diagramScale(200,0,5)!=0) throw new AssertionError("Empty viewport");
        System.out.println("GuideStructureGuiTest OK");
    }
}
