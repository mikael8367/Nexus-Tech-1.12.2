package com.mikael8367.nexustech;

import java.lang.reflect.Field;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Bootstrap;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import sun.misc.Unsafe;

/** Server-side GUI dispatch, slots, reach and 32-bit synchronization for all original machines. */
public final class MachineGuiRoutingTest extends NexusEnergyTestSupport {
    static final class Player extends EntityOtherPlayerMP {
        int opens, guiId, x, y, z;
        Player(net.minecraft.world.World world) { super(world, new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(), "test")); }
        @Override public void openGui(Object mod, int id, net.minecraft.world.World world, int x, int y, int z) {
            opens++; guiId=id; this.x=x; this.y=y; this.z=z;
        }
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true);
        Unsafe u=(Unsafe)f.get(null);
        Player p=(Player)u.allocateInstance(Player.class);
        p.inventory=new InventoryPlayer(p);
        FakeWorld w=world(false); p.world=w; p.posX=.5; p.posY=64.5; p.posZ=.5;
        MachineGuiHandler h=new MachineGuiHandler();
        MachineTile[] machines={new MachineTile.Solar(),new MachineTile.Generator(),new MachineTile.Turbine(),
            new MachineTile.Battery(),new MachineTile.Furnace(),new MachineTile.Crusher(),
            new MachineTile.Compressor(),new MachineTile.LavaGenerator()};
        for (MachineTile tile:machines) {
            w.put(O,tile);
            MachineBlock block=new MachineBlock("gui_test", tile.kind);
            int before=p.opens;
            ok(block.onBlockActivated(w,O,block.getDefaultState(),p,net.minecraft.util.EnumHand.MAIN_HAND,net.minecraft.util.EnumFacing.UP,0,0,0),"activation consumed " + tile.kind);
            eq(p.opens,before+1,"activation opens " + tile.kind);
            ok(p.guiId==0 && p.x==0 && p.y==64 && p.z==0,"activation coordinates " + tile.kind);
            Object result=h.getServerGuiElement(0,p,w,0,64,0);
            ok(result instanceof MachineContainer,"dispatch " + tile.kind);
            MachineContainer c=(MachineContainer)result;
            eq(c.inventorySlots.size(),36+tile.inventory.getSlots(),"slot count " + tile.kind);
            if (tile.inventory.getSlots()==2) ok(!c.getSlot(1).isItemValid(new ItemStack(Items.COAL)),"output rejects insertion " + tile.kind);
            c.updateProgressBar(0,100000 & 65535); c.updateProgressBar(1,100000 >>> 16);
            eq(tile.energy,100000,"32-bit field " + tile.kind);
            p.posX=100; ok(!c.canInteractWith(p),"distant player denied " + tile.kind); p.posX=.5;
            FakeWorld other=world(false); p.world=other; ok(!c.canInteractWith(p),"other dimension denied " + tile.kind); p.world=w;
            w.unloaded.add(O); ok(!c.canInteractWith(p),"unloaded denied " + tile.kind);
            ok(h.getServerGuiElement(0,p,w,0,64,0)==null,"no dispatch while unloaded " + tile.kind); w.unloaded.clear();
        }
        MachineTile.Generator generator=new MachineTile.Generator(); w.put(O,generator);
        MachineContainer generatorGui=(MachineContainer)h.getServerGuiElement(0,p,w,0,64,0);
        p.inventory.setInventorySlotContents(9,new ItemStack(Items.COAL,4));
        ok(!generatorGui.transferStackInSlot(p,1).isEmpty(),"shift-click fuel into generator");
        eq(generator.inventory.getStackInSlot(0).getCount(),4,"fuel count preserved");
        ok(!generatorGui.transferStackInSlot(p,0).isEmpty(),"shift-click fuel out of generator");
        ok(generator.inventory.getStackInSlot(0).isEmpty(),"fuel slot emptied");
        MachineTile.LavaGenerator lava=new MachineTile.LavaGenerator(); w.put(O,lava);
        MachineContainer lavaGui=(MachineContainer)h.getServerGuiElement(0,p,w,0,64,0);
        lava.inventory.setStackInSlot(1,new ItemStack(Items.BUCKET));
        ok(!lavaGui.transferStackInSlot(p,1).isEmpty(),"shift-click bucket out of lava generator");
        ok(lava.inventory.getStackInSlot(1).isEmpty(),"bucket slot emptied");
        ok(!generatorGui.canInteractWith(p),"replaced tile denied");
        w.put(O,new MachineTile.Cable());
        MachineBlock cable=new MachineBlock("gui_test_cable",MachineTile.Kind.CABLE);
        int before=p.opens;
        ok(!cable.onBlockActivated(w,O,cable.getDefaultState(),p,net.minecraft.util.EnumHand.MAIN_HAND,net.minecraft.util.EnumFacing.UP,0,0,0),"cable click passes through");
        eq(p.opens,before,"cable does not open");
        ok(h.getServerGuiElement(0,p,w,0,64,0)==null,"cable has no GUI");
        ok(h.getServerGuiElement(999,p,w,0,64,0)==null,"unknown id denied");
        Bootstrap.printToSYSOUT("PASS original machine GUI server routing, slots, reach and sync");
    }
}
