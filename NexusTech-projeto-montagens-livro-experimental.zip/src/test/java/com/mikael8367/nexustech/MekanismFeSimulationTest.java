package com.mikael8367.nexustech;

import net.minecraft.init.Bootstrap;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;

/**
 * Standalone fake-world FE compatibility simulation, not the Mekanism JAR.
 * Models only a connected, receive-only FE endpoint that can actively push.
 */
public final class MekanismFeSimulationTest extends NexusEnergyTestSupport {
    static final class MekLikeEndpoint extends Endpoint {
        final EnumFacing face;
        boolean connected = true;
        final int capacity = 1000;
        MekLikeEndpoint(EnumFacing face, int initial) { super(initial, true, false); this.face = face; }
        @Override public <T> T getCapability(Capability<T> capability, EnumFacing side) {
            return connected && side == face && capability == CapabilityEnergy.ENERGY
                    ? CapabilityEnergy.ENERGY.cast(this) : null;
        }
        @Override public boolean canReceive() { return connected; }
        @Override public boolean canExtract() { return false; }
        @Override public int getMaxEnergyStored() { return capacity; }
        @Override public int receiveEnergy(int max, boolean simulate) {
            if (!connected || max <= 0) return 0;
            int accepted = Math.min(Math.min(max, receiveLimit), capacity - energy);
            if (!simulate) energy += accepted;
            return accepted;
        }
        // No energy may be pulled through FE even while the model contains energy.
        @Override public int extractEnergy(int max, boolean simulate) { reads++; return 0; }
        int push(IEnergyStorage target, int max, boolean simulate) {
            if (!connected || max <= 0) return 0;
            int offered = Math.min(max, energy);
            int accepted = target.receiveEnergy(offered, simulate);
            if (!simulate) energy -= accepted;
            return accepted;
        }
    }

    static void nexusToMek(EnumFacing dir) throws Exception {
        FakeWorld w = world(false); Cable cable = new Cable(); Generator generator = new Generator();
        generator.energy = 200;
        MekLikeEndpoint endpoint = new MekLikeEndpoint(dir.getOpposite(), 0);
        w.put(O, cable); w.put(O.offset(dir), endpoint); w.put(O.offset(dir.getOpposite()), generator);
        IEnergyStorage wire = cap(cable, dir.getOpposite());
        ok(!endpoint.canExtract(), "mock never exposes FE extraction " + dir);
        eq(wire.receiveEnergy(100, true), 100, "simulated Nexus -> endpoint " + dir);
        eq(endpoint.energy, 0, "simulation does not credit endpoint " + dir);
        generator.update();
        eq(endpoint.energy, 100, "generator -> Nexus cable -> endpoint " + dir);
        eq(generator.energy, 100, "generator debit " + dir);
        eq(endpoint.energy + generator.energy, 200, "conservation " + dir);
        endpoint.connected = false;
        generator.update();
        eq(endpoint.energy, 100, "disconnected endpoint receives nothing " + dir);
        eq(generator.energy, 100, "disconnected push refunded " + dir);
    }

    static void mekToConsumer(EnumFacing dir) throws Exception {
        FakeWorld w = world(false); Cable cable = new Cable(); Crusher consumer = new Crusher();
        MekLikeEndpoint endpoint = new MekLikeEndpoint(dir.getOpposite(), 200);
        w.put(O, cable); w.put(O.offset(dir), endpoint); w.put(O.offset(dir.getOpposite()), consumer);
        IEnergyStorage wire = cap(cable, dir);
        consumer.update();
        eq(consumer.energy, 0, "passive pull cannot extract from model " + dir);
        eq(endpoint.energy, 200, "failed pull leaves endpoint unchanged " + dir);
        eq(endpoint.reads, 0, "nonextractable endpoint is not queried for FE extraction " + dir);
        eq(endpoint.push(wire, 80, true), 80, "simulated endpoint push " + dir);
        eq(endpoint.energy, 200, "simulated push does not debit " + dir);
        eq(consumer.energy, 0, "simulated push does not credit " + dir);
        eq(endpoint.push(wire, 80, false), 80, "endpoint actively pushes via cable " + dir);
        eq(consumer.energy, 80, "consumer receives pushed FE " + dir);
        eq(endpoint.energy, 120, "endpoint debited by accepted FE " + dir);
        eq(endpoint.energy + consumer.energy, 200, "push conservation " + dir);
        consumer.energy = consumer.capacity - 30;
        int total = endpoint.energy + consumer.energy;
        eq(endpoint.push(wire, 80, true), 30, "partial simulated push " + dir);
        eq(endpoint.push(wire, 80, false), 30, "partial accepted push " + dir);
        eq(endpoint.energy, 90, "only accepted FE debited " + dir);
        eq(consumer.energy, consumer.capacity, "consumer filled without overflow " + dir);
        eq(endpoint.energy + consumer.energy, total, "partial push conservation " + dir);
        endpoint.connected = false;
        eq(endpoint.push(wire, 50, false), 0, "disconnected model cannot push " + dir);
        eq(consumer.energy, consumer.capacity, "consumer unchanged while disconnected " + dir);
    }

    public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        for (EnumFacing dir : EnumFacing.VALUES) { nexusToMek(dir); mekToConsumer(dir); }
        Bootstrap.printToSYSOUT("PASS MekanismFeSimulationTest: 6 faces; Nexus->mock 100 FE; mock->Nexus consumer 80 FE; simulations, disconnection, no passive extraction, conservation");
    }
}
