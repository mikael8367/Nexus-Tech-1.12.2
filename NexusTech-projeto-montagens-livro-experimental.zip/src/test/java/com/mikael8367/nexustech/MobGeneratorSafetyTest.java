package com.mikael8367.nexustech;
import com.mikael8367.nexustech.mobgenerator.MobGeneratorTile;
import net.minecraft.init.Bootstrap;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.energy.IEnergyStorage;

/** Isolated capability and persistence checks, not an actual game. */
public final class MobGeneratorSafetyTest extends NexusEnergyTestSupport {
 public static void main(String[] args) throws Exception {
  Bootstrap.register(); setupCapability();
  net.minecraft.tileentity.TileEntity.register("nexustech:mob_generator",MobGeneratorTile.class);
  FakeWorld w=world(false); MobGeneratorTile t=new MobGeneratorTile(); w.put(O,t);
  IEnergyStorage e=cap(t,EnumFacing.UP);
  eq(e.receiveEnergy(-1,false),0,"negative"); eq(e.receiveEnergy(Integer.MAX_VALUE,true),1000,"simulation rate");
  eq(e.getEnergyStored(),0,"simulation unchanged");
  for(int i=0;i<100;i++) eq(e.receiveEnergy(Integer.MAX_VALUE,false),1000,"bounded input");
  eq(e.getEnergyStored(),100000,"capacity"); eq(e.receiveEnergy(1,false),0,"full"); eq(e.extractEnergy(1,false),0,"no output");
  NBTTagCompound save=t.writeToNBT(new NBTTagCompound());
  MobGeneratorTile loaded=new MobGeneratorTile(); w.put(O,loaded); loaded.readFromNBT(save);
  eq(loaded.getEnergy(),100000,"persisted FE");
  for(int i=0;i<250;i++) loaded.update();
  eq(loaded.getEnergy(),100000,"no card means no debit");
  save.setInteger("Energy",Integer.MAX_VALUE); NBTTagCompound card=new NBTTagCompound(); card.setInteger("Size",Integer.MAX_VALUE); save.setTag("Card",card);
  loaded.readFromNBT(save); eq(loaded.getEnergy(),100000,"malformed energy clamped");
  save.setInteger("Energy",-100); loaded.readFromNBT(save); eq(loaded.getEnergy(),0,"negative energy clamped");
  eq(e.receiveEnergy(1,false),0,"stale tile cannot receive");
  FakeWorld client=world(true); MobGeneratorTile c=new MobGeneratorTile(); client.put(O,c);
  eq(cap(c,EnumFacing.UP).receiveEnergy(1000,false),0,"client cannot charge");
  System.out.println("PASS fake-world FE bounds, persistence, no-card, stale and client safety");
 }
}
