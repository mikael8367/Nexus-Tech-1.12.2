package com.mikael8367.nexustech;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;
import java.util.zip.ZipFile;
import net.minecraft.client.renderer.block.model.ModelBlock;
import net.minecraft.client.renderer.block.model.BlockPart;
import net.minecraft.client.renderer.block.model.BlockPartFace;
import net.minecraft.util.ResourceLocation;

/** Run with allStandaloneSuites. NEXUS_TEST_MINECRAFT_JAR may name the 1.12.2 client
 * or ForgeGradle client-extra.jar if vanilla assets are not already on the classpath.
 * Uses the actual 1.12.2 ModelBlock resolver, without starting the game. */
public final class ModelTextureResolutionTest {
    private static final Path ROOT = Paths.get("src/main/resources/assets/nexustech/models");
    private static final Map<String, ModelBlock> CACHE = new HashMap<>();
    private static ZipFile vanilla;
    private static int checks;

    private static String read(InputStream in) throws IOException {
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192]; int n;
            while ((n = input.read(b)) != -1) out.write(b, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
    private static ModelBlock load(String id, Set<String> loading) throws Exception {
        if (CACHE.containsKey(id)) return CACHE.get(id);
        if (!loading.add(id)) throw new AssertionError("Model parent cycle: " + id);
        String[] pair = id.split(":", 2);
        String namespace = pair.length == 2 ? pair[0] : "minecraft";
        String path = pair.length == 2 ? pair[1] : pair[0];
        if (namespace.equals("minecraft") && path.startsWith("builtin/")) return null;
        String json;
        if (namespace.equals("nexustech")) {
            json = new String(Files.readAllBytes(ROOT.resolve(path + ".json")), StandardCharsets.UTF_8);
        } else if (namespace.equals("minecraft")) {
            String resource = "assets/minecraft/models/" + path + ".json";
            InputStream in = ModelTextureResolutionTest.class.getClassLoader().getResourceAsStream(resource);
            if (in == null && vanilla != null && vanilla.getEntry(resource) != null)
                in = vanilla.getInputStream(vanilla.getEntry(resource));
            if (in == null) throw new AssertionError("Missing vanilla " + resource + "; set NEXUS_TEST_MINECRAFT_JAR to the 1.12.2 client or client-extra.jar");
            json = read(in);
        } else throw new AssertionError("Unknown namespace " + id);
        ModelBlock model = ModelBlock.deserialize(json);
        model.name = id;
        ResourceLocation parent = model.getParentLocation();
        if (parent != null) model.parent = load(parent.toString(), loading);
        loading.remove(id);
        CACHE.put(id, model);
        return model;
    }
    private static String expected(ModelBlock root, String name) {
        Set<String> visited = new HashSet<>();
        String value = name.startsWith("#") ? name.substring(1) : name;
        while (true) {
            if (!visited.add(value)) throw new AssertionError(root.name + ": cyclic alias #" + value);
            String next = null;
            for (ModelBlock current = root; current != null && next == null; current = current.parent)
                next = current.textures.get(value);
            if (next == null) throw new AssertionError(root.name + ": undefined texture #" + value);
            if (!next.startsWith("#")) return next;
            value = next.substring(1);
        }
    }
    private static void check(ModelBlock root, String name) {
        String expected = expected(root, name);
        String actual = root.resolveTextureName(name);
        checks++;
        if (!expected.equals(actual)) throw new AssertionError(root.name + " " + name + " expected " + expected + " but Minecraft returned " + actual);
    }
    private static void fixtures() {
        ModelBlock parent = ModelBlock.deserialize("{\"textures\":{\"side\":\"nexustech:blocks/nuclear_casing\",\"particle\":\"#side\"}}");
        ModelBlock child = ModelBlock.deserialize("{\"parent\":\"nexustech:block/nuclear_casing\"}");
        child.parent = parent; parent.name = "fixture-parent"; child.name = "fixture-child";
        if (!"missingno".equals(child.resolveTextureName("particle"))) throw new AssertionError("Expected 1.12.2 upward-reference failure");
        child.textures.put("side", "nexustech:blocks/nuclear_casing_formed");
        if (!"nexustech:blocks/nuclear_casing_formed".equals(child.resolveTextureName("particle"))) throw new AssertionError("Child override should resolve");
        parent.textures.put("particle", "nexustech:blocks/nuclear_casing");
        child.textures.clear();
        if (!"nexustech:blocks/nuclear_casing".equals(child.resolveTextureName("particle"))) throw new AssertionError("Direct parent texture should resolve");
    }
    private static void originalFailureFixtures() throws Exception {
        String[] names = {"powerexpansion_battery_advanced", "powerexpansion_battery_elite",
            "nuclear_casing", "nuclear_controller", "nuclear_controller_active", "nuclear_core"};
        for (String name : names) {
            ModelBlock parent = load("nexustech:block/" + name, new HashSet<String>());
            // The active controller has no dedicated inventory model; reproduce the same child relationship.
            ModelBlock child = ModelBlock.deserialize("{\"parent\":\"nexustech:block/" + name + "\"}");
            child.parent = parent; child.name = "original-fixture-" + name;
            Map<String, String> saved = new HashMap<>(parent.textures);
            try {
                parent.textures.put("particle", "#side");
                if (!"missingno".equals(child.resolveTextureName("particle"))) throw new AssertionError(name + " did not reproduce particle failure");
                if (name.startsWith("powerexpansion_")) {
                    for (String[] alias : new String[][] {{"down", "side"}, {"up", "top"}, {"north", "front"}, {"south", "side"}, {"east", "side"}, {"west", "side"}}) {
                        parent.textures.put(alias[0], "#" + alias[1]);
                        if (!"missingno".equals(child.resolveTextureName(alias[0]))) throw new AssertionError(name + " did not reproduce " + alias[0] + " failure");
                    }
                }
            } finally { parent.textures.clear(); parent.textures.putAll(saved); }
        }
    }
    private static void visualContracts() throws Exception {
        for (String name : new String[] {"nuclear_casing", "nuclear_controller", "nuclear_controller_active", "nuclear_core"}) {
            ModelBlock base = load("nexustech:block/" + name, new HashSet<String>());
            ModelBlock formed = load("nexustech:block/" + name + "_formed", new HashSet<String>());
            String texture = name.equals("nuclear_core") ? "nuclear_core" : "nuclear_casing";
            if (!base.resolveTextureName("particle").equals("nexustech:blocks/" + texture) ||
                !formed.resolveTextureName("particle").equals("nexustech:blocks/" + texture + "_formed"))
                throw new AssertionError(name + ": particle mapping changed");
        }
        for (String name : new String[] {"powerexpansion_battery_advanced", "powerexpansion_battery_elite"}) {
            ModelBlock item = load("nexustech:item/" + name, new HashSet<String>());
            String[] keys = {"particle", "down", "up", "north", "south", "east", "west"};
            String[] values = {"side", "side", "top", "front", "side", "side", "side"};
            for (int i = 0; i < keys.length; i++)
                if (!item.resolveTextureName(keys[i]).equals("nexustech:blocks/" + name + "_" + values[i])) throw new AssertionError(name + ": unexpected " + keys[i]);
        }
    }
    public static void main(String[] args) throws Exception {
        String jar = System.getenv("NEXUS_TEST_MINECRAFT_JAR");
        if (jar == null || jar.isEmpty()) {
            String home = System.getenv("GRADLE_USER_HOME");
            if (home == null || home.isEmpty()) home = System.getProperty("user.home") + "/.gradle";
            Path candidate = Paths.get(home, "caches/forge_gradle/minecraft_repo/versions/1.12.2/client-extra.jar");
            if (Files.isRegularFile(candidate)) jar = candidate.toString();
        }
        if (jar != null && !jar.isEmpty()) vanilla = new ZipFile(jar);
        try {
            fixtures();
            originalFailureFixtures();
            visualContracts();
            List<Path> models;
            try (Stream<Path> s = Files.walk(ROOT)) { models = s.filter(p -> p.toString().endsWith(".json")).sorted().collect(Collectors.toList()); }
            List<String> failures = new ArrayList<>();
            for (Path path : models) {
                String rel = ROOT.relativize(path).toString().replace(File.separatorChar, '/');
                ModelBlock root = load("nexustech:" + rel.substring(0, rel.length() - 5), new HashSet<String>());
                Set<String> keys = new TreeSet<>();
                for (ModelBlock p = root; p != null; p = p.parent) keys.addAll(p.textures.keySet());
                for (String key : keys) try { check(root, key); } catch (AssertionError e) { failures.add(e.getMessage()); }
                for (BlockPart part : root.getElements()) for (BlockPartFace face : part.mapFaces.values()) {
                    if (face.texture.startsWith("#")) try { check(root, face.texture); } catch (AssertionError e) { failures.add(e.getMessage()); }
                }
            }
            if (!failures.isEmpty()) throw new AssertionError(failures.size() + " failed resolutions:\n" + String.join("\n", failures));
            System.out.println("Verified " + models.size() + " mod models and " + checks + " actual 1.12.2 texture resolutions");
        } finally { if (vanilla != null) vanilla.close(); }
    }
}
