package com.mikael8367.nexustech;

import java.lang.reflect.Constructor;
import java.util.concurrent.Callable;
import com.mikael8367.nexustech.techmachines.TechMachineTile;
import net.minecraft.init.Blocks;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Items;
import net.minecraft.init.PotionTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;

/** Standalone fixture; exercises real tile logic with the project's fake world. */
public final class TechMachinesTest extends NexusEnergyTestSupport {
    static IItemHandler items(TechMachineTile t) { return t.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, EnumFacing.UP); }
    static IEnergyStorage power(TechMachineTile t) { return t.getCapability(CapabilityEnergy.ENERGY, EnumFacing.DOWN); }
    static void charge(TechMachineTile t, int n) { while (n > 0) { int got = power(t).receiveEnergy(n, false); ok(got > 0, "charge"); n -= got; } }
    static void tick(TechMachineTile t, int n) { while (n-- > 0) t.update(); }
    @SuppressWarnings("unchecked") public static void main(String[] args) throws Exception {
        Bootstrap.register(); setupCapability();
        java.util.List<net.minecraft.block.Block> blocks = new java.util.ArrayList<>();
        net.minecraftforge.registries.IForgeRegistry<net.minecraft.block.Block> registry = (net.minecraftforge.registries.IForgeRegistry<net.minecraft.block.Block>) java.lang.reflect.Proxy.newProxyInstance(net.minecraftforge.registries.IForgeRegistry.class.getClassLoader(), new Class<?>[]{net.minecraftforge.registries.IForgeRegistry.class}, (proxy, method, arguments) -> { if (method.getName().equals("register")) { blocks.add((net.minecraft.block.Block) arguments[0]); return null; } if (method.getName().equals("getRegistrySuperType")) return net.minecraft.block.Block.class; throw new AssertionError(method.getName()); });
        com.mikael8367.nexustech.techmachines.TechMachineRegistry.blocks(new net.minecraftforge.event.RegistryEvent.Register<>(new net.minecraft.util.ResourceLocation("minecraft:blocks"), registry));
        eq(blocks.size(), 3, "three blocks registered");
        Constructor<?> c = Capability.class.getDeclaredConstructors()[0]; c.setAccessible(true);
        CapabilityItemHandler.ITEM_HANDLER_CAPABILITY = (Capability<IItemHandler>) c.newInstance("test:items", null, (Callable<IItemHandler>) () -> null);
        FakeWorld w = world(false); TechMachineTile.Sawmill s = new TechMachineTile.Sawmill(); w.put(O,s);
        IItemHandler inv = items(s); IEnergyStorage fe = power(s);
        eq(fe.receiveEnergy(-1,false),0,"negative energy"); eq(fe.receiveEnergy(2000,true),1000,"simulated rate"); eq(fe.getEnergyStored(),0,"simulation no credit");
        ItemStack tagged = new ItemStack(Blocks.LOG); tagged.setTagCompound(new NBTTagCompound()); ok(!inv.insertItem(0,tagged,false).isEmpty(),"tagged logs refused");
        ok(!inv.insertItem(1,new ItemStack(Blocks.LOG),false).isEmpty(),"output insertion refused");
        inv.insertItem(0,new ItemStack(Blocks.LOG,2,1),false); inv.getStackInSlot(0).setCount(64); eq(inv.getStackInSlot(0).getCount(),2,"defensive copy");
        charge(s,3200); tick(s,80); eq(inv.getStackInSlot(0).getCount(),1,"one log consumed"); eq(inv.getStackInSlot(1).getCount(),6,"six planks"); eq(inv.getStackInSlot(1).getMetadata(),1,"spruce metadata"); eq(fe.getEnergyStored(),1600,"exact cost");
        tick(s,80); eq(inv.getStackInSlot(1).getCount(),12,"output stacks");
        inv.extractItem(1,64,false); inv.insertItem(0,new ItemStack(Blocks.LOG2,1,1),false); charge(s,1600); tick(s,80); eq(inv.getStackInSlot(1).getMetadata(),5,"dark oak metadata");
        inv.extractItem(1,64,false); inv.insertItem(0,new ItemStack(Blocks.LOG,1,0),false); charge(s,1600); tick(s,40);
        NBTTagCompound save = s.writeToNBT(new NBTTagCompound()); TechMachineTile.Sawmill restored = new TechMachineTile.Sawmill(); w.put(O,restored); restored.readFromNBT(save);
        eq(power(restored).getEnergyStored(),800,"FE persisted"); eq(items(restored).getStackInSlot(0).getCount(),1,"input persisted"); tick(restored,40); eq(items(restored).getStackInSlot(1).getCount(),6,"progress persisted"); eq(fe.receiveEnergy(10,false),0,"stale energy blocked"); ok(inv.extractItem(0,1,false).isEmpty(),"stale items blocked");
        FakeWorld v=world(false); TechMachineTile.Composter comp=new TechMachineTile.Composter(); v.put(O,comp); IItemHandler ci=items(comp); ci.insertItem(0,new ItemStack(Items.WHEAT_SEEDS,7),false); charge(comp,1600); tick(comp,80); eq(power(comp).getEnergyStored(),1600,"not enough ingredients no cost"); ci.insertItem(0,new ItemStack(Items.WHEAT_SEEDS),false); tick(comp,80); eq(ci.getStackInSlot(0).getCount(),0,"eight seeds consumed"); eq(ci.getStackInSlot(1).getMetadata(),15,"bone meal metadata"); ok(ci.getStackInSlot(1).getItem()==Items.DYE,"bone meal item");
        FakeWorld p=world(false); TechMachineTile.WaterBottler bottle=new TechMachineTile.WaterBottler(); p.put(O,bottle); IItemHandler bi=items(bottle); bi.insertItem(0,new ItemStack(Items.GLASS_BOTTLE,2),false); charge(bottle,3200); tick(bottle,80); eq(power(bottle).getEnergyStored(),3200,"no water no cost");
        p.states.put(E,Blocks.WATER.getDefaultState()); tick(bottle,80); eq(bi.getStackInSlot(0).getCount(),1,"one bottle consumed"); ok(PotionUtils.getPotionFromItem(bi.getStackInSlot(1))==PotionTypes.WATER,"water potion produced"); eq(power(bottle).getEnergyStored(),1600,"bottler cost"); ok(p.states.get(E).getBlock()==Blocks.WATER,"source remains"); tick(bottle,80); eq(power(bottle).getEnergyStored(),1600,"unstackable output backpressure"); eq(bi.getStackInSlot(0).getCount(),1,"backpressure input preserved");
        bi.extractItem(1,1,false); p.unloaded.add(E); tick(bottle,80); eq(power(bottle).getEnergyStored(),1600,"unloaded source ignored"); eq(p.forbiddenQueries,0,"no unloaded tile queries");
        FakeWorld client=world(true); TechMachineTile.Composter ct=new TechMachineTile.Composter(); client.put(O,ct); eq(power(ct).receiveEnergy(100,false),0,"client cannot mutate FE"); ok(!items(ct).insertItem(0,new ItemStack(Items.WHEAT_SEEDS,8),false).isEmpty(),"client cannot mutate inventory");
        FakeWorld z=world(false); TechMachineTile.Sawmill pull=new TechMachineTile.Sawmill(); Endpoint source=new Endpoint(1600,false,true); z.put(O,pull); z.put(E,source); items(pull).insertItem(0,new ItemStack(Blocks.LOG),false); tick(pull,80); eq(items(pull).getStackInSlot(1).getCount(),6,"pull from passive FE source"); eq(source.energy,0,"source debited");
        FakeWorld change = world(false); TechMachineTile.Sawmill cs = new TechMachineTile.Sawmill(); change.put(O,cs); IItemHandler ca = items(cs); ca.insertItem(0,new ItemStack(Blocks.LOG),false); charge(cs,3200); tick(cs,79); ca.extractItem(0,1,false); ca.insertItem(0,new ItemStack(Blocks.LOG,1,1),false); tick(cs,1); ok(ca.getStackInSlot(1).isEmpty(),"changing input resets progress"); tick(cs,79); eq(ca.getStackInSlot(1).getMetadata(),1,"new recipe completes only after full cycle");
        FakeWorld bad=world(false); TechMachineTile.Sawmill safe=new TechMachineTile.Sawmill(); Endpoint foreign=new Endpoint(1000,false,true); bad.put(O,safe); bad.put(E,foreign); IItemHandler sa=items(safe); sa.insertItem(0,new ItemStack(Blocks.LOG),false); foreign.onExtract=() -> { ok(!sa.insertItem(0,new ItemStack(Blocks.LOG),false).isEmpty(),"reentrant insertion denied"); bad.tiles.remove(O); }; safe.update(); eq(power(safe).getEnergyStored(),0,"removed tile cannot receive energy"); ok(sa.extractItem(0,1,false).isEmpty(),"removed tile inaccessible");
        Bootstrap.printToSYSOUT("PASS techmachines processing, FE, backpressure, NBT, reentry, water, client and pull");
    }
}
