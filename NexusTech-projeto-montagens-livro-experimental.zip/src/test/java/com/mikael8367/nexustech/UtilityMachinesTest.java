package com.mikael8367.nexustech;

import com.mikael8367.nexustech.utilitymachines.UtilityMachineTile;
import java.lang.reflect.Constructor;
import java.util.concurrent.Callable;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;

/** Standalone real-tile regression; shares the existing fake-world fixture. */
public final class UtilityMachinesTest extends NexusEnergyTestSupport {
 static IItemHandler items(UtilityMachineTile t){return t.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.UP);}
 static IEnergyStorage power(UtilityMachineTile t){return t.getCapability(CapabilityEnergy.ENERGY,EnumFacing.DOWN);}
 static void charge(UtilityMachineTile t,int n){while(n>0){int got=power(t).receiveEnergy(n,false);ok(got>0,"charge");n-=got;}}
 static void tick(UtilityMachineTile t,int n){while(n-->0)t.update();}
 static final class Probe extends UtilityMachineTile {
  boolean armed; int callbacks; boolean partial;
  Probe(){super(1);}
  @Override public void markDirty(){
   if(armed){callbacks++; IItemHandler i=items(this); if(!i.getStackInSlot(0).isEmpty() && !i.getStackInSlot(1).isEmpty()) partial=true;}
  }
 }
 static final class DropWorld extends net.minecraft.world.World {
  net.minecraft.tileentity.TileEntity tile;
  java.util.List<ItemStack> drops;
  private DropWorld(){super(null,null,null,null,false);}
  protected net.minecraft.world.chunk.IChunkProvider createChunkProvider(){return null;}
  protected boolean isChunkLoaded(int x,int z,boolean allowEmpty){return true;}
  @Override public boolean isBlockLoaded(net.minecraft.util.math.BlockPos pos){return true;}
  @Override public net.minecraft.block.state.IBlockState getBlockState(net.minecraft.util.math.BlockPos pos){return Blocks.AIR.getDefaultState();}
  @Override public net.minecraft.tileentity.TileEntity getTileEntity(net.minecraft.util.math.BlockPos pos){return tile;}
  @Override public void removeTileEntity(net.minecraft.util.math.BlockPos pos){if(tile!=null) tile.invalidate(); tile=null;}
  @Override public void markChunkDirty(net.minecraft.util.math.BlockPos pos,net.minecraft.tileentity.TileEntity t){}
  @Override public boolean spawnEntity(net.minecraft.entity.Entity entity){drops.add(((net.minecraft.entity.item.EntityItem)entity).getItem().copy());return true;}
 }
 @SuppressWarnings("unchecked") public static void main(String[] args)throws Exception{
  Bootstrap.register(); setupCapability();
  net.minecraftforge.fml.common.registry.GameRegistry.registerTileEntity(UtilityMachineTile.Recycler.class,new net.minecraft.util.ResourceLocation("nexustech:utility_recycler"));
  net.minecraftforge.fml.common.registry.GameRegistry.registerTileEntity(UtilityMachineTile.Purifier.class,new net.minecraft.util.ResourceLocation("nexustech:utility_purifier"));
  Constructor<?> c=Capability.class.getDeclaredConstructors()[0];c.setAccessible(true);
  CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<IItemHandler>)c.newInstance("test:items",null,(Callable<IItemHandler>)()->null);
  FakeWorld w=world(false); UtilityMachineTile.Recycler r=new UtilityMachineTile.Recycler();w.put(O,r);IItemHandler ri=items(r);
  eq(power(r).receiveEnergy(-1,false),0,"negative FE");eq(power(r).receiveEnergy(2000,true),1000,"simulate rate");eq(power(r).getEnergyStored(),0,"simulation");
  ok(!ri.insertItem(1,new ItemStack(Blocks.GLASS_PANE),false).isEmpty(),"output protected");
  ItemStack tagged=new ItemStack(Blocks.GLASS_PANE);tagged.setTagCompound(new NBTTagCompound());ok(!ri.insertItem(0,tagged,false).isEmpty(),"tagged input rejected");
  ri.insertItem(0,new ItemStack(Blocks.GLASS_PANE,8),false);ri.getStackInSlot(0).setCount(1);eq(ri.getStackInSlot(0).getCount(),8,"defensive copy");
  charge(r,3200);tick(r,80);eq(ri.getStackInSlot(0).getCount(),4,"four panes consumed");ok(ri.getStackInSlot(1).getItem()==net.minecraft.item.Item.getItemFromBlock(Blocks.GLASS),"glass output");eq(power(r).getEnergyStored(),1600,"cost");
  tick(r,40);NBTTagCompound save=r.writeToNBT(new NBTTagCompound());UtilityMachineTile.Recycler restored=new UtilityMachineTile.Recycler();w.put(O,restored);restored.readFromNBT(save);tick(restored,40);eq(items(restored).getStackInSlot(1).getCount(),2,"progress persists");ok(ri.extractItem(0,1,false).isEmpty(),"stale handler");
  IItemHandler i=items(restored);i.extractItem(1,64,false);i.insertItem(0,new ItemStack(Blocks.IRON_BARS,4),false);charge(restored,1600);tick(restored,80);ok(i.getStackInSlot(1).getItem()==Items.IRON_INGOT,"iron output");
  FakeWorld p=world(false);UtilityMachineTile.Purifier t=new UtilityMachineTile.Purifier();p.put(O,t);IItemHandler pi=items(t);pi.insertItem(0,new ItemStack(Items.ROTTEN_FLESH,3),false);charge(t,3200);tick(t,80);eq(pi.getStackInSlot(0).getCount(),1,"two flesh consumed");ok(pi.getStackInSlot(1).getItem()==Items.LEATHER,"leather output");tick(t,80);eq(power(t).getEnergyStored(),1600,"not enough ingredients no consumption");
  pi.insertItem(0,new ItemStack(Items.ROTTEN_FLESH),false);pi.extractItem(1,64,false);pi.insertItem(0,new ItemStack(Items.ROTTEN_FLESH,62),false);charge(t,1600);tick(t,80);eq(pi.getStackInSlot(1).getCount(),1,"second output");
  FakeWorld client=world(true);UtilityMachineTile.Purifier ct=new UtilityMachineTile.Purifier();client.put(O,ct);eq(power(ct).receiveEnergy(1,false),0,"client energy blocked");ok(!items(ct).insertItem(0,new ItemStack(Items.ROTTEN_FLESH),false).isEmpty(),"client items blocked");
  FakeWorld bad=world(false);UtilityMachineTile.Purifier safe=new UtilityMachineTile.Purifier();Endpoint source=new Endpoint(1600,false,true);bad.put(O,safe);bad.put(E,source);IItemHandler sa=items(safe);sa.insertItem(0,new ItemStack(Items.ROTTEN_FLESH,2),false);source.onExtract=()->{ok(!sa.insertItem(0,new ItemStack(Items.ROTTEN_FLESH),false).isEmpty(),"reentry blocked");bad.tiles.remove(O);};safe.update();eq(power(safe).getEnergyStored(),0,"removed tile not credited");
  // A dirty callback must never see the output while its ingredients still exist.
  FakeWorld atomic=world(false); Probe probe=new Probe();atomic.put(O,probe);
  items(probe).insertItem(0,new ItemStack(Items.ROTTEN_FLESH,2),false);charge(probe,1600);
  tick(probe,79);probe.armed=true;tick(probe,1);
  ok(probe.callbacks>0,"completed transaction dirtied");ok(!probe.partial,"no partially committed production exposed");
  ok(items(probe).getStackInSlot(0).isEmpty(),"atomic ingredients consumed");eq(items(probe).getStackInSlot(1).getCount(),1,"atomic output");
  // A load without an inventory must replace, not retain, the old inventory.
  NBTTagCompound empty=new NBTTagCompound();probe.readFromNBT(empty);
  ok(items(probe).getStackInSlot(1).isEmpty(),"missing inventory clears old contents");eq(power(probe).getEnergyStored(),0,"missing energy resets");
  // The foreign energy endpoint cannot overwrite the machine during extraction.
  FakeWorld rw=world(false);UtilityMachineTile.Purifier reentrant=new UtilityMachineTile.Purifier();Endpoint es=new Endpoint(1000,false,true);rw.put(O,reentrant);rw.put(E,es);
  items(reentrant).insertItem(0,new ItemStack(Items.ROTTEN_FLESH,2),false);
  NBTTagCompound injected=new NBTTagCompound();injected.setInteger("Energy",20000);injected.setInteger("Progress",79);
  es.onExtract=()->reentrant.readFromNBT(injected);reentrant.update();
  eq(power(reentrant).getEnergyStored(),980,"reentrant NBT cannot inject energy");
  eq(items(reentrant).getStackInSlot(0).getCount(),2,"reentrant NBT cannot erase input");
  ok(items(reentrant).getStackInSlot(1).isEmpty(),"reentrant NBT cannot advance progress");
  // Full and incompatible outputs do not consume power or ingredients.
  FakeWorld fw=world(false);UtilityMachineTile.Purifier full=new UtilityMachineTile.Purifier();fw.put(O,full);
  NBTTagCompound filled=full.writeToNBT(new NBTTagCompound());filled.setInteger("Energy",1600);
  NBTTagCompound inv=new NBTTagCompound();inv.setInteger("Size",2);net.minecraft.nbt.NBTTagList entries=new net.minecraft.nbt.NBTTagList();
  NBTTagCompound in=new NBTTagCompound();new ItemStack(Items.ROTTEN_FLESH,2).writeToNBT(in);in.setByte("Slot",(byte)0);entries.appendTag(in);
  NBTTagCompound out=new NBTTagCompound();new ItemStack(Items.LEATHER,64).writeToNBT(out);out.setByte("Slot",(byte)1);entries.appendTag(out);inv.setTag("Items",entries);filled.setTag("Inventory",inv);
  full.readFromNBT(filled);tick(full,100);eq(power(full).getEnergyStored(),1600,"full output spends no power");eq(items(full).getStackInSlot(0).getCount(),2,"full output retains ingredients");
  eq(items(full).extractItem(1,1,true).getCount(),1,"extract simulation returns item");eq(items(full).getStackInSlot(1).getCount(),64,"extract simulation preserves output");
  items(full).extractItem(1,1,false);tick(full,80);eq(items(full).getStackInSlot(1).getCount(),64,"production resumes after output space");
  FakeWorld iw=world(false);UtilityMachineTile.Purifier incompatible=new UtilityMachineTile.Purifier();iw.put(O,incompatible);
  NBTTagCompound incompatibleSave=filled.copy();net.minecraft.nbt.NBTTagList wrong=new net.minecraft.nbt.NBTTagList();
  wrong.appendTag(in.copy());NBTTagCompound iron=new NBTTagCompound();new ItemStack(Items.IRON_INGOT).writeToNBT(iron);iron.setByte("Slot",(byte)1);wrong.appendTag(iron);incompatibleSave.getCompoundTag("Inventory").setTag("Items",wrong);
  incompatible.readFromNBT(incompatibleSave);tick(incompatible,100);eq(power(incompatible).getEnergyStored(),1600,"incompatible output spends no power");eq(items(incompatible).getStackInSlot(0).getCount(),2,"incompatible output retains ingredients");
  filled.setInteger("Energy",Integer.MAX_VALUE);full.readFromNBT(filled);eq(power(full).getEnergyStored(),UtilityMachineTile.CAPACITY,"energy load clamps to capacity");
  filled.setInteger("Energy",-10);full.readFromNBT(filled);eq(power(full).getEnergyStored(),0,"negative energy load clamps to zero");
  // Breaking a machine drops both inventories exactly once and invalidates old handles.
  java.lang.reflect.Field uf=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);sun.misc.Unsafe unsafe=(sun.misc.Unsafe)uf.get(null);
  DropWorld dw=(DropWorld)unsafe.allocateInstance(DropWorld.class);dw.drops=new java.util.ArrayList<>();
  unsafe.putObject(dw,unsafe.objectFieldOffset(net.minecraft.world.World.class.getField("provider")),new net.minecraft.world.WorldProviderSurface());
  UtilityMachineTile.Purifier dropped=new UtilityMachineTile.Purifier();dw.tile=dropped;dropped.setWorld(dw);dropped.setPos(O);dropped.readFromNBT(filled);
  IItemHandler stale=items(dropped);net.minecraft.block.Block b=com.mikael8367.nexustech.utilitymachines.UtilityMachinesRegistry.PURIFIER;
  b.breakBlock(dw,O,b.getDefaultState());eq(dw.drops.size(),2,"two inventory drops");
  eq(dw.drops.get(0).getCount(),2,"input dropped once");eq(dw.drops.get(1).getCount(),64,"output dropped once");
  ok(stale.extractItem(0,64,false).isEmpty(),"broken tile cannot be extracted");
  b.breakBlock(dw,O,b.getDefaultState());eq(dw.drops.size(),2,"no duplicate drops on repeated break");
  Bootstrap.printToSYSOUT("PASS utility machines: recipes, energy, persistence, client and reentry");
 }
}
