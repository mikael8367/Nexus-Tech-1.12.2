package com.mikael8367.nexustech.blockbreaker;

import java.util.UUID;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.NonNullList;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;

/** A non-server world cannot perform a tick; fault status persists and synchronizes. */
public final class BlockBreakerDisabledTest {
    static void ok(boolean v,String msg){if(!v)throw new AssertionError(msg);}
    static final class Listener implements IContainerListener {
        int status=-1;
        public void sendAllContents(Container c,NonNullList<ItemStack> stacks){}
        public void sendSlotContents(Container c,int slot,ItemStack stack){}
        public void sendWindowProperty(Container c,int id,int value){if(id==1)status=value;}
        public void sendAllWindowProperties(Container c,IInventory inv){}
    }
    public static void main(String[] args)throws Exception{
        Bootstrap.register();
        java.lang.reflect.Constructor<?> cap=net.minecraftforge.common.capabilities.Capability.class.getDeclaredConstructors()[0];cap.setAccessible(true);
        CapabilityEnergy.ENERGY=(net.minecraftforge.common.capabilities.Capability<IEnergyStorage>)cap.newInstance("test:energy",null,(java.util.concurrent.Callable<IEnergyStorage>)()->null);
        TileEntity.register("nexustech:disabled_test",BlockBreakerTile.class);
        BlockBreakerSafetyTest.W w=BlockBreakerSafetyTest.world(false);
        BlockBreakerTile t=new BlockBreakerTile();BlockBreakerSafetyTest.put(w,t);
        NBTTagCompound n=new NBTTagCompound();n.setUniqueId("Owner",UUID.randomUUID());n.setString("OwnerName","Owner");n.setInteger("Energy",1000);n.setTag("Pick",new ItemStack(Items.DIAMOND_PICKAXE).writeToNBT(new NBTTagCompound()));
        t.readFromNBT(n);
        for(int i=0;i<100;i++)t.update();
        ok(t.energy()==1000 && t.tool.getStackInSlot(0).getItemDamage()==0 && w.spawnCalls==0,"non-server-world tick changes nothing");
        w.loaded=false;for(int i=0;i<100;i++)t.update();
        ok(t.energy()==1000 && w.spawnCalls==0,"unloaded tick changes nothing");
        w.loaded=true;
        BlockBreakerContainer server=new BlockBreakerContainer(new InventoryPlayer(null),t);Listener listener=new Listener();server.addListener(listener);
        ok(listener.status==BlockBreakerTile.STATUS_ACTIVE,"active status sent at open");
        n.setBoolean("Fault",true);t.readFromNBT(n);server.detectAndSendChanges();
        ok(listener.status==BlockBreakerTile.STATUS_FAULT,"legacy fault synchronized");
        NBTTagCompound saved=t.writeToNBT(new NBTTagCompound());ok(saved.getBoolean("Fault"),"legacy fault persists");
        t.update();ok(t.status()==BlockBreakerTile.STATUS_FAULT && t.energy()==1000,"fault never auto-resets");
        BlockBreakerSafetyTest.W cw=BlockBreakerSafetyTest.world(true);BlockBreakerTile ct=new BlockBreakerTile();BlockBreakerSafetyTest.put(cw,ct);
        BlockBreakerContainer client=new BlockBreakerContainer(new InventoryPlayer(null),ct);client.updateProgressBar(1,listener.status);
        ok(ct.status()==BlockBreakerTile.STATUS_FAULT,"client receives fault");client.updateProgressBar(1,BlockBreakerTile.STATUS_ACTIVE);ok(ct.status()==BlockBreakerTile.STATUS_ACTIVE,"client receives active");
        t.clientStatus(BlockBreakerTile.STATUS_ACTIVE);ok(t.status()==BlockBreakerTile.STATUS_FAULT,"client sync cannot clear server fault");
        System.out.println("PASS non-server-world tick, unloaded tick, energy/tool unchanged, fault persistence, server/client status synchronization");
    }
}
