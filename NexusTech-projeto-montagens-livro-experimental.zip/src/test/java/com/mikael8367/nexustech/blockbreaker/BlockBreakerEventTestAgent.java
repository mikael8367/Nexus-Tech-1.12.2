package com.mikael8367.nexustech.blockbreaker;

import java.lang.instrument.*;
import java.security.ProtectionDomain;
import net.minecraftforge.fml.common.asm.transformers.EventSubscriptionTransformer;

/** Installs Forge's normal event transformer for the standalone test JVM. */
public final class BlockBreakerEventTestAgent {
 public static void premain(String args,Instrumentation inst){
  final EventSubscriptionTransformer forge=new EventSubscriptionTransformer();
  inst.addTransformer(new ClassFileTransformer(){
   @Override public byte[] transform(ClassLoader loader,String name,Class<?> redefined,ProtectionDomain domain,byte[] bytes){
    if(name!=null && (name.startsWith("net/minecraftforge/event/") || name.startsWith("net/minecraftforge/fml/common/gameevent/"))){
     String dotted=name.replace('/','.');return forge.transform(dotted,dotted,bytes);
    }
    return null;
   }
  });
  try { Class.forName("net.minecraftforge.event.world.BlockEvent"); } catch(ClassNotFoundException e){throw new RuntimeException(e);}
 }
}
