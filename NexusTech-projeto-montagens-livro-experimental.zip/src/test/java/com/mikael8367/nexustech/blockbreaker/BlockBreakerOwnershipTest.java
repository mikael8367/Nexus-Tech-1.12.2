package com.mikael8367.nexustech.blockbreaker;

import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.*;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.storage.MapStorage;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.energy.*;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import sun.misc.Unsafe;

/** Real Forge break callbacks with an isolated in-memory world, not a server. */
public final class BlockBreakerOwnershipTest {
 static class W extends BlockBreakerWorldTest.WorldStub {
  boolean swapInPermission; ItemStack permissionReplacement;
  @Override public void playSound(EntityPlayer p,double x,double y,double z,net.minecraft.util.SoundEvent sound,net.minecraft.util.SoundCategory category,float volume,float pitch){}
  @Override public void spawnParticle(net.minecraft.util.EnumParticleTypes type,double x,double y,double z,double sx,double sy,double sz,int... args){}
  @Override public boolean isBlockModifiable(EntityPlayer p,net.minecraft.util.math.BlockPos b){
   if(swapInPermission){swapInPermission=false;p.inventory.setInventorySlotContents(0,permissionReplacement);return false;}return true;
  }
 }
 public static class Hook {
  int mode; BlockBreakerTile t; W w; ItemStack stolen;
  @SubscribeEvent public void onBreak(BlockEvent.BreakEvent e){
   EntityPlayer p=e.getPlayer();ItemStack original=p.inventory.getStackInSlot(0);
   if(mode==1 || mode==2 || mode==3 || mode==4 || mode==5 || mode==9 || mode==11){
    if(mode==1 || mode==9)p.inventory.setInventorySlotContents(1,original); // definite possession
    if(mode==2)stolen=original; // transferred by reference
    if(mode==3)stolen=original.copy(); // copied externally, original reference left behind
    p.inventory.setInventorySlotContents(0,new ItemStack(Items.GOLDEN_PICKAXE));
    if(mode==4 || mode==9)t.tool.setStackInSlot(0,new ItemStack(Items.IRON_PICKAXE));
    if(mode==5){t.drain();w.tiles.remove(BlockBreakerWorldTest.origin);}
    if(mode==11)throw new IllegalStateException("callback after swap");
    e.setCanceled(true);
   } else if(mode==6){original.setItemDamage(4);NBTTagCompound n=new NBTTagCompound();n.setString("mutation","ok");original.setTagCompound(n);e.setCanceled(true);}
   else if(mode==8){t.drain();w.tiles.remove(BlockBreakerWorldTest.origin);e.setCanceled(true);}
   else if(mode==12){p.inventory.setInventorySlotContents(1,new ItemStack(Items.GOLDEN_PICKAXE));p.inventory.currentItem=1;e.setCanceled(true);}
  }
 }
 static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 static NBTTagCompound recovery(W w){return BlockBreakerRecovery.get(w).writeToNBT(new NBTTagCompound());}
 static int count(NBTTagCompound n,net.minecraft.item.Item item){NBTTagList a=n.getTagList("Pending",10);int k=0;for(int i=0;i<a.tagCount();i++){ItemStack s=new ItemStack(a.getCompoundTagAt(i).getCompoundTag("Item"));if(s.getItem()==item)k+=s.getCount();}return k;}
 static void setup(W w,BlockBreakerTile t){
  t.setWorld(w);t.setPos(BlockBreakerWorldTest.origin);w.tiles.put(BlockBreakerWorldTest.origin,t);
  w.blocks.put(BlockBreakerWorldTest.origin,new BlockBreakerBlock().getDefaultState().withProperty(BlockBreakerBlock.FACING,EnumFacing.EAST));
  w.blocks.put(BlockBreakerWorldTest.target,Blocks.STONE.getDefaultState());
  t.tool.setStackInSlot(0,new ItemStack(Items.DIAMOND_PICKAXE));
  t.getCapability(CapabilityEnergy.ENERGY,null).receiveEnergy(200,false);
 }
 public static void main(String[] args)throws Exception{
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);BlockBreakerWorldTest.u=(Unsafe)f.get(null);
  Bootstrap.register();TileEntity.register("nexustech:ownership_test",BlockBreakerTile.class);
  java.lang.reflect.Constructor<?> c=net.minecraftforge.common.capabilities.Capability.class.getDeclaredConstructors()[0];c.setAccessible(true);CapabilityEnergy.ENERGY=(net.minecraftforge.common.capabilities.Capability<IEnergyStorage>)c.newInstance("test:energy",null,(java.util.concurrent.Callable<IEnergyStorage>)()->null);
  Hook hook=new Hook();MinecraftForge.EVENT_BUS.register(hook);MinecraftForge.EVENT_BUS.register(BlockBreakerHarvestGuard.class);
  for(int mode=1;mode<=12;mode++){
   W w=(W)BlockBreakerWorldTest.u.allocateInstance(W.class);w.tiles=new HashMap<>();w.loaded=true;w.blocks=new HashMap<>();w.drops=new ArrayList<>();w.border=new WorldBorder();
   BlockBreakerWorldTest.set(w,World.class,"rand",new Random(13));BlockBreakerWorldTest.set(w,World.class,"provider",new net.minecraft.world.WorldProviderSurface());BlockBreakerWorldTest.set(w,World.class,"perWorldStorage",new MapStorage(null));
   BlockBreakerTile t=new BlockBreakerTile();setup(w,t);FakePlayer p=BlockBreakerWorldTest.player(w);hook.mode=mode;hook.t=t;hook.w=w;hook.stolen=null;
   if(mode==7){w.swapInPermission=true;w.permissionReplacement=new ItemStack(Items.GOLDEN_PICKAXE);}
   if(mode==10){t.tool.getStackInSlot(0).setItemDamage(Items.DIAMOND_PICKAXE.getMaxDamage());
    net.minecraft.network.datasync.EntityDataManager dm=new net.minecraft.network.datasync.EntityDataManager(p);
    Field flags=net.minecraft.entity.Entity.class.getDeclaredField("FLAGS");flags.setAccessible(true);dm.register((net.minecraft.network.datasync.DataParameter<Byte>)flags.get(null),(byte)0);
    BlockBreakerWorldTest.set(p,net.minecraft.entity.Entity.class,"dataManager",dm);
   }
   if(mode==11){BlockBreakerWorldTest.bool(t,"mining",true);try{t.harvestChecked(p,BlockBreakerWorldTest.target);}finally{BlockBreakerWorldTest.bool(t,"mining",false);}}
   else BlockBreakerWorldTest.run(t,p);
   NBTTagCompound n=recovery(w);ItemStack inTile=t.tool.getStackInSlot(0);
   if(mode==6){ok(t.status()==BlockBreakerTile.STATUS_ACTIVE && inTile.getItemDamage()==4 && "ok".equals(inTile.getTagCompound().getString("mutation")),"legitimate NBT/damage mutation");continue;}
   if(mode==8){ok(count(n,Items.DIAMOND_PICKAXE)==1 && inTile.isEmpty(),"removed tile recovers unchanged hand once");continue;}
   if(mode==10){ok(t.status()==BlockBreakerTile.STATUS_ACTIVE && inTile.isEmpty(),"vanilla tool exhaustion no false fault");continue;}
   ok(t.status()==BlockBreakerTile.STATUS_AMBIGUOUS && t.writeToNBT(new NBTTagCompound()).getBoolean("AmbiguousTool"),"persistent ambiguity "+mode);
   ok(n.getTagList("AmbiguousTools",10).tagCount()==1,"incident record "+mode);
   BlockBreakerRecovery restored=new BlockBreakerRecovery();restored.readFromNBT(n);ok(restored.writeToNBT(new NBTTagCompound()).getTagList("AmbiguousTools",10).tagCount()==1,"incident NBT roundtrip");
   ok(w.getBlockState(BlockBreakerWorldTest.target).getBlock()==Blocks.STONE,"break canceled "+mode);
   int diamond=count(n,Items.DIAMOND_PICKAXE)+(inTile.getItem()==Items.DIAMOND_PICKAXE?1:0)+(hook.stolen!=null?hook.stolen.getCount():0);
   int gold=count(n,Items.GOLDEN_PICKAXE)+(inTile.getItem()==Items.GOLDEN_PICKAXE?1:0);
   ok(gold==1,"callback item conserved "+mode+" gold="+gold);
   if(mode==1 || mode==2 || mode==3 || mode==9)ok(diamond==1,"original not duplicated or lost "+mode+" n="+diamond);
   if(mode==4 || mode==9)ok(count(n,Items.IRON_PICKAXE)+(inTile.getItem()==Items.IRON_PICKAXE?1:0)==1,"new tile item preserved");
   if(mode==5)ok(count(n,Items.GOLDEN_PICKAXE)==1,"removed tile recovery");
   if(mode==4 || mode==5 || mode==7)ok(diamond==0,"uncertain original not minted");
   BlockBreakerTile reload=new BlockBreakerTile();reload.readFromNBT(t.writeToNBT(new NBTTagCompound()));ok(reload.status()==BlockBreakerTile.STATUS_AMBIGUOUS,"reload status");
  }
  System.out.println("PASS real callback swap, internal/external move, copy, tile replacement/removal, permission hook and legitimate mutation");
 }
}
