package com.mikael8367.nexustech.blockbreaker;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.Callable;
import sun.misc.Unsafe;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.*;
public final class BlockBreakerSafetyTest {
 static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 static class W extends World {
  Map<BlockPos,TileEntity> tiles; boolean loaded; int spawnMode, spawnCalls;
  public boolean spawnEntity(net.minecraft.entity.Entity entity){spawnCalls++;if(spawnMode==2)throw new IllegalStateException("ambiguous spawn");return spawnMode==1;}
  W(){super(null,null,null,null,false);} protected IChunkProvider createChunkProvider(){return null;}
  protected boolean isChunkLoaded(int x,int z,boolean a){return loaded;}
  public boolean isBlockLoaded(BlockPos p){return loaded;}
  public TileEntity getTileEntity(BlockPos p){if(!loaded)throw new AssertionError("unloaded lookup");return tiles.get(p);}
  public void markChunkDirty(BlockPos p,TileEntity t){}
  public net.minecraft.block.state.IBlockState getBlockState(BlockPos p){return net.minecraft.init.Blocks.AIR.getDefaultState();}
 }
 static W world(boolean remote)throws Exception{
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);Unsafe u=(Unsafe)f.get(null);
  W w=(W)u.allocateInstance(W.class);w.tiles=new HashMap<>();w.loaded=true;
  u.putBoolean(w,u.objectFieldOffset(World.class.getField("isRemote")),remote);
  Field rand=World.class.getDeclaredField("rand");rand.setAccessible(true);rand.set(w,new Random(1));
  Field provider=World.class.getDeclaredField("provider");provider.setAccessible(true);provider.set(w,new net.minecraft.world.WorldProviderSurface());return w;
 }
 static void put(W w,BlockBreakerTile t){t.setWorld(w);t.setPos(BlockPos.ORIGIN);w.tiles.put(BlockPos.ORIGIN,t);}
 public static void main(String[] args)throws Exception{
  Bootstrap.register();
  Constructor<?> c=Capability.class.getDeclaredConstructors()[0];c.setAccessible(true);
  CapabilityEnergy.ENERGY=(Capability<IEnergyStorage>)c.newInstance("test:energy",null,(Callable<IEnergyStorage>)()->null);
  TileEntity.register("nexustech:block_breaker_test",BlockBreakerTile.class);
  W w=world(false);BlockBreakerTile t=new BlockBreakerTile();put(w,t);
  IEnergyStorage e=t.getCapability(CapabilityEnergy.ENERGY,EnumFacing.UP);
  ok(e.receiveEnergy(-1,false)==0,"negative");ok(e.receiveEnergy(999,true)==200 && e.getEnergyStored()==0,"simulation");
  for(int i=0;i<50;i++)ok(e.receiveEnergy(Integer.MAX_VALUE,false)==200,"receive cap");
  ok(e.getEnergyStored()==10000 && e.receiveEnergy(1,false)==0 && e.extractEnergy(1,false)==0,"capacity and no extraction");
  ItemStack pick=new ItemStack(Items.DIAMOND_PICKAXE);pick.setItemDamage(32);NBTTagCompound custom=new NBTTagCompound();custom.setString("TestMarker","preserved");pick.setTagCompound(custom);
  ok(BlockBreakerTile.validTool(pick) && !BlockBreakerTile.validTool(new ItemStack(Items.DIAMOND_AXE)),"only damageable pickaxe");
  ok(t.tool.insertItem(0,pick,false).isEmpty(),"insert pickaxe");
  NBTTagCompound n=t.writeToNBT(new NBTTagCompound());BlockBreakerTile loaded=new BlockBreakerTile();put(w,loaded);loaded.readFromNBT(n);
  ok(loaded.energy()==10000 && loaded.tool.getStackInSlot(0).getItemDamage()==32 && "preserved".equals(loaded.tool.getStackInSlot(0).getTagCompound().getString("TestMarker")),"save roundtrip");
  ok(e.receiveEnergy(1,false)==0,"stale capability");
  ok(ITickable.class.isInstance(loaded),"scheduled mining available");
  ItemStack first=loaded.drain();ok(!first.isEmpty() && loaded.drain().isEmpty(),"single drain");
  n.setInteger("Energy",Integer.MAX_VALUE);loaded.readFromNBT(n);ok(loaded.energy()==10000,"overflow cap");
  n.setInteger("Energy",-1);loaded.readFromNBT(n);ok(loaded.energy()==0,"negative clamp");
  w.loaded=false;ok(loaded.getCapability(CapabilityEnergy.ENERGY,null).receiveEnergy(1,false)==0,"no chunk loads");
  W client=world(true);BlockBreakerTile ct=new BlockBreakerTile();put(client,ct);ok(ct.getCapability(CapabilityEnergy.ENERGY,null).receiveEnergy(100,false)==0,"client cannot charge");
  BlockBreakerRecovery recovery=new BlockBreakerRecovery();recovery.enqueue(BlockPos.ORIGIN,pick);
  NBTTagCompound saved=recovery.writeToNBT(new NBTTagCompound());BlockBreakerRecovery reload=new BlockBreakerRecovery();reload.readFromNBT(saved);
  ok(reload.writeToNBT(new NBTTagCompound()).getTagList("Pending",10).tagCount()==1,"recovery persists");
  w.loaded=true;new net.minecraft.entity.item.EntityItem(w,.5,.5,.5,pick.copy());reload.retry(w);ok(w.spawnCalls==1 && reload.writeToNBT(new NBTTagCompound()).getTagList("Pending",10).tagCount()==1,"refused spawn retries");
  w.spawnMode=1;reload.retry(w);ok(w.spawnCalls==2 && reload.writeToNBT(new NBTTagCompound()).getTagList("Pending",10).tagCount()==0,"successful spawn removed once");
  reload.enqueue(BlockPos.ORIGIN,pick);w.spawnMode=2;reload.retry(w);w.spawnMode=1;reload.retry(w);
  ok(w.spawnCalls==3 && reload.writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==1,"ambiguous spawn quarantined without retry");
  BlockBreakerTile stale=new BlockBreakerTile();put(w,stale);NBTTagCompound reused=new NBTTagCompound();reused.setUniqueId("Owner",UUID.randomUUID());reused.setString("OwnerName","stale");reused.setTag("Pick",pick.writeToNBT(new NBTTagCompound()));
  stale.writeToNBT(reused);ok(!reused.hasKey("Pick") && !reused.hasUniqueId("Owner") && !reused.hasKey("OwnerName"),"empty state clears reused NBT keys");
  reused.setTag("Pick",new ItemStack(Items.DIAMOND_AXE).writeToNBT(new NBTTagCompound()));stale.readFromNBT(reused);
  ok(stale.tool.getStackInSlot(0).getItem()==Items.DIAMOND_AXE && !BlockBreakerTile.validTool(stale.tool.getStackInSlot(0)),"legacy invalid item preserved but cannot mine");
  ok(stale.drain().getItem()==Items.DIAMOND_AXE,"legacy invalid item recoverable once");
  System.out.println("PASS bounded FE, valid tool, tag/damage persistence, one drain, stale/client/unloaded, recovery NBT, reused NBT and invalid-item retention");
 }
}
