package com.mikael8367.nexustech.blockbreaker;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import net.minecraftforge.fml.common.asm.transformers.EventSubscriptionTransformer;
/** Prepare Forge event classes for the standalone test JVM without building a jar. */
public final class BlockBreakerTransformTestEvents {
 public static void main(String[] args)throws Exception{
  EventSubscriptionTransformer transformer=new EventSubscriptionTransformer();
  try(ZipFile zip=new ZipFile(args[0])) {
   Enumeration<? extends ZipEntry> entries=zip.entries();
   while(entries.hasMoreElements()){
    ZipEntry e=entries.nextElement();String n=e.getName();
    if(!n.endsWith(".class") || !(n.startsWith("net/minecraftforge/event/") || n.startsWith("net/minecraftforge/fml/common/gameevent/") || n.equals("net/minecraftforge/fml/common/eventhandler/GenericEvent.class")))continue;
    byte[] in;try(java.io.InputStream s=zip.getInputStream(e);java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream()){byte[] buf=new byte[8192];int count;while((count=s.read(buf))!=-1)b.write(buf,0,count);in=b.toByteArray();}
    String dotted=n.substring(0,n.length()-6).replace('/','.');
    byte[] out=transformer.transform(dotted,dotted,in);Path dest=Paths.get(args[1],n);Files.createDirectories(dest.getParent());Files.write(dest,out);
   }
  }
 }
}
