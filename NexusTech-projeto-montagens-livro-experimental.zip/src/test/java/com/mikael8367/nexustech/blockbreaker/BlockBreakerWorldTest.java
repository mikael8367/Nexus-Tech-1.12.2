package com.mikael8367.nexustech.blockbreaker;

import java.lang.reflect.Field;
import java.util.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.init.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.*;
import net.minecraft.item.ItemStack;
import net.minecraft.network.*;
import net.minecraft.server.management.PlayerInteractionManager;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.border.WorldBorder;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.energy.*;
import sun.misc.Unsafe;

/** Uses the real 1.12.2 Forge interaction manager against an in-memory World. */
public final class BlockBreakerWorldTest {
 static Unsafe u;
 static class WorldStub extends BlockBreakerSafetyTest.W {
  Map<BlockPos,IBlockState> blocks; List<ItemStack> drops; WorldBorder border; boolean allow=true;
  WorldStub(){super();}
  @Override public IBlockState getBlockState(BlockPos p){IBlockState s=blocks.get(p);return s==null?Blocks.AIR.getDefaultState():s;}
  @Override public boolean setBlockState(BlockPos p,IBlockState state,int flags){blocks.put(p,state);return true;}
  @Override public boolean setBlockToAir(BlockPos p){blocks.put(p,Blocks.AIR.getDefaultState());return true;}
  @Override public WorldBorder getWorldBorder(){return border;}
  @Override public GameRules getGameRules(){return new GameRules();}
  @Override public boolean isBlockModifiable(EntityPlayer p,BlockPos b){return allow;}
  @Override public void playEvent(EntityPlayer p,int id,BlockPos b,int data){}
  @Override public boolean spawnEntity(Entity entity){if(entity instanceof EntityItem)drops.add(((EntityItem)entity).getItem().copy());return true;}
 }
 static void set(Object o,Class<?> type,String name,Object value)throws Exception{Field f=type.getDeclaredField(name);f.setAccessible(true);u.putObject(o,u.objectFieldOffset(f),value);}
 static void bool(Object o,String name,boolean value)throws Exception{Field f=BlockBreakerTile.class.getDeclaredField(name);f.setAccessible(true);f.setBoolean(o,value);}
 static WorldStub world()throws Exception{
  WorldStub w=(WorldStub)u.allocateInstance(WorldStub.class);w.tiles=new HashMap<>();w.loaded=true;w.blocks=new HashMap<>();w.drops=new ArrayList<>();w.border=new WorldBorder();w.allow=true;
  set(w,World.class,"rand",new Random(13));set(w,World.class,"provider",new WorldProviderSurface());return w;
 }
 static FakePlayer player(WorldStub w)throws Exception{
  FakePlayer p=(FakePlayer)u.allocateInstance(FakePlayer.class);
  p.world=w;p.inventory=new InventoryPlayer(p);p.capabilities=new PlayerCapabilities();set(p,EntityPlayer.class,"foodStats",new net.minecraft.util.FoodStats());
  set(p,Entity.class,"rand",new Random(15));set(p,Entity.class,"entityUniqueID",BlockBreakerTile.machineProfile(UUID.fromString("12345678-1234-1234-1234-123456789abc"),0,origin).getId());
  set(p,EntityPlayer.class,"gameProfile",new GameProfile(p.getUniqueID(),"TestOwner"));
  PlayerInteractionManager m=new PlayerInteractionManager(w);m.player=p;Field f=PlayerInteractionManager.class.getDeclaredField("gameType");f.setAccessible(true);f.set(m,GameType.SURVIVAL);
  set(p,EntityPlayerMP.class,"interactionManager",m);
  new NetHandlerPlayServer(null,new NetworkManager(EnumPacketDirection.SERVERBOUND),p){@Override public void sendPacket(Packet<?> x){}};
  return p;
 }
 public static class Cancel {boolean cancel, replace, rotate, fail; int calls; BlockBreakerTile tile;
  @SubscribeEvent public void breakEvent(BlockEvent.BreakEvent e){calls++;if(fail)throw new IllegalStateException("test failure");if(tile!=null)tile.update();if(replace)e.getWorld().setBlockState(e.getPos(),Blocks.CHEST.getDefaultState());if(rotate)e.getWorld().setBlockState(origin,e.getWorld().getBlockState(origin).withProperty(BlockBreakerBlock.FACING,net.minecraft.util.EnumFacing.NORTH));if(cancel)e.setCanceled(true);}
 }
 static void ok(boolean v,String s){if(!v)throw new AssertionError(s);}
 static BlockPos target=new BlockPos(1,64,0), origin=new BlockPos(0,64,0);
 static void run(BlockBreakerTile t,FakePlayer p)throws Exception {bool(t,"mining",true);try{t.harvest(p,target);}finally{bool(t,"mining",false);}}
 public static void main(String[] args)throws Exception{
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);u=(Unsafe)f.get(null);
  Bootstrap.register();
  TileEntity.register("nexustech:breaker_world_test",BlockBreakerTile.class);
  java.lang.reflect.Constructor<?> c=net.minecraftforge.common.capabilities.Capability.class.getDeclaredConstructors()[0];c.setAccessible(true);CapabilityEnergy.ENERGY=(net.minecraftforge.common.capabilities.Capability<IEnergyStorage>)c.newInstance("test:energy",null,(java.util.concurrent.Callable<IEnergyStorage>)()->null);
  WorldStub w=world();BlockBreakerTile t=new BlockBreakerTile();t.setWorld(w);t.setPos(origin);w.tiles.put(origin,t);FakePlayer p=player(w);
  IBlockState facingEast=new BlockBreakerBlock().getDefaultState().withProperty(BlockBreakerBlock.FACING,net.minecraft.util.EnumFacing.EAST);w.blocks.put(origin,facingEast);
  IEnergyStorage e=t.getCapability(CapabilityEnergy.ENERGY,null);e.receiveEnergy(200,false);
  t.tool.setStackInSlot(0,new ItemStack(Items.DIAMOND_PICKAXE));
  w.blocks.put(target,Blocks.BEDROCK.getDefaultState());ok(!t.safeTarget(target,p),"bedrock rejected");
  w.blocks.put(target,Blocks.CHEST.getDefaultState());ok(!t.safeTarget(target,p),"chest rejected");
  w.blocks.put(target,Blocks.STONE.getDefaultState());w.loaded=false;ok(!t.safeTarget(target,p),"unloaded rejected");w.loaded=true;
  w.allow=false; w.blocks.put(target,Blocks.STONE.getDefaultState()); run(t,p);
  ok(w.getBlockState(target).getBlock()==Blocks.STONE && e.getEnergyStored()==200 && t.tool.getStackInSlot(0).getItemDamage()==0,"world protection denial preserves block tool and energy"); w.allow=true;
  t.tool.setStackInSlot(0,new ItemStack(Items.WOODEN_PICKAXE));w.blocks.put(target,Blocks.DIAMOND_ORE.getDefaultState());run(t,p);
  ok(w.getBlockState(target).getBlock()==Blocks.DIAMOND_ORE && e.getEnergyStored()==200 && t.tool.getStackInSlot(0).getItemDamage()==0,"insufficient harvest level preserves block tool and energy");
  t.tool.setStackInSlot(0,new ItemStack(Items.DIAMOND_PICKAXE));
  Cancel listener=new Cancel();MinecraftForge.EVENT_BUS.register(listener);MinecraftForge.EVENT_BUS.register(BlockBreakerHarvestGuard.class);
  UUID owner=UUID.fromString("12345678-1234-1234-1234-123456789abc");
  GameProfile a=BlockBreakerTile.machineProfile(owner,0,origin), b=BlockBreakerTile.machineProfile(owner,0,origin);
  ok(a.getId().equals(b.getId()) && !a.getId().equals(owner) && a.getId().version()==8,"stable synthetic UUID differs from owner");
  ok(!a.getId().equals(BlockBreakerTile.machineProfile(owner,1,origin).getId()) && !a.getId().equals(BlockBreakerTile.machineProfile(owner,0,target).getId()) && !a.getId().equals(BlockBreakerTile.machineProfile(UUID.randomUUID(),0,origin).getId()),"identity separates dimension position owner");
  BlockBreakerTile.MachinePlayer positioned=(BlockBreakerTile.MachinePlayer)u.allocateInstance(BlockBreakerTile.MachinePlayer.class);positioned.world=w;positioned.posX=target.getX()+.5;positioned.posY=target.getY()+.5;positioned.posZ=target.getZ()+.5;positioned.dimension=7;
  ok(positioned.world==w && positioned.dimension==7 && positioned.getPositionVector().x==1.5 && positioned.getPositionVector().y==64.5 && positioned.getPositionVector().z==.5,"synthetic position and dimension");
  listener.cancel=true;w.blocks.put(target,Blocks.STONE.getDefaultState());run(t,p);
  ok(w.getBlockState(target).getBlock()==Blocks.STONE && e.getEnergyStored()==200 && t.tool.getStackInSlot(0).getItemDamage()==0,"cancel preserves block energy tool");
  listener.cancel=false;listener.tile=t;listener.replace=true;run(t,p);
  ok(w.getBlockState(target).getBlock()==Blocks.CHEST && e.getEnergyStored()==200,"guard cancels mutated target and reentry");
  listener.replace=false;listener.rotate=true;w.blocks.put(target,Blocks.STONE.getDefaultState());run(t,p);
  ok(w.getBlockState(target).getBlock()==Blocks.STONE && e.getEnergyStored()==200 && t.tool.getStackInSlot(0).getItemDamage()==0,"rotation during event cancels former front");
  listener.rotate=false;w.blocks.put(origin,facingEast);
  w.blocks.put(target,Blocks.STONE.getDefaultState());int beforeCalls=listener.calls;run(t,p);
  ok(listener.calls==beforeCalls+1,"no reentrant break event");
  ok(w.getBlockState(target).getBlock()==Blocks.AIR && e.getEnergyStored()==100 && t.tool.getStackInSlot(0).getItemDamage()==1,"stone harvest costs and damages tool");
  ok(w.drops.stream().anyMatch(s->s.getItem()==net.minecraft.item.Item.getItemFromBlock(Blocks.COBBLESTONE)),"vanilla cobblestone drop");
  t.tool.setStackInSlot(0,new ItemStack(Items.DIAMOND_PICKAXE));t.tool.getStackInSlot(0).addEnchantment(Enchantments.SILK_TOUCH,1);w.drops.clear();w.blocks.put(target,Blocks.DIAMOND_ORE.getDefaultState());run(t,p);
  ok(w.drops.stream().anyMatch(s->s.getItem()==ItemStackItem.DIAMOND_ORE),"silk ore drop");
  for(int i=0;i<32;i++)e.receiveEnergy(200,false);
  ItemStack enchanted=new ItemStack(Items.DIAMOND_PICKAXE);enchanted.addEnchantment(Enchantments.FORTUNE,3);enchanted.addEnchantment(Enchantments.UNBREAKING,3);t.tool.setStackInSlot(0,enchanted);w.drops.clear();
  for(int i=0;i<64;i++){w.blocks.put(target,Blocks.DIAMOND_ORE.getDefaultState());run(t,p);}
  int diamonds=w.drops.stream().filter(s->s.getItem()==Items.DIAMOND).mapToInt(ItemStack::getCount).sum();
  ok(diamonds>64,"fortune increased drops: "+diamonds);ok(t.tool.getStackInSlot(0).getItemDamage()<64,"unbreaking reduces wear");
  listener.fail=true; w.blocks.put(target,Blocks.STONE.getDefaultState()); bool(t,"mining",true);try{t.harvestChecked(p,target);}finally{bool(t,"mining",false);}
  ok(t.status()==BlockBreakerTile.STATUS_FAULT && t.writeToNBT(new net.minecraft.nbt.NBTTagCompound()).getBoolean("Fault"),"exception causes persistent fail-closed fault");
  ok(!t.tool.getStackInSlot(0).isEmpty() && p.inventory.getStackInSlot(0).isEmpty(),"tool recovered after exception");
  listener.fail=false;IBlockState expected=w.getBlockState(target);BlockBreakerHarvestGuard.begin(p,t,target,expected);
  try {
   boolean rejected=false;try{run(t,p);}catch(IllegalStateException duplicate){rejected=true;}
   ok(rejected,"nested guard rejected");
   BlockEvent.BreakEvent wrong=new BlockEvent.BreakEvent(w,origin,facingEast,p);BlockBreakerHarvestGuard.onBreak(wrong);
   ok(wrong.isCanceled(),"failed nested guard must not remove outer guard");
  } finally {BlockBreakerHarvestGuard.end(p);}
  System.out.println("PASS real interaction manager, world denial, synthetic identity/position, Forge cancel, stone, silk, fortune="+diamonds+", unbreaking wear="+t.tool.getStackInSlot(0).getItemDamage()+", FE, unsafe targets");
 }
 static class ItemStackItem {static final net.minecraft.item.Item DIAMOND_ORE=net.minecraft.item.Item.getItemFromBlock(Blocks.DIAMOND_ORE);}
}
