package com.mikael8367.nexustech.conveyor;

import com.mojang.authlib.GameProfile;
import java.lang.reflect.Field;
import java.util.UUID;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Bootstrap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.chunk.IChunkProvider;
import sun.misc.Unsafe;

public final class ConveyorTest {
    static void check(boolean condition, String label) { if (!condition) throw new AssertionError(label); }
    static class TestWorld extends World {
        boolean blocked, obstruction; WorldBorder border; BlockPos crusher;
        public IBlockState getBlockState(BlockPos p) { return p.equals(crusher) ? com.mikael8367.nexustech.crusher.CrusherRegistry.BLOCK.getDefaultState() : net.minecraft.init.Blocks.AIR.getDefaultState(); }
        public java.util.List<AxisAlignedBB> getCollisionBoxes(Entity e, AxisAlignedBB box) {
            java.util.List<AxisAlignedBB> out=new java.util.ArrayList<>();
            if (obstruction) out.add(box);
            if (crusher!=null) { AxisAlignedBB b=com.mikael8367.nexustech.crusher.CrusherRegistry.BLOCK.getCollisionBoundingBox(getBlockState(crusher),this,crusher).offset(crusher); if(b.intersects(box))out.add(b); }
            return out;
        }
        private TestWorld() { super(null, null, null, null, false); }
        protected IChunkProvider createChunkProvider() { return null; }
        protected boolean isChunkLoaded(int x, int z, boolean allowEmpty) { return !blocked; }
        public boolean isBlockLoaded(BlockPos p) { return !blocked; }
        public WorldBorder getWorldBorder() { return border; }
        public BlockPos getSpawnPoint() { return new BlockPos(0,64,0); }
    }
    static TestWorld world(boolean client) throws Exception {
        Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); Unsafe u=(Unsafe) f.get(null);
        TestWorld w=(TestWorld)u.allocateInstance(TestWorld.class);
        u.putBoolean(w,u.objectFieldOffset(World.class.getField("isRemote")),client);
        w.border=new WorldBorder();
        u.putObject(w,u.objectFieldOffset(World.class.getField("provider")),new net.minecraft.world.WorldProviderSurface());
        return w;
    }
    static class Player extends EntityPlayer {
        Player(World w) { super(w, new GameProfile(UUID.randomUUID(), "test")); }
        public boolean isSpectator() { return false; }
        public boolean isCreative() { return false; }
    }
    static void prepare(Entity e, double x, double y, double z) {
        e.setPosition(x,y,z); e.motionX=0; e.motionY=0; e.motionZ=0; e.onGround=true; e.velocityChanged=false;
    }
    static void collision(ConveyorBlock belt, World w, BlockPos p, EnumFacing f, Entity e) {
        belt.onEntityCollidedWithBlock(w,p,belt.getDefaultState().withProperty(ConveyorBlock.FACING,f),e);
    }
    public static void main(String[] args) throws Exception {
        Bootstrap.register();
        ConveyorBlock belt=ConveyorRegistry.BLOCK;
        BlockPos p=new BlockPos(0,64,0); TestWorld server=world(false), client=world(true);
        Player player=new Player(server); EntityCow cow=new EntityCow(server); EntityItem item=new EntityItem(server);
        check(belt.getBlockState().getValidStates().size()==4,"four states");
        for (EnumFacing dir : EnumFacing.HORIZONTALS) {
            IBlockState state=belt.getDefaultState().withProperty(ConveyorBlock.FACING,dir);
            check(belt.getStateFromMeta(belt.getMetaFromState(state)).equals(state),"metadata "+dir);
            player.rotationYaw=dir.getHorizontalAngle();
            check(player.getHorizontalFacing()==dir,"yaw corresponds to direction "+dir);
            check(belt.getStateForPlacement(server,p,EnumFacing.UP,0,0,0,0,player,EnumHand.MAIN_HAND).getValue(ConveyorBlock.FACING)==dir,"placement "+dir);
            for (Entity entity : new Entity[]{player,cow,item}) {
                prepare(entity,.5,64+ConveyorBlock.HEIGHT,.5);
                collision(belt,server,p,dir,entity);
                check(Math.abs(entity.motionX-dir.getFrontOffsetX()*ConveyorBlock.SPEED)<1e-9 && Math.abs(entity.motionZ-dir.getFrontOffsetZ()*ConveyorBlock.SPEED)<1e-9 && entity.velocityChanged,"velocity and sync "+dir+" "+entity.getClass());
                check(entity.motionY==0,"vertical motion preserved");
            }
        }
        prepare(player,.5,64+ConveyorBlock.HEIGHT,.5); player.setSneaking(true); collision(belt,server,p,EnumFacing.EAST,player);
        check(player.motionX==0 && !player.velocityChanged,"sneaking player exempt"); player.setSneaking(false);
        prepare(cow,.5,64+ConveyorBlock.HEIGHT,.5); cow.setSneaking(true); collision(belt,server,p,EnumFacing.EAST,cow);
        check(cow.motionX==ConveyorBlock.SPEED,"sneaking mob moves"); cow.setSneaking(false);
        prepare(item,.5,64+ConveyorBlock.HEIGHT,.5); collision(belt,client,p,EnumFacing.EAST,item);
        check(item.motionX==0 && !item.velocityChanged,"client does not drive");
        prepare(item,.5,64+ConveyorBlock.HEIGHT+.3,.5); collision(belt,server,p,EnumFacing.EAST,item);
        check(item.motionX==0,"airborne does not move");
        prepare(item,1.05,64+ConveyorBlock.HEIGHT,.5); collision(belt,server,p,EnumFacing.EAST,item);
        check(item.motionX==0,"center outside does not move");
        prepare(item,.5,64+ConveyorBlock.HEIGHT,.5); item.onGround=false; collision(belt,server,p,EnumFacing.EAST,item);
        check(item.motionX==ConveyorBlock.SPEED,"horizontal-only grounded move");
        prepare(item,.5,64+ConveyorBlock.HEIGHT,.5); item.motionY=0.42; collision(belt,server,p,EnumFacing.EAST,item);
        check(item.motionX==0,"jumping ignored");
        prepare(item,.5,64+ConveyorBlock.HEIGHT,.5); server.blocked=true; collision(belt,server,p,EnumFacing.EAST,item);
        check(item.motionX==0,"unloaded blocked"); server.blocked=false;
        prepare(item,.5,64+ConveyorBlock.HEIGHT,.5); server.border.setCenter(100,100); server.border.setTransition(2);
        collision(belt,server,p,EnumFacing.EAST,item); check(item.motionX==0,"border blocked");
        check(!ConveyorBlock.accepts(false,false,false,false,false,false,false,false),"other entity ignored");
        check(!ConveyorBlock.accepts(true,false,false,false,false,true,false,false),"noclip ignored");
        check(!ConveyorBlock.accepts(true,false,false,false,false,false,true,false),"rider ignored");
        check(!ConveyorBlock.accepts(true,false,false,false,false,false,false,true),"vehicle ignored");
        check(!ConveyorBlock.accepts(true,false,false,false,true,false,false,false),"dead ignored");
        check(!ConveyorBlock.onSurface(new AxisAlignedBB(-.3,64.125,.2,-.1,65,.8),p),"side collision rejected");
        server.border.setCenter(0,0); server.border.setTransition(60000000);
        for (EnumFacing dir : EnumFacing.HORIZONTALS) {
            server.crusher=p.offset(dir);
            for (Entity entity : new Entity[]{player,cow,item}) {
                double half=entity.width/2.0;
                double center=.5 + (0.5-half-ConveyorBlock.SPEED/2);
                double x=.5+dir.getFrontOffsetX()*(center-.5), z=.5+dir.getFrontOffsetZ()*(center-.5);
                prepare(entity,x,64+ConveyorBlock.HEIGHT,z); collision(belt,server,p,dir,entity);
                check(entity.motionY==.20,"transfer lift "+dir+" "+entity.getClass());
                AxisAlignedBB raised=entity.getEntityBoundingBox().offset(0,.16,0).offset(dir.getFrontOffsetX()*ConveyorBlock.SPEED,0,dir.getFrontOffsetZ()*ConveyorBlock.SPEED);
                check(server.getCollisionBoxes(entity,raised).isEmpty(),"raised path clears base "+dir);
            }
            prepare(player,.7,64+ConveyorBlock.HEIGHT,.5); player.setSneaking(true); collision(belt,server,p,dir,player); check(player.motionY==0 && player.motionX==0 && player.motionZ==0,"sneaking never lifted"); player.setSneaking(false);
        }
        server.crusher=p.east(); server.obstruction=true; prepare(item,.82,64+ConveyorBlock.HEIGHT,.5); collision(belt,server,p,EnumFacing.EAST,item); check(item.motionY==0,"blocked headroom does not lift");
        server.obstruction=false; prepare(item,.82,64+ConveyorBlock.HEIGHT,.5); collision(belt,server,p,EnumFacing.EAST,item);
        // Simulate item gravity and vanilla's axis-by-axis collision clipping for six ticks.
        AxisAlignedBB moving=item.getEntityBoundingBox(), plate=com.mikael8367.nexustech.crusher.CrusherRegistry.BLOCK.getCollisionBoundingBox(server.getBlockState(server.crusher),server,server.crusher).offset(server.crusher);
        double vx=item.motionX, vy=item.motionY;
        for(int tick=0;tick<6;tick++){vy-=.04;double dy=plate.calculateYOffset(moving,vy);moving=moving.offset(0,dy,0);double dx=plate.calculateXOffset(moving,vx);moving=moving.offset(dx,0,0);if(dy!=vy)vy=0;if(dx!=vx)vx=0;vx*=.98;vy*=.98;}
        check((moving.minX+moving.maxX)*.5>1.0 && moving.minY>=64.25-1e-9,"simulated item crosses onto plate");
        server.crusher=null; prepare(item,.82,64+ConveyorBlock.HEIGHT,.5); collision(belt,server,p,EnumFacing.EAST,item); check(item.motionY==0,"no crusher means no lift");
        Bootstrap.printToSYSOUT("PASS conveyor metadata, placement, contact, velocity, filtering, transfer clearance, authority, border and unloaded checks");
    }
}
