import json
from pathlib import Path
import unittest
from PIL import Image

ROOT = Path(__file__).resolve().parents[7]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'

class ConveyorAssetsTest(unittest.TestCase):
    def load(self, name):
        return json.loads((ASSETS / name).read_text(encoding='utf-8'))

    def test_variants_and_model(self):
        variants = self.load('blockstates/conveyor_belt.json')['variants']
        for facing, rotation in [('north', 0), ('east', 90), ('south', 180), ('west', 270)]:
            self.assertEqual(variants['facing=' + facing].get('y', 0), rotation)
            self.assertEqual(variants['facing=' + facing]['model'], 'nexustech:conveyor_belt')
        model = self.load('models/block/conveyor_belt.json')
        self.assertEqual(model['elements'][0]['to'], [16, 2, 16])
        self.assertEqual(model['elements'][0]['faces']['up']['texture'], '#top')
        self.assertEqual(self.load('models/item/conveyor_belt.json')['parent'], 'nexustech:block/conveyor_belt')
        for texture in ('conveyor_top', 'conveyor_side'):
            with Image.open(ASSETS / 'textures/blocks' / (texture + '.png')) as im:
                self.assertEqual(im.size, (16, 16))
                im.verify()

    def test_recipe(self):
        recipe = self.load('recipes/conveyor_belt.json')
        self.assertEqual(recipe['pattern'], ['ILI'])
        self.assertEqual(recipe['key']['I']['item'], 'minecraft:iron_ingot')
        self.assertEqual(recipe['key']['L']['item'], 'minecraft:leather')
        self.assertEqual(recipe['result'], {'item': 'nexustech:conveyor_belt', 'count': 4})

if __name__ == '__main__':
    unittest.main()
