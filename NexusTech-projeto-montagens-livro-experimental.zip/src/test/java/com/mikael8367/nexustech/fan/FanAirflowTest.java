package com.mikael8367.nexustech.fan;

import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.Callable;
import sun.misc.Unsafe;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.*;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.*;

/** Exercises the real tile and real entity classes against a bounded in-memory world. */
public final class FanAirflowTest {
 static Unsafe unsafe;
 static class AirWorld extends FanSafetyTest.W {
  EnumFacing facing; Set<BlockPos> solids, unloaded; int traces, count; boolean blockNear;
  FanTile callbackTile; boolean reenter, removeDuringTrace;
  @Override public boolean isBlockLoaded(BlockPos p){return !unloaded.contains(p);}
  @Override public IBlockState getBlockState(BlockPos p){
   if(!isBlockLoaded(p))throw new AssertionError("read unloaded block " + p);
   if(p.equals(BlockPos.ORIGIN))return FanRegistry.BLOCK.getDefaultState().withProperty(FanBlock.FACING,facing);
   return (solids.contains(p)?Blocks.STONE:Blocks.AIR).getDefaultState();
  }
  @Override public <T extends Entity> List<T> getEntitiesWithinAABB(Class<? extends T> c,AxisAlignedBB box,com.google.common.base.Predicate<? super T> pred){
   List<T> result=super.getEntitiesWithinAABB(c,box,pred);count=result.size();return result;
  }
  @Override public RayTraceResult rayTraceBlocks(Vec3d a,Vec3d b,boolean liquid,boolean ignore,boolean last){traces++;if(reenter){reenter=false;callbackTile.update();}if(removeDuringTrace){removeDuringTrace=false;tiles.remove(BlockPos.ORIGIN);}if(blockNear&&b.x<2)return new RayTraceResult(a,EnumFacing.UP,BlockPos.ORIGIN);return super.rayTraceBlocks(a,b,liquid,ignore,last);}
 }
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static AirWorld world(EnumFacing f)throws Exception{
  AirWorld w=(AirWorld)unsafe.allocateInstance(AirWorld.class);w.tiles=new HashMap<>();w.entities=new ArrayList<>();w.border=new net.minecraft.world.border.WorldBorder();w.solids=new HashSet<>();w.unloaded=new HashSet<>();w.facing=f;
  unsafe.putObject(w,unsafe.objectFieldOffset(World.class.getField("rand")),new Random());return w;
 }
 static EntityItem item(AirWorld w,double x,double y,double z)throws Exception{
  EntityItem e=(EntityItem)unsafe.allocateInstance(EntityItem.class);initEntity(e,w,x,y,z);return e;
 }
 static void initEntity(Entity e,AirWorld w,double x,double y,double z)throws Exception{
  e.world=w;e.posX=x;e.posY=y;e.posZ=z;e.setEntityBoundingBox(new AxisAlignedBB(x-.1,y,z-.1,x+.1,y+.2,z+.1));
  Field passengers=Entity.class.getDeclaredField("riddenByEntities");passengers.setAccessible(true);passengers.set(e,new ArrayList<Entity>());
 }
 static FanTile tile(AirWorld w,int energy,int speed,int range){FanTile t=new FanTile();FanSafetyTest.put(w,t);NBTTagCompound n=new NBTTagCompound();n.setInteger("Energy",energy);n.setInteger("Speed",speed);n.setInteger("Range",range);t.readFromNBT(n);return t;}
 static EntityItem at(AirWorld w,EnumFacing f,double distance)throws Exception{EntityItem e=item(w,.5+f.getFrontOffsetX()*distance,.5,.5+f.getFrontOffsetZ()*distance);w.entities.add(e);return e;}
 static double motion(Entity e,EnumFacing f){return e.motionX*f.getFrontOffsetX()+e.motionZ*f.getFrontOffsetZ();}
 public static void main(String[] args)throws Exception{
  Field u=Unsafe.class.getDeclaredField("theUnsafe");u.setAccessible(true);unsafe=(Unsafe)u.get(null);
  Bootstrap.register();java.lang.reflect.Constructor<?> c=Capability.class.getDeclaredConstructors()[0];c.setAccessible(true);CapabilityEnergy.ENERGY=(Capability<IEnergyStorage>)c.newInstance("test:energy",null,(Callable<IEnergyStorage>)()->null);
  for(EnumFacing f:new EnumFacing[]{EnumFacing.NORTH,EnumFacing.SOUTH,EnumFacing.EAST,EnumFacing.WEST}){
   AirWorld w=world(f);FanTile t=tile(w,100,0,0);EntityItem target=at(w,f,1.0);EntityItem behind=at(w,f,-1.5);t.update();check(Math.abs(motion(target,f)-.12)<1e-9,"direction "+f);check(motion(behind,f)==0,"behind "+f);check(t.field(0)==80,"one payment "+f);t.update();check(t.field(0)==80,"no payment at speed");
   w=world(f);t=tile(w,100,0,3);EntityItem before=at(w,f,1.0);EntityItem inside=at(w,f,2.0);EntityItem beyond=at(w,f,3.5);w.solids.add(BlockPos.ORIGIN.offset(f,2));t.update();check(motion(before,f)>0 && motion(inside,f)==0 && motion(beyond,f)==0,"solid wall "+f);
   w=world(f);t=tile(w,100,0,3);EntityItem after=at(w,f,2.0);w.unloaded.add(BlockPos.ORIGIN.offset(f,2));t.update();check(motion(after,f)==0&&t.field(0)==100,"unloaded chunk "+f);
  }
  for(EnumFacing f:new EnumFacing[]{EnumFacing.NORTH,EnumFacing.SOUTH,EnumFacing.EAST,EnumFacing.WEST}){
   IBlockState s=FanRegistry.BLOCK.getDefaultState().withProperty(FanBlock.FACING,f);
   check(FanRegistry.BLOCK.getStateFromMeta(FanRegistry.BLOCK.getMetaFromState(s)).getValue(FanBlock.FACING)==f,"facing metadata "+f);
  }
  AirWorld w=world(EnumFacing.EAST);FanTile t=tile(w,100,2,3);EntityItem near=at(w,EnumFacing.EAST,1.5),far=at(w,EnumFacing.EAST,8.5);t.update();check(Math.abs(near.motionX-.28)<1e-9&&far.motionX==0&&t.field(0)==55,"maximum range/speed and cost");
  w=world(EnumFacing.EAST);t=tile(w,19,0,0);near=at(w,EnumFacing.EAST,1.5);t.update();check(near.motionX==0&&t.field(0)==19,"insufficient energy");
  w=world(EnumFacing.EAST);t=tile(w,100,0,0);near=at(w,EnumFacing.EAST,1.5);w.blocked=true;t.update();check(near.motionX==0&&t.field(0)==100,"partial obstacle ray blocked");
  w=world(EnumFacing.EAST);t=tile(w,100,0,0);EntityPlayerMP player=(EntityPlayerMP)unsafe.allocateInstance(EntityPlayerMP.class);initEntity(player,w,1.5,.5,.5);w.entities.add(player);t.update();check(player.motionX>0&&player.velocityChanged,"player push sync");
  w=world(EnumFacing.EAST);t=tile(w,100,0,0);for(int i=0;i<100;i++)at(w,EnumFacing.EAST,1.5);t.update();int moved=0;for(Entity e:w.entities)if(e.motionX>0)moved++;check(moved==16&&w.count==16&&w.traces==16&&t.field(0)==80,"bounded batch");
  t.getCapability(CapabilityEnergy.ENERGY,null).receiveEnergy(500,false);for(int i=0;i<6;i++)t.update();for(Entity e:w.entities)check(e.motionX>0,"all targets eventually pushed under saturation");
  w=world(EnumFacing.EAST);t=tile(w,100,0,0);w.blockNear=true;for(int i=0;i<16;i++)at(w,EnumFacing.EAST,1.0);EntityItem unobstructed=at(w,EnumFacing.EAST,1.7);t.update();check(unobstructed.motionX==0&&t.field(0)==100&&w.traces==16,"blocked first batch costs nothing");t.update();check(unobstructed.motionX>0&&t.field(0)==80&&w.traces==17,"blocked targets cannot starve clear target");
  w=world(EnumFacing.EAST);t=tile(w,100,0,0);for(int i=0;i<17;i++)at(w,EnumFacing.EAST,1.0);t.update();w.entities.subList(1,17).clear();w.entities.get(0).motionX=0;t.update();t.update();check(w.entities.get(0).motionX>0,"cursor recovers after crowd shrinks");
  w=world(EnumFacing.EAST);t=tile(w,100,0,0);w.callbackTile=t;w.reenter=true;near=at(w,EnumFacing.EAST,1.5);t.update();check(w.traces==1&&near.motionX>0&&t.field(0)==80,"reentrant callback is bounded and charged once");
  w=world(EnumFacing.EAST);t=tile(w,100,0,0);w.callbackTile=t;w.removeDuringTrace=true;near=at(w,EnumFacing.EAST,1.5);t.update();check(near.motionX==0&&t.field(0)==100,"removed fan cannot push or consume energy");
  System.out.println("FanAirflowTest PASS");
 }
}
