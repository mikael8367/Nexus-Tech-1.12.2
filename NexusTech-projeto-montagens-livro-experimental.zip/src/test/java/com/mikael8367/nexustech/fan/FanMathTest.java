package com.mikael8367.nexustech.fan;
public final class FanMathTest {public static void main(String[] args){
 check(FanMath.distance(-3)==2 && FanMath.distance(0)==2 && FanMath.distance(3)==8 && FanMath.distance(999)==8);
 check(Math.abs(FanMath.speed(0)-.12)<1e-9 && Math.abs(FanMath.speed(2)-.28)<1e-9 && Math.abs(FanMath.speed(999)-.28)<1e-9);
 check(FanMath.cost(20,0,0)==20 && FanMath.cost(20,2,3)==45 && FanMath.cost(-1,-1,-1)==1 && FanMath.cost(Integer.MAX_VALUE,99,99)==2250);
 System.out.println("FanMathTest PASS");}private static void check(boolean b){if(!b)throw new AssertionError();}}
