package com.mikael8367.nexustech.itemcable;

import java.lang.reflect.*;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Bootstrap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.items.*;
import sun.misc.Unsafe;

/** Standalone simulated world and Forge event bus without LaunchWrapper transformations. */
public class ItemCableProtectionTest {
 static class W extends ItemCableSafetyTest.W {
  BlockPos denied;
  W(){super();}
  @Override public boolean isBlockModifiable(EntityPlayer p,BlockPos at){return !at.equals(denied);}
  @Override public void notifyNeighborsOfStateChange(BlockPos p,net.minecraft.block.Block b,boolean v){}
 }
 static class P extends FakePlayer {
  BlockPos denied; boolean spectator;
  P(){super((WorldServer)null,(GameProfile)null);}
  @Override public boolean isSpectator(){return spectator;}
  @Override public boolean canPlayerEdit(BlockPos p,EnumFacing f,ItemStack s){return !p.equals(denied);}
  @Override public ItemStack getHeldItem(EnumHand h){return ItemStack.EMPTY;}
 }
 public static class Listener {
  BlockPos denied; boolean cancel,denyBlock,denyItem,replace; W w; int calls;
  @SubscribeEvent public void event(PlayerInteractEvent.RightClickBlock e){
   calls++;
   if(e.getPos().equals(denied)){
    if(cancel)e.setCanceled(true);
    if(denyBlock)e.setUseBlock(Event.Result.DENY);
    if(denyItem)e.setUseItem(Event.Result.DENY);
    if(replace)w.tiles.remove(e.getPos());
   }
  }
 }
 static void ok(boolean v,String s){if(!v)throw new AssertionError(s);}
 public static void main(String[] args)throws Exception{
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);Unsafe u=(Unsafe)f.get(null);
  Bootstrap.register();
  Constructor<?> ctor=Capability.class.getDeclaredConstructors()[0];ctor.setAccessible(true);
  CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<IItemHandler>)ctor.newInstance("test:item",null,(java.util.concurrent.Callable<IItemHandler>)()->null);
  W w=(W)u.allocateInstance(W.class);w.tiles=new java.util.HashMap<>();w.blocks=new java.util.HashMap<>();w.unloaded=new java.util.HashSet<>();w.border=new net.minecraft.world.border.WorldBorder();
  P p=(P)u.allocateInstance(P.class);p.world=w;
  BlockPos a=ItemCableSafetyTest.A,b=a.east();
  w.blocks.put(a,ItemCableRegistry.EXTRACTOR.getDefaultState());w.blocks.put(b,ItemCableRegistry.CABLE.getDefaultState());
  ItemCableTile ta=ItemCableSafetyTest.put(w,a,new ItemCableTile()),tb=ItemCableSafetyTest.put(w,b,new ItemCableTile());
  // Standalone JVM lacks LaunchWrapper's event bytecode transformation. Register
  // directly on the real base listener list to exercise ForgeHooks/EVENT_BUS.
  Listener l=new Listener();l.w=w;
  Field busId=net.minecraftforge.fml.common.eventhandler.EventBus.class.getDeclaredField("busID");busId.setAccessible(true);
  int id=busId.getInt(MinecraftForge.EVENT_BUS);
  net.minecraftforge.fml.common.eventhandler.ListenerList list=new Event().getListenerList();
  net.minecraftforge.fml.common.eventhandler.IEventListener hook=e->{if(e instanceof PlayerInteractEvent.RightClickBlock)l.event((PlayerInteractEvent.RightClickBlock)e);};
  list.register(id,net.minecraftforge.fml.common.eventhandler.EventPriority.NORMAL,hook);
  p.spectator=true;ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"spectator rejected");p.spectator=false;
  p.world=ItemCableSafetyTest.world();ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"different world rejected");p.world=w;
  for(BlockPos pos:new BlockPos[]{a,b}){
   w.denied=pos;ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"world permission "+pos);w.denied=null;
   p.denied=pos;ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"edit permission "+pos);p.denied=null;
   l.denied=pos;
   l.denyBlock=true;ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"event block denied "+pos);l.denyBlock=false;
   l.denyItem=true;ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"event item denied "+pos);l.denyItem=false;
  }
  l.denied=null;ok(ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"toggle allowed");ok(ta.blocked(EnumFacing.EAST)&&tb.blocked(EnumFacing.WEST),"symmetric off");
  ok(ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"toggle again");ok(!ta.blocked(EnumFacing.EAST)&&!tb.blocked(EnumFacing.WEST),"symmetric on");
  w.unloaded.add(b);ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"unloaded target denied");w.unloaded.clear();
  ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.NORTH,p),"air target denied");
  l.denied=b;l.replace=true;ok(!ItemCableNetwork.toggleConnection(w,a,EnumFacing.EAST,p),"event mutation denied");ok(!ta.blocked(EnumFacing.EAST),"no change after mutation");
  list.unregister(id,hook);
  System.out.println("PASS ItemCableProtectionTest events="+l.calls);
 }
}
