package com.mikael8367.nexustech.itemcable;
import java.lang.reflect.*;
import java.util.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.*;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.*;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.*;
import sun.misc.Unsafe;

/** Standalone in-memory tests, not a running Minecraft server. */
public final class ItemCableSafetyTest {
 static final BlockPos A=new BlockPos(0,64,0),B=A.east(),SOURCE=A.north(),DEST=B.south();
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static class W extends World {
  Map<BlockPos,TileEntity> tiles;Map<BlockPos,IBlockState> blocks;Set<BlockPos> unloaded;WorldBorder border;int illegal;
  W(){super(null,null,null,null,false);}protected IChunkProvider createChunkProvider(){return null;}protected boolean isChunkLoaded(int x,int z,boolean empty){return true;}
  public boolean isBlockLoaded(BlockPos p){return !unloaded.contains(p);} public WorldBorder getWorldBorder(){return border;}
  public TileEntity getTileEntity(BlockPos p){if(!isBlockLoaded(p)){illegal++;throw new AssertionError("forced tile");}return tiles.get(p);}
  public IBlockState getBlockState(BlockPos p){if(!isBlockLoaded(p)){illegal++;throw new AssertionError("forced state");}IBlockState s=blocks.get(p);return s==null?Blocks.AIR.getDefaultState():s;}
  public void markChunkDirty(BlockPos p,TileEntity t){}
  public void notifyBlockUpdate(BlockPos p,IBlockState a,IBlockState b,int f){}
  public void markBlockRangeForRenderUpdate(BlockPos a,BlockPos b){}
 }
 static class Endpoint extends TileEntity {
  ItemStackHandler inv=new ItemStackHandler(1);EnumFacing used;
  public <T>T getCapability(Capability<T> cap,EnumFacing side){used=side;return cap==CapabilityItemHandler.ITEM_HANDLER_CAPABILITY?CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(inv):null;}
 }
 static W world()throws Exception{Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);W w=(W)((Unsafe)f.get(null)).allocateInstance(W.class);w.tiles=new HashMap<>();w.blocks=new HashMap<>();w.unloaded=new HashSet<>();w.border=new WorldBorder();return w;}
 static <T extends TileEntity>T put(W w,BlockPos p,T t){w.tiles.put(p,t);t.setWorld(w);t.setPos(p);return t;}
 static void run(ItemCableTile t)throws Exception{Method m=ItemCableNetwork.class.getDeclaredMethod("transfer",ItemCableTile.class);m.setAccessible(true);t.sourceCursor=EnumFacing.NORTH.ordinal();m.invoke(null,t);}
 public static void main(String[] args)throws Exception{
  Bootstrap.register();net.minecraftforge.fml.common.registry.GameRegistry.registerTileEntity(ItemCableTile.class,new ResourceLocation("nexustech","item_cable"));
  Constructor<?> ctor=Capability.class.getDeclaredConstructors()[0];ctor.setAccessible(true);CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<IItemHandler>)ctor.newInstance("test:item",null,(java.util.concurrent.Callable<IItemHandler>)()->null);
  W w=world();w.blocks.put(A,ItemCableRegistry.EXTRACTOR.getDefaultState());w.blocks.put(B,ItemCableRegistry.CABLE.getDefaultState());ItemCableTile a=put(w,A,new ItemCableTile()),b=put(w,B,new ItemCableTile());Endpoint from=put(w,SOURCE,new Endpoint()),to=put(w,DEST,new Endpoint());from.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,10));
  run(a);check(from.inv.getStackInSlot(0).getCount()==9&&to.inv.getStackInSlot(0).getCount()==1,"transport and conservation");check(from.used==EnumFacing.SOUTH&&to.used==EnumFacing.NORTH,"sided capability");
  to.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,64));run(a);check(from.inv.getStackInSlot(0).getCount()==9,"full destination");to.inv.setStackInSlot(0,ItemStack.EMPTY);
  b.setBlocked(EnumFacing.WEST,true);run(a);check(from.inv.getStackInSlot(0).getCount()==9,"one-sided blocked link");b.setBlocked(EnumFacing.WEST,false);
  b.setBlocked(EnumFacing.SOUTH,true);run(a);check(from.inv.getStackInSlot(0).getCount()==9,"blocked destination");b.setBlocked(EnumFacing.SOUTH,false);
  w.unloaded.add(B.east());run(a);check(from.inv.getStackInSlot(0).getCount()==9&&w.illegal==0,"unloaded network fails closed");w.unloaded.clear();
  w.tiles.put(DEST,from);run(a);check(from.inv.getStackInSlot(0).getCount()==9,"shared handler not source destination");w.tiles.put(DEST,to);
  NBTTagCompound n=b.writeToNBT(new NBTTagCompound());b.setBlocked(EnumFacing.EAST,true);n=b.writeToNBT(new NBTTagCompound());ItemCableTile restore=new ItemCableTile();restore.readFromNBT(n);check(restore.blocked(EnumFacing.EAST)&&!restore.blocked(EnumFacing.WEST),"persistent face mask");
  run(a);check(from.inv.getStackInSlot(0).getCount()==8&&to.inv.getStackInSlot(0).getCount()==1,"resumes after disconnect repaired");
  // Real Forge vanilla chests: getCapability may allocate a new InvWrapper each time.
  W wc=world();wc.blocks.put(A,ItemCableRegistry.EXTRACTOR.getDefaultState());wc.blocks.put(B,ItemCableRegistry.CABLE.getDefaultState());
  ItemCableTile ca=put(wc,A,new ItemCableTile()),cb=put(wc,B,new ItemCableTile());
  wc.blocks.put(SOURCE,Blocks.CHEST.getDefaultState());wc.blocks.put(DEST,Blocks.CHEST.getDefaultState());
  net.minecraft.tileentity.TileEntityChest chestA=put(wc,SOURCE,new net.minecraft.tileentity.TileEntityChest()),chestB=put(wc,DEST,new net.minecraft.tileentity.TileEntityChest());
  chestA.setInventorySlotContents(0,new ItemStack(Blocks.STONE,10));
  IItemHandler h1=chestA.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.SOUTH),h2=chestA.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.SOUTH);
  check(h1!=null&&h2!=null,"real chest capabilities");
  System.out.println("Chest capability references identical="+(h1==h2)+" class="+h1.getClass().getName());
  Method eq=ItemCableNetwork.class.getDeclaredMethod("equivalent",IItemHandler.class,IItemHandler.class);eq.setAccessible(true);
  IItemHandler fresh1=new net.minecraftforge.items.wrapper.InvWrapper(chestA),fresh2=new net.minecraftforge.items.wrapper.InvWrapper(chestA),freshOther=new net.minecraftforge.items.wrapper.InvWrapper(chestB);
  check(fresh1!=fresh2&&(Boolean)eq.invoke(null,fresh1,fresh2)&&!(Boolean)eq.invoke(null,fresh1,freshOther),"distinct wrapper references use underlying chest identity");
  check(ItemCableBlock.connected(wc,A,EnumFacing.NORTH)&&ItemCableBlock.connected(wc,B,EnumFacing.SOUTH),"single chests visual");
  run(ca);check(chestA.getStackInSlot(0).getCount()==9&&chestB.getStackInSlot(0).getCount()==1,"real chest transport and conservation");
  cb.setBlocked(EnumFacing.WEST,true);run(ca);check(chestA.getStackInSlot(0).getCount()==9,"chest route blocked");cb.setBlocked(EnumFacing.WEST,false);
  BlockPos adjacent=DEST.east();wc.blocks.put(adjacent,Blocks.CHEST.getDefaultState());put(wc,adjacent,new net.minecraft.tileentity.TileEntityChest());
  check(!ItemCableBlock.connected(wc,B,EnumFacing.SOUTH),"double chest visual closed");run(ca);check(chestA.getStackInSlot(0).getCount()==9,"double chest fails closed");
  // Scan all 27 slots on two actual vanilla chest tile entities, with only
  // the last source and last destination slot usable; conserve total items.
  W ws=world();ws.blocks.put(A,ItemCableRegistry.EXTRACTOR.getDefaultState());ws.blocks.put(B,ItemCableRegistry.CABLE.getDefaultState());
  ItemCableTile scanner=put(ws,A,new ItemCableTile());put(ws,B,new ItemCableTile());
  ws.blocks.put(SOURCE,Blocks.CHEST.getDefaultState());ws.blocks.put(DEST,Blocks.CHEST.getDefaultState());
  net.minecraft.tileentity.TileEntityChest sc=put(ws,SOURCE,new net.minecraft.tileentity.TileEntityChest()),dc=put(ws,DEST,new net.minecraft.tileentity.TileEntityChest());
  sc.setInventorySlotContents(26,new ItemStack(Blocks.STONE,5));for(int i=0;i<26;i++)dc.setInventorySlotContents(i,new ItemStack(Blocks.STONE,64));
  Method transfer=ItemCableNetwork.class.getDeclaredMethod("transfer",ItemCableTile.class);transfer.setAccessible(true);
  for(int i=0;i<4500;i++)transfer.invoke(null,scanner);
  int total=0;for(int i=0;i<27;i++)total+=sc.getStackInSlot(i).getCount()+dc.getStackInSlot(i).getCount();
  check(!dc.getStackInSlot(26).isEmpty()&&total==26*64+5,"full source and destination scan conserves items");
  System.out.println("PASS ItemCableSafetyTest");
 }
}
