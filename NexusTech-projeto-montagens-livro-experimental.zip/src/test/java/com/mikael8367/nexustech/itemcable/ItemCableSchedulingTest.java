package com.mikael8367.nexustech.itemcable;
import java.lang.reflect.*;
import java.util.*;
import net.minecraft.init.*;
import net.minecraft.item.ItemStack;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.border.WorldBorder;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.*;
import sun.misc.Unsafe;

/** Fixed tile-update order with intentionally colliding phases, in a simulated world. */
public class ItemCableSchedulingTest {
 static class W extends ItemCableSafetyTest.W {
  long time;
  W(){super();}
  @Override public long getTotalWorldTime(){return time;}
 }
 public static void main(String[] args)throws Exception{
  Bootstrap.register();
  Constructor<?> ctor=Capability.class.getDeclaredConstructors()[0];ctor.setAccessible(true);
  CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<IItemHandler>)ctor.newInstance("test:item",null,(java.util.concurrent.Callable<IItemHandler>)()->null);
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);W w=(W)((Unsafe)f.get(null)).allocateInstance(W.class);
  w.tiles=new HashMap<>();w.blocks=new HashMap<>();w.unloaded=new HashSet<>();w.border=new WorldBorder();
  List<ItemCableTile> extractors=new ArrayList<>();List<ItemCableSafetyTest.Endpoint> sources=new ArrayList<>();
  int last=-100;for(int x=0;extractors.size()<12;x++){
   BlockPos p=new BlockPos(x,64,0);if(Math.floorMod(p.hashCode(),20)!=0||x-last<10)continue;last=x;
   BlockPos gray=p.east(),src=p.north(),dest=gray.south();
   w.blocks.put(p,ItemCableRegistry.EXTRACTOR.getDefaultState());w.blocks.put(gray,ItemCableRegistry.CABLE.getDefaultState());
   extractors.add(ItemCableSafetyTest.put(w,p,new ItemCableTile()));ItemCableSafetyTest.put(w,gray,new ItemCableTile());
   ItemCableSafetyTest.Endpoint from=ItemCableSafetyTest.put(w,src,new ItemCableSafetyTest.Endpoint());
   from.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,64));sources.add(from);
   ItemCableSafetyTest.put(w,dest,new ItemCableSafetyTest.Endpoint());
  }
  for(w.time=0;w.time<2400;w.time++){
   int before=0;for(ItemCableTile t:extractors)before+=t.sourceCursor;
   for(ItemCableTile t:extractors)t.update();
   int after=0;for(ItemCableTile t:extractors)after+=t.sourceCursor;
   if(after-before>4)throw new AssertionError("global limit exceeded at tick "+w.time);
  }
  for(int i=0;i<sources.size();i++)if(sources.get(i).inv.getStackInSlot(0).getCount()==64)throw new AssertionError("starved extractor "+i+" at "+extractors.get(i).getPos());
  // Remove a queued head without ticking it: other live requests must not stall
  // or cause a tile lookup in the unloaded position.
  Field budgets=ItemCableNetwork.class.getDeclaredField("BUDGETS");budgets.setAccessible(true);
  Object budget=((Map<?,?>)budgets.get(null)).get(w);Field waitingField=budget.getClass().getDeclaredField("waiting");waitingField.setAccessible(true);
  Map<?,?> waiting=(Map<?,?>)waitingField.get(budget);
  while(waiting.size()<2&&w.time<2450){for(ItemCableTile t:extractors)t.update();w.time++;}
  if(waiting.size()<2)throw new AssertionError("failed to create backlog");
  BlockPos unloaded=(BlockPos)waiting.keySet().iterator().next();w.unloaded.add(unloaded);
  int[] before=new int[extractors.size()];for(int i=0;i<before.length;i++)before[i]=extractors.get(i).sourceCursor;
  for(int n=0;n<200;n++,w.time++)for(ItemCableTile t:extractors)t.update();
  for(int i=0;i<before.length;i++)if(!extractors.get(i).getPos().equals(unloaded)&&extractors.get(i).sourceCursor==before[i])throw new AssertionError("queue stalled after unload "+i);
  if(w.illegal!=0)throw new AssertionError("forced load");
  w.unloaded.clear();int old=0;for(ItemCableTile t:extractors)if(t.getPos().equals(unloaded))old=t.sourceCursor;
  for(int n=0;n<200;n++,w.time++)for(ItemCableTile t:extractors)t.update();
  for(ItemCableTile t:extractors)if(t.getPos().equals(unloaded)&&t.sourceCursor==old)throw new AssertionError("reloaded extractor stalled");
  System.out.println("PASS ItemCableSchedulingTest: 12 colliding extractors, 4/tick cap, unload and reload");
 }
}
