import json
from pathlib import Path
from PIL import Image
root=Path('src/main/resources/assets/nexustech')
for name in ('item_cable','item_extractor_cable'):
    state=json.loads((root/'blockstates'/f'{name}.json').read_text())
    assert len(state['multipart'])==7
    for part in state['multipart']:
        model=part['apply']['model'].split(':')[1]
        data=json.loads((root/'models/block'/f'{model}.json').read_text())
        assert data['elements'] and data['textures']['cable']==f'nexustech:blocks/{name}'
    assert json.loads((root/'models/item'/f'{name}.json').read_text())['parent']==f'nexustech:block/{name}_center'
    assert json.loads((root/'recipes'/f'{name}.json').read_text())['result']['item']==f'nexustech:{name}'
    Image.open(root/'textures/blocks'/f'{name}.png').verify()
    for lang in ('pt_br','en_us'):
        assert f'tile.nexustech.{name}.name=' in Path(f'docs/itemcable-localization/{lang}.lang').read_text()
print('PASS item cable resources')
