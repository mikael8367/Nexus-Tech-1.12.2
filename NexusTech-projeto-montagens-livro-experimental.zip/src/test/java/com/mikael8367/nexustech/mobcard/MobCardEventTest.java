package com.mikael8367.nexustech.mobcard;

import java.lang.reflect.Field;
import net.minecraft.init.Bootstrap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import sun.misc.Unsafe;

public class MobCardEventTest {
 static Unsafe u;
 static { try {Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); u=(Unsafe)f.get(null);} catch(Exception e){throw new RuntimeException(e);} }
 static <T>T make(Class<T> c) throws Exception {return c.cast(u.allocateInstance(c));}
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static class C extends Container { public boolean canInteractWith(EntityPlayer p){return true;} }
 static class Connection extends NetHandlerPlayServer {
   Packet<?> last; int sent;
   Connection(){super(null,null,null);}
   @Override public void sendPacket(Packet<?> p){last=p;sent++;}
 }
 static class Death extends LivingDeathEvent {
   boolean cancelled;
   Death(net.minecraft.entity.EntityLivingBase e,net.minecraft.util.DamageSource d,boolean c){super(e,d);cancelled=c;}
   @Override public boolean isCanceled(){return cancelled;}
 }
 public static void main(String[] x) throws Exception {
   Bootstrap.register();
   WorldServer w=make(WorldServer.class), client=make(WorldServer.class);
   Field remote=net.minecraft.world.World.class.getField("isRemote"); u.putBoolean(client,u.objectFieldOffset(remote),true);
   EntityPlayerMP player=make(EntityPlayerMP.class); player.world=w; player.inventory=new InventoryPlayer(player);
   player.inventoryContainer=new C();player.openContainer=new C();
   Connection conn=make(Connection.class); player.connection=conn;
   EntityZombie z=make(EntityZombie.class); z.world=w;
   ItemStack card=new ItemStack(new MobCardItem());player.inventory.offHandInventory.set(0,card);
   MobCardEvents.death(new Death(z,new EntityDamageSource("player",player),true));check(MobCardItem.getKills(card)==0,"cancelled death");
   MobCardEvents.death(new Death(z,new EntityDamageSourceIndirect("arrow",make(EntitySkeleton.class),player),false));check(MobCardItem.getKills(card)==0,"indirect damage");
   MobCardEvents.death(new Death(z,new EntityDamageSource("thorns",player).setIsThornsDamage(),false));check(MobCardItem.getKills(card)==0,"thorns damage");
   MobCardEvents.death(new Death(z,new EntityDamageSource("explosion",player).setExplosion(),false));check(MobCardItem.getKills(card)==0,"explosion damage");
   z.world=client; MobCardEvents.death(new Death(z,new EntityDamageSource("player",player),false));check(MobCardItem.getKills(card)==0,"client side");
   z.world=w; MobCardEvents.death(new Death(z,new EntityDamageSource("player",player),false));
   check(MobCardItem.getKills(card)==1,"direct player kill"); check(conn.sent==1 && conn.last instanceof SPacketSetSlot,"one explicit packet");
   SPacketSetSlot p=(SPacketSetSlot)conn.last; check(p.getWindowId()==-2 && p.getSlot()==40 && MobCardItem.getKills(p.getStack())==1,"offhand packet");
   EntitySkeleton skeleton=make(EntitySkeleton.class);skeleton.world=w;
   MobCardEvents.death(new Death(skeleton,new EntityDamageSource("player",player),false));check(MobCardItem.getKills(card)==1 && conn.sent==1,"other mob unchanged");
   player.inventory.offHandInventory.set(0,ItemStack.EMPTY);MobCardEvents.death(new Death(z,new EntityDamageSource("player",player),false));check(conn.sent==1,"no offhand card");
   Bootstrap.printToSYSOUT("PASS MobCardEventTest");
 }
}
