package com.mikael8367.nexustech.mobcard;

import net.minecraft.init.Bootstrap;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;

public final class MobCardTest {
    static void check(boolean value, String label) { if (!value) throw new AssertionError(label); }
    static ResourceLocation id(String s) { return new ResourceLocation(s); }
    static ItemStack corrupt(MobCardItem item, String mob, int kills) {
        ItemStack stack = new ItemStack(item); NBTTagCompound root = new NBTTagCompound(), data = new NBTTagCompound();
        data.setString("mob", mob); data.setInteger("kills", kills); root.setTag("NexusMobCard", data); stack.setTagCompound(root); return stack;
    }
    public static void main(String[] args) {
        Bootstrap.register();
        MobCardItem item = new MobCardItem();
        ResourceLocation zombie = id("minecraft:zombie"), blaze = id("minecraft:blaze"), ghast = id("minecraft:ghast");
        check(item.getItemStackLimit() == 1, "unstackable");
        check(!MobCardItem.isReady(ItemStack.EMPTY) && MobCardItem.getMob(ItemStack.EMPTY) == null, "empty");
        check(!MobCardItem.isReady(new ItemStack(Items.PAPER)), "wrong item");
        check(MobCardItem.required(zombie) == 20 && MobCardItem.required(blaze) == 10 && MobCardItem.required(ghast) == 5, "thresholds");
        for (String name : new String[]{"pig", "cow", "sheep", "chicken", "rabbit", "zombie", "skeleton", "spider", "creeper", "slime", "magma_cube", "enderman", "blaze", "witch", "cave_spider", "ghast"}) {
            ResourceLocation type = id("minecraft:" + name);
            check(net.minecraft.entity.EntityList.getClass(type) != null && MobCardItem.required(type) > 0, "registered " + type);
            check(net.minecraft.entity.EntityList.getTranslationName(type) != null, "translation key " + type);
        }
        for (String x : new String[]{"minecraft:ender_dragon", "minecraft:wither", "minecraft:player", "minecraft:armor_stand", "evil:zombie"}) check(MobCardItem.required(id(x)) == 0, "disallowed " + x);
        ItemStack stack = new ItemStack(item);
        check(!MobCardItem.isReady(stack) && MobCardItem.getMob(stack) == null, "blank");
        check(!MobCardItem.recordKill(stack, id("minecraft:wither")), "cannot bind boss");
        check(MobCardItem.recordKill(stack, zombie) && zombie.equals(MobCardItem.getMob(stack)) && MobCardItem.getKills(stack) == 1, "first kill binds");
        check(!MobCardItem.recordKill(stack, blaze) && MobCardItem.getKills(stack) == 1, "other mob ignored");
        for (int i = 2; i <= 20; i++) { check(MobCardItem.recordKill(stack, zombie), "count " + i); check(MobCardItem.getKills(stack) == i, "exact count"); check(MobCardItem.isReady(stack) == (i == 20), "readiness"); }
        check(!MobCardItem.recordKill(stack, zombie) && MobCardItem.getKills(stack) == 20, "saturates");
        ItemStack copy = stack.copy(); check(MobCardItem.isReady(copy) && zombie.equals(MobCardItem.getMob(copy)), "copy survives");
        for (int bad : new int[]{Integer.MIN_VALUE, -1, 0, 21, Integer.MAX_VALUE}) {
            ItemStack c = corrupt(item, "minecraft:zombie", bad);
            check(MobCardItem.getMob(c) == null && !MobCardItem.isReady(c) && !MobCardItem.recordKill(c, zombie), "invalid count " + bad);
        }
        for (String bad : new String[]{"minecraft:wither", "minecraft:ender_dragon", "evil:zombie", "ZOMBIE", "minecraft:zombie\n", ""}) {
            ItemStack c = corrupt(item, bad, 20);
            check(MobCardItem.getMob(c) == null && !MobCardItem.isReady(c) && !MobCardItem.recordKill(c, zombie), "invalid id");
        }
        ItemStack wrongType = new ItemStack(item); NBTTagCompound root = new NBTTagCompound(); root.setString("NexusMobCard", "oops"); wrongType.setTagCompound(root);
        check(!MobCardItem.recordKill(wrongType, zombie) && !MobCardItem.isReady(wrongType), "malformed compound never reset");
        ItemStack wrongInt = corrupt(item, "minecraft:zombie", 20); wrongInt.getTagCompound().getCompoundTag("NexusMobCard").setLong("kills", 20);
        check(!MobCardItem.isReady(wrongInt), "long not accepted");
        ItemStack stacked = new ItemStack(item, 2); check(!MobCardItem.recordKill(stacked, zombie) && !MobCardItem.isReady(stacked), "illicit stack rejected");
        ItemStack hard = new ItemStack(item); for (int i=0; i<5; i++) check(MobCardItem.recordKill(hard, ghast), "ghast"); check(MobCardItem.isReady(hard), "ghast ready after five");
        Bootstrap.printToSYSOUT("PASS MobCardTest");
    }
}
