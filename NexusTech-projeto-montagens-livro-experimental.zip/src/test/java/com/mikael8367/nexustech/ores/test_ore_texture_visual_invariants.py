#!/usr/bin/env python3
"""Ore texture source, visual invariants and resource-reference checks (Pillow)."""
import base64
import hashlib
import io
import json
import re
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[7]
SOURCES = ROOT / 'src/main/texture_sources/assets/nexustech/textures/blocks'
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TYPE = ROOT / 'src/main/java/com/mikael8367/nexustech/ores/OreType.java'


def ore_names():
    text = TYPE.read_text(encoding='utf-8').split('public final String', 1)[0]
    return re.findall(r'^\s*[A-Z]+\("([a-z]+)",', text, re.MULTILINE)


def decode(name):
    return base64.b64decode((SOURCES / (name + '_ore.png.b64')).read_text().strip(), validate=True)


class OreTextureVisualInvariants(unittest.TestCase):
    def test_registry_and_references(self):
        names = ore_names()
        self.assertEqual(len(names), 10)
        self.assertEqual(len(set(names)), len(names))
        self.assertEqual({p.name for p in SOURCES.glob('*_ore.png.b64')},
                         {name + '_ore.png.b64' for name in names})
        for name in names:
            with self.subTest(ore=name):
                ore = name + '_ore'
                state = json.loads((ASSETS / 'blockstates' / (ore + '.json')).read_text())
                block = json.loads((ASSETS / 'models/block' / (ore + '.json')).read_text())
                item = json.loads((ASSETS / 'models/item' / (ore + '.json')).read_text())
                self.assertEqual(state['variants']['normal']['model'], 'nexustech:' + ore)
                self.assertEqual(block['parent'], 'block/cube_all')
                self.assertEqual(block['textures']['all'], 'nexustech:blocks/' + ore)
                self.assertEqual(item['parent'], 'nexustech:block/' + ore)
                # A duplicate regular resource could shadow generated output.
                self.assertFalse((ASSETS / 'textures/blocks' / (ore + '.png')).exists())

    def test_pixels_and_palettes(self):
        hashes, colored_palettes, images = set(), [], []
        for name in ore_names():
            with self.subTest(ore=name):
                data = decode(name)
                self.assertTrue(data.startswith(b'\x89PNG\r\n\x1a\n'))
                im = Image.open(io.BytesIO(data))
                self.assertEqual(im.format, 'PNG')
                im.verify()  # also checks PNG integrity / CRC
                im = Image.open(io.BytesIO(data)).convert('RGBA')
                self.assertEqual(im.size, (16, 16))
                pixels = list(im.getdata())
                self.assertTrue(all(a == 255 for r, g, b, a in pixels))
                gray = [p for p in pixels if p[0] == p[1] == p[2]]
                self.assertGreaterEqual(len(gray), 190)  # primarily stone
                self.assertLessEqual(len(gray), 235)    # visibly veined
                self.assertGreaterEqual(len(set(gray)), 6)
                colored = frozenset(p for p in pixels if not p[0] == p[1] == p[2])
                self.assertGreaterEqual(len(colored), 3)
                self.assertNotIn(colored, colored_palettes)
                colored_palettes.append(colored)
                digest = hashlib.sha256(data).hexdigest()
                self.assertNotIn(digest, hashes)
                hashes.add(digest)
                images.append(pixels)
        # Same authored pixel stone is shared where no vein covers it.
        common_stone = sum(1 for column in zip(*images)
                           if len(set(column)) == 1 and column[0][0] == column[0][1] == column[0][2])
        self.assertGreaterEqual(common_stone, 100)

    def test_build_wiring(self):
        build = (ROOT / 'build.gradle').read_text(encoding='utf-8')
        self.assertIn("file('src/main/texture_sources')", build)
        self.assertIn("include '**/*.png.b64'", build)
        self.assertIn("Base64.decoder.decode(source.getText('UTF-8').trim())", build)
        self.assertIn('dependsOn generateTextureResources', build)
        self.assertIn('from generatedTextures', build)
        # Emulate the exact decoded byte output for each ore, without touching
        # Gradle's shared generated directory or creating a JAR.
        for name in ore_names():
            with self.subTest(ore=name):
                self.assertEqual(Image.open(io.BytesIO(decode(name))).size, (16, 16))


if __name__ == '__main__':
    unittest.main()
