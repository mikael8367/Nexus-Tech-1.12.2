package com.mikael8367.nexustech.plantharvester;

import java.lang.reflect.*;
import java.util.*;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.WorldProviderSurface;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.storage.MapStorage;
import sun.misc.Unsafe;

/** Optional external MysticalAudit fixture: real crop/seed, transformed fake-player harness.
 * This is NOT an in-game or production fake-player test. No mod dependency at compile time. */
public final class PlantHarvesterMysticalRegressionTest {
 static final BlockPos MACHINE=new BlockPos(10,64,10), CROP=MACHINE.east();
 static final class W extends WorldServer {
  Map<BlockPos,TileEntity> tiles; IBlockState crop,soil; WorldBorder border; MapStorage storage; int permissions,changes; boolean alterSoil,throwAfterState,soilOnDirty;
  W(){super(null,null,null,0,null);}
  public boolean isBlockLoaded(BlockPos p){return true;}
  public TileEntity getTileEntity(BlockPos p){return tiles.get(p);}
  public IBlockState getBlockState(BlockPos p){return p.equals(CROP)?crop:p.equals(CROP.down())?soil:Blocks.AIR.getDefaultState();}
  public boolean setBlockState(BlockPos p,IBlockState s,int f){crop=s;changes++;if(throwAfterState)throw new IllegalStateException("callback after mutation");return true;}
  public boolean isBlockModifiable(EntityPlayer player,BlockPos p){if(++permissions==2&&alterSoil)soil=Blocks.STONE.getDefaultState();return true;}
  public net.minecraft.world.GameRules getGameRules(){return new net.minecraft.world.GameRules();}
  public WorldBorder getWorldBorder(){return border;}
  public MapStorage getPerWorldStorage(){return storage;}
  public void markChunkDirty(BlockPos p,TileEntity t){if(soilOnDirty){soilOnDirty=false;soil=Blocks.STONE.getDefaultState();}}
 }
 static void field(Object obj,Class<?> c,String name,Object value,Unsafe u)throws Exception {
  Field f=c.getDeclaredField(name);f.setAccessible(true);u.putObject(obj,u.objectFieldOffset(f),value);
 }
 public static void main(String[] args)throws Exception {
  Class<?> fixture=Class.forName("com.mikael8367.nexustech.plantharvester.MysticalAudit");
  fixture.getMethod("main",String[].class).invoke(null,(Object)args);
  Field uf=Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);Unsafe u=(Unsafe)uf.get(null);
  Field cf=fixture.getDeclaredField("crop");cf.setAccessible(true);BlockCrops crop=(BlockCrops)cf.get(null);
  W w=(W)u.allocateInstance(W.class);w.tiles=new HashMap<>();w.border=new WorldBorder();w.storage=new MapStorage(null);
  w.crop=crop.withAge(7);w.soil=Blocks.FARMLAND.getDefaultState();w.alterSoil=true;
  field(w,World.class,"rand",new Random(100),u);field(w,World.class,"provider",new WorldProviderSurface(),u);
  PlantHarvesterTile t=new PlantHarvesterTile();t.setWorld(w);t.setPos(MACHINE);w.tiles.put(MACHINE,t);
  NBTTagCompound n=new NBTTagCompound();n.setUniqueId("Owner",UUID.randomUUID());n.setTag("Inventory",t.inv.serializeNBT());t.readFromNBT(n);t.setPos(MACHINE);t.energy=1000;
  Method harvest=PlantHarvesterTile.class.getDeclaredMethod("harvest",BlockPos.class,IBlockState.class,BlockCrops.class);harvest.setAccessible(true);
  boolean result=(Boolean)harvest.invoke(t,CROP,w.crop,crop);
  if(result||w.permissions!=2||w.crop!=crop.withAge(7)||w.changes!=0||t.energy!=1000)throw new AssertionError("soil change must abort without crop/energy mutation");
  for(int i=0;i<27;i++)if(!t.inv.getStackInSlot(i).isEmpty())throw new AssertionError("output created on abort");
  w.crop=crop.withAge(7);w.soil=Blocks.FARMLAND.getDefaultState();w.permissions=0;w.alterSoil=false;w.soilOnDirty=true;
  if((Boolean)harvest.invoke(t,CROP,w.crop,crop)||w.crop!=crop.withAge(7)||w.changes!=0||t.energy!=1000||t.writeToNBT(new NBTTagCompound()).getTagList("Pending",10).tagCount()!=0)throw new AssertionError("dirty callback soil change must abort and refund");
  // Simulate setBlockState throwing after changing the crop: outputs are
  // uncertain and must not be replayed on the following tick.
  w.crop=crop.withAge(7);w.soil=Blocks.FARMLAND.getDefaultState();w.permissions=0;w.changes=0;w.alterSoil=false;w.throwAfterState=true;
  t.cursor=41;t.delay=0;t.update();
  if(w.crop!=crop.withAge(0)||w.changes!=1||t.energy!=800||t.busy)throw new AssertionError("post-mutation exception contained");
  if(t.writeToNBT(new NBTTagCompound()).getTagList("Pending",10).tagCount()==0)throw new AssertionError("ambiguous drops retained");
  t.update();
  if(t.writeToNBT(new NBTTagCompound()).getTagList("Pending",10).tagCount()!=0||PlantHarvesterRecovery.get(w).writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==0)throw new AssertionError("ambiguous drops quarantined");
  for(int i=0;i<27;i++)if(!t.inv.getStackInSlot(i).isEmpty())throw new AssertionError("ambiguous drops replayed");
  System.out.println("PASS PlantHarvesterMysticalRegressionTest: soil change abort and post-mutation exception quarantine (transformed fake harness)");
 }
}
