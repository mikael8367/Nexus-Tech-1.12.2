package com.mikael8367.nexustech.plantharvester;

import java.lang.reflect.*;
import java.util.*;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Bootstrap;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.storage.MapStorage;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import sun.misc.Unsafe;

/** Standalone simulated handlers and world, not an integration test in Forge. */
public final class PlantHarvesterSafetyTest {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static final BlockPos POS=new BlockPos(12,64,12);
 static class W extends World {
  Map<BlockPos,TileEntity> tiles; Set<BlockPos> unloaded; MapStorage store; Runnable dirty; int illegal; BlockPos throwAt; IBlockState soil; net.minecraft.world.border.WorldBorder border;
  W(){super(null,null,null,null,false);} protected IChunkProvider createChunkProvider(){return null;}
  protected boolean isChunkLoaded(int x,int z,boolean allow){return true;}
  public boolean isBlockLoaded(BlockPos p){return !unloaded.contains(p);}
  public TileEntity getTileEntity(BlockPos p){if(unloaded.contains(p)){illegal++;throw new AssertionError("unloaded tile");}return tiles.get(p);}
  public IBlockState getBlockState(BlockPos p){if(p.equals(throwAt))throw new IllegalStateException("broken crop");return p.equals(POS.down())?soil:Blocks.AIR.getDefaultState();}
  public net.minecraft.world.border.WorldBorder getWorldBorder(){return border;}
  public net.minecraft.world.GameRules getGameRules(){return new net.minecraft.world.GameRules();}
  public MapStorage getPerWorldStorage(){return store;}
  public void markChunkDirty(BlockPos p,TileEntity t){if(dirty!=null){Runnable r=dirty;dirty=null;r.run();}}
 }
 static W world() throws Exception {
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);Unsafe u=(Unsafe)f.get(null);
  W w=(W)u.allocateInstance(W.class);w.tiles=new HashMap<>();w.unloaded=new HashSet<>();w.store=new MapStorage(null);w.soil=Blocks.FARMLAND.getDefaultState();w.border=new net.minecraft.world.border.WorldBorder();
  Field r=World.class.getDeclaredField("rand");r.setAccessible(true);r.set(w,new Random(123));return w;
 }
 static PlantHarvesterTile tile(W w){PlantHarvesterTile t=new PlantHarvesterTile();t.setWorld(w);t.setPos(POS);w.tiles.put(POS,t);NBTTagCompound n=new NBTTagCompound();n.setUniqueId("Owner",UUID.randomUUID());n.setTag("Inventory",t.inv.serializeNBT());t.readFromNBT(n);t.setPos(POS);return t;}
 static class ServerW extends net.minecraft.world.WorldServer {ServerW(){super(null,null,null,0,null);}}
 static class CustomProvider extends net.minecraft.world.WorldProviderSurface {}
 static class Destination extends TileEntity {
  final ItemStackHandler inv=new ItemStackHandler(1);String fault="";int calls;Runnable callback;EnumFacing expected=EnumFacing.SOUTH;
  final IItemHandler h=new IItemHandler(){
   public int getSlots(){return 1;} public int getSlotLimit(int s){return 64;}
   public ItemStack getStackInSlot(int s){return inv.getStackInSlot(s);}public ItemStack extractItem(int s,int n,boolean sim){return inv.extractItem(s,n,sim);}
   public ItemStack insertItem(int s,ItemStack stack,boolean sim){calls++;if(callback!=null){Runnable r=callback;callback=null;r.run();}if(fault.equals("before"))throw new IllegalStateException();ItemStack left=inv.insertItem(s,stack,sim);if(fault.equals("after"))throw new IllegalStateException();return left;}
  };
  public <T>T getCapability(Capability<T> c,EnumFacing side){check(side==expected,"destination side");return CapabilityItemHandler.ITEM_HANDLER_CAPABILITY.cast(h);}
 }
 static class TestPlayer extends net.minecraft.entity.player.EntityPlayer {
  String message;
  TestPlayer(World w){super(w,new com.mojang.authlib.GameProfile(UUID.randomUUID(),"tester"));}
  public boolean isSpectator(){return false;} public boolean isCreative(){return false;}
  public boolean canUseCommand(int n,String command){return false;}
  public void sendMessage(net.minecraft.util.text.ITextComponent text){message=text.getUnformattedText();}
 }
 static TestPlayer player(UUID id) throws Exception {
  Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);TestPlayer p=(TestPlayer)((Unsafe)f.get(null)).allocateInstance(TestPlayer.class);p.setUniqueId(id);return p;
 }
 static class VariantCrop extends BlockCrops {
  static final net.minecraft.block.properties.PropertyInteger VARIANT=net.minecraft.block.properties.PropertyInteger.create("variant",0,2);
  VariantCrop(){setDefaultState(blockState.getBaseState().withProperty(AGE,0).withProperty(VARIANT,0));}
  protected net.minecraft.block.state.BlockStateContainer createBlockState(){return new net.minecraft.block.state.BlockStateContainer(this,AGE,VARIANT);}
 }
 static class Plant implements net.minecraftforge.common.IPlantable {
  IBlockState state;int calls;Plant(IBlockState s){state=s;}
  public net.minecraftforge.common.EnumPlantType getPlantType(net.minecraft.world.IBlockAccess w,BlockPos p){return net.minecraftforge.common.EnumPlantType.Crop;}
  public IBlockState getPlant(net.minecraft.world.IBlockAccess w,BlockPos p){calls++;return state;}
 }
 static int quarantine(PlantHarvesterTile t){return t.writeToNBT(new NBTTagCompound()).hasKey("Uncertain",10)?1:0;}
 static void tests() throws Exception {
  W w=world();PlantHarvesterTile t=tile(w);IItemHandler h=t.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.UP);
  check(h!=null&&h.getSlots()==27,"output capability");t.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,10));
  ItemStack copy=h.getStackInSlot(0);copy.shrink(9);check(t.inv.getStackInSlot(0).getCount()==10,"view is defensive copy");
  check(h.insertItem(0,new ItemStack(Blocks.STONE,2),false).getCount()==2,"output insertion denied");
  check(t.inv.insertItem(27,new ItemStack(Blocks.STONE,2),false).getCount()==2 && t.inv.getStackInSlot(27).isEmpty(),"invalid upgrade rejected by handler");
  check(h.extractItem(0,3,true).getCount()==3&&t.inv.getStackInSlot(0).getCount()==10,"simulated extraction");
  check(h.extractItem(0,3,false).getCount()==3&&t.inv.getStackInSlot(0).getCount()==7,"real extraction");
  IEnergyStorage e=t.getCapability(CapabilityEnergy.ENERGY,EnumFacing.DOWN);
  check(e.receiveEnergy(3000,true)==2000&&e.getEnergyStored()==0,"energy simulation");
  check(e.receiveEnergy(3000,false)==2000&&e.extractEnergy(5,false)==0&&e.getEnergyStored()==2000,"energy receive cap");
  for(int n=0;n<=50;n++){t.inv.setStackInSlot(27,n==0?ItemStack.EMPTY:new ItemStack(PlantHarvesterRegistry.UPGRADE,n));check(t.period()==20-n*15/50,"upgrade period "+n);}
  InventoryPlayer player=new InventoryPlayer(null);player.setInventorySlotContents(9,new ItemStack(PlantHarvesterRegistry.UPGRADE,64));t.inv.setStackInSlot(27,ItemStack.EMPTY);
  PlantHarvesterContainer c=new PlantHarvesterContainer(player,t);Method transfer=PlantHarvesterContainer.class.getDeclaredMethod("transferImpl",net.minecraft.entity.player.EntityPlayer.class,int.class);transfer.setAccessible(true);transfer.invoke(c,null,28);
  check(t.inv.getStackInSlot(27).getCount()==50&&player.getStackInSlot(9).getCount()==14,"shift click respects limit");
  NBTTagCompound saved=t.writeToNBT(new NBTTagCompound());saved.getCompoundTag("Inventory").setInteger("Size",999999999);PlantHarvesterTile loaded=new PlantHarvesterTile();loaded.readFromNBT(saved);check(loaded.inv.getSlots()==28&&loaded.inv.getStackInSlot(0).getCount()==7,"NBT fixed inventory size");
  Method fits=PlantHarvesterTile.class.getDeclaredMethod("fits",List.class);fits.setAccessible(true);List<ItemStack> drops=Collections.singletonList(new ItemStack(Blocks.DIAMOND_BLOCK,1));
  for(int i=0;i<27;i++)t.inv.setStackInSlot(i,new ItemStack(Blocks.STONE,64));check(!(Boolean)fits.invoke(t,drops),"full output blocks harvest");t.inv.setStackInSlot(0,ItemStack.EMPTY);check((Boolean)fits.invoke(t,drops),"space permits harvest");
  BlockCrops crop=(BlockCrops)Blocks.WHEAT;IBlockState mature=crop.withAge(7), young=crop.withAge(0);check(crop.isMaxAge(mature)&&!crop.isMaxAge(young)&&young.getBlock()==crop,"wheat maturity and replant state");
  for(Object[] pair:new Object[][]{{Blocks.WHEAT,net.minecraft.init.Items.WHEAT_SEEDS},{Blocks.CARROTS,net.minecraft.init.Items.CARROT},{Blocks.POTATOES,net.minecraft.init.Items.POTATO},{Blocks.BEETROOTS,net.minecraft.init.Items.BEETROOT_SEEDS}}){
   BlockCrops b=(BlockCrops)pair[0];net.minecraftforge.common.IPlantable plant=(net.minecraftforge.common.IPlantable)pair[1];
   check(PlantHarvesterTile.replantState(w,POS,b,plant)==plant.getPlant(w,POS),"vanilla replant state "+b);
  }
  VariantCrop variant=new VariantCrop();IBlockState special=variant.getDefaultState().withProperty(VariantCrop.VARIANT,2).withProperty(BlockCrops.AGE,3);
  check(PlantHarvesterTile.replantState(w,POS,variant,new Plant(special))==special,"plant metadata and age preserved");
  check(PlantHarvesterTile.replantState(w,POS,variant,new Plant(special.withProperty(BlockCrops.AGE,7)))==null,"mature replant rejected");
  check(PlantHarvesterTile.replantState(w,POS,variant,new Plant(Blocks.WHEAT.getDefaultState()))==null,"different crop rejected");
  Plant guarded=new Plant(special);w.unloaded.add(POS.down());check(PlantHarvesterTile.replantState(w,POS,variant,guarded)==null&&guarded.calls==0,"unloaded soil rejected before invoking foreign plant");w.unloaded.clear();
  check(PlantHarvesterTile.replantState(w,POS,variant,guarded)==special,"valid soil initially");w.soil=Blocks.STONE.getDefaultState();check(PlantHarvesterTile.replantState(w,POS,variant,guarded)==null,"changed soil rejected on recheck");w.soil=Blocks.FARMLAND.getDefaultState();
  W failed=world();PlantHarvesterTile failedTile=tile(failed);failedTile.energy=1000;failed.throwAt=POS.add(-4,0,-4);failedTile.update();check(!failedTile.busy&&failedTile.cursor==1&&failedTile.energy==1000,"foreign exception contained and cursor advanced");failed.throwAt=null;failedTile.delay=0;failedTile.update();check(failedTile.cursor==9&&!failedTile.busy,"next scan continues after foreign failure");
  UUID real=UUID.randomUUID();com.mojang.authlib.GameProfile a=PlantHarvesterTile.machineProfile(real,0,POS),b=PlantHarvesterTile.machineProfile(real,1,POS);
  check(!a.getId().equals(real)&&!a.getId().equals(b.getId()),"fake identity differs from human and between dimensions");
  check(a.equals(PlantHarvesterTile.machineProfile(real,0,POS))&&!a.getId().equals(PlantHarvesterTile.machineProfile(real,0,POS.east()).getId()),"machine identity stable and location-specific");
  Field uf=Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);Unsafe unsafe=(Unsafe)uf.get(null);
  ServerW serverWorld=(ServerW)unsafe.allocateInstance(ServerW.class);Field provider=World.class.getDeclaredField("provider");provider.setAccessible(true);unsafe.putObject(serverWorld,unsafe.objectFieldOffset(provider),new CustomProvider());
  check(!PlantHarvesterTile.safeFakeConstruction(serverWorld),"custom dimension provider rejected before constructor");
  PlantHarvesterTile.MachinePlayer mp=(PlantHarvesterTile.MachinePlayer)unsafe.allocateInstance(PlantHarvesterTile.MachinePlayer.class);
  mp.setPosition(12.5,64.5,12.5);net.minecraft.util.math.Vec3d v=mp.getPositionVector();
  check(v.x==12.5&&v.y==64.5&&v.z==12.5,"fake player vector uses target, not Forge zero vector");

  for(String fault:new String[]{"","before","after"}){
   w=world();t=tile(w);Destination d=new Destination();w.tiles.put(POS.north(),d);t.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,7));d.fault=fault;
   final PlantHarvesterTile machine=t;IItemHandler pull=t.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY,EnumFacing.UP);
   d.callback=()->{machine.update();check(pull.extractItem(0,99,false).isEmpty(),"reentrant extraction blocked");};t.update();
   if(fault.isEmpty())check(d.inv.getStackInSlot(0).getCount()==7&&t.inv.getStackInSlot(0).isEmpty()&&quarantine(t)==0,"successful chest transfer once");
   else {check(quarantine(t)==1&&t.inv.getStackInSlot(0).isEmpty(),"exception quarantined "+fault);int calls=d.calls;t.update();check(d.calls==calls,"ambiguous transfer not retried");PlantHarvesterTile restore=new PlantHarvesterTile();restore.readFromNBT(t.writeToNBT(new NBTTagCompound()));check(quarantine(restore)==1,"quarantine persisted");}
  }
  for(String fault:new String[]{"before","after"}) {
   W qw=world();PlantHarvesterTile qt=tile(qw);Destination qd=new Destination();qw.tiles.put(POS.north(),qd);qd.fault=fault;qt.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,7));qt.update();
   UUID oid=qt.writeToNBT(new NBTTagCompound()).getUniqueId("Owner");TestPlayer owner=player(oid), stranger=player(UUID.randomUUID());
   check(!qt.recoveryInteraction(stranger,true)&&quarantine(qt)==1,"unauthorized recovery denied");
   check(!qt.recoveryInteraction(owner,false)&&owner.message.contains("transferência incerta"),"diagnostic visible");
   check(qt.recoveryInteraction(owner,true)&&quarantine(qt)==1&&owner.message.contains("novamente"),"first confirmation keeps evidence");
   check(qt.recoveryInteraction(owner,true)&&quarantine(qt)==0&&owner.message.contains("Nenhum item"),"second confirmation quarantines only");
   NBTTagList records=PlantHarvesterRecovery.get(qw).writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10);
   check(records.tagCount()==1&&new ItemStack(records.getCompoundTagAt(0).getCompoundTag("Stack")).getCount()==7,"evidence retained exactly once");
   check(qt.inv.getStackInSlot(0).isEmpty()&&qd.inv.getStackInSlot(0).getCount()==(fault.equals("after")?7:0),"no recreated uncertain item");
  }
  w=world();t=tile(w);Destination d=new Destination();w.tiles.put(POS.north(),d);d.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,64));t.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,7));t.update();check(t.inv.getStackInSlot(0).getCount()==7&&quarantine(t)==0,"full chest backpressure");d.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,60));t.update();check(d.inv.getStackInSlot(0).getCount()==64&&t.inv.getStackInSlot(0).getCount()==3,"partial transfer conserved");
  w.unloaded.add(POS.north());t.update();check(w.illegal==0,"unloaded destination skipped");
  for(EnumFacing face:EnumFacing.VALUES){W fw=world();PlantHarvesterTile ft=tile(fw);Destination fd=new Destination();fd.expected=face.getOpposite();fw.tiles.put(POS.offset(face),fd);ft.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,4));ft.update();check(fd.inv.getStackInSlot(0).getCount()==4&&ft.inv.getStackInSlot(0).isEmpty(),"push on "+face);}
  W pw=world();PlantHarvesterTile pt=tile(pw);NBTTagCompound pn=pt.writeToNBT(new NBTTagCompound());net.minecraft.nbt.NBTTagList pending=new net.minecraft.nbt.NBTTagList();pending.appendTag(new ItemStack(Blocks.STONE,5).writeToNBT(new NBTTagCompound()));pn.setTag("Pending",pending);pt.readFromNBT(pn);pt.update();
  check(pt.writeToNBT(new NBTTagCompound()).getTagList("Pending",10).tagCount()==0 && PlantHarvesterRecovery.get(pw).writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==1,"interrupted pending quarantined once");
  pt.update();check(PlantHarvesterRecovery.get(pw).writeToNBT(new NBTTagCompound()).getTagList("Quarantine",10).tagCount()==1,"pending not replayed");
  W rw=world();PlantHarvesterTile rt=tile(rw);Destination rd=new Destination();rw.tiles.put(POS.north(),rd);rt.inv.setStackInSlot(0,new ItemStack(Blocks.STONE,7));rw.dirty=()->{rt.removed();rw.tiles.remove(POS);rt.invalidate();};rt.update();check(rd.calls==0&&PlantHarvesterRecovery.get(rw).size()==1,"removal during reservation avoids foreign insertion");
 }
 public static void main(String[] args)throws Exception{
  Bootstrap.register();net.minecraftforge.fml.common.registry.GameRegistry.registerTileEntity(PlantHarvesterTile.class,new net.minecraft.util.ResourceLocation("nexustech","plant_harvester"));Constructor<?> ctor=Capability.class.getDeclaredConstructors()[0];ctor.setAccessible(true);
  CapabilityEnergy.ENERGY=(Capability<IEnergyStorage>)ctor.newInstance("test:energy",null,(java.util.concurrent.Callable<IEnergyStorage>)()->null);
  CapabilityItemHandler.ITEM_HANDLER_CAPABILITY=(Capability<IItemHandler>)ctor.newInstance("test:item",null,(java.util.concurrent.Callable<IItemHandler>)()->null);
  tests();System.out.println("PASS PlantHarvesterSafetyTest");
 }
}
