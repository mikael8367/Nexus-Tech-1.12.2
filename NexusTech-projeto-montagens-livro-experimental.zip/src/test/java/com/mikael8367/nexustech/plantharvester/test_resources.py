import json
from pathlib import Path
from PIL import Image
root=Path("src/main/resources/assets/nexustech")
for f in ["blockstates/plant_harvester.json","models/block/plant_harvester.json","models/item/plant_harvester.json","models/item/plant_harvester_upgrade.json","recipes/plant_harvester.json","recipes/plant_harvester_upgrade.json"]:
    data=json.loads((root/f).read_text()); assert data
for f in ["textures/blocks/plant_harvester.png","textures/items/plant_harvester_upgrade.png"]:
    im=Image.open(root/f); im.verify()
for n in range(51):
    period=20-n*15//50
    assert 5 <= period <= 20
assert 20-0*15//50 == 20 and 20-50*15//50 == 5
for lang in ["pt_br", "en_us"]:
    s=Path("docs/plantharvester-localization/"+lang+".lang").read_text()
    assert "plant_harvester.name=" in s and "plantharvester.upgrades=" in s
for name in ["plant_harvester", "plant_harvester_upgrade"]:
    recipe=json.loads((root/"recipes"/(name+".json")).read_text())
    assert recipe["result"]["item"] == "nexustech:"+name
    assert recipe["pattern"] and set("".join(recipe["pattern"]))-{" "} == set(recipe["key"])
block=json.loads((root/"models/block/plant_harvester.json").read_text())
assert block["textures"]["all"] == "nexustech:blocks/plant_harvester"
for lang in ["pt_br", "en_us"]:
    text=(root/"lang"/(lang+".lang")).read_text(encoding="utf-8")
    for key in ["tile.nexustech.plant_harvester.name=", "item.nexustech.plant_harvester_upgrade.name=", "plantharvester.upgrades="]:
        assert sum(line.startswith(key) for line in text.splitlines()) == 1, (lang,key)
print("resource, recipe, model, formula and translation checks passed")
