package com.mikael8367.nexustech.powerexpansion;

import net.minecraft.block.BlockLiquid;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.energy.IEnergyStorage;

/** Isolated server fixtures only, not an in-game test. */
public final class RenewableGeneratorTest {
    static final BlockPos P = new BlockPos(15, 90, 15);
    static void eq(int a,int b,String m) { if(a!=b) throw new AssertionError(m+": "+a+" != "+b); }
    static RenewableTile.Wind wind(SolarArrayTest.W w) { RenewableTile.Wind t=new RenewableTile.Wind(); w.put(P,t); w.states.put(P,RenewableRegistry.WIND.getDefaultState()); return t; }
    static RenewableTile.Hydro hydro(SolarArrayTest.W w) { RenewableTile.Hydro t=new RenewableTile.Hydro(); w.put(P,t); w.states.put(P,RenewableRegistry.HYDRO.getDefaultState()); return t; }
    static IEnergyStorage cap(TileEntity t) { return SolarArrayTest.cap(t,null); }
    static class Sink extends TileEntity implements IEnergyStorage {
        RenewableTile source; int stored; boolean fail;
        @Override public <T> T getCapability(net.minecraftforge.common.capabilities.Capability<T> c, EnumFacing f) {
            return c == net.minecraftforge.energy.CapabilityEnergy.ENERGY ? net.minecraftforge.energy.CapabilityEnergy.ENERGY.cast(this) : null;
        }
        public int receiveEnergy(int n, boolean simulate) {
            source.update(); eq(cap(source).extractEnergy(1,false),0,"reentrant pull blocked");
            int accepted=Math.min(n,10); if (!simulate) stored+=accepted;
            if (fail) throw new IllegalStateException("after mutation"); return accepted;
        }
        public int extractEnergy(int n,boolean s){return 0;} public int getEnergyStored(){return stored;}
        public int getMaxEnergyStored(){return 10000;} public boolean canReceive(){return true;} public boolean canExtract(){return false;}
    }
    static void boundaries() throws Exception {
        SolarArrayTest.W water=SolarArrayTest.world(true); RenewableTile.Hydro h=hydro(water);
        water.states.put(P.east(),Blocks.WATER.getDefaultState());
        water.states.put(P.west(),Blocks.FLOWING_WATER.getDefaultState());
        h.update(); eq(h.buffer.stored(),0,"two source blocks are not flowing water");
        water.states.put(P.east(),Blocks.FLOWING_WATER.getDefaultState().withProperty(BlockLiquid.LEVEL,8));
        water.states.put(P.west(),Blocks.FLOWING_WATER.getDefaultState().withProperty(BlockLiquid.LEVEL,15));
        water.tick++; h.update(); eq(h.buffer.stored(),32,"falling levels 8 and 15 count as flows");
        water.states.put(P.west(),Blocks.FLOWING_LAVA.getDefaultState().withProperty(BlockLiquid.LEVEL,1));
        water.tick++; h.update(); eq(h.buffer.stored(),32,"lava does not count");
        SolarArrayTest.W noSky=SolarArrayTest.world(false); RenewableTile.Wind n=wind(noSky);
        n.update(); eq(n.buffer.stored(),0,"no sky dimension");
        SolarArrayTest.W stale=SolarArrayTest.world(true); RenewableTile.Wind old=wind(stale); old.buffer.load(1000);
        IEnergyStorage retained=cap(old); stale.states.put(P,Blocks.STONE.getDefaultState());
        eq(retained.extractEnergy(100,false),0,"old capability cannot extract after block replacement");
        old.update(); eq(old.buffer.stored(),1000,"replaced block cannot generate or push");
        stale.unloaded.add(P); eq(retained.extractEnergy(100,false),0,"unloaded tile cannot extract");
        eq(stale.forbidden,0,"no stale or unloaded access");
        SolarArrayTest.W network=SolarArrayTest.world(true); RenewableTile.Wind gen=wind(network);
        com.mikael8367.nexustech.MachineTile.Cable cable=new com.mikael8367.nexustech.MachineTile.Cable();
        PowerTile.AdvancedBattery battery=new PowerTile.AdvancedBattery();
        network.put(P.east(),cable); network.put(P.east().east(),battery); gen.update();
        eq(battery.buffer.stored(),24,"real Nexus cable transfers renewable FE");
        SolarArrayTest.W limits=SolarArrayTest.world(true); RenewableTile.Hydro limited=hydro(limits); limited.buffer.load(1000);
        eq(SolarArrayTest.cap(limited,EnumFacing.NORTH).extractEnergy(100,true),100,"simulation output");
        eq(limited.buffer.stored(),1000,"simulation does not debit");
        eq(SolarArrayTest.cap(limited,EnumFacing.NORTH).extractEnergy(100,false),100,"output first face");
        eq(SolarArrayTest.cap(limited,EnumFacing.SOUTH).extractEnergy(100,false),28,"faces share budget");
        limits.tick++; eq(cap(limited).extractEnergy(100,false),100,"next tick budget resets");
    }
    public static void main(String[] args) throws Exception {
        PowerExpansionTest.setup(); TileEntity.register("test:wind",RenewableTile.Wind.class); TileEntity.register("test:hydro",RenewableTile.Hydro.class);
        SolarArrayTest.W w=SolarArrayTest.world(true); RenewableTile.Wind a=wind(w);
        a.update(); a.update(); eq(a.buffer.stored(),24,"wind once per tick");
        NBTTagCompound saved=a.writeToNBT(new NBTTagCompound()); RenewableTile.Wind restored=new RenewableTile.Wind(); restored.readFromNBT(saved); w.put(P,restored); restored.update(); eq(restored.buffer.stored(),24,"reload same tick");
        w.blocked.add(P.up()); w.tick++; restored.update(); eq(restored.buffer.stored(),24,"blocked sky");
        w.blocked.clear(); w.unloaded.add(P.up()); w.tick++; restored.update(); eq(w.forbidden,0,"never read unloaded sky");
        SolarArrayTest.W low=SolarArrayTest.world(true); BlockPos p=new BlockPos(1,79,1); RenewableTile.Wind below=new RenewableTile.Wind(); low.put(p,below); low.states.put(p,RenewableRegistry.WIND.getDefaultState()); below.update(); eq(below.buffer.stored(),0,"altitude");
        SolarArrayTest.W h=SolarArrayTest.world(true); RenewableTile.Hydro b=hydro(h);
        h.states.put(P.east(),Blocks.FLOWING_WATER.getDefaultState().withProperty(BlockLiquid.LEVEL,1)); b.update(); eq(b.buffer.stored(),0,"one flow insufficient");
        h.states.put(P.west(),Blocks.FLOWING_WATER.getDefaultState().withProperty(BlockLiquid.LEVEL,2)); h.tick++; b.update(); eq(b.buffer.stored(),32,"two flows");
        h.unloaded.add(P.north()); h.tick++; b.update(); eq(b.buffer.stored(),32,"unloaded neighbor blocks generation"); eq(h.forbidden,0,"no unloaded reads");
        b.buffer.load(1000); eq(cap(b).receiveEnergy(100,false),0,"input rejected"); eq(cap(b).extractEnergy(100,false),100,"first output");
        saved=b.writeToNBT(new NBTTagCompound()); RenewableTile.Hydro c=new RenewableTile.Hydro(); c.readFromNBT(saved); h.put(P,c); eq(cap(c).extractEnergy(100,false),28,"persisted shared budget"); eq(cap(c).extractEnergy(1,false),0,"budget exhausted");
        NBTTagCompound injected=new NBTTagCompound(); injected.setInteger(PowerTile.ENERGY_KEY,10000); c.readFromNBT(injected); h.put(P,c);
        RenewableRegistry.HYDRO.onBlockPlacedBy(h,P,RenewableRegistry.HYDRO.getDefaultState(),null,ItemStack.EMPTY); eq(c.buffer.stored(),0,"forged item state discarded"); c.update(); eq(c.buffer.stored(),0,"same tick placement guard");
        SolarArrayTest.W transfer=SolarArrayTest.world(true); RenewableTile.Wind g=wind(transfer); Sink sink=new Sink(); sink.source=g; transfer.put(P.east(),sink); g.update(); eq(sink.stored,10,"partial receiver"); eq(g.buffer.stored(),14,"unaccepted energy refunded"); sink.fail=true; transfer.tick++; g.update(); eq(sink.stored,20,"receiver mutated before throwing"); eq(g.buffer.stored(),0,"uncertain transfer fully debited");
        SolarArrayTest.W remote=SolarArrayTest.world(true); SolarArrayTest.unsafe().putBoolean(remote,SolarArrayTest.unsafe().objectFieldOffset(net.minecraft.world.World.class.getField("isRemote")),true); RenewableTile.Wind client=wind(remote); client.update(); eq(client.buffer.stored(),0,"client cannot generate");
        boundaries();
        System.out.println("RenewableGeneratorTest OK");
    }
}
