package com.mikael8367.nexustech.powerexpansion;

import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import sun.misc.Unsafe;

/** Isolated callback and collision regressions; not an in-game integration test. */
public final class SolarArrayBlockSafetyTest {
    private static final BlockPos P = new BlockPos(0, 64, 0);
    private static void ok(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static final class W extends World {
        IBlockState state; TileEntity tile; boolean loaded; int removals;
        private W() { super(null, null, null, null, false); }
        protected IChunkProvider createChunkProvider() { return null; }
        protected boolean isChunkLoaded(int x, int z, boolean allowEmpty) { return true; }
        public boolean isBlockLoaded(BlockPos p) { return loaded; }
        public IBlockState getBlockState(BlockPos p) { if (!loaded) throw new AssertionError("unloaded block read"); return state; }
        public TileEntity getTileEntity(BlockPos p) { if (!loaded) throw new AssertionError("unloaded tile read"); return tile; }
        public boolean setBlockToAir(BlockPos p) { removals++; state = Blocks.AIR.getDefaultState(); tile = null; return true; }
        public void markChunkDirty(BlockPos p, TileEntity t) { }
    }
    private static W world() throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true);
        W w = (W) ((Unsafe) f.get(null)).allocateInstance(W.class);
        w.loaded = true; w.state = SolarArrayRegistry.ARRAY.getDefaultState();
        w.tile = new SolarArrayTile(); w.tile.setWorld(w); w.tile.setPos(P);
        return w;
    }
    private static void callbacks() throws Exception {
        SolarArrayBlock block = SolarArrayRegistry.ARRAY;
        W w = world(); TileEntity stale = w.tile;
        w.state = Blocks.AIR.getDefaultState(); w.tile = null;
        block.harvestBlock(w, null, P, block.getDefaultState(), stale, ItemStack.EMPTY);
        ok(w.removals == 0, "stale callback must not harvest or remove");
        w = world(); stale = new SolarArrayTile();
        block.harvestBlock(w, null, P, block.getDefaultState(), stale, ItemStack.EMPTY);
        ok(w.removals == 0 && w.tile != stale, "replacement tile must survive");
        w = world(); w.loaded = false;
        block.harvestBlock(w, null, P, block.getDefaultState(), w.tile, ItemStack.EMPTY);
        ok(w.removals == 0, "callback must not read unloaded chunk");
        w = world(); SolarArrayTile original = (SolarArrayTile) w.tile;
        try { block.harvestBlock(w, null, P, block.getDefaultState(), original, ItemStack.EMPTY); throw new AssertionError("expected failure"); }
        catch (NullPointerException expected) { }
        ok(w.removals == 1 && w.state.getBlock() == Blocks.AIR, "failed harvest must retire original block");
        ok(!original.harvesting, "exception must release harvest guard");
        block.harvestBlock(w, null, P, block.getDefaultState(), original, ItemStack.EMPTY);
        ok(w.removals == 1, "repeated callback cannot remove or drop again");
    }
    private static void boxes() throws Exception {
        W w = world();
        for (SolarArrayBlock b : new SolarArrayBlock[]{SolarArrayRegistry.ARRAY, SolarArrayRegistry.POLE, SolarArrayRegistry.MODULE}) {
            AxisAlignedBB box = b.getBoundingBox(b.getDefaultState(), w, P);
            AxisAlignedBB collision = b.getCollisionBoundingBox(b.getDefaultState(), w, P);
            ok(box.equals(collision), "collision must match model bounds: " + b.getRegistryName());
            ok(box.minX >= 0 && box.minY >= 0 && box.minZ >= 0 && box.maxX <= 1 && box.maxY <= 1 && box.maxZ <= 1, "box must stay inside cell");
        }
        ok(SolarArrayRegistry.POLE.getBoundingBox(SolarArrayRegistry.POLE.getDefaultState(), w, P).maxX == 0.625, "pole width");
        ok(SolarArrayRegistry.MODULE.getBoundingBox(SolarArrayRegistry.MODULE.getDefaultState(), w, P).maxY == 0.125, "module height");
    }
    public static void main(String[] args) throws Exception {
        PowerExpansionTest.setup(); callbacks(); boxes();
        System.out.println("SolarArrayBlockSafetyTest OK");
    }
}
