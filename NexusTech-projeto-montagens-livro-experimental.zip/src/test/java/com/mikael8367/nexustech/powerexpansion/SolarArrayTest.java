package com.mikael8367.nexustech.powerexpansion;

import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldProviderSurface;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.energy.CapabilityEnergy;
import net.minecraftforge.energy.IEnergyStorage;
import com.mikael8367.nexustech.MachineTile;
import sun.misc.Unsafe;

/** Isolated server-world regression; does not claim to be an in-game test. */
public final class SolarArrayTest {
    static final BlockPos P = new BlockPos(15, 64, 15);
    static void ok(boolean b, String m) { if (!b) throw new AssertionError(m); }
    static void eq(int a, int b, String m) { if (a != b) throw new AssertionError(m+": "+a+" != "+b); }
    static class W extends World {
        Map<BlockPos,IBlockState> states; Map<BlockPos,TileEntity> tiles;
        Set<BlockPos> unloaded, blocked; long tick; boolean day, rain, thunder; int forbidden, height, dirty;
        net.minecraft.world.GameRules rules; BlockPos trigger; Runnable hook;
        private W() { super(null,null,null,null,false); }
        protected IChunkProvider createChunkProvider() { return null; }
        protected boolean isChunkLoaded(int x, int z, boolean allowEmpty) { return true; }
        public boolean isBlockLoaded(BlockPos p) { return !unloaded.contains(p); }
        public IBlockState getBlockState(BlockPos p) { if(!isBlockLoaded(p)) { forbidden++; throw new AssertionError("unloaded block"); } if (p.equals(trigger) && hook != null) { Runnable h=hook; hook=null; h.run(); } return states.getOrDefault(p, Blocks.AIR.getDefaultState()); }
        public TileEntity getTileEntity(BlockPos p) { if(!isBlockLoaded(p)) { forbidden++; throw new AssertionError("unloaded tile"); } return tiles.get(p); }
        public boolean canSeeSky(BlockPos p) { if(!isBlockLoaded(p)) { forbidden++; throw new AssertionError("unloaded sky"); } return !blocked.contains(p); }
        public void markChunkDirty(BlockPos p, TileEntity t) { dirty++; }
        public net.minecraft.world.GameRules getGameRules() { return rules; }
        public boolean setBlockToAir(BlockPos p) { states.remove(p); tiles.remove(p); return true; }
        public long getTotalWorldTime() { return tick; }
        public boolean isDaytime() { return day; }
        public boolean isRaining() { return rain; }
        public boolean isThundering() { return thunder; }
        public int getActualHeight() { return height; }
        void put(BlockPos p, TileEntity t) { tiles.put(p,t); t.setWorld(this); t.setPos(p); }
        void state(BlockPos p, SolarArrayBlock b) { states.put(p,b.getDefaultState()); }
        void form(BlockPos p) { state(p,SolarArrayRegistry.ARRAY); state(p.up(),SolarArrayRegistry.POLE); state(p.up(2),SolarArrayRegistry.POLE); for(int x=-1;x<=1;x++) for(int z=-1;z<=1;z++) state(p.add(x,3,z),SolarArrayRegistry.MODULE); }
    }
    static Unsafe unsafe() throws Exception { Field f=Unsafe.class.getDeclaredField("theUnsafe"); f.setAccessible(true); return (Unsafe) f.get(null); }
    static W world(boolean skylight) throws Exception {
        Unsafe u=unsafe(); W w=(W)u.allocateInstance(W.class);
        w.states=new HashMap<>(); w.tiles=new HashMap<>(); w.unloaded=new HashSet<>(); w.blocked=new HashSet<>(); w.day=true; w.height=256;
        w.rules=new net.minecraft.world.GameRules();
        u.putObject(w,u.objectFieldOffset(World.class.getField("rand")),new Random(1));
        u.putObject(w,u.objectFieldOffset(World.class.getField("provider")),new WorldProviderSurface() { public boolean hasSkyLight() { return skylight; } });
        return w;
    }
    static SolarArrayTile make(W w, BlockPos p) { SolarArrayTile t=new SolarArrayTile(); w.put(p,t); w.form(p); return t; }
    static IEnergyStorage cap(TileEntity t, EnumFacing side) { return t.getCapability(CapabilityEnergy.ENERGY,side); }
    static class Sink extends TileEntity implements IEnergyStorage {
        SolarArrayTile source; int stored, limit=100000, calls; boolean reenter, fail;
        public <T> T getCapability(Capability<T> c, EnumFacing f) { return c==CapabilityEnergy.ENERGY ? CapabilityEnergy.ENERGY.cast(this) : null; }
        public int receiveEnergy(int n, boolean sim) { calls++; if(reenter) { source.update(); eq(cap(source,null).extractEnergy(100,false),0,"reentrant extraction"); } int x=Math.min(n,limit); if(!sim) stored+=x; if(fail) throw new IllegalStateException(); return x; }
        public int extractEnergy(int n,boolean sim) {return 0;} public int getEnergyStored(){return stored;} public int getMaxEnergyStored(){return 100000;}
        public boolean canReceive(){return true;} public boolean canExtract(){return false;}
    }
    static void checks() throws Exception {
        W w=world(true); SolarArrayTile t=make(w,P);
        ok(t.status()==SolarArrayTile.Status.ACTIVE,"complete roof");
        t.update(); eq(t.buffer.stored(),576,"one generation"); t.update(); eq(t.buffer.stored(),576,"once per tick");
        W reload=world(true); SolarArrayTile original=make(reload,P); original.update();
        NBTTagCompound saved=original.writeToNBT(new NBTTagCompound()); SolarArrayTile restored=new SolarArrayTile();
        restored.readFromNBT(saved); reload.put(P,restored); restored.update();
        eq(restored.buffer.stored(),576,"reload same tick does not generate again");
        reload.tick++; restored.update(); eq(restored.buffer.stored(),1152,"reload generates next tick");
        ok(!cap(t,null).canReceive(),"reject FE input"); eq(cap(t,null).receiveEnergy(100,false),0,"cannot inject");
        w.day=false; w.tick++; t.update(); eq(t.buffer.stored(),576,"night"); eq(cap(t,EnumFacing.DOWN).extractEnergy(100,false),100,"stored power usable at night");
        w.day=true; w.rain=true; w.tick++; t.update(); eq(t.buffer.stored(),476,"rain");
        w.rain=false; w.thunder=true; w.tick++; t.update(); eq(t.buffer.stored(),476,"thunder");
        w.thunder=false; w.blocked.add(P.add(1,4,1)); w.tick++; t.update(); eq(t.buffer.stored(),476,"one roof cell blocked"); ok(t.status()==SolarArrayTile.Status.OBSTRUCTED,"obstruction status"); w.blocked.clear();
        w.states.remove(P.add(-1,3,1)); w.tick++; t.update(); eq(t.buffer.stored(),476,"missing cell"); ok(t.status()==SolarArrayTile.Status.INCOMPLETE,"incomplete status"); w.form(P);
        w.states.remove(P.up()); ok(t.status()==SolarArrayTile.Status.INCOMPLETE,"missing pole"); w.form(P);
        w.unloaded.add(P.add(2,0,0)); ok(t.status()==SolarArrayTile.Status.UNLOADED,"neighbor chunk unloaded"); w.tick++; t.update(); eq(w.forbidden,0,"no unloaded reads"); w.unloaded.clear();
        w.state(P.add(2,0,0),SolarArrayRegistry.ARRAY); ok(t.status()==SolarArrayTile.Status.OVERLAP,"overlap blocked"); w.states.remove(P.add(2,0,0));
        w.height=68; ok(t.status()==SolarArrayTile.Status.INCOMPLETE,"height boundary"); w.height=256;
        W no=world(false); SolarArrayTile n=make(no,P); n.update(); eq(n.buffer.stored(),0,"dimension without skylight");
        NBTTagCompound tag=t.writeToNBT(new NBTTagCompound()); SolarArrayTile loaded=new SolarArrayTile(); loaded.readFromNBT(tag); eq(loaded.buffer.stored(),476,"world NBT roundtrip"); tag.setInteger(PowerTile.ENERGY_KEY,Integer.MAX_VALUE); loaded.readFromNBT(tag); eq(loaded.buffer.stored(),SolarArrayTile.CAPACITY,"clamp excessive NBT");
        W remote=world(true); unsafe().putBoolean(remote,unsafe().objectFieldOffset(World.class.getField("isRemote")),true); SolarArrayTile client=make(remote,P); client.update(); eq(client.buffer.stored(),0,"client cannot generate"); eq(cap(client,null).extractEnergy(1,false),0,"client cannot extract");
        W transfer=world(true); SolarArrayTile a=make(transfer,P); Sink sink=new Sink(); sink.source=a; sink.reenter=true; sink.limit=100; transfer.put(P.east(),sink); a.update(); eq(sink.stored,100,"sink receives"); eq(a.buffer.stored(),476,"partial refund conserves");
        sink.reenter=false; sink.fail=true; sink.limit=10000; transfer.tick++; a.update(); eq(a.buffer.stored(),0,"uncertain transfer conservatively debited"); eq(sink.stored,1152,"throw after receiver mutation does not duplicate");
        W cableWorld=world(true); SolarArrayTile gen=make(cableWorld,P); MachineTile.Cable cable=new MachineTile.Cable(); PowerTile.AdvancedBattery battery=new PowerTile.AdvancedBattery(); cableWorld.put(P.east(),cable); cableWorld.put(P.east().east(),battery); gen.update(); eq(battery.buffer.stored(),576,"actual Nexus cable and battery");
        W limits=world(true); SolarArrayTile b=make(limits,P); b.buffer.load(10000); IEnergyStorage north=cap(b,EnumFacing.NORTH), south=cap(b,EnumFacing.SOUTH); eq(north.extractEnergy(4000,true),4000,"simulate"); eq(b.buffer.stored(),10000,"simulate no change"); eq(north.extractEnergy(4000,false),4000,"actual"); eq(south.extractEnergy(4000,false),608,"shared per tick output"); limits.tiles.remove(P); eq(north.extractEnergy(1,false),0,"stale capability");
    }
    static void reloadAndBoundaries() throws Exception {
        W w=world(true); SolarArrayTile a=make(w,P); a.buffer.load(12000);
        eq(cap(a,null).extractEnergy(4000,false),4000,"extract before reload");
        NBTTagCompound tag=a.writeToNBT(new NBTTagCompound());
        SolarArrayTile b=new SolarArrayTile(); b.readFromNBT(tag); w.put(P,b);
        eq(cap(b,EnumFacing.UP).extractEnergy(9999,true),608,"simulation sees persisted budget");
        eq(cap(b,EnumFacing.DOWN).extractEnergy(9999,false),608,"reload retains same-tick budget");
        eq(cap(b,null).extractEnergy(1,false),0,"all faces exhausted after reload");
        w.tick++; eq(cap(b,null).extractEnergy(9999,false),4608,"next tick replenishes budget");
        tag=b.writeToNBT(new NBTTagCompound()); tag.setInteger("SolarArrayOutputUsed",Integer.MAX_VALUE);
        SolarArrayTile clamped=new SolarArrayTile(); clamped.readFromNBT(tag); w.put(P,clamped);
        eq(cap(clamped,null).extractEnergy(1,false),0,"bad budget is clamped");
        W pushWorld=world(true); pushWorld.day=false; SolarArrayTile ps=make(pushWorld,P); ps.buffer.load(10000);
        Sink partial=new Sink(); partial.limit=1000; pushWorld.put(P.east(),partial); ps.update();
        eq(partial.stored,1000,"partial push accepted"); eq(ps.buffer.stored(),9000,"push refund preserves energy");
        NBTTagCompound afterPush=ps.writeToNBT(new NBTTagCompound());
        SolarArrayTile pr=new SolarArrayTile(); pr.readFromNBT(afterPush); pushWorld.put(P,pr);
        eq(cap(pr,null).extractEnergy(9999,false),3608,"push and pull share persisted budget");
        W full=world(true); SolarArrayTile f=make(full,P); f.buffer.load(SolarArrayTile.CAPACITY);
        f.update(); ok(full.dirty>0,"full buffer persists production guard");
        NBTTagCompound saved=f.writeToNBT(new NBTTagCompound());
        SolarArrayTile restored=new SolarArrayTile(); restored.readFromNBT(saved); full.put(P,restored);
        eq(cap(restored,null).extractEnergy(576,false),576,"space created after reload");
        restored.update(); eq(restored.buffer.stored(),SolarArrayTile.CAPACITY-576,"no second production after full reload");
        W dark=world(true); dark.day=false; SolarArrayTile d=make(dark,P); d.update();
        ok(dark.dirty>0,"inactive tile persists production guard");
        saved=d.writeToNBT(new NBTTagCompound()); restored=new SolarArrayTile(); restored.readFromNBT(saved); dark.put(P,restored); dark.day=true;
        restored.update(); eq(restored.buffer.stored(),0,"changing weather after reload does not produce twice");
        dark.tick++; restored.update(); eq(restored.buffer.stored(),576,"active next tick");
        W edge=world(true); SolarArrayTile e=make(edge,P);
        for(int x=-2;x<=2;x++) for(int z=-2;z<=2;z++) {
            if(x==0 && z==0) continue;
            BlockPos p=P.add(x,0,z); edge.unloaded.add(p);
            ok(e.status()==SolarArrayTile.Status.UNLOADED,"unloaded overlap neighbor"); edge.unloaded.clear();
        }
        edge.state(P.add(2,0,2),SolarArrayRegistry.ARRAY);
        ok(e.status()==SolarArrayTile.Status.OVERLAP,"diagonal footprint overlap");
        edge.states.remove(P.add(2,0,2)); edge.state(P.add(3,0,0),SolarArrayRegistry.ARRAY);
        ok(e.status()==SolarArrayTile.Status.ACTIVE,"adjacent non-overlapping roof");
        eq(edge.forbidden,0,"boundary inspection never reads unloaded position");
    }
    @SuppressWarnings("unchecked") static void drops() throws Exception {
        Field map=Item.class.getDeclaredField("BLOCK_TO_ITEM"); map.setAccessible(true); ((Map<Object,Object>)map.get(null)).put(SolarArrayRegistry.ARRAY,new ItemBlock(SolarArrayRegistry.ARRAY));
        W w=world(true); SolarArrayTile t=make(w,P); t.buffer.load(2000); NonNullList<ItemStack> preview=NonNullList.create();
        SolarArrayRegistry.ARRAY.getDrops(preview,w,P,SolarArrayRegistry.ARRAY.getDefaultState(),0); ok(preview.get(0).getTagCompound()==null,"preview cannot copy live energy"); eq(t.buffer.stored(),2000,"preview preserves buffer");
        t.harvesting=true; NonNullList<ItemStack> real=NonNullList.create(); SolarArrayRegistry.ARRAY.getDrops(real,w,P,SolarArrayRegistry.ARRAY.getDefaultState(),0);
        eq(real.get(0).getTagCompound().getInteger(PowerTile.ENERGY_KEY),2000,"harvest item energy"); eq(t.buffer.stored(),0,"claim debits tile");
        NonNullList<ItemStack> repeated=NonNullList.create(); SolarArrayRegistry.ARRAY.getDrops(repeated,w,P,SolarArrayRegistry.ARRAY.getDefaultState(),0); ok(repeated.get(0).getTagCompound()==null,"cannot claim twice");
        W replacement=world(true); SolarArrayTile placed=make(replacement,P); SolarArrayRegistry.ARRAY.onBlockPlacedBy(replacement,P,SolarArrayRegistry.ARRAY.getDefaultState(),null,real.get(0)); eq(placed.buffer.stored(),2000,"placed charged item");
    }
    static class Player extends net.minecraft.entity.player.EntityPlayer {
        Player() { super(null,null); }
        public boolean isSpectator() { return false; }
        public boolean isCreative() { return false; }
        public void addStat(net.minecraft.stats.StatBase stat) { }
        public void addExhaustion(float amount) { }
    }
    @SuppressWarnings("unchecked") static void harvestReplacementLimits() throws Exception {
        W w=world(true); SolarArrayTile original=make(w,P); original.buffer.load(12000);
        original.update(); eq(original.buffer.stored(),12576,"generation before harvest");
        eq(cap(original,null).extractEnergy(4000,false),4000,"extraction before harvest");
        Player player=(Player)unsafe().allocateInstance(Player.class); player.world=w;
        SolarArrayBlock block=SolarArrayRegistry.ARRAY;
        java.lang.reflect.Method capture=net.minecraft.block.Block.class.getDeclaredMethod("captureDrops",boolean.class);
        capture.setAccessible(true); capture.invoke(block,true);
        ok(block.removedByPlayer(block.getDefaultState(),w,P,player,true),"normal harvest removal accepted");
        ok(w.getTileEntity(P)==original,"tile retained until harvest");
        NonNullList<ItemStack> drops;
        try { block.harvestBlock(w,player,P,block.getDefaultState(),original,ItemStack.EMPTY); }
        finally { drops=(NonNullList<ItemStack>)capture.invoke(block,false); }
        eq(drops.size(),1,"actual harvest gives one item");
        ok(w.getTileEntity(P)==null,"actual harvest removes original");
        ItemStack item=drops.get(0); eq(original.buffer.stored(),0,"harvest debits energy");
        eq(item.getTagCompound().getInteger("SolarArrayOutputUsed"),4000,"item carries output use");
        ok(item.getTagCompound().hasKey("SolarArrayLastProductionTick",4),"item carries production tick");
        ok(item.getTagCompound().hasKey("SolarArrayOutputTick",4),"item carries output tick");
        SolarArrayTile placed=make(w,P);
        SolarArrayRegistry.ARRAY.onBlockPlacedBy(w,P,SolarArrayRegistry.ARRAY.getDefaultState(),null,item);
        placed.update(); eq(placed.buffer.stored(),8576,"no second same-tick generation");
        eq(cap(placed,null).extractEnergy(5000,true),608,"simulation respects carried budget");
        eq(cap(placed,null).extractEnergy(5000,false),608,"only remainder can be extracted");
        eq(cap(placed,null).extractEnergy(1,false),0,"same tick budget exhausted");
        SolarArrayRegistry.ARRAY.onBlockPlacedBy(w,P,block.getDefaultState(),null,item);
        eq(placed.buffer.stored(),7968,"replayed placement cannot recreate energy");
        eq(cap(placed,null).extractEnergy(1,false),0,"replayed placement cannot reset budget");
        w.tick++; placed.update(); eq(placed.buffer.stored(),8544,"generation resumes next tick");
        eq(cap(placed,null).extractEnergy(5000,false),4608,"output resets next tick");

        // Clocks from different worlds are not comparable; the destination tick is conservative.
        W destination=world(true); destination.tick=999; SolarArrayTile moved=make(destination,P);
        SolarArrayRegistry.ARRAY.onBlockPlacedBy(destination,P,SolarArrayRegistry.ARRAY.getDefaultState(),null,item);
        moved.update(); eq(moved.buffer.stored(),8576,"different clock cannot cause immediate generation");
        eq(cap(moved,null).extractEnergy(5000,false),608,"different clock preserves usage on placement tick");
        destination.tick++; moved.update(); eq(moved.buffer.stored(),8544,"different clock next tick generates");

        // Simulate vanilla applying BlockEntityTag first; the placement whitelist replaces it.
        W injected=world(true); SolarArrayTile target=make(injected,P);
        NBTTagCompound inner=new NBTTagCompound(); inner.setInteger(PowerTile.ENERGY_KEY,70000);
        inner.setLong("SolarArrayLastProductionTick",-5); inner.setLong("SolarArrayOutputTick",0); inner.setInteger("SolarArrayOutputUsed",0);
        target.readFromNBT(inner); injected.put(P,target);
        ItemStack forged=new ItemStack(SolarArrayRegistry.ARRAY); NBTTagCompound outer=new NBTTagCompound();
        outer.setTag("BlockEntityTag",inner); forged.setTagCompound(outer);
        SolarArrayRegistry.ARRAY.onBlockPlacedBy(injected,P,SolarArrayRegistry.ARRAY.getDefaultState(),null,forged);
        eq(target.buffer.stored(),0,"nested arbitrary energy discarded"); target.update();
        eq(target.buffer.stored(),0,"nested arbitrary generation guard discarded");
        injected.tick++; target.update(); eq(target.buffer.stored(),576,"safe next tick");
        NBTTagCompound malformed=item.getTagCompound().copy(); malformed.setInteger("SolarArrayOutputUsed",-1);
        ItemStack bad=new ItemStack(SolarArrayRegistry.ARRAY); bad.setTagCompound(malformed);
        SolarArrayTile failClosed=make(injected,P); SolarArrayRegistry.ARRAY.onBlockPlacedBy(injected,P,SolarArrayRegistry.ARRAY.getDefaultState(),null,bad);
        eq(cap(failClosed,null).extractEnergy(1,false),0,"negative usage fails closed");

        W empty=world(true); SolarArrayTile drained=make(empty,P); drained.update();
        eq(cap(drained,null).extractEnergy(576,false),576,"drain generated energy");
        drained.harvesting=true; NonNullList<ItemStack> emptyDrops=NonNullList.create();
        SolarArrayRegistry.ARRAY.getDrops(emptyDrops,empty,P,block.getDefaultState(),0);
        ItemStack emptyItem=emptyDrops.get(0);
        eq(emptyItem.getTagCompound().getInteger("SolarArrayOutputUsed"),576,"empty item carries budget");
        eq(emptyItem.getTagCompound().getKeySet().size(),4,"drop contains only whitelist");
        SolarArrayTile emptyPlaced=make(empty,P);
        block.onBlockPlacedBy(empty,P,block.getDefaultState(),null,emptyItem);
        emptyPlaced.update(); eq(emptyPlaced.buffer.stored(),0,"empty replacement cannot generate again");
        empty.tick++; emptyPlaced.update(); eq(emptyPlaced.buffer.stored(),576,"empty replacement generates next tick");
    }
    public static void main(String[] args) throws Exception { PowerExpansionTest.setup(); TileEntity.register("test:array",SolarArrayTile.class); checks(); reloadAndBoundaries(); drops(); harvestReplacementLimits(); System.out.println("SolarArrayTest OK"); }
}
