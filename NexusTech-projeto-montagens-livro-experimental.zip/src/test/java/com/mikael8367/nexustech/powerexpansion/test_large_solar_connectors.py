"""Static checks for the large solar panel's visual cable sockets.

Run directly with Python; no Minecraft, Forge, or Gradle required. These checks
cannot establish how the game renderer or third-party cable models behave.
"""
import base64
import json
from pathlib import Path
import struct
import unittest

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'build.gradle').is_file())
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures'
MODELS = ASSETS / 'models/block'
DIRECTIONS = {
    # axis, solar block edge, post edge, cable direction towards the panel
    'north': (2, 0, 5, 'south'),
    'south': (2, 16, 11, 'north'),
    'west': (0, 0, 5, 'east'),
    'east': (0, 16, 11, 'west'),
}
ALL_FACES = {'up', 'down', 'north', 'south', 'east', 'west'}


def load_model(name):
    return json.loads((MODELS / (name + '.json')).read_text(encoding='utf-8'))


def box(lo, hi, axis, boundary, post):
    return all(lo[i] == (min(boundary, post) if i == axis else 6)
               and hi[i] == (max(boundary, post) if i == axis else 10)
               for i in range(3))


class LargeSolarConnectorTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = load_model('powerexpansion_solar_large')
        cls.elements = cls.model['elements']

    def test_original_panel_geometry_retained(self):
        expected = [([5, 0, 5], [11, 11, 11], '#metal'),
                    ([0, 11, 0], [16, 14, 16], '#rim'),
                    ([1, 14, 1], [15, 14.5, 15], '#panel')]
        self.assertEqual(len(self.elements), 11)
        for element, (lo, hi, material) in zip(self.elements[:3], expected):
            self.assertEqual((element['from'], element['to']), (lo, hi))
            self.assertEqual(set(element['faces']), ALL_FACES)
            self.assertTrue(all(face == {'texture': material}
                                for face in element['faces'].values()))

    def test_connections_meet_post_and_real_cable_models(self):
        for side, (axis, boundary, post, cable_direction) in DIRECTIONS.items():
            with self.subTest(side=side):
                arms = [e for e in self.elements[3:]
                        if box(e['from'], e['to'], axis, boundary, post)]
                self.assertEqual(len(arms), 1)
                arm = arms[0]
                self.assertEqual(set(arm['faces']),
                                 {'up', 'down', 'north', 'south'} if axis == 0
                                 else {'up', 'down', 'east', 'west'})
                self.assertTrue(all(face == {'texture': '#metal'}
                                    for face in arm['faces'].values()))
                cable = load_model('energy_cable_' + cable_direction)
                # The cable in the neighbouring block ends at the shared plane.
                cable_boundary = 16 if boundary == 0 else 0
                matching = [e for e in cable['elements']
                            if e['to' if cable_boundary == 16 else 'from'][axis] == cable_boundary
                            and all(e['from'][i] == arm['from'][i]
                                    and e['to'][i] == arm['to'][i]
                                    for i in range(3) if i != axis)]
                self.assertTrue(matching, 'No cable arm reaches the socket with matching cross-section')

    def test_socket_caps_are_recessed_and_face_outward(self):
        # Avoid coincident faces with a cable end at the shared block boundary.
        for side, (axis, boundary, post, _) in DIRECTIONS.items():
            with self.subTest(side=side):
                inset = 0.0625 if boundary == 0 else 15.9375
                caps = [e for e in self.elements[3:]
                        if box(e['from'], e['to'], axis, inset, inset)
                        and set(e['faces']) == {side}]
                self.assertEqual(len(caps), 1)
                self.assertEqual(caps[0]['faces'][side], {'texture': '#metal'})

    def test_all_faces_and_source_textures_resolve(self):
        # Default UVs are derived from coordinates and remain in the 0..16 atlas.
        for element in self.elements:
            for lo, hi in zip(element['from'], element['to']):
                self.assertTrue(0 <= lo <= hi <= 16)
            self.assertTrue(set(element['faces']) <= ALL_FACES)
            for face in element['faces'].values():
                name = face['texture'].removeprefix('#')
                resource = self.model['textures'][name]
                namespace, path = resource.split(':', 1)
                self.assertEqual(namespace, 'nexustech')
                data = base64.b64decode((TEXTURES / (path + '.png.b64')).read_bytes())
                self.assertEqual(data[:8], b'\x89PNG\r\n\x1a\n')
                self.assertEqual(struct.unpack('>II', data[16:24]), (16, 16))
                if 'uv' in face:
                    self.assertTrue(all(0 <= v <= 16 for v in face['uv']))


if __name__ == '__main__':
    unittest.main()
