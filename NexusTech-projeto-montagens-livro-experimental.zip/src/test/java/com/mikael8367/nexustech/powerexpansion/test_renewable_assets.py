"""Standalone resource-contract checks; no Minecraft renderer or Gradle build."""
import base64
import json
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[7]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures/blocks'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))

def check_png(path):
    data = base64.b64decode(path.read_text().strip(), validate=True)
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    pos, kinds, compressed = 8, [], bytearray()
    while pos < len(data):
        assert pos + 12 <= len(data)
        length, = struct.unpack_from('>I', data, pos)
        kind = data[pos+4:pos+8]
        end = pos + 12 + length
        assert end <= len(data)
        content = data[pos+8:pos+8+length]
        crc, = struct.unpack_from('>I', data, pos+8+length)
        assert zlib.crc32(kind + content) & 0xffffffff == crc
        kinds.append(kind)
        if kind == b'IHDR':
            assert len(kinds) == 1 and length == 13
            width, height, depth, color, comp, filt, interlace = struct.unpack('>IIBBBBB', content)
            assert (width, height, depth, color, comp, filt, interlace) == (16, 16, 8, 6, 0, 0, 0)
        if kind == b'IDAT': compressed.extend(content)
        pos = end
        if kind == b'IEND': break
    assert pos == len(data) and kinds[-1] == b'IEND'
    raw = zlib.decompress(bytes(compressed))
    assert len(raw) == 16 * (1 + 16 * 4)
    assert all(raw[y * 65] <= 4 for y in range(16))

registry = (ROOT / 'src/main/java/com/mikael8367/nexustech/powerexpansion/RenewableRegistry.java').read_text()
coal = (ROOT / 'src/main/java/com/mikael8367/nexustech/ModRegistry.java').read_text()
assert 'new MachineBlock("coal_generator"' in coal
build = (ROOT / 'build.gradle').read_text()
assert "include '**/*.png.b64'" in build
assert 'dependsOn generateTextureResources' in build and 'from generatedTextures' in build
for name, ingredient in [('wind_generator', 'minecraft:feather'), ('hydro_generator', 'minecraft:water_bucket')]:
    assert 'new RenewableBlock("' + name + '"' in registry
    assert read_json(ASSETS / 'blockstates' / (name+'.json'))['variants']['normal']['model'] == 'nexustech:'+name
    model = read_json(ASSETS / 'models/block' / (name+'.json'))
    assert model['parent'] == 'block/cube_all' and model['textures']['all'] == 'nexustech:blocks/'+name
    assert read_json(ASSETS / 'models/item' / (name+'.json'))['parent'] == 'nexustech:block/'+name
    recipe = read_json(ASSETS / 'recipes' / (name+'.json'))
    assert recipe['type'] == 'minecraft:crafting_shaped' and recipe['pattern'] == ['IRI', 'IGI', ' C ']
    assert recipe['key']['G']['item'] == 'nexustech:coal_generator'
    assert recipe['key']['I']['item'] == 'minecraft:iron_ingot'
    assert recipe['key']['R']['item'] == 'minecraft:redstone'
    assert recipe['key']['C']['item'] == ingredient
    assert recipe['result']['item'] == 'nexustech:'+name
    check_png(TEXTURES / (name+'.png.b64'))
print('renewable resource contracts OK')
