package com.mikael8367.nexustech.techarmor;

public final class TechArmorPolicyTest {
    public static void main(String[] args) {
        for (boolean remote : new boolean[] {false, true}) {
            for (boolean helmet : new boolean[] {false, true}) {
                for (boolean active : new boolean[] {false, true}) {
                    boolean expected = !remote && helmet && !active;
                    if (TechArmorPolicy.shouldApplyNightVision(remote, helmet, active) != expected)
                        throw new AssertionError("Unexpected night vision decision");
                }
            }
        }
        System.out.println("PASS TechArmorPolicyTest (8 combinations)");
    }
}
