#!/usr/bin/env python3
"""Regenerate only the explicitly owned techitem_* assets and localization fragments."""
from pathlib import Path
import base64, io, json
from techitem_art import render

ROOT = Path(__file__).resolve().parents[7]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures/items'
JAVA = ROOT / 'src/main/java/com/mikael8367/nexustech/techitems'
LANG = ROOT / 'docs/techitems-localization'
metals = [
    ('copper','Copper','Cobre', (212,115,65)),
    ('tin','Tin','Estanho', (173,191,204)),
    ('aluminum','Aluminum','Alumínio', (185,207,218)),
    ('silver','Silver','Prata', (217,228,225)),
    ('lead','Lead','Chumbo', (112,125,154)),
]
# Each is a component, not a functional device; ingredient layouts reflect its form.
types = [
 ('circuit_board','Circuit Board','Placa de Circuito',['MGM','RQR','MGM'], {'G':'glass','R':'redstone','Q':'quartz'}),
 ('coil','Coil','Bobina',[' M ','MRM',' M '], {'R':'redstone'}),
 ('gear','Gear','Engrenagem',[' M ','MIM',' M '], {'I':'iron_ingot'}),
 ('frame','Frame','Armação',['M M',' I ','M M'], {'I':'iron_ingot'}),
 ('conductor','Conductor','Condutor',['M M',' R ','M M'], {'R':'redstone'}),
 ('contact','Contact','Contato',['M M',' Q ','M M'], {'Q':'quartz'}),
 ('mesh','Mesh','Malha',['M M',' S ','M M'], {'S':'string'}),
 ('casing','Casing','Carcaça',['MMM','M M','MMM'], {}),
 ('panel','Panel','Painel',['MMM','MGM','M M'], {'G':'glass'}),
 ('rotor','Rotor','Rotor',[' M ','MGM',' M '], {'G':'gold_ingot'}),
]
JAVA.mkdir(parents=True,exist_ok=True); LANG.mkdir(parents=True,exist_ok=True)
(TEXTURES).mkdir(parents=True,exist_ok=True)
for d in ('models/item','recipes'): (ASSETS/d).mkdir(parents=True,exist_ok=True)
ids=[]; lines={'en_us':[], 'pt_br':[]}
for ti,(kind,en,pt,pattern,aux) in enumerate(types):
 for mi,(metal,men,mpt,color) in enumerate(metals):
  ident='techitem_'+metal+'_'+kind; ids.append(ident)
  lines['en_us'].append(f'item.{ident}.name={men} {en} Component')
  lines['pt_br'].append(f'item.{ident}.name=Componente de {pt} de {mpt}')
  model={'parent':'item/generated','textures':{'layer0':'nexustech:items/'+ident}}
  recipe={'type':'minecraft:crafting_shaped','pattern':pattern,'key':{'M':{'item':'nexustech:'+metal+'_ingot'},**{k:{'item':'minecraft:'+v} for k,v in aux.items()}},'result':{'item':'nexustech:'+ident,'count':1}}
  for folder,data in [('models/item',model),('recipes',recipe)]:
   (ASSETS/folder/(ident+'.json')).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
  # The shared renderer owns the 50 component textures.
  im=render(kind, metal)
  b=io.BytesIO(); im.save(b,format='PNG',optimize=True)
  (TEXTURES/(ident+'.png.b64')).write_text(base64.b64encode(b.getvalue()).decode()+'\n',encoding='ascii')
for locale,entries in lines.items(): (LANG/(locale+'.lang.fragment')).write_text('\n'.join(entries)+'\n',encoding='utf8')
quoted=',\n            '.join('"'+s+'"' for s in ids)
(JAVA/'TechItemsRegistry.java').write_text('''package com.mikael8367.nexustech.techitems;

import com.mikael8367.nexustech.NexusTech;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Crafting components only; none provide machine or energy behavior. */
@Mod.EventBusSubscriber(modid = NexusTech.MODID)
public final class TechItemsRegistry {
    private static final String[] IDS = {
            '''+quoted+'''
    };
    public static final List<Item> ITEMS;
    static {
        List<Item> items = new ArrayList<Item>();
        for (String id : IDS) {
            items.add(new Item().setRegistryName(NexusTech.MODID, id)
                .setUnlocalizedName(id).setCreativeTab(NexusTech.CREATIVE_TAB));
        }
        ITEMS = Collections.unmodifiableList(items);
    }
    private TechItemsRegistry() { }
    @SubscribeEvent public static void registerItems(RegistryEvent.Register<Item> event) {
        for (Item item : ITEMS) event.getRegistry().register(item);
    }
}
''',encoding='utf8')
(JAVA/'TechItemsClient.java').write_text('''package com.mikael8367.nexustech.techitems;

import com.mikael8367.nexustech.NexusTech;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(modid = NexusTech.MODID, value = Side.CLIENT)
public final class TechItemsClient {
    private TechItemsClient() { }
    @SubscribeEvent public static void registerModels(ModelRegistryEvent event) {
        for (Item item : TechItemsRegistry.ITEMS) {
            ModelLoader.setCustomModelResourceLocation(item, 0,
                    new ModelResourceLocation(item.getRegistryName(), "inventory"));
        }
    }
}
''',encoding='utf8')
print('Generated',len(ids),'components')
