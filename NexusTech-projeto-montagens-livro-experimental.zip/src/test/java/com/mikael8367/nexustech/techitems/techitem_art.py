#!/usr/bin/env python3
"""Original 16px component pixel art, used by generate_techitems.py.

Each form has its own hand-placed silhouette; the metal palettes are intentionally
muted, with opaque, hard-edged pixels suitable for the 1.12 item renderer.
"""
from PIL import Image, ImageDraw

# outline, shade, midtone, highlight, glint; warm/cool ramps distinguish metals.
PALETTES = {
    'copper':  ('#53392e','#89523a','#b47750','#d79e70','#ebc496'),
    'tin':     ('#41484a','#707f80','#a2b3ae','#c2d1c8','#e0e7dc'),
    'aluminum':('#3e4852','#687e91','#96b0bf','#b9cdd5','#dee8e6'),
    'silver':  ('#514c52','#89848e','#bab7bd','#dbd9d6','#f1eee4'),
    'lead':    ('#393943','#56566a','#777e96','#a0a7b7','#c8cbd0'),
}
FORMS = ('circuit_board','coil','gear','frame','conductor','contact','mesh','casing','panel','rotor')

def render(kind, metal):
    if kind not in FORMS or metal not in PALETTES:
        raise ValueError((kind, metal))
    im = Image.new('RGBA', (16,16), (0,0,0,0))
    d = ImageDraw.Draw(im)
    o,s,m,h,g = PALETTES[metal]
    # Distinct angled, irregular silhouettes rather than generic square icons.
    if kind == 'circuit_board':
        d.polygon([(3,2),(12,2),(13,3),(13,12),(12,13),(3,13),(2,12),(2,3)], fill=o)
        d.rectangle((3,3,12,12),fill='#40594b')
        d.line([(4,4),(10,4),(10,6),(12,6)],fill=m)
        d.line([(4,6),(6,6),(6,10),(4,10),(4,11)],fill=h)
        d.line([(9,9),(11,9),(11,11),(8,11)],fill=m)
        d.rectangle((7,6,9,8),fill=o); d.point((7,6),fill=g)
        for x in (4,7,10):
            d.point((x,2),fill=h); d.point((x,13),fill=s)
    elif kind == 'coil':
        d.polygon([(4,2),(11,2),(13,4),(13,11),(11,13),(4,13),(2,11),(2,4)],fill=o)
        d.rectangle((4,3,11,12),fill=s)
        d.rectangle((3,4,12,11),fill=m)
        for y in (4,6,8,10):
            d.line((3,y,12,y),fill=o); d.line((4,y,11,y),fill=h)
            d.point((4,y+1),fill=s)
        d.line((5,3,10,3),fill=g); d.line((4,12,11,12),fill=o)
    elif kind == 'gear':
        d.polygon([(6,1),(9,1),(10,3),(12,3),(12,5),(14,6),(14,9),(12,10),(12,12),(10,12),(9,14),(6,14),(5,12),(3,12),(3,10),(1,9),(1,6),(3,5),(3,3),(5,3)],fill=o)
        d.polygon([(6,2),(9,2),(9,4),(11,4),(11,6),(13,6),(13,9),(11,9),(11,11),(9,11),(9,13),(6,13),(6,11),(4,11),(4,9),(2,9),(2,6),(4,6),(4,4),(6,4)],fill=m)
        d.line([(3,6),(4,6),(4,4),(6,4),(6,2),(9,2)],fill=h)
        d.line([(3,9),(4,10),(5,11),(6,11),(6,13),(9,13),(9,11),(11,11),(11,9),(13,9)],fill=s)
        d.rectangle((5,5,10,10),fill=o); d.rectangle((6,6,9,9),fill='#00000000')
        d.line((6,5,9,5),fill=s); d.point((10,9),fill=h)
    elif kind == 'frame':
        d.polygon([(3,2),(12,2),(14,4),(14,12),(12,14),(3,14),(1,12),(1,4)],fill=o)
        d.polygon([(4,3),(12,3),(13,4),(13,12),(12,13),(3,13),(2,12),(2,4)],fill=m)
        d.rectangle((5,5,10,11),fill=o); d.rectangle((6,6,9,10),fill='#00000000')
        d.line([(3,11),(3,4),(11,4)],fill=h); d.line([(4,12),(12,12),(12,5)],fill=s)
        for xy in ((4,5),(11,5),(4,11),(11,11)): d.point(xy,fill=g)
    elif kind == 'conductor':
        d.line((3,12,12,3),fill=o,width=5)
        d.line((3,12,12,3),fill=m,width=3)
        d.line((3,11,11,3),fill=h,width=1)
        d.polygon([(1,10),(3,10),(5,12),(5,14),(3,14),(1,12)],fill=o)
        d.line((2,11,4,13),fill=g); d.point((2,12),fill=s)
        d.polygon([(10,1),(12,1),(14,3),(14,5),(12,5),(10,3)],fill=o)
        d.line((11,2,13,4),fill=g); d.point((12,2),fill=s)
    elif kind == 'contact':
        d.polygon([(2,6),(4,4),(11,4),(13,6),(14,6),(14,10),(12,10),(11,12),(4,12),(3,10),(1,10),(1,6)],fill=o)
        d.rectangle((3,6,12,10),fill=s); d.rectangle((5,5,10,11),fill=m)
        d.rectangle((6,6,9,10),fill=h); d.line((6,6,9,6),fill=g)
        d.line((2,7,4,7),fill=h); d.line((11,9,13,9),fill=m)
    elif kind == 'mesh':
        d.polygon([(3,2),(12,2),(13,3),(13,12),(12,13),(3,13),(2,12),(2,3)],fill=o)
        d.rectangle((3,3,12,12),fill=m)
        d.rectangle((4,4,11,11),fill='#00000000')
        for x in (5,8,11): d.line((x,4,x,11),fill=h)
        for y in (5,8,11): d.line((4,y,11,y),fill=m)
        for x in (5,8,11):
            for y in (5,8,11): d.point((x,y),fill=g)
        d.line((3,3,11,3),fill=h); d.line((3,12,12,12),fill=s)
    elif kind == 'casing':
        d.polygon([(3,4),(6,2),(12,3),(14,5),(14,11),(11,13),(3,12),(2,10),(2,5)],fill=o)
        d.polygon([(3,5),(6,3),(12,4),(13,5),(10,7),(3,6)],fill=h)
        d.polygon([(3,7),(10,8),(10,12),(3,11)],fill=m)
        d.polygon([(11,8),(13,6),(13,10),(11,12)],fill=s)
        d.line((4,8,9,9),fill=s); d.line((4,10,9,11),fill=h)
        d.point((5,4),fill=g); d.point((12,6),fill=g)
    elif kind == 'panel':
        d.polygon([(2,4),(12,3),(14,5),(14,11),(4,13),(2,11)],fill=o)
        d.polygon([(3,5),(12,4),(13,5),(13,10),(4,12),(3,11)],fill=m)
        d.polygon([(5,6),(11,5),(11,9),(5,10)],fill=s)
        d.line((5,6,11,5),fill=g); d.line((5,7,5,10),fill=h)
        d.line((6,9,10,8),fill=m)
        d.point((4,5),fill=g); d.point((12,10),fill=h)
    elif kind == 'rotor':
        d.polygon([(6,1),(9,1),(10,3),(9,6),(12,5),(14,6),(14,9),(12,10),(9,9),(10,12),(9,14),(6,14),(5,12),(6,9),(3,10),(1,9),(1,6),(3,5),(6,6),(5,3)],fill=o)
        d.polygon([(7,2),(9,2),(9,4),(8,6),(7,6)],fill=m)
        d.polygon([(10,7),(12,6),(13,7),(13,8),(11,9),(9,8)],fill=h)
        d.polygon([(7,9),(8,9),(9,12),(8,13),(6,13),(6,12)],fill=s)
        d.polygon([(2,7),(3,6),(6,7),(6,8),(3,9),(2,8)],fill=m)
        d.rectangle((6,6,9,9),fill=o); d.rectangle((7,7,8,8),fill=g)
    return im
