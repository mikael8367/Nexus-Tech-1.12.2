#!/usr/bin/env python3
"""Independent source/assets and crafting overlap checks; run without Gradle."""
import base64, io, itertools, json, re, unittest
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parents[7]
A=ROOT/'src/main/resources/assets/nexustech'
T=ROOT/'src/main/texture_sources/assets/nexustech/textures/items'
J=ROOT/'src/main/java/com/mikael8367/nexustech/techitems'
L=ROOT/'docs/techitems-localization'
METALS=('copper','tin','aluminum','silver','lead')
FORMS=('circuit_board','coil','gear','frame','conductor','contact','mesh','casing','panel','rotor')
IDS={'techitem_'+m+'_'+f for m in METALS for f in FORMS}

def load(p):
    return json.loads(p.read_text(encoding='utf8'))

def cells(recipe):
    """All legal 3x3 placements, including Forge's horizontal mirror."""
    pattern=recipe['pattern']; w=len(pattern[0]); h=len(pattern)
    assert 1<=w<=3 and 1<=h<=3 and all(len(row)==w for row in pattern)
    key=recipe['key']; used=set(''.join(pattern))-{' '}
    assert set(key)==used and all(len(k)==1 for k in key)
    assert any(c!=' ' for c in pattern[0]) and any(c!=' ' for c in pattern[-1])
    assert any(row[0]!=' ' for row in pattern) and any(row[-1]!=' ' for row in pattern)
    for mirror in (False,True):
        for dy in range(4-h):
            for dx in range(4-w):
                grid=[None]*9
                for y,row in enumerate(pattern):
                    for x,c in enumerate(row[::-1] if mirror else row):
                        if c!=' ': grid[(y+dy)*3+x+dx]=key[c]
                yield grid

def intersects(a,b):
    if a is None or b is None: return a is b
    if isinstance(a,list): return any(intersects(x,b) for x in a)
    if isinstance(b,list): return any(intersects(a,x) for x in b)
    # Forge ore dictionaries can be extended by other mods, so conservatively
    # assume any named ore entry can contain any item (or overlap another ore).
    if a.get('type')=='forge:ore_dict' or b.get('type')=='forge:ore_dict': return True
    if 'item' not in a or 'item' not in b: raise AssertionError('Unknown ingredient '+str((a,b)))
    if a['item']!=b['item']: return False
    # Vanilla ingredient without data accepts all metadata; 32767 is wildcard.
    da,db=a.get('data',32767),b.get('data',32767)
    return da==32767 or db==32767 or da==db

def recipes_overlap(a,b):
    assert a['type'] in ('minecraft:crafting_shaped','forge:ore_shaped')
    if b['type'] in ('minecraft:crafting_shaped','forge:ore_shaped'):
        return any(all(intersects(x,y) for x,y in zip(ga,gb)) for ga in cells(a) for gb in cells(b))
    if b['type'] in ('minecraft:crafting_shapeless','forge:ore_shapeless'):
        aa=[x for x in next(cells(a)) if x is not None]; bb=b['ingredients']
        if len(aa)!=len(bb): return False
        def match(i,remaining):
            return i==len(aa) or any(intersects(aa[i],b) and match(i+1,remaining[:j]+remaining[j+1:]) for j,b in enumerate(remaining))
        return match(0,bb)
    raise AssertionError('Cannot compare recipe type '+str(b.get('type')))

class TechItemsTest(unittest.TestCase):
    def test_registry_and_localization(self):
        code=(J/'TechItemsRegistry.java').read_text(encoding='utf8')
        registered=re.findall(r'"(techitem_[a-z0-9_]+)"',code)
        self.assertEqual(len(registered),50); self.assertEqual(set(registered),IDS)
        self.assertIn('@Mod.EventBusSubscriber',code); self.assertIn('event.getRegistry().register(item)',code)
        client=(J/'TechItemsClient.java').read_text(encoding='utf8')
        self.assertIn('value = Side.CLIENT',client); self.assertIn('setCustomModelResourceLocation',client)
        for lang in ('en_us','pt_br'):
            lines=(L/(lang+'.lang.fragment')).read_text(encoding='utf8').splitlines()
            entries=dict(x.split('=',1) for x in lines)
            self.assertEqual(len(lines),50); self.assertEqual(len(entries),50)
            self.assertEqual(set(entries),{'item.'+id+'.name' for id in IDS})
            self.assertTrue(all(v.strip() for v in entries.values()))
    def test_models_and_pngs(self):
        self.assertEqual({p.stem for p in (A/'models/item').glob('techitem_*.json')},IDS)
        self.assertEqual({p.name[:-8] for p in T.glob('techitem_*.png.b64')},IDS)
        visuals=set()
        for id in IDS:
            model=load(A/'models/item'/(id+'.json'))
            self.assertEqual(model['parent'],'item/generated')
            self.assertEqual(model['textures']['layer0'],'nexustech:items/'+id)
            raw=base64.b64decode((T/(id+'.png.b64')).read_text().strip(),validate=True)
            with Image.open(io.BytesIO(raw)) as image:
                self.assertEqual(image.format,'PNG'); self.assertEqual(image.size,(16,16))
                image.load(); image=image.convert('RGBA')
                self.assertIsNotNone(image.getchannel('A').getbbox())
                visuals.add(image.tobytes())
        self.assertEqual(len(visuals),50)
    def test_recipes_valid_and_non_circular(self):
        paths=list((A/'recipes').glob('techitem_*.json'))
        self.assertEqual({p.stem for p in paths},IDS)
        valid_vanilla={'glass','redstone','quartz','iron_ingot','string','gold_ingot'}
        allowed={'minecraft:'+x for x in valid_vanilla}|{'nexustech:'+x+'_ingot' for x in METALS}
        ore=(ROOT/'src/main/java/com/mikael8367/nexustech/ores/OreType.java').read_text()
        for metal in METALS: self.assertIn('("'+metal+'",',ore)
        for p in paths:
            r=load(p); self.assertEqual(r['type'],'minecraft:crafting_shaped')
            self.assertEqual(r['result'],{'item':'nexustech:'+p.stem,'count':1})
            self.assertTrue(list(cells(r)))
            ingredients={v['item'] for v in r['key'].values()}
            self.assertLessEqual(ingredients,allowed)
            self.assertTrue(any(x.startswith('nexustech:') for x in ingredients))
            self.assertFalse(any('techitem_' in x for x in ingredients))
    def test_recipe_collisions(self):
        paths=sorted((A/'recipes').glob('*.json'))
        ours=[(p,load(p)) for p in paths if p.stem in IDS]
        others=[(p,load(p)) for p in paths if p.stem not in IDS]
        self.assertEqual(len(ours),50)
        for i,(p,r) in enumerate(ours):
            for q,s in ours[i+1:]+others:
                self.assertFalse(recipes_overlap(r,s),f'Possible collision: {p.name} / {q.name}')

if __name__=='__main__': unittest.main(verbosity=2)
