#!/usr/bin/env python3
"""Texture integrity, model references and isolated generator regression tests."""
import base64
import io
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image
from techitem_art import PALETTES, FORMS, render

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[7]
T = ROOT/'src/main/texture_sources/assets/nexustech/textures/items'
A = ROOT/'src/main/resources/assets/nexustech'
IDS = {f'techitem_{m}_{f}' for m in PALETTES for f in FORMS}

def encoded(metal, form):
    b = io.BytesIO()
    render(form, metal).save(b, format='PNG', optimize=True)
    return base64.b64encode(b.getvalue()).decode()+'\n'

class VanillaTextureArtTest(unittest.TestCase):
    def test_all_png_alpha_and_pixel_data(self):
        self.assertEqual({p.name[:-8] for p in T.glob('techitem_*.png.b64')}, IDS)
        for metal in PALETTES:
            for form in FORMS:
                with self.subTest(metal=metal, form=form):
                    ident = f'techitem_{metal}_{form}'
                    path = T/(ident+'.png.b64')
                    self.assertEqual(path.read_text(), encoded(metal, form))
                    raw = base64.b64decode(path.read_text().strip(),validate=True)
                    self.assertTrue(raw.startswith(b'\x89PNG\r\n\x1a\n'))
                    with Image.open(io.BytesIO(raw)) as image:
                        self.assertEqual(image.format,'PNG')
                        self.assertEqual(image.size,(16,16))
                        self.assertEqual(image.mode,'RGBA')
                        image.load()
                        alpha=image.getchannel('A')
                        pixels=alpha.tobytes()
                        values=set(pixels)
                        self.assertEqual(values,{0,255})
                        self.assertEqual([alpha.getpixel(pt) for pt in ((0,0),(15,0),(0,15),(15,15))],[0]*4)
                        self.assertLessEqual(alpha.getbbox()[2],15)
                        self.assertGreaterEqual(alpha.getbbox()[0],1)
                        self.assertGreater(sum(v==255 for v in pixels),25)
                        if form in ('gear','frame'): self.assertEqual(alpha.getpixel((7,8)),0)
                        if form=='mesh': self.assertEqual(alpha.getpixel((6,6)),0)
    def test_distinct_shapes_and_metal_variants(self):
        masks={f: render(f,'copper').getchannel('A').tobytes() for f in FORMS}
        self.assertEqual(len(set(masks.values())),10)
        self.assertEqual(len({render(f,m).tobytes() for f in FORMS for m in PALETTES}),50)
    def test_models_point_to_source_and_no_shadow_resources(self):
        for ident in IDS:
            model=json.loads((A/'models/item'/(ident+'.json')).read_text())
            self.assertEqual(model['parent'],'item/generated')
            self.assertEqual(model['textures']['layer0'],f'nexustech:items/{ident}')
            self.assertTrue((T/(ident+'.png.b64')).is_file())
            self.assertFalse((A/'textures/items'/(ident+'.png')).exists(),ident)
    def test_build_wiring(self):
        gradle=(ROOT/'build.gradle').read_text()
        for expected in ("file('src/main/texture_sources')", "task generateTextureResources", "inputs.dir textureSources", "outputs.dir generatedTextures", "dependsOn generateTextureResources", "from generatedTextures"):
            self.assertIn(expected,gradle)
        # Match the Gradle task's path removal and decode, in an isolated staging dir.
        with tempfile.TemporaryDirectory() as tmp:
            for ident in IDS:
                relative=Path('assets/nexustech/textures/items')/(ident+'.png')
                out=Path(tmp)/relative
                out.parent.mkdir(parents=True,exist_ok=True)
                source=T/(ident+'.png.b64')
                out.write_bytes(base64.b64decode(source.read_text().strip(),validate=True))
                with Image.open(out) as image: image.verify()
                self.assertTrue(out.exists())
    def test_generator_in_isolated_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake=Path(tmp)
            folder=fake/'src/test/java/com/mikael8367/nexustech/techitems'
            folder.mkdir(parents=True)
            for name in ('generate_techitems.py','techitem_art.py'):
                shutil.copy2(HERE/name,folder/name)
            run=subprocess.run([sys.executable,str(folder/'generate_techitems.py')],capture_output=True,text=True,check=True)
            self.assertIn('Generated 50 components',run.stdout)
            gen=fake/'src/main/texture_sources/assets/nexustech/textures/items'
            for ident in IDS:
                self.assertEqual((gen/(ident+'.png.b64')).read_bytes(),(T/(ident+'.png.b64')).read_bytes(),ident)
                for sub in ('models/item','recipes'):
                    a=json.loads((A/sub/(ident+'.json')).read_text())
                    b=json.loads((fake/'src/main/resources/assets/nexustech'/sub/(ident+'.json')).read_text())
                    self.assertEqual(a,b,ident)
            # Running twice must not alter any output.
            before={p.relative_to(fake):p.read_bytes() for p in fake.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
            subprocess.run([sys.executable,str(folder/'generate_techitems.py')],capture_output=True,text=True,check=True)
            after={p.relative_to(fake):p.read_bytes() for p in fake.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
            self.assertEqual(before,after)

if __name__=='__main__': unittest.main(verbosity=2)
