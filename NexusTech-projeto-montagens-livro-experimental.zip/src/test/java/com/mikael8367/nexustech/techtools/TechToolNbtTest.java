package com.mikael8367.nexustech.techtools;

import java.util.UUID;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public final class TechToolNbtTest {
    static void check(boolean condition, String what) { if (!condition) throw new AssertionError(what); }
    public static void main(String[] args) {
        Bootstrap.register();
        TechTool tool = new TechTool(TechTool.Kind.PICKAXE);
        ItemStack a = new ItemStack(tool), b = new ItemStack(tool);
        check(TechTool.speed(a) == 0 && TechTool.area(a) == 0 && TechTool.id(a) == null, "defaults");
        NBTTagCompound tag = new NBTTagCompound(); a.setTagCompound(tag);
        UUID id = UUID.randomUUID(); tag.setUniqueId(TechTool.ID, id);
        for (int i = 0; i < 3; i++) {
            tag.setInteger(TechTool.SPEED, i); tag.setInteger(TechTool.AREA, i);
            check(TechTool.speed(a) == i && TechTool.area(a) == i, "valid settings");
            check(tool.getDestroySpeed(a, Blocks.STONE.getDefaultState()) == new float[]{4,6,8}[i], "bounded speed");
        }
        check(TechTool.speed(b) == 0 && TechTool.area(b) == 0, "individual settings");
        for (int invalid : new int[]{-1, 3, Integer.MIN_VALUE, Integer.MAX_VALUE}) {
            tag.setInteger(TechTool.SPEED, invalid); tag.setInteger(TechTool.AREA, invalid);
            check(TechTool.speed(a) == 0 && TechTool.area(a) == 0, "invalid NBT fails closed");
        }
        check(id.equals(TechTool.id(a)), "UUID NBT");
        check(tool.getDestroySpeed(a, Blocks.DIRT.getDefaultState()) == 1, "wrong material");
        check(!tool.canHarvestBlock(Blocks.DIRT.getDefaultState()), "wrong harvest tool");
        Bootstrap.printToSYSOUT("PASS NBT defaults, isolation, invalid bounds, ID and speed");
    }
}
