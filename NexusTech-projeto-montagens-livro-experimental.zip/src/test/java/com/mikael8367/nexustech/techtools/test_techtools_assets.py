import json
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[7]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
JAVA = ROOT / 'src/main/java/com/mikael8367/nexustech/techtools'

class ToolResourcesTest(unittest.TestCase):
    def test_geometry_is_volumetric(self):
        for name in ('pickaxe', 'axe', 'shovel'):
            model = json.loads((ASSETS / 'models/item' / ('techtool_' + name + '.json')).read_text())
            self.assertGreaterEqual(len(model['elements']), 3)
            for element in model['elements']:
                self.assertTrue(all(a < b for a, b in zip(element['from'], element['to'])))
                self.assertEqual(set(element['faces']), {'up', 'down', 'north', 'south', 'east', 'west'})
                for face in element['faces'].values(): self.assertIn(face['texture'][1:], model['textures'])
    def test_recipes_and_components_exist(self):
        component_source = (ROOT / 'src/main/java/com/mikael8367/nexustech/techitems/TechItemsRegistry.java').read_text()
        for name in ('pickaxe', 'axe', 'shovel'):
            recipe = json.loads((ASSETS / 'recipes' / ('techtool_' + name + '.json')).read_text())
            self.assertEqual(recipe['result']['item'], 'nexustech:techtool_' + name)
            for value in recipe['key'].values():
                if value['item'].startswith('nexustech:techitem_'): self.assertIn('"' + value['item'].split(':')[1] + '"', component_source)
            self.assertEqual(set(''.join(recipe['pattern'])) - {' '}, set(recipe['key']))
    def test_guards_present(self):
        tool = (JAVA / 'TechTool.java').read_text()
        queue = (JAVA / 'TechToolsQueue.java').read_text()
        network = (JAVA / 'TechToolsNetwork.java').read_text()
        for guard in ('tryHarvestBlock', 'canHarvestBlock', 'hasTileEntity', 'isBlockModifiable', 'rayTraceBlocks', 'getBlockReachDistance', 'EXPANDING.remove'):
            self.assertIn(guard, tool)
        for guard in ('isAirBlock', 'getHeldItemMainhand()', 'getBlockReachDistance', 'JOBS.remove'):
            self.assertIn(guard, queue)
        for guard in ('m.slot < 0', 'm.slot > 8', 'm.speed > 2', 'm.area > 2', 'currentItem != m.slot', 'getMostSignificantBits', 'addScheduledTask'):
            self.assertIn(guard, network)
    def test_translations_complete(self):
        folder = ROOT / 'docs/techtools-localization'
        langs = []
        for name in ('en_us', 'pt_br'):
            lines = (folder / (name + '.lang.fragment')).read_text().splitlines()
            langs.append({line.split('=', 1)[0] for line in lines if '=' in line})
        self.assertEqual(langs[0], langs[1]); self.assertEqual(len(langs[0]), 11)

if __name__ == '__main__': unittest.main()
