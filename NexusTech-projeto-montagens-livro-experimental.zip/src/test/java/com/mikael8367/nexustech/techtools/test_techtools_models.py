"""Static 1.12 resource checks for the three custom tool models."""
import base64
import json
import pathlib
import struct
import unittest
import zlib

ROOT = pathlib.Path(__file__).resolve().parents[7]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures'
JAVA = ROOT / 'src/main/java/com/mikael8367/nexustech/techtools'
NAMES = ('pickaxe', 'axe', 'shovel')
DISPLAY = {
    'thirdperson_righthand': {'rotation': [0, 90, -35], 'translation': [0, 2, 0], 'scale': [.75, .75, .75]},
    'firstperson_righthand': {'rotation': [0, 90, -25], 'translation': [1, 3, 1], 'scale': [.85, .85, .85]},
    'gui': {'rotation': [30, 45, 0], 'scale': [.8, .8, .8]},
    'ground': {'scale': [.5, .5, .5]},
    'fixed': {'rotation': [0, 180, 0], 'scale': [.7, .7, .7]},
}
FACES = {'up', 'down', 'north', 'south', 'east', 'west'}


def valid_png(path):
    raw = base64.b64decode(path.read_text().strip(), validate=True)
    assert raw[:8] == b'\x89PNG\r\n\x1a\n'
    pos, chunks, data = 8, [], b''
    while pos < len(raw):
        size = struct.unpack('>I', raw[pos:pos+4])[0]
        kind = raw[pos+4:pos+8]
        payload = raw[pos+8:pos+8+size]
        crc = struct.unpack('>I', raw[pos+8+size:pos+12+size])[0]
        assert zlib.crc32(kind + payload) == crc
        chunks.append(kind)
        if kind == b'IHDR':
            assert struct.unpack('>IIBBBBB', payload) == (16, 16, 8, 6, 0, 0, 0)
        if kind == b'IDAT': data += payload
        pos += 12 + size
        if kind == b'IEND': break
    assert pos == len(raw) and chunks[0] == b'IHDR' and chunks[-1] == b'IEND'
    assert len(zlib.decompress(data)) == 16 * (1 + 16 * 4)


class ToolModelTest(unittest.TestCase):
    def test_models_geometry_and_textures(self):
        seen = set()
        silhouettes = []
        for name in NAMES:
            with self.subTest(tool=name):
                model = json.loads((ASSETS / 'models/item' / ('techtool_' + name + '.json')).read_text())
                self.assertEqual(model['display'], DISPLAY)
                self.assertTrue(10 <= len(model['elements']) <= 24)
                self.assertNotIn('parent', model)
                for tex in model['textures'].values():
                    self.assertTrue(tex.startswith('nexustech:items/techtool_'))
                    path = TEXTURES / (tex.split(':', 1)[1] + '.png.b64')
                    valid_png(path)
                    seen.add(path.name)
                head = []
                for element in model['elements']:
                    a, b = element['from'], element['to']
                    self.assertEqual(len(a), 3); self.assertEqual(len(b), 3)
                    self.assertTrue(all(0 <= x < y <= 16 for x, y in zip(a, b)))
                    self.assertEqual(set(element['faces']), FACES)
                    for face in element['faces'].values():
                        self.assertTrue(face['texture'].startswith('#'))
                        self.assertIn(face['texture'][1:], model['textures'])
                        self.assertEqual(face['uv'], [0, 0, 16, 16])
                    if a[1] >= 9.5: head.append((tuple(a), tuple(b)))
                silhouettes.append(tuple(head))
        self.assertEqual(len(seen), 5)
        self.assertEqual(len(set(silhouettes)), 3)

    def test_client_registration_unchanged(self):
        client = (JAVA / 'TechToolsClient.java').read_text()
        registry = (JAVA / 'TechToolsRegistry.java').read_text()
        self.assertIn('ModelLoader.setCustomModelResourceLocation', client)
        self.assertIn('new ModelResourceLocation(item.getRegistryName(), "inventory")', client)
        for name in NAMES:
            self.assertIn('TechToolsRegistry.' + name.upper(), client)
            self.assertIn('"techtool_' + name + '"', registry)


if __name__ == '__main__':
    unittest.main()
