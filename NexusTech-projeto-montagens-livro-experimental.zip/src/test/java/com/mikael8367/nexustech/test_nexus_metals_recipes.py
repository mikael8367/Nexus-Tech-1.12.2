#!/usr/bin/env python3
"""Static recipe and texture checks; does not start Forge or load a modpack."""
import base64
import hashlib
import json
import unittest
from pathlib import Path

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'build.gradle').exists())
RECIPES = ROOT / 'src/main/resources/assets/nexustech/recipes'
TEXTURES = ROOT / 'src/main/texture_sources'
ORIGINAL_HASHES = {
    'solar_panel': 'ba3e159b12c8a923d91d0699f7ba0ca0131d13933cd45e3fa61760d53e7db51b',
    # Updated baseline: both generator recipes explicitly select regular coal (data 0).
    'coal_generator': 'b31941c08101e4eb4839ce40c989311de9fc7fa57043caf53c8c3705599f52a7',
    'electric_turbine': 'b4c29a5dd86eb737513c3229712880eb1fb597f00d806485d9adcedf8e230213',
    'battery': '832990be62b42961775344edf4349d9a661a3e7425c8044da7e654dfeb30b55f',
    'electric_furnace': '107317f232f209da21217a6685b291f57ea87035c2eb64ab5b8a814a0b87e415',
    'electric_crusher': '067a7dee53a28ea5b81450d51a54840159d04aad610e34924ca7a38245448dbf',
    'electric_compressor': 'f3918a6484bcfac6fdda6f6bbe1afea50d513e55f14b548d98864f8577fb1369',
    'lava_generator': 'ac306af8f416876cf5187779657d2407fb3db20457364e999785596aa413fc55',
    'digital_mine_casing': '49f6af52d5ebaf44527b59ae3e93e98b396bfaeacbe9d4e6a3f50fb25215d35f',
    'digital_mine_basic': '6a70aa2859444edaa6a9f5f2eaef5c378cf78a446999d4f147ef3ad0e70967a4',
    'nuclear_casing': '2af49c105bb6fb2c2a885a67d4d381bb8ad0b7245dfa24341118499e878907b0',
    'nuclear_core': '135557798ecae0c4a1c29fcbcbb2167ecae32835bb219cf2095903fa89a9df87',
    'nuclear_controller': '77325a9fe220433a0ad7347b02f17b9d5a192eb4f2d0388310205eaab8970e6e',
}
TEXTURE_HASHES = {
    'nexus_brass_ingot': '1be77d1ce5eb62fbc7b951f87e8e0452da48eada55d5f09e38848322e52301c8',
    'nexus_bronze_ingot': '7936dbcfba187a1e527a456a4d846c0b35ec5db46a1cbeee5c32b0d4fa604eba',
    'nexus_copper_plate': 'b2cc811e0d1be022dcbbd49615a1e255c46d56205e7e7186d029f7ca96798ff4',
    'nexus_tin_plate': '8acef56dc5ef85ec0c78d4e0d0ba167439c0837e384472aeb095b6675cbceb2a',
}

def load(name):
    return json.loads((RECIPES / (name + '.json')).read_text(encoding='utf-8'))

class NexusMetalRecipes(unittest.TestCase):
    def test_old_recipes_preserved_and_alternatives_correct(self):
        for name, digest in ORIGINAL_HASHES.items():
            with self.subTest(name=name):
                self.assertEqual(hashlib.sha256((RECIPES / (name + '.json')).read_bytes()).hexdigest(), digest)
                old, new = load(name), load(name + '_nexus_metals')
                self.assertEqual(new['type'], 'forge:ore_shaped')
                self.assertEqual(new['result'], old['result'])
                self.assertEqual(new['key']['A'], {'type': 'forge:ore_dict', 'ore': 'ingotCopper'})
                self.assertEqual(new['key']['Z'], {'type': 'forge:ore_dict', 'ore': 'ingotTin'})
                self.assertEqual({k: v for k, v in new['key'].items() if k not in ('A', 'Z')},
                                 {k: v for k, v in old['key'].items() if k != 'I'})
                counter = 0
                for a, b in zip(old['pattern'], new['pattern']):
                    self.assertEqual(len(a), len(b))
                    for before, after in zip(a, b):
                        if before == 'I':
                            self.assertEqual(after, 'A' if counter % 2 == 0 else 'Z')
                            counter += 1
                        else:
                            self.assertEqual(before, after)
                self.assertEqual(len(old['pattern']), len(new['pattern']))
                self.assertGreaterEqual(counter, 2)

    def test_nexus_dependencies_are_acyclic(self):
        graph = {}
        for name in ORIGINAL_HASHES:
            rec = load(name + '_nexus_metals')
            graph[name] = {v['item'].split(':', 1)[1] for v in rec['key'].values()
                           if v.get('item', '').startswith('nexustech:')}
        self.assertEqual(graph['digital_mine_basic'], {'digital_mine_casing'})
        self.assertEqual(graph['nuclear_controller'], {'nuclear_core'})
        visiting, seen = set(), set()
        def visit(node):
            self.assertNotIn(node, visiting, 'cycle at ' + node)
            if node in seen:
                return
            self.assertIn(node, graph, 'unknown dependency ' + node)
            visiting.add(node)
            for dep in graph[node]:
                visit(dep)
            visiting.remove(node)
            seen.add(node)
        for node in graph:
            visit(node)

    def test_no_new_recipe_collides_with_nexus_only_shaped_recipes(self):
        # This uses Nexus items only for known ore names. Other mods may register
        # the same item under several ore names, so this cannot rule out all overlaps.
        ore_items = {'ingotIron': 'minecraft:iron_ingot'}
        for name in ('Copper', 'Tin', 'Zinc', 'Lead', 'Titanium', 'Silver', 'Aluminum', 'Steel'):
            ore_items['ingot' + name] = 'nexustech:' + name.lower() + '_ingot'
        ore_items.update({'plateCopper': 'nexustech:nexus_copper_plate',
                          'plateTin': 'nexustech:nexus_tin_plate',
                          'ingotBronze': 'nexustech:nexus_bronze_ingot',
                          'ingotBrass': 'nexustech:nexus_brass_ingot'})
        def grids(recipe):
            if 'pattern' not in recipe:
                return set()
            pattern = recipe['pattern']
            def value(char):
                if char == ' ':
                    return None
                spec = recipe['key'][char]
                return spec.get('item') or ore_items.get(spec.get('ore'), 'ore:' + str(spec.get('ore')))
            values = [[value(c) for c in row] for row in pattern]
            # Forge shaped recipes may match horizontally mirrored patterns.
            return {tuple(tuple(row) for row in values), tuple(tuple(reversed(row)) for row in values)}
        all_recipes = {p.stem: json.loads(p.read_text(encoding='utf-8')) for p in RECIPES.glob('*.json')}
        for name in ORIGINAL_HASHES:
            alt = name + '_nexus_metals'
            for other, recipe in all_recipes.items():
                if other == alt or recipe['result']['item'] == 'nexustech:' + name:
                    continue
                self.assertFalse(grids(all_recipes[alt]) & grids(recipe), (alt, other))

    def test_png_sources_are_lossless_and_unambiguous(self):
        for name, digest in TEXTURE_HASHES.items():
            with self.subTest(name=name):
                source = TEXTURES / 'assets/nexustech/textures/items' / (name + '.png.b64')
                data = base64.b64decode(source.read_text(encoding='ascii').strip(), validate=True)
                self.assertEqual(hashlib.sha256(data).hexdigest(), digest)
                self.assertEqual(data, (TEXTURES / 'original_png/items' / (name + '.png')).read_bytes())
                self.assertFalse((ROOT / 'src/main/resources/assets/nexustech/textures/items' / (name + '.png')).exists())

if __name__ == '__main__':
    unittest.main(verbosity=2)
