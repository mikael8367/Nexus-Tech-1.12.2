"""Check the assembled JAR, not just source resources. Run after Gradle jar.
Pass a JAR path as the first argument; defaults to build/libs/nexustech-1.0.jar.
"""
import base64
import io
import json
import sys
import zipfile
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[6]
jar_path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'build/libs/nexustech-1.0.jar'
sources = ROOT / 'src/main/texture_sources'
resources = ROOT / 'src/main/resources'
errors = []
with zipfile.ZipFile(jar_path) as jar:
    entries = jar.namelist()
    names = set(entries)
    if len(entries) != len(names):
        errors.append('Duplicate ZIP entries')
    encoded = list(sources.rglob('*.png.b64'))
    if not encoded:
        errors.append('No texture sources')
    for source in encoded:
        name = source.relative_to(sources).as_posix()[:-4]
        try:
            data = base64.b64decode(source.read_bytes().strip(), validate=True)
            image = Image.open(io.BytesIO(data))
            image.load()
            if image.format != 'PNG':
                raise ValueError('Not PNG')
            if name not in names:
                errors.append('Missing texture ' + name)
            elif jar.read(name) != data:
                errors.append('Texture differs from source ' + name)
        except Exception as exc:
            errors.append(f'{name}: {exc}')
    resource_json = list((resources / 'assets/nexustech').rglob('*.json'))
    for file in resource_json:
        name = file.relative_to(resources).as_posix()
        try:
            json.loads(file.read_text(encoding='utf-8'))
            if name not in names:
                errors.append('Missing JSON ' + name)
            elif jar.read(name) != file.read_bytes():
                errors.append('JSON differs from source ' + name)
        except Exception as exc:
            errors.append(f'{name}: {exc}')
    print(f'Checked {len(encoded)} encoded textures and {len(resource_json)} JSON resources in {jar_path}')
if errors:
    print('\n'.join(errors))
    raise SystemExit(1)
print('PASS: encoded PNGs decode, load, and match the JAR; all JSON resources match')
