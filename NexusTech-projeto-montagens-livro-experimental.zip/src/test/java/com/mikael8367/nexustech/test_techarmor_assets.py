import base64
import io
import json
import re
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[6]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures'
NAMES = ('helmet', 'chestplate', 'leggings', 'boots')

class TechArmorAssets(unittest.TestCase):
    def test_recipes_and_models(self):
        registry = (ROOT / 'src/main/java/com/mikael8367/nexustech/techitems/TechItemsRegistry.java').read_text()
        available = set(re.findall(r'"(techitem_[a-z_]+)"', registry))
        for part in NAMES:
            item = 'techarmor_' + part
            recipe = json.loads((ASSETS / 'recipes' / (item + '.json')).read_text())
            self.assertEqual(recipe['result']['item'], 'nexustech:' + item)
            self.assertEqual(recipe['type'], 'minecraft:crafting_shaped')
            pattern, keys = recipe['pattern'], recipe['key']
            self.assertEqual(len(pattern), 3)
            self.assertTrue(all(len(row) == 3 for row in pattern))
            self.assertEqual(set(''.join(pattern)) - {' '}, set(keys))
            for ingredient in keys.values():
                self.assertIn(ingredient['item'].split(':', 1)[1], available)
            model = json.loads((ASSETS / 'models/item' / (item + '.json')).read_text())
            self.assertEqual(model['textures']['layer0'], 'nexustech:items/' + item)
            for subdir, size in [('items', (16, 16)), ('models/armor', (64, 32))]:
                data = base64.b64decode((TEXTURES / subdir / (item + '.png.b64')).read_bytes(), validate=False)
                im = Image.open(io.BytesIO(data))
                self.assertEqual(im.size, size)
                self.assertEqual(im.format, 'PNG')
    def test_localizations(self):
        for lang in ('en_us', 'pt_br'):
            text = (ROOT / 'docs/techarmor-localization' / (lang + '.lang')).read_text()
            for part in NAMES:
                self.assertIn('item.techarmor_' + part + '.name=', text)

if __name__ == '__main__':
    unittest.main()
