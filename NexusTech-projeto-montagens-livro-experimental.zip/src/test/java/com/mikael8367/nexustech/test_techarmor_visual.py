"""Atlas and simplified front-projection regression checks; not a Minecraft renderer."""
import base64
import io
import itertools
import re
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[6]
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures/models/armor'
JAVA = ROOT / 'src/main/java/com/mikael8367/nexustech/techarmor/TechArmorClient.java'
PARTS = ('helmet', 'chestplate', 'leggings', 'boots')

def atlas(part):
    png = base64.b64decode((TEXTURES / ('techarmor_' + part + '.png.b64')).read_bytes(), validate=False)
    return Image.open(io.BytesIO(png)).convert('RGBA')

def project(parts):
    """Flatten vanilla front UVs onto a 16x32 canvas; omit inflated faces and GL."""
    image = Image.new('RGBA', (16, 32))
    def paste(tile, xy):
        image.alpha_composite(tile, xy)
    if 'helmet' in parts:
        a = atlas('helmet')
        paste(a.crop((8, 8, 16, 16)), (4, 0))
        paste(a.crop((33, 1, 39, 3)), (5, 2))
    if 'chestplate' in parts:
        a = atlas('chestplate')
        paste(a.crop((20, 20, 28, 32)), (4, 8))
        paste(a.crop((44, 20, 48, 32)), (0, 8))
        paste(a.crop((44, 20, 48, 32)).transpose(Image.Transpose.FLIP_LEFT_RIGHT), (12, 8))
        paste(a.crop((33, 1, 37, 4)), (6, 11))
    if 'leggings' in parts:
        a = atlas('leggings')
        paste(a.crop((20, 20, 28, 32)), (4, 8))
        paste(a.crop((4, 20, 8, 32)), (4, 20))
        paste(a.crop((4, 20, 8, 32)).transpose(Image.Transpose.FLIP_LEFT_RIGHT), (8, 20))
    if 'boots' in parts:
        a = atlas('boots')
        paste(a.crop((4, 20, 8, 32)), (4, 20))
        paste(a.crop((4, 20, 8, 32)).transpose(Image.Transpose.FLIP_LEFT_RIGHT), (8, 20))
    return image

class TechArmorVisual(unittest.TestCase):
    def test_atlas_and_silhouette(self):
        for part in PARTS:
            a = atlas(part)
            self.assertEqual(a.size, (64, 32))
            self.assertEqual(a.getpixel((33, 1))[3], 255)
            self.assertGreater(len(a.getcolors(maxcolors=2048)), 5)
        # The lower-body layer only adds a belt; boots leave upper legs uncovered.
        legs = atlas('leggings')
        boots = atlas('boots')
        for x in range(16, 40):
            for y in range(20, 28):
                self.assertEqual(legs.getpixel((x, y))[3], 0)
        for x in range(0, 16):
            for y in range(20, 27):
                self.assertEqual(boots.getpixel((x, y))[3], 0)

    def test_all_16_equipment_combinations(self):
        for mask in itertools.product((False, True), repeat=4):
            equipped = {p for p, on in zip(PARTS, mask) if on}
            im = project(equipped)
            self.assertEqual(im.getpixel((6, 3))[3] != 0, 'helmet' in equipped)
            self.assertEqual(im.getpixel((1, 12))[3] != 0, 'chestplate' in equipped)
            self.assertEqual(im.getpixel((5, 22))[3] != 0, 'leggings' in equipped)
            self.assertEqual(im.getpixel((5, 30))[3] != 0, bool({'boots', 'leggings'} & equipped))
            if 'leggings' in equipped and 'chestplate' not in equipped:
                self.assertEqual(im.getpixel((6, 10))[3], 0)
            if 'boots' in equipped and 'leggings' not in equipped:
                self.assertEqual(im.getpixel((5, 22))[3], 0)

    def test_child_geometry_and_slot_selection(self):
        source = JAVA.read_text()
        self.assertIn('slot == EntityEquipmentSlot.LEGS ? inner : outer', source)
        self.assertIn('bipedHeadwear.showModel = false', source)
        boxes = re.findall(r'box\((biped\w+),\s*(\d+),\s*(\d+),\s*([-\d.]+)F?,\s*([-\d.]+)F?,\s*([-\d.]+)F?,\s*(\d+),\s*(\d+),\s*(\d+)\);', source)
        self.assertEqual(len(boxes), 8)
        for parent,u,v,x,y,z,w,h,d in boxes:
            self.assertEqual((int(u), int(v)), (32, 0))
            self.assertEqual(int(d), 1)
            self.assertLessEqual(int(w), 6)
            self.assertLessEqual(int(h), 3)
            # All UVs used by a child fit within its reserved 16x8 detail area.
            self.assertLessEqual(2 * int(d) + 2 * int(w), 16)
            self.assertLessEqual(int(d) + int(h), 8)
        self.assertEqual({b[0] for b in boxes}, {'bipedHead', 'bipedBody', 'bipedRightArm', 'bipedLeftArm', 'bipedRightLeg', 'bipedLeftLeg'})
        self.assertNotIn('rotateAngle', source)  # child parts inherit vanilla limb animation

if __name__ == '__main__':
    unittest.main()
