#!/usr/bin/env python3
"""Check independently generated machine assets, recipes, textures and translations."""
import base64
import io
import json
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[6]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures/blocks'
NAMES = ('sawmill', 'composter', 'water_bottler')

def load(path):
    return json.loads(path.read_text(encoding='utf8'))

def test_assets():
    recipes = []
    for name in NAMES:
        ident = 'techmachines_' + name
        state = load(ASSETS / 'blockstates' / (ident + '.json'))
        assert state['variants']['normal']['model'] == 'nexustech:' + ident
        model = load(ASSETS / 'models/block' / (ident + '.json'))
        assert model['textures']['all'] == 'nexustech:blocks/' + ident
        assert load(ASSETS / 'models/item' / (ident + '.json'))['parent'] == 'nexustech:block/' + ident
        recipe = load(ASSETS / 'recipes' / (ident + '.json'))
        assert recipe['type'] == 'minecraft:crafting_shaped'
        assert recipe['result']['item'] == 'nexustech:' + ident
        assert set(''.join(recipe['pattern'])) == set(recipe['key'])
        assert all(x['item'].startswith('minecraft:') for x in recipe['key'].values())
        recipes.append(recipe['key'])
        data = base64.b64decode((TEXTURES / (ident + '.png.b64')).read_text().strip(), validate=True)
        with Image.open(io.BytesIO(data)) as image:
            assert image.format == 'PNG' and image.size == (16, 16)
            image.verify()
        for lang in ('en_us', 'pt_br'):
            text = (ASSETS / 'lang' / (lang + '.lang')).read_text(encoding='utf8')
            assert text.count('tile.nexustech.' + ident + '.name=') == 1
            assert text.count('message.nexustech.techmachines.energy=') == 1
            for suffix in ('0', '1', '2', 'controls', 'controls2'):
                assert text.count('tooltip.nexustech.techmachines.' + suffix + '=') == 1
    assert len({json.dumps(r, sort_keys=True) for r in recipes}) == 3

if __name__ == '__main__':
    test_assets()
    print('PASS techmachines assets, recipes, textures and translations')
