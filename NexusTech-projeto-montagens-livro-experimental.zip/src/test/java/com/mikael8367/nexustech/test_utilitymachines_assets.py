"""Standalone utility machine resources and project packaging contract checks."""
import base64
import io
import json
import pathlib
import unittest

from PIL import Image

ROOT = pathlib.Path(__file__).resolve().parents[6]
ASSETS = ROOT / 'src/main/resources/assets/nexustech'
TEXTURES = ROOT / 'src/main/texture_sources/assets/nexustech/textures/blocks'


class UtilityAssetsTest(unittest.TestCase):
    def test_resource_chain(self):
        for machine, center, side in [('utility_recycler', 'minecraft:hopper', 'minecraft:iron_bars'),
                                      ('utility_purifier', 'minecraft:cauldron', 'minecraft:glass')]:
            with self.subTest(machine=machine):
                def load(group):
                    return json.loads((ASSETS / group / (machine + '.json')).read_text())
                state = load('blockstates')
                self.assertEqual(state['variants']['normal']['model'], 'nexustech:' + machine)
                block = load('models/block')
                self.assertEqual(block['parent'], 'minecraft:block/cube_all')
                self.assertEqual(block['textures']['all'], 'nexustech:blocks/' + machine)
                self.assertEqual(load('models/item')['parent'], 'nexustech:block/' + machine)
                recipe = load('recipes')
                self.assertEqual(recipe['type'], 'minecraft:crafting_shaped')
                self.assertEqual(recipe['result']['item'], 'nexustech:' + machine)
                self.assertEqual(recipe['pattern'], ['IRI', 'MCM', 'IRI'])
                self.assertEqual(recipe['key']['C']['item'], center)
                self.assertEqual(recipe['key']['M']['item'], side)
                self.assertEqual(recipe['key']['I']['item'], 'minecraft:iron_ingot')
                self.assertEqual(recipe['key']['R']['item'], 'minecraft:redstone')
                data = base64.b64decode((TEXTURES / (machine + '.png.b64')).read_text().strip(), validate=True)
                with Image.open(io.BytesIO(data)) as image:
                    self.assertEqual(image.format, 'PNG')
                    image.verify()

    def test_gradle_resources_wiring(self):
        gradle = (ROOT / 'build.gradle').read_text()
        self.assertIn("file('src/main/texture_sources')", gradle)
        self.assertIn("include '**/*.png.b64'", gradle)
        self.assertIn('dependsOn generateTextureResources', gradle)
        self.assertIn('from generatedTextures', gradle)
        self.assertIn('relativePath.length() - 4', gradle)
        self.assertIn('processResources {', gradle)


if __name__ == '__main__':
    unittest.main()
