package com.mikael8367.nexustech.testfixture;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.objectweb.asm.*;

/** Test-only fake-player replacement, used exclusively by MysticalRegression. */
public final class Transform {
    public static void main(String[] args) throws Exception {
        ClassReader reader = new ClassReader(Files.readAllBytes(Paths.get(args[0])));
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        final int[] replaced = new int[2];
        reader.accept(new ClassVisitor(Opcodes.ASM5, writer) {
            @Override public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] exceptions) {
                MethodVisitor mv = super.visitMethod(access, name, desc, sig, exceptions);
                if (name.equals("safeFakeConstruction") && desc.equals("(Lnet/minecraft/world/WorldServer;)Z")) {
                    replaced[0]++;
                    mv.visitCode(); mv.visitInsn(Opcodes.ICONST_1); mv.visitInsn(Opcodes.IRETURN);
                    mv.visitMaxs(0, 0); mv.visitEnd(); return null;
                }
                if (name.equals("machinePlayer") && desc.equals("(Lnet/minecraft/world/WorldServer;Lcom/mojang/authlib/GameProfile;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraftforge/common/util/FakePlayer;")) {
                    replaced[1]++;
                    mv.visitCode(); mv.visitVarInsn(Opcodes.ALOAD, 0);
                    mv.visitMethodInsn(Opcodes.INVOKESTATIC, "com/mikael8367/nexustech/plantharvester/MysticalAudit", "fake", "(Lnet/minecraft/world/WorldServer;)Lnet/minecraftforge/common/util/FakePlayer;", false);
                    mv.visitInsn(Opcodes.ARETURN); mv.visitMaxs(0, 0); mv.visitEnd(); return null;
                }
                return mv;
            }
        }, 0);
        if (replaced[0] != 1 || replaced[1] != 1)
            throw new IllegalStateException("Fake-player fixture targets changed: " + replaced[0] + ", " + replaced[1]);
        Path output = Paths.get(args[1]);
        Files.createDirectories(output.getParent());
        Files.write(output, writer.toByteArray());
    }
}
