package net.optifine.override;

import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;

/** Test double for G5's wrapper shape and non-creating tile lookup, not OptiFine itself. */
public final class ChunkCacheOF implements IBlockAccess {
    private final ChunkCache delegate;
    public ChunkCacheOF(ChunkCache delegate) { this.delegate = delegate; }
    public TileEntity getTileEntity(BlockPos pos) { return delegate.getTileEntity(pos, Chunk.EnumCreateEntityType.CHECK); }
    public IBlockState getBlockState(BlockPos pos) { return delegate.getBlockState(pos); }
    public int getCombinedLight(BlockPos pos, int light) { return delegate.getCombinedLight(pos, light); }
    public boolean isAirBlock(BlockPos pos) { return delegate.isAirBlock(pos); }
    public Biome getBiome(BlockPos pos) { return delegate.getBiome(pos); }
    public int getStrongPower(BlockPos pos, EnumFacing side) { return delegate.getStrongPower(pos, side); }
    public WorldType getWorldType() { return delegate.getWorldType(); }
    public boolean isSideSolid(BlockPos pos, EnumFacing side, boolean fallback) { return delegate.isSideSolid(pos, side, fallback); }
}
