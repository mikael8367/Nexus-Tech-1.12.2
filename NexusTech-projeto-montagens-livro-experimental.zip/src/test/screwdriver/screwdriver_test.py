"""Isolated screwdriver behavior test. Compiles actual item with temporary fakes; no Gradle."""
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import json
import os

root = Path(__file__).resolve().parents[3]
jdk = Path(os.environ.get('JAVA_HOME', '/home/daytona/workspace/nexus-test/jdk')) / 'bin'
source = root / 'src/main/java/com/mikael8367/nexustech/screwdriver/ScrewdriverItem.java'
resources = root / 'src/main/resources/assets/nexustech'
assert json.loads((resources/'recipes/screwdriver.json').read_text())['result']['item'] == 'nexustech:screwdriver'
assert json.loads((resources/'models/item/screwdriver.json').read_text())['textures']['layer0'] == 'nexustech:items/screwdriver'
from PIL import Image
with Image.open(resources/'textures/items/screwdriver.png') as image:
    assert image.size == (16,16) and image.mode == 'RGBA'
    assert image.getbbox() is not None

stubs = {
'net/minecraft/util/EnumActionResult.java': 'package net.minecraft.util; public enum EnumActionResult {SUCCESS,PASS,FAIL}',
'net/minecraft/util/EnumHand.java': 'package net.minecraft.util; public enum EnumHand {MAIN_HAND,OFF_HAND}',
'net/minecraft/util/EnumFacing.java': 'package net.minecraft.util; public enum EnumFacing {DOWN,UP,NORTH,SOUTH,WEST,EAST; public EnumFacing getOpposite(){return values()[ordinal()^1];}}',
'net/minecraft/util/math/BlockPos.java': 'package net.minecraft.util.math; import net.minecraft.util.EnumFacing; public class BlockPos { public final int n; public BlockPos(int n){this.n=n;} public BlockPos offset(EnumFacing f){return new BlockPos(n+1);}}',
'net/minecraft/block/Block.java': 'package net.minecraft.block; public class Block {}',
'net/minecraft/block/state/IBlockState.java': 'package net.minecraft.block.state; import net.minecraft.block.Block; public class IBlockState {public Block b; public Block getBlock(){return b;}}',
'net/minecraft/item/Item.java': 'package net.minecraft.item; import net.minecraft.entity.player.EntityPlayer; import net.minecraft.world.World; import net.minecraft.util.math.BlockPos; import net.minecraft.util.*; public class Item {public Item setMaxStackSize(int x){return this;} public EnumActionResult onItemUseFirst(EntityPlayer p, World w, BlockPos b, EnumFacing s, float x,float y,float z, EnumHand h){return EnumActionResult.PASS;}}',
'net/minecraft/item/ItemStack.java': 'package net.minecraft.item; public class ItemStack {public Item item; public boolean empty; public boolean isEmpty(){return empty;} public Item getItem(){return item;}}',
'net/minecraft/world/World.java': 'package net.minecraft.world; import net.minecraft.util.math.BlockPos; import net.minecraft.entity.player.EntityPlayer; import net.minecraft.block.state.IBlockState; public class World {public boolean isRemote,loaded=true,modifiable=true,bordered=true,neighborLoaded=true,neighborModifiable=true,neighborBordered=true; public IBlockState state=new IBlockState(); public boolean isBlockLoaded(BlockPos p){return loaded && (p.n==0 || neighborLoaded);} public Border getWorldBorder(){return new Border();} public class Border {public boolean contains(BlockPos p){return bordered && (p.n==0 || neighborBordered);}} public boolean isBlockModifiable(EntityPlayer p,BlockPos pos){return modifiable && (pos.n==0 || neighborModifiable);} public IBlockState getBlockState(BlockPos p){return state;}}',
'net/minecraft/entity/player/EntityPlayer.java': 'package net.minecraft.entity.player; import net.minecraft.world.World; import net.minecraft.item.ItemStack; import net.minecraft.util.*; import net.minecraft.util.math.BlockPos; public class EntityPlayer {public World world; public ItemStack held=new ItemStack(); public boolean spectator,editable=true; public ItemStack getHeldItem(EnumHand h){return held;} public boolean isSpectator(){return spectator;} public boolean canPlayerEdit(BlockPos p, EnumFacing f,ItemStack s){return editable;}}',
'com/mikael8367/nexustech/itemcable/ItemCableBlock.java': 'package com.mikael8367.nexustech.itemcable; public class ItemCableBlock extends net.minecraft.block.Block {}',
'com/mikael8367/nexustech/itemcable/ItemCableNetwork.java': 'package com.mikael8367.nexustech.itemcable; import net.minecraft.world.World; import net.minecraft.util.math.BlockPos; import net.minecraft.util.EnumFacing; import net.minecraft.entity.player.EntityPlayer; public class ItemCableNetwork {public static int calls; public static boolean result=true; public static EnumFacing side; public static boolean toggleConnection(World w, BlockPos p, EnumFacing s, EntityPlayer e, net.minecraft.util.EnumHand h){calls++;side=s;return result;}}',
'TestScrewdriver.java': '''import com.mikael8367.nexustech.screwdriver.ScrewdriverItem;
import com.mikael8367.nexustech.itemcable.*;
import net.minecraft.block.Block; import net.minecraft.world.World; import net.minecraft.entity.player.EntityPlayer; import net.minecraft.util.*; import net.minecraft.util.math.BlockPos;
public class TestScrewdriver {
 static void ok(boolean x){if(!x)throw new AssertionError();}
 static EnumActionResult use(ScrewdriverItem item,EntityPlayer p,World w,EnumFacing s){return item.onItemUseFirst(p,w,new BlockPos(0),s,0,0,0,EnumHand.MAIN_HAND);}
 public static void main(String[] args){
  ScrewdriverItem tool=new ScrewdriverItem(); World w=new World(); EntityPlayer p=new EntityPlayer();p.world=w;p.held.item=tool;w.state.b=new ItemCableBlock();
  for(EnumFacing s:EnumFacing.values()){int before=ItemCableNetwork.calls;ok(use(tool,p,w,s)==EnumActionResult.SUCCESS);ok(ItemCableNetwork.calls==before+1 && ItemCableNetwork.side==s);}
  int calls=ItemCableNetwork.calls; w.isRemote=true;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.SUCCESS);ok(calls==ItemCableNetwork.calls);w.isRemote=false;
  ItemCableNetwork.result=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);ItemCableNetwork.result=true;calls=ItemCableNetwork.calls;
  w.state.b=new Block();ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);w.state.b=new ItemCableBlock();
  w.loaded=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);w.loaded=true;
  w.modifiable=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);w.modifiable=true;
  w.bordered=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);w.bordered=true;
  w.neighborLoaded=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);w.neighborLoaded=true;
  w.neighborModifiable=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);w.neighborModifiable=true;
  w.neighborBordered=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);w.neighborBordered=true;
  p.editable=false;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);p.editable=true;
  p.spectator=true;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);p.spectator=false;
  p.held.empty=true;ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);p.held.empty=false;
  p.world=new World();ok(use(tool,p,w,EnumFacing.UP)==EnumActionResult.PASS);ok(ItemCableNetwork.calls==calls);
  System.out.println("PASS: all faces, client/server, denial, FE/non-cable, world guards and API result");
 }
}'''
}
with TemporaryDirectory(prefix='screwdriver-test-') as tmp:
    tmp=Path(tmp); files=[]
    for name,text in stubs.items():
        path=tmp/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(text);files.append(str(path))
    subprocess.run([str(jdk/'javac'),'-source','8','-target','8','-d',str(tmp),str(source),*files],check=True)
    subprocess.run([str(jdk/'java'),'-cp',str(tmp),'TestScrewdriver'],check=True)
print('PASS: resource JSONs and PNG')
